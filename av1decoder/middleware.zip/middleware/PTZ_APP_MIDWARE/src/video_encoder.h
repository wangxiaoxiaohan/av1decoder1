﻿#ifndef VIDEO_ENCODER_H
#define VIDEO_ENCODER_H

#include <QString>

class QVideoFrame;

extern "C" {
struct AVFormatContext;
struct AVCodecContext;
struct AVStream;
struct AVFrame;
struct SwsContext;
}

struct VideoEncodingConfig {
    QString filePath;
    QString codec;
    QString format;
    int fps = 25;
    int bitrateKbps = 2000;
};

class VideoEncoder
{
public:
    VideoEncoder();
    ~VideoEncoder();

    bool start(const VideoEncodingConfig& config);
    void stop();
    void encodeFrameIfNeeded(const QVideoFrame& frame);
    bool isEncoding() const { return m_active; }
    QString lastError() const { return m_lastError; }

private:
    bool ensureInitialized(const QVideoFrame& firstFrame);
    void cleanup();

    VideoEncodingConfig m_config;
    bool m_requested;
    bool m_active;
    QString m_lastError;

    SwsContext* m_swsCtx;
    AVFormatContext* m_fmtCtx;
    AVCodecContext* m_codecCtx;
    AVStream* m_stream;
    AVFrame* m_frame;
    long long m_frameIndex;
};

#endif // VIDEO_ENCODER_H
