#ifndef STITCHED_STREAMER_H
#define STITCHED_STREAMER_H

#include <QString>

#include "frame_provider.h"
#include "video_encoder.h"

extern "C" {
struct SwsContext;
struct AVFrame;
}

class StitchedStreamer
{
public:
    StitchedStreamer();
    ~StitchedStreamer();

    bool start(FrameProvider* visibleProvider,
               FrameProvider* infraredProvider,
               const QString& outputUrl,
               const QString& codec,
               int fps,
               int bitrateKbps,
               const QString& format);

    void stop();
    void setProviders(FrameProvider* visibleProvider,
                      FrameProvider* infraredProvider);
    bool isActive() const { return m_requested; }
    QString lastError() const { return m_lastError; }
    
    // 获取输出分辨率（用于 ONVIF 报告）
    int outputWidth() const { return m_outWidth; }
    int outputHeight() const { return m_outHeight; }

    void tick();

private:
    void resetPipeline();
    bool ensurePipelineForFrames(const QVideoFrame& visibleFrame, const QVideoFrame& infraredFrame);
    bool composeToOutput(const QVideoFrame& visibleFrame, const QVideoFrame& infraredFrame);

    FrameProvider* m_visibleProvider;
    FrameProvider* m_infraredProvider;

    bool m_requested;
    QString m_lastError;

    VideoEncodingConfig m_encoderConfig;
    VideoEncoder m_encoder;
    long long m_lastEncodeMs;

    int m_outWidth;
    int m_outHeight;
    int m_visibleOutWidth;
    int m_infraredOutWidth;
    QVideoFrame::PixelFormat m_visibleInFmt;
    QVideoFrame::PixelFormat m_infraredInFmt;
    int m_visibleInWidth;
    int m_visibleInHeight;
    int m_infraredInWidth;
    int m_infraredInHeight;

    SwsContext* m_visibleSws;
    SwsContext* m_infraredSws;
    AVFrame* m_outFrame;
};

#endif // STITCHED_STREAMER_H
