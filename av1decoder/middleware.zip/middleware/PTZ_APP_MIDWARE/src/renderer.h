#ifndef HEATMAP_RENDERER_H
#define HEATMAP_RENDERER_H

#include <string>
#include <vector>

typedef struct
{
    unsigned char y;
    signed char u;
    signed char v;
} HeatmapColor;

bool load_heatmap_lut(const std::string &filename, std::vector<HeatmapColor> &lut);

bool render_heatmap(unsigned char *yuv_data, int width, int height, const std::vector<HeatmapColor> &lut);

#endif // HEATMAP_RENDERER_H