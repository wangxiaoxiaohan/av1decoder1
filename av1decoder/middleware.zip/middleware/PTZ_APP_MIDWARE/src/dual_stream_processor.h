#ifndef DUAL_STREAM_PROCESSOR_H
#define DUAL_STREAM_PROCESSOR_H

#include <QObject>
#include <QString>
#include <QTimer>
#include <memory>

class splayer;
class FrameProvider;
class StitchedStreamer;

class DualStreamProcessor : public QObject
{
    Q_OBJECT
public:
    explicit DualStreamProcessor(QObject *parent = nullptr);
    ~DualStreamProcessor();

    /**
     * @brief Starts the processing pipeline
     * @param visibleUrl RTSP URL for visible light camera
     * @param infraredUrl RTSP URL for infrared camera
     * @param outputUrl RTSP URL for the output stitched stream
     * @return true if started successfully
     */
    bool start(const QString& visibleUrl, const QString& infraredUrl, const QString& outputUrl);

    /**
     * @brief Stops the processing pipeline
     */
    void stop();
    
    /**
     * @brief Gets the output resolution of the stitched stream
     * @param width Output width
     * @param height Output height
     * @return true if resolution is available
     */
    bool getOutputResolution(int& width, int& height) const;

private slots:
    void onTick();

private:
    splayer* m_visiblePlayer;
    splayer* m_infraredPlayer;
    FrameProvider* m_visibleProvider;
    FrameProvider* m_infraredProvider;
    std::unique_ptr<StitchedStreamer> m_streamer;
    QTimer* m_timer;
    bool m_running;
};

#endif // DUAL_STREAM_PROCESSOR_H
