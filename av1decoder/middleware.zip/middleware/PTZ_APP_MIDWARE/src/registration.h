#pragma once
#define TDLAS_THRESHOLD 30.0f

#ifdef _WIN32
#ifdef REGISTRATION_EXPORTS
#define REG_API __declspec(dllexport)
#else
#define REG_API __declspec(dllimport)
#endif
#else
#define REG_API
#endif

#ifdef __cplusplus
extern "C"
{
#endif

    /**
     * @brief 融合可见光和红外图像
     *
     * @param visible_yuv 可见光图像数据 (YUV420SP NV12格式)
     * @param ir_yuv 红外图像数据 (YUV420SP NV12格式)
     * @param visible_width 可见光图像宽度 (2592)
     * @param visible_height 可见光图像高度 (1944)
     * @param ir_width 红外图像宽度 (640)
     * @param ir_height 红外图像高度 (480)
     * @param depth 深度参数
     * @param tdlas TDLAS数据
     * @param calibration_params 相机标定参数JSON字符串
     * @param output_yuv 输出融合图像数据 (YUV420SP NV12格式，需预分配内存)
     * @return int 0表示成功，非0表示失败
     */
    REG_API int fuse_images(const unsigned char *visible_yuv, const unsigned char *ir_yuv,
                            int visible_width, int visible_height,
                            int ir_width, int ir_height,
                            int depth, float tdlas, const char *calibration_params,
                            unsigned char *output_yuv);

    /**
     * @brief 读取标定参数文件，输出JSON字符串到out_json，out_json_size为缓冲区大小
     * @param file_path 标定参数文件路径
     * @param out_json 输出JSON字符串缓冲区
     * @param out_json_size 缓冲区大小
     * @return int 0表示成功，非0表示失败
     */
    REG_API int load_calibration_params(const char *file_path, char *out_json, int out_json_size);
    // REG_API int load_calibration_params(const char* file_path, char* out_json);

#ifdef __cplusplus
}
#endif