#ifndef MICROLEAKMANAGER_H
#define MICROLEAKMANAGER_H

#include <QObject>
#include <QMutex>
#include <QThread>
#include <QVideoFrame>
#include <QByteArray>
#include <QString>
#include <QImage>
#include <vector>
#include <random>

// Forward declarations for Gaussian Plume headers
// We include them in cpp to avoid dependency issues if headers are tricky, 
// but here we need types for member variables if we store them.
// For now, we use the headers.
#include "gaussian_plume.h"
#include "concentration_map.h"
#include "renderer.h"

#define MICROLEAD_TDLAS_THRESHOLD 30
using namespace GaussianPlumeModel;
class MicroLeakWorker;

class MicroLeakManager : public QObject
{
    Q_OBJECT

public:
    static MicroLeakManager* instance();

    // Initialize with config path
    // configPath: absolute path to config directory (e.g. .../config/microleak)
    bool initialize(const QString& configPath);
    
    // Async process a frame
    // yuvData: NV12 data (YUV420SP)
    void processAsync(const QByteArray& yuvData, int width, int height, float tdlas, int channelIndex, qint64 timestamp);

    bool isAvailable() const;

signals:
    // Emitted when processing is done
    // resultImage: The processed image (RGB)
    void processingFinished(const QImage& resultImage, bool success, int channelIndex, qint64 timestamp);
    void errorOccurred(const QString& msg);

private:
    explicit MicroLeakManager(QObject* parent = nullptr);
    ~MicroLeakManager();

    static MicroLeakManager* m_instance;
    QThread* m_workerThread;
    MicroLeakWorker* m_worker;
    bool m_initialized;
    mutable QMutex m_mutex;
};

class MicroLeakWorker : public QObject
{
    Q_OBJECT
public:
    explicit MicroLeakWorker(QObject* parent = nullptr);
    ~MicroLeakWorker();
    
    Q_INVOKABLE bool init(const QString& configPath);

public slots:
    void process(const QByteArray& yuvData, int width, int height, float tdlas, int channelIndex, qint64 timestamp);

signals:
    void processingCompleted(const QImage& resultImage, bool success, int channelIndex, qint64 timestamp);
    void errorOccurred(const QString& msg);

private:
    void* m_detectorHandle; 
    GaussianPlumeModel::ConcentrationMapParams m_params;
    std::vector<HeatmapColor> m_lut;
    bool m_initSuccess;
    int m_WindyDirection;
    std::mt19937 m_rng;
    int m_frameCount;
    bool m_rngInitialized;

    // Helper to convert YUV NV12 to RGB QImage
    QImage yuvToRgb(const unsigned char* yuv, int width, int height);
    void loadLut(const QString& path);
};

#endif // MICROLEAKMANAGER_H
