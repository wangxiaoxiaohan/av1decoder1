#include "zlm_rtsp_forward_server.h"

ZlmRtspForwardServer::~ZlmRtspForwardServer() {
    stop();
}

bool ZlmRtspForwardServer::start(const StartOptions& options) {
    std::lock_guard<std::mutex> lock(mutex_);
    if (running_) {
        return true;
    }

    std::string ini_path = options.ini_path;
    char* ini_path_alloc = nullptr;
    if (ini_path.empty()) {
        ini_path_alloc = mk_util_get_exe_dir("config.ini");
        if (ini_path_alloc) {
            ini_path = ini_path_alloc;
        }
    }

    mk_config config = {};
    config.thread_num = options.thread_num;
    config.log_level = options.log_level;
    config.log_mask = options.log_mask;
    config.log_file_path = options.log_file_path.empty() ? nullptr : options.log_file_path.c_str();
    config.log_file_days = options.log_file_days;
    config.ini_is_path = 1;
    config.ini = ini_path.empty() ? nullptr : ini_path.c_str();
    config.ssl_is_path = 1;
    config.ssl = options.ssl_path.empty() ? nullptr : options.ssl_path.c_str();
    config.ssl_pwd = options.ssl_pwd.empty() ? nullptr : options.ssl_pwd.c_str();

    if (!env_inited_) {
        mk_env_init(&config);
        env_inited_ = true;
    }

    if (ini_path_alloc) {
        mk_free(ini_path_alloc);
    }

    const uint16_t actual_port = mk_rtsp_server_start(options.rtsp_port, options.rtsp_ssl ? 1 : 0);
    if (actual_port == 0) {
        mk_stop_all_server();
        running_ = false;
        rtsp_port_ = 0;
        return false;
    }

    rtsp_port_ = actual_port;
    running_ = true;
    return true;
}

bool ZlmRtspForwardServer::start() {
    return start(StartOptions());
}

void ZlmRtspForwardServer::stop() {
    std::unordered_map<ProxyId, mk_proxy_player> proxies_copy;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!running_ && proxies_.empty()) {
            return;
        }
        proxies_copy = std::move(proxies_);
        proxies_.clear();
        running_ = false;
        rtsp_port_ = 0;
    }

    for (auto& kv : proxies_copy) {
        if (kv.second) {
            mk_proxy_player_release(kv.second);
        }
    }

    mk_stop_all_server();
}

bool ZlmRtspForwardServer::isRunning() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return running_;
}

uint16_t ZlmRtspForwardServer::rtspPort() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return rtsp_port_;
}

ZlmRtspForwardServer::ProxyId ZlmRtspForwardServer::addRtspProxy(const std::string& url, const ProxyOptions& options) {
    mk_proxy_player player = nullptr;
    ProxyId id = 0;

    {
        std::lock_guard<std::mutex> lock(mutex_);
        if (!running_) {
            return 0;
        }

        id = next_proxy_id_++;
        player = mk_proxy_player_create3(
            options.vhost.c_str(),
            options.app.c_str(),
            options.stream.c_str(),
            options.hls_enabled ? 1 : 0,
            options.mp4_enabled ? 1 : 0,
            options.retry_count
        );

        if (!player) {
            return 0;
        }

        proxies_.emplace(id, player);
    }

    auto* close_data = new ProxyCloseUserData{this, id};
    mk_proxy_player_set_on_close2(player, &ZlmRtspForwardServer::onProxyClose, close_data, &ZlmRtspForwardServer::freeProxyCloseUserData);

    auto* play_data = new ProxyPlayResultUserData{this, id};
    mk_proxy_player_set_on_play_result(player, &ZlmRtspForwardServer::onProxyPlayResult, play_data, &ZlmRtspForwardServer::freeProxyPlayResultUserData);

    mk_proxy_player_play(player, url.c_str());
    return id;
}

ZlmRtspForwardServer::ProxyId ZlmRtspForwardServer::addRtspProxy(const std::string& url) {
    return addRtspProxy(url, ProxyOptions());
}

void ZlmRtspForwardServer::removeProxy(ProxyId id) {
    mk_proxy_player player = nullptr;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = proxies_.find(id);
        if (it == proxies_.end()) {
            return;
        }
        player = it->second;
        proxies_.erase(it);
    }
    if (player) {
        mk_proxy_player_release(player);
    }
}

void API_CALL ZlmRtspForwardServer::onProxyClose(void* user_data, int, const char*, int) {
    auto* data = static_cast<ProxyCloseUserData*>(user_data);
    if (!data || !data->self) {
        return;
    }
    data->self->releaseProxyLocked(data->id);
}

void API_CALL ZlmRtspForwardServer::onProxyPlayResult(void* user_data, int, const char*, int) {
    auto* data = static_cast<ProxyPlayResultUserData*>(user_data);
    if (!data || !data->self) {
        return;
    }
}

void API_CALL ZlmRtspForwardServer::freeProxyCloseUserData(void* user_data) {
    delete static_cast<ProxyCloseUserData*>(user_data);
}

void API_CALL ZlmRtspForwardServer::freeProxyPlayResultUserData(void* user_data) {
    delete static_cast<ProxyPlayResultUserData*>(user_data);
}

void ZlmRtspForwardServer::releaseProxyLocked(ProxyId id) {
    mk_proxy_player player = nullptr;
    {
        std::lock_guard<std::mutex> lock(mutex_);
        auto it = proxies_.find(id);
        if (it == proxies_.end()) {
            return;
        }
        player = it->second;
        proxies_.erase(it);
    }
    if (player) {
        mk_proxy_player_release(player);
    }
}
