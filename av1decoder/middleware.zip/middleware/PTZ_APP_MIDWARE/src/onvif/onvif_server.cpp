#include "onvif_server.h"

#include <QTcpSocket>
#include <QNetworkInterface>
#include <QDateTime>
#include <QUuid>
#include <QXmlStreamWriter>
#include <QXmlStreamReader>
#include <QRegularExpression>
#include <QUrl>

OnvifServer::OnvifServer(QObject* parent)
    : QObject(parent)
    , discoveryMulticastAddr_("239.255.255.250")
{
}

OnvifServer::~OnvifServer() {
    stop();
}

bool OnvifServer::start(const OnvifServerConfig& config) {
    if (running_) {
        return true;
    }

    config_ = config;

    // 如果没有指定UUID，生成一个
    if (config_.uuid.isEmpty()) {
        config_.uuid = QUuid::createUuid().toString();
        config_.uuid = config_.uuid.mid(1, config_.uuid.length() - 2); // 去掉大括号
    }

    // 如果没有指定IP，获取本机IP
    if (config_.ipAddress.isEmpty()) {
        const auto interfaces = QNetworkInterface::allInterfaces();
        for (const auto& iface : interfaces) {
            if (iface.flags() & QNetworkInterface::IsUp &&
                iface.flags() & QNetworkInterface::IsRunning &&
                !(iface.flags() & QNetworkInterface::IsLoopBack)) {
                for (const auto& addr : iface.addressEntries()) {
                    if (addr.ip().protocol() == QAbstractSocket::IPv4Protocol) {
                        config_.ipAddress = addr.ip().toString();
                        break;
                    }
                }
            }
            if (!config_.ipAddress.isEmpty()) break;
        }
    }

    // 初始化WS-Discovery
    if (!initDiscoverySocket()) {
        stop();
        return false;
    }

    // 启动 HTTP 服务
    httpServer_ = new QTcpServer(this);
    connect(httpServer_, &QTcpServer::newConnection, this, &OnvifServer::onNewHttpConnection);

    // 尝试指定端口，如果被占用则使用随机端口
    if (!httpServer_->listen(QHostAddress::Any, config_.httpPort)) {
        qWarning() << "ONVIF HTTP server failed to listen on port" << config_.httpPort << ", trying random port";
        // 尝试使用 8080-8090 范围内的其他端口
        for (int port = 8080; port <= 8090; ++port) {
            if (port == config_.httpPort) continue;
            if (httpServer_->listen(QHostAddress::Any, port)) {
                config_.httpPort = port;
                qDebug() << "ONVIF HTTP server started on port" << port;
                break;
            }
        }
        
        // 如果还是失败，使用随机端口
        if (!httpServer_->isListening()) {
            if (!httpServer_->listen(QHostAddress::Any, 0)) {
                qWarning() << "ONVIF HTTP server failed to listen on any port";
                stop();
                return false;
            }
            config_.httpPort = httpServer_->serverPort();
        }
    }

    // 启动Hello定时器
    helloTimer_ = new QTimer(this);
    connect(helloTimer_, &QTimer::timeout, this, &OnvifServer::sendHelloMessage);
    helloTimer_->start(60000); // 每分钟发送一次Hello

    // 立即发送一次Hello
    sendHelloMessage();

    running_ = true;
    qDebug() << "ONVIF server started on" << config_.ipAddress << ":" << config_.httpPort;
    return true;
}

void OnvifServer::stop() {
    running_ = false;

    if (helloTimer_) {
        helloTimer_->stop();
        delete helloTimer_;
        helloTimer_ = nullptr;
    }

    if (httpServer_) {
        httpServer_->close();
        delete httpServer_;
        httpServer_ = nullptr;
    }

    for (auto it = httpBuffers_.begin(); it != httpBuffers_.end(); ++it) {
        it.key()->close();
    }
    httpBuffers_.clear();

    if (discoverySocket_) {
        discoverySocket_->leaveMulticastGroup(discoveryMulticastAddr_);
        discoverySocket_->close();
        delete discoverySocket_;
        discoverySocket_ = nullptr;
    }
}

bool OnvifServer::isRunning() const {
    return running_;
}

QString OnvifServer::getDeviceServiceUrl() const {
    return QString("http://%1:%2/onvif/device_service")
        .arg(config_.ipAddress).arg(config_.httpPort);
}

QString OnvifServer::getMediaServiceUrl() const {
    return QString("http://%1:%2/onvif/media_service")
        .arg(config_.ipAddress).arg(config_.httpPort);
}

void OnvifServer::setRtspPath(const QString& path) {
    config_.rtspPath = path;
}

void OnvifServer::setVideoResolution(int width, int height) {
    config_.videoWidth = width;
    config_.videoHeight = height;
}

bool OnvifServer::initDiscoverySocket() {
    discoverySocket_ = new QUdpSocket(this);

    // 绑定到3702端口
    if (!discoverySocket_->bind(QHostAddress::AnyIPv4, DISCOVERY_PORT,
                                QUdpSocket::ShareAddress | QUdpSocket::ReuseAddressHint)) {
        qWarning() << "Failed to bind discovery socket to port" << DISCOVERY_PORT;
        return false;
    }

    // 加入多播组
    bool joined = false;
    QList<QNetworkInterface> interfaces = QNetworkInterface::allInterfaces();
    for (const QNetworkInterface& iface : interfaces) {
        if (!(iface.flags() & QNetworkInterface::CanMulticast) || 
            !(iface.flags() & QNetworkInterface::IsUp) || 
            (iface.flags() & QNetworkInterface::IsLoopBack)) {
            continue;
        }

        // 尝试找到与配置IP匹配的接口
        bool ipMatch = false;
        QHostAddress configIp(config_.ipAddress);
        for (const QNetworkAddressEntry& entry : iface.addressEntries()) {
            if (entry.ip() == configIp) {
                ipMatch = true;
                break;
            }
        }

        if (ipMatch) {
            if (discoverySocket_->joinMulticastGroup(discoveryMulticastAddr_, iface)) {
                qDebug() << "Joined multicast group" << discoveryMulticastAddr_.toString() << "on interface" << iface.humanReadableName();
                discoverySocket_->setMulticastInterface(iface);
                joined = true;
            } else {
                qWarning() << "Failed to join multicast group on interface" << iface.humanReadableName();
            }
        }
    }

    if (!joined) {
        // 如果没有找到匹配的接口，尝试让OS自动选择（回退）
        qWarning() << "Could not find specific interface for IP" << config_.ipAddress << ", letting OS choose.";
        if (!discoverySocket_->joinMulticastGroup(discoveryMulticastAddr_)) {
            qWarning() << "Failed to join multicast group" << discoveryMulticastAddr_.toString();
            return false;
        }
    }

    connect(discoverySocket_, &QUdpSocket::readyRead, this, &OnvifServer::onDiscoveryDatagram);
    return true;
}

void OnvifServer::onDiscoveryDatagram() {
    while (discoverySocket_->hasPendingDatagrams()) {
        QByteArray datagram;
        datagram.resize(discoverySocket_->pendingDatagramSize());
        QHostAddress sender;
        quint16 senderPort;

        discoverySocket_->readDatagram(datagram.data(), datagram.size(), &sender, &senderPort);
        
        qDebug() << "Received UDP datagram from" << sender.toString() << ":" << senderPort << "Size:" << datagram.size();
        // qDebug() << "Content:" << datagram; 

        processProbeRequest(datagram, sender, senderPort);
    }
}

void OnvifServer::processProbeRequest(const QByteArray& request, const QHostAddress& sender, quint16 port) {
    QString reqStr = QString::fromUtf8(request);

    // 检查是否是Probe请求
    if (!reqStr.contains("Probe") || reqStr.contains("ProbeMatches")) {
        return;
    }
    
    qDebug() << "Processing Probe request from" << sender.toString();
    qDebug() << "Request content:" << reqStr.left(500);

    // 提取MessageId - 支持多种命名空间格式
    QRegularExpression msgIdRe("MessageID[^>]*>([^<]+)");
    QRegularExpressionMatch match = msgIdRe.match(reqStr);
    if (!match.hasMatch()) {
        qDebug() << "No MessageID found in request from" << sender.toString();
        return;
    }
    QString messageId = match.captured(1);
    qDebug() << "Extracted MessageID:" << messageId;

    // 检查Scopes（可选过滤）- 支持多种命名空间
    bool typeMatch = true;
    if (reqStr.contains("Types") || reqStr.contains("types")) {
        QRegularExpression typesRe("Types[^>]*>([^<]+)");
        QRegularExpressionMatch typesMatch = typesRe.match(reqStr);
        if (typesMatch.hasMatch()) {
            QString types = typesMatch.captured(1);
            qDebug() << "Request Types:" << types;
            // 如果指定了类型，检查是否匹配
            if (!types.contains("NetworkVideoTransmitter") &&
                !types.contains("Device") &&
                !types.contains("NetworkVideoTransmitter") &&
                types != "") {
                typeMatch = false;
            }
        }
    }

    if (typeMatch) {
        qDebug() << "Type matched! Sending ProbeMatch to" << sender.toString() << ":" << port;
        sendProbeMatch(messageId, sender, port);
    } else {
        qDebug() << "Type mismatch for Probe from" << sender.toString();
    }
}

void OnvifServer::sendProbeMatch(const QString& messageId, const QHostAddress& sender, quint16 port) {
    QString deviceServiceUrl = getDeviceServiceUrl();

    QString response = QString(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n"
        "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://www.w3.org/2003/05/soap-envelope\" "
        "xmlns:wsa=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\" "
        "xmlns:d=\"http://schemas.xmlsoap.org/ws/2005/04/discovery\" "
        "xmlns:dn=\"http://www.onvif.org/ver10/network/wsdl\">\r\n"
        "  <SOAP-ENV:Header>\r\n"
        "    <wsa:MessageID>uuid:%1</wsa:MessageID>\r\n"
        "    <wsa:RelatesTo>%2</wsa:RelatesTo>\r\n"
        "    <wsa:To>http://schemas.xmlsoap.org/ws/2004/08/addressing/role/anonymous</wsa:To>\r\n"
        "    <wsa:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/ProbeMatches</wsa:Action>\r\n"
        "  </SOAP-ENV:Header>\r\n"
        "  <SOAP-ENV:Body>\r\n"
        "    <d:ProbeMatches>\r\n"
        "      <d:ProbeMatch>\r\n"
        "        <wsa:EndpointReference>\r\n"
        "          <wsa:Address>uuid:%3</wsa:Address>\r\n"
        "        </wsa:EndpointReference>\r\n"
        "        <d:Types>dn:NetworkVideoTransmitter</d:Types>\r\n"
        "        <d:Scopes>onvif://www.onvif.org/type/video_encoder onvif://www.onvif.org/type/ptz onvif://www.onvif.org/hardware/%4 onvif://www.onvif.org/name/%5</d:Scopes>\r\n"
        "        <d:XAddrs>%6</d:XAddrs>\r\n"
        "        <d:MetadataVersion>1</d:MetadataVersion>\r\n"
        "      </d:ProbeMatch>\r\n"
        "    </d:ProbeMatches>\r\n"
        "  </SOAP-ENV:Body>\r\n"
        "</SOAP-ENV:Envelope>\r\n"
    ).arg(generateMessageId(), messageId, config_.uuid, config_.hardwareId,
          config_.deviceName, deviceServiceUrl);

    qDebug() << "Sending ProbeMatch to" << sender.toString() << ":" << port;
    qDebug() << "ProbeMatch content:" << response;
    
    qint64 sent = discoverySocket_->writeDatagram(response.toUtf8(), sender, port);
    if (sent < 0) {
        qWarning() << "Failed to send ProbeMatch:" << discoverySocket_->errorString();
    } else {
        qDebug() << "Sent" << sent << "bytes";
    }
}

void OnvifServer::sendResolveMatch(const QString& messageId, const QHostAddress& sender, quint16 port) {
    // ResolveMatch与ProbeMatch类似
    sendProbeMatch(messageId, sender, port);
}

void OnvifServer::sendHelloMessage() {
    if (!discoverySocket_) return;

    QString deviceServiceUrl = getDeviceServiceUrl();

    QString hello = QString(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://www.w3.org/2003/05/soap-envelope\"\n"
        "                   xmlns:wsa=\"http://schemas.xmlsoap.org/ws/2004/08/addressing\"\n"
        "                   xmlns:d=\"http://schemas.xmlsoap.org/ws/2005/04/discovery\"\n"
        "                   xmlns:dn=\"http://www.onvif.org/ver10/network/wsdl\">\n"
        "  <SOAP-ENV:Header>\n"
        "    <wsa:MessageID>uuid:%1</wsa:MessageID>\n"
        "    <wsa:To>urn:schemas-xmlsoap-org:ws:2005:04:discovery</wsa:To>\n"
        "    <wsa:Action>http://schemas.xmlsoap.org/ws/2005/04/discovery/Hello</wsa:Action>\n"
        "  </SOAP-ENV:Header>\n"
        "  <SOAP-ENV:Body>\n"
        "    <d:Hello>\n"
        "      <wsa:EndpointReference>\n"
        "        <wsa:Address>uuid:%2</wsa:Address>\n"
        "      </wsa:EndpointReference>\n"
        "      <d:Types>dn:NetworkVideoTransmitter</d:Types>\n"
        "      <d:Scopes>\n"
        "        onvif://www.onvif.org/type/video_encoder\n"
        "        onvif://www.onvif.org/type/ptz\n"
        "        onvif://www.onvif.org/hardware/%3\n"
        "        onvif://www.onvif.org/name/%4\n"
        "        onvif://www.onvif.org/location/anywhere\n"
        "      </d:Scopes>\n"
        "      <d:XAddrs>%5</d:XAddrs>\n"
        "      <d:MetadataVersion>1</d:MetadataVersion>\n"
        "    </d:Hello>\n"
        "  </SOAP-ENV:Body>\n"
        "</SOAP-ENV:Envelope>\n"
    ).arg(generateMessageId(), config_.uuid, config_.hardwareId,
          config_.deviceName, deviceServiceUrl);

    discoverySocket_->writeDatagram(hello.toUtf8(), discoveryMulticastAddr_, DISCOVERY_PORT);
}

void OnvifServer::onNewHttpConnection() {
    while (httpServer_->hasPendingConnections()) {
        QTcpSocket* socket = httpServer_->nextPendingConnection();
        httpBuffers_[socket] = QByteArray();
        connect(socket, &QTcpSocket::readyRead, this, &OnvifServer::onHttpReadyRead);
        connect(socket, &QTcpSocket::disconnected, [this, socket]() {
            httpBuffers_.remove(socket);
            socket->deleteLater();
        });
    }
}

void OnvifServer::onHttpReadyRead() {
    QTcpSocket* socket = qobject_cast<QTcpSocket*>(sender());
    if (!socket) return;

    httpBuffers_[socket].append(socket->readAll());

    // 检查是否收到完整的HTTP请求
    QByteArray& buffer = httpBuffers_[socket];
    int headerEnd = buffer.indexOf("\r\n\r\n");
    if (headerEnd < 0) return; // 头部不完整

    // 检查Content-Length
    QRegularExpression contentLengthRe("Content-Length:\\s*(\\d+)", QRegularExpression::CaseInsensitiveOption);
    QRegularExpressionMatch match = contentLengthRe.match(QString::fromUtf8(buffer));
    int bodyStart = headerEnd + 4;
    int expectedLength = 0;

    if (match.hasMatch()) {
        expectedLength = match.captured(1).toInt();
    }

    if (buffer.size() < bodyStart + expectedLength) {
        return; // 正文不完整
    }

    // 处理请求
    handleHttpRequest(socket, buffer);

    // 清空缓冲区
    httpBuffers_[socket].clear();
}

void OnvifServer::handleHttpRequest(QTcpSocket* socket, const QByteArray& request) {
    qDebug() << "Received HTTP request from" << socket->peerAddress().toString();
    
    QString reqStr = QString::fromUtf8(request);
    
    // 打印完整请求用于调试
    qDebug() << "Full request:" << reqStr.left(1000);

    // 解析 SOAP Action - 支持多种格式
    QRegularExpression actionRe("SOAPAction:\\s*\"([^\"]+)\"");
    QRegularExpressionMatch actionMatch = actionRe.match(reqStr);
    QString soapAction;
    if (actionMatch.hasMatch()) {
        soapAction = actionMatch.captured(1);
        qDebug() << "SOAP Action from header:" << soapAction;
    }

    // 提取 SOAP Body - 支持多种命名空间格式
    QByteArray soapBody;
    int bodyStart = -1, bodyEnd = -1;
    
    // 尝试不同的 Body 标签格式
    QStringList bodyStartTags = {"<SOAP-ENV:Body>", "<s:Body>", "<Body>", "<soap:Body>"};
    QStringList bodyEndTags = {"</SOAP-ENV:Body>", "</s:Body>", "</Body>", "</soap:Body>"};
    
    for (int i = 0; i < bodyStartTags.size(); ++i) {
        bodyStart = reqStr.indexOf(bodyStartTags[i]);
        if (bodyStart >= 0) {
            bodyEnd = reqStr.indexOf(bodyEndTags[i], bodyStart);
            if (bodyEnd > bodyStart) {
                int tagLen = bodyStartTags[i].length();
                soapBody = request.mid(bodyStart + tagLen, bodyEnd - bodyStart - tagLen);
                qDebug() << "Found SOAP Body using tag:" << bodyStartTags[i];
                break;
            }
        }
    }
    
    if (soapBody.isEmpty()) {
        qDebug() << "Warning: Could not extract SOAP Body";
    } else {
        qDebug() << "SOAP Body:" << soapBody.left(500);
    }

    // 根据 URL 路径和服务类型处理
    QByteArray responseBody;
    if (reqStr.contains("/device_service")) {
        qDebug() << "Routing to Device Service";
        responseBody = handleDeviceServiceRequest(soapAction, soapBody);
    } else if (reqStr.contains("/media_service")) {
        qDebug() << "Routing to Media Service";
        responseBody = handleMediaServiceRequest(soapAction, soapBody);
    } else {
        qDebug() << "Unknown service path:" << reqStr.left(200);
        responseBody = createFaultResponse("ter:ActionNotSupported", "Action not supported");
    }

    QByteArray soapResponse = createSoapEnvelope(responseBody);

    // 发送 HTTP 响应
    QString httpResponse = QString(
        "HTTP/1.1 200 OK\r\n"
        "Content-Type: application/soap+xml; charset=utf-8\r\n"
        "Content-Length: %1\r\n"
        "Connection: close\r\n"
        "\r\n"
    ).arg(soapResponse.size());

    qDebug() << "Sending HTTP response, size:" << soapResponse.size();
    socket->write(httpResponse.toUtf8());
    socket->write(soapResponse);
    socket->flush();
}

QByteArray OnvifServer::handleDeviceServiceRequest(const QString& action, const QByteArray& body) {
    QString bodyStr = QString::fromUtf8(body);

    qDebug() << "Device Service - Action:" << action;
    qDebug() << "Device Service - Body:" << bodyStr.left(500);

    // 如果 action 为空，尝试从 Body 中提取
    QString effectiveAction = action;
    if (effectiveAction.isEmpty() && !bodyStr.isEmpty()) {
        // 尝试提取 <tds:ActionName> 或 <ActionName>
        QRegularExpression actionRe("<(?:tds:|)(\\w+)>");
        QRegularExpressionMatch match = actionRe.match(bodyStr);
        if (match.hasMatch()) {
            effectiveAction = match.captured(1);
            qDebug() << "Extracted action from body:" << effectiveAction;
        }
    }

    if (effectiveAction.contains("GetCapabilities") || bodyStr.contains("GetCapabilities")) {
        qDebug() << "Handling GetCapabilities";
        return createGetCapabilitiesResponse();
    } else if (effectiveAction.contains("GetDeviceInformation") || bodyStr.contains("GetDeviceInformation")) {
        qDebug() << "Handling GetDeviceInformation";
        return createGetDeviceInformationResponse();
    } else if (effectiveAction.contains("GetNetworkInterfaces") || bodyStr.contains("GetNetworkInterfaces")) {
        qDebug() << "Handling GetNetworkInterfaces";
        return createGetNetworkInterfacesResponse();
    } else if (effectiveAction.contains("GetServices") || bodyStr.contains("GetServices")) {
        qDebug() << "Handling GetServices";
        return createGetServicesResponse();
    } else if (effectiveAction.contains("GetServiceCapabilities") || bodyStr.contains("GetServiceCapabilities")) {
        qDebug() << "Handling GetServiceCapabilities";
        return createGetCapabilitiesResponse();
    } else if (effectiveAction.contains("GetSystemDateAndTime") || bodyStr.contains("GetSystemDateAndTime")) {
        qDebug() << "Handling GetSystemDateAndTime";
        return createGetSystemDateAndTimeResponse();
    } else if (effectiveAction.contains("SetSystemDateAndTime") || bodyStr.contains("SetSystemDateAndTime")) {
        qDebug() << "Handling SetSystemDateAndTime - returning success";
        // 返回成功响应
        return QString("<tds:SetSystemDateAndTimeResponse/>").toUtf8();
    }

    qDebug() << "Unknown Device Service action:" << effectiveAction;
    // 返回一个默认的响应而不是错误，以便 NVR 能继续
    return createGetCapabilitiesResponse();
}

QByteArray OnvifServer::handleMediaServiceRequest(const QString& action, const QByteArray& body) {
    QString bodyStr = QString::fromUtf8(body);

    qDebug() << "Media Service - Action:" << action;
    qDebug() << "Media Service - Body:" << bodyStr.left(200);

    if (action.contains("GetProfiles") || bodyStr.contains("GetProfiles")) {
        qDebug() << "Handling GetProfiles";
        return createGetProfilesResponse();
    } else if (action.contains("GetStreamUri") || bodyStr.contains("GetStreamUri")) {
        qDebug() << "Handling GetStreamUri";
        return createGetStreamUriResponse();
    } else if (action.contains("GetVideoSources") || bodyStr.contains("GetVideoSources")) {
        qDebug() << "Handling GetVideoSources";
        return createGetVideoSourcesResponse();
    } else if (action.contains("GetVideoEncoderConfigurations") || bodyStr.contains("GetVideoEncoderConfigurations")) {
        qDebug() << "Handling GetVideoEncoderConfigurations";
        return createGetProfilesResponse(); // 简化处理
    }

    qDebug() << "Unknown Media Service action:" << action;
    return createFaultResponse("ter:ActionNotSupported", "Action not supported");
}

QByteArray OnvifServer::createSoapEnvelope(const QByteArray& body) const {
    return QByteArray(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
        "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://www.w3.org/2003/05/soap-envelope\"\n"
        "                   xmlns:tt=\"http://www.onvif.org/ver10/schema\"\n"
        "                   xmlns:trt=\"http://www.onvif.org/ver10/media/wsdl\"\n"
        "                   xmlns:tds=\"http://www.onvif.org/ver10/device/wsdl\">\n"
        "  <SOAP-ENV:Body>\n"
    ) + body + QByteArray(
        "  </SOAP-ENV:Body>\n"
        "</SOAP-ENV:Envelope>\n"
    );
}

QByteArray OnvifServer::createFaultResponse(const QString& faultCode, const QString& faultString) const {
    return QString(
        "<SOAP-ENV:Fault>\n"
        "  <SOAP-ENV:Code>\n"
        "    <SOAP-ENV:Value>%1</SOAP-ENV:Value>\n"
        "  </SOAP-ENV:Code>\n"
        "  <SOAP-ENV:Reason>\n"
        "    <SOAP-ENV:Text xml:lang=\"en\">%2</SOAP-ENV:Text>\n"
        "  </SOAP-ENV:Reason>\n"
        "</SOAP-ENV:Fault>\n"
    ).arg(faultCode, faultString).toUtf8();
}

QByteArray OnvifServer::createGetCapabilitiesResponse() const {
    QString deviceUrl = getDeviceServiceUrl();
    QString mediaUrl = getMediaServiceUrl();

    return QString(
        "<tds:GetCapabilitiesResponse>\n"
        "  <tds:Capabilities>\n"
        "    <tt:Device>\n"
        "      <tt:XAddr>%1</tt:XAddr>\n"
        "      <tt:Network>\n"
        "        <tt:IPFilter>false</tt:IPFilter>\n"
        "        <tt:ZeroConfiguration>false</tt:ZeroConfiguration>\n"
        "        <tt:IPVersion6>false</tt:IPVersion6>\n"
        "        <tt:DynDNS>false</tt:DynDNS>\n"
        "      </tt:Network>\n"
        "      <tt:System>\n"
        "        <tt:DiscoveryResolve>true</tt:DiscoveryResolve>\n"
        "        <tt:DiscoveryBye>true</tt:DiscoveryBye>\n"
        "        <tt:RemoteDiscovery>true</tt:RemoteDiscovery>\n"
        "        <tt:SystemBackup>false</tt:SystemBackup>\n"
        "        <tt:FirmwareUpgrade>false</tt:FirmwareUpgrade>\n"
        "        <tt:SupportedVersions>\n"
        "          <tt:Major>2</tt:Major>\n"
        "          <tt:Minor>0</tt:Minor>\n"
        "        </tt:SupportedVersions>\n"
        "        <tt:Extension>\n"
        "          <tt:HttpFirmwareUpgrade>false</tt:HttpFirmwareUpgrade>\n"
        "          <tt:HttpSystemBackup>false</tt:HttpSystemBackup>\n"
        "          <tt:HttpSystemLogging>false</tt:HttpSystemLogging>\n"
        "          <tt:HttpSupportInformation>false</tt:HttpSupportInformation>\n"
        "        </tt:Extension>\n"
        "      </tt:System>\n"
        "      <tt:IO>\n"
        "        <tt:InputConnectors>0</tt:InputConnectors>\n"
        "        <tt:RelayOutputs>0</tt:RelayOutputs>\n"
        "      </tt:IO>\n"
        "      <tt:Security>\n"
        "        <tt:TLS1.1>false</tt:TLS1.1>\n"
        "        <tt:TLS1.2>false</tt:TLS1.2>\n"
        "        <tt:OnboardKeyGeneration>false</tt:OnboardKeyGeneration>\n"
        "        <tt:AccessPolicyConfig>false</tt:AccessPolicyConfig>\n"
        "        <tt:X.509Token>false</tt:X.509Token>\n"
        "        <tt:SAMLToken>false</tt:SAMLToken>\n"
        "        <tt:KerberosToken>false</tt:KerberosToken>\n"
        "        <tt:RELToken>false</tt:RELToken>\n"
        "      </tt:Security>\n"
        "    </tt:Device>\n"
        "    <tt:Media>\n"
        "      <tt:XAddr>%2</tt:XAddr>\n"
        "      <tt:StreamingCapabilities>\n"
        "        <tt:RTPMulticast>true</tt:RTPMulticast>\n"
        "        <tt:RTP_TCP>true</tt:RTP_TCP>\n"
        "        <tt:RTP_RTSP_TCP>true</tt:RTP_RTSP_TCP>\n"
        "      </tt:StreamingCapabilities>\n"
        "    </tt:Media>\n"
        "  </tds:Capabilities>\n"
        "</tds:GetCapabilitiesResponse>\n"
    ).arg(deviceUrl, mediaUrl).toUtf8();
}

QByteArray OnvifServer::createGetDeviceInformationResponse() const {
    return QString(
        "<tds:GetDeviceInformationResponse>\n"
        "  <tds:Manufacturer>%1</tds:Manufacturer>\n"
        "  <tds:Model>%2</tds:Model>\n"
        "  <tds:FirmwareVersion>%3</tds:FirmwareVersion>\n"
        "  <tds:SerialNumber>%4</tds:SerialNumber>\n"
        "  <tds:HardwareId>%5</tds:HardwareId>\n"
        "</tds:GetDeviceInformationResponse>\n"
    ).arg(config_.manufacturer, config_.model, config_.firmwareVersion,
          config_.serialNumber, config_.hardwareId).toUtf8();
}

QByteArray OnvifServer::createGetNetworkInterfacesResponse() const {
    return QString(
        "<tds:GetNetworkInterfacesResponse>\n"
        "  <tds:NetworkInterfaces token=\"eth0\">\n"
        "    <tt:Enabled>true</tt:Enabled>\n"
        "    <tt:Info>\n"
        "      <tt:Name>eth0</tt:Name>\n"
        "      <tt:HwAddress>00:11:22:33:44:55</tt:HwAddress>\n"
        "      <tt:MTU>1500</tt:MTU>\n"
        "    </tt:Info>\n"
        "    <tt:IPv4>\n"
        "      <tt:Enabled>true</tt:Enabled>\n"
        "      <tt:Config>\n"
        "        <tt:FromDHCP>\n"
        "          <tt:Address>%1</tt:Address>\n"
        "          <tt:PrefixLength>24</tt:PrefixLength>\n"
        "        </tt:FromDHCP>\n"
        "      </tt:Config>\n"
        "    </tt:IPv4>\n"
        "  </tds:NetworkInterfaces>\n"
        "</tds:GetNetworkInterfacesResponse>\n"
    ).arg(config_.ipAddress).toUtf8();
}

QByteArray OnvifServer::createGetProfilesResponse() const {
    // 使用动态分辨率（从编码器实际输出获取）
    int width = config_.videoWidth;
    int height = config_.videoHeight;
    
    qDebug() << "!!!!!!!config width hegiht" << width << " 1111 "<< height;

    return QString(
        "<trt:GetProfilesResponse>\n"
        "  <trt:Profiles token=\"profile_1\" fixed=\"true\">\n"
        "    <tt:Name>main_stream</tt:Name>\n"
        "    <tt:VideoSourceConfiguration token=\"video_source_1\">\n"
        "      <tt:Name>video_source</tt:Name>\n"
        "      <tt:SourceToken>video_source_1</tt:SourceToken>\n"
        "      <tt:Bounds x=\"0\" y=\"0\" width=\"%1\" height=\"%2\"/>\n"
        "    </tt:VideoSourceConfiguration>\n"
        "    <tt:VideoEncoderConfiguration token=\"video_encoder_1\">\n"
        "      <tt:Name>video_encoder</tt:Name>\n"
        "      <tt:Encoding>H265</tt:Encoding>\n"
        "      <tt:Resolution>\n"
        "        <tt:Width>%1</tt:Width>\n"
        "        <tt:Height>%2</tt:Height>\n"
        "      </tt:Resolution>\n"
        "      <tt:Quality>3</tt:Quality>\n"
        "      <tt:RateControl>\n"
        "        <tt:FrameRateLimit>25</tt:FrameRateLimit>\n"
        "        <tt:EncodingInterval>1</tt:EncodingInterval>\n"
        "        <tt:BitrateLimit>4096</tt:BitrateLimit>\n"
        "      </tt:RateControl>\n"
        "    </tt:VideoEncoderConfiguration>\n"
        "  </trt:Profiles>\n"
        "</trt:GetProfilesResponse>\n"
    ).arg(width).arg(height).toUtf8();
}

QByteArray OnvifServer::createGetStreamUriResponse() const {
    // 海康 NVR 通常期望带有用户名密码的 RTSP URL
    // 使用 admin/admin 作为默认凭证（海康默认）
    QString rtspUrl = QString("rtsp://admin:admin@%1:%2%3")
        .arg(config_.ipAddress)
        .arg(config_.rtspPort)
        .arg(config_.rtspPath);

    qDebug() << "GetStreamUri - Returning RTSP URL:" << rtspUrl;

    return QString(
        "<trt:GetStreamUriResponse>\n"
        "  <trt:MediaUri>\n"
        "    <tt:Uri>%1</tt:Uri>\n"
        "    <tt:InvalidAfterConnect>false</tt:InvalidAfterConnect>\n"
        "    <tt:InvalidAfterReboot>false</tt:InvalidAfterReboot>\n"
        "    <tt:Timeout>PT60S</tt:Timeout>\n"
        "  </trt:MediaUri>\n"
        "</trt:GetStreamUriResponse>\n"
    ).arg(rtspUrl).toUtf8();
}

QByteArray OnvifServer::createGetVideoSourcesResponse() const {
    return QString(
        "<trt:GetVideoSourcesResponse>\n"
        "  <trt:VideoSources token=\"video_source_1\">\n"
        "    <tt:Framerate>25</tt:Framerate>\n"
        "    <tt:Resolution>\n"
        "      <tt:Width>1920</tt:Width>\n"
        "      <tt:Height>1080</tt:Height>\n"
        "    </tt:Resolution>\n"
        "  </trt:VideoSources>\n"
        "</trt:GetVideoSourcesResponse>\n"
    ).toUtf8();
}

QByteArray OnvifServer::createGetServicesResponse() const {
    QString deviceUrl = getDeviceServiceUrl();
    QString mediaUrl = getMediaServiceUrl();

    return QString(
        "<tds:GetServicesResponse>\n"
        "  <tds:Service>\n"
        "    <tds:Namespace>http://www.onvif.org/ver10/device/wsdl</tds:Namespace>\n"
        "    <tds:XAddr>%1</tds:XAddr>\n"
        "    <tds:Version>\n"
        "      <tt:Major>2</tt:Major>\n"
        "      <tt:Minor>0</tt:Minor>\n"
        "    </tds:Version>\n"
        "  </tds:Service>\n"
        "  <tds:Service>\n"
        "    <tds:Namespace>http://www.onvif.org/ver10/media/wsdl</tds:Namespace>\n"
        "    <tds:XAddr>%2</tds:XAddr>\n"
        "    <tds:Version>\n"
        "      <tt:Major>2</tt:Major>\n"
        "      <tt:Minor>0</tt:Minor>\n"
        "    </tds:Version>\n"
        "  </tds:Service>\n"
        "</tds:GetServicesResponse>\n"
    ).arg(deviceUrl, mediaUrl).toUtf8();
}

QByteArray OnvifServer::createGetSystemDateAndTimeResponse() const {
    // 获取当前系统时间
    QDateTime now = QDateTime::currentDateTime();
    QDate date = now.date();
    QTime time = now.time();
    
    // 判断是否是夏令时（简化处理，中国没有夏令时）
    bool daylightSavings = false;
    
    // 时区 - 使用 CST+8（中国标准时间）
    QString tz = "CST+8";

    return QString(
        "<tds:GetSystemDateAndTimeResponse>\n"
        "  <tds:SystemDateAndTime>\n"
        "    <tt:DateTimeType>Manual</tt:DateTimeType>\n"
        "    <tt:DaylightSavings>%1</tt:DaylightSavings>\n"
        "    <tt:TimeZone>\n"
        "      <tt:TZ>%2</tt:TZ>\n"
        "    </tt:TimeZone>\n"
        "    <tt:UTCDateTime>\n"
        "      <tt:Time>\n"
        "        <tt:Hour>%3</tt:Hour>\n"
        "        <tt:Minute>%4</tt:Minute>\n"
        "        <tt:Second>%5</tt:Second>\n"
        "      </tt:Time>\n"
        "      <tt:Date>\n"
        "        <tt:Year>%6</tt:Year>\n"
        "        <tt:Month>%7</tt:Month>\n"
        "        <tt:Day>%8</tt:Day>\n"
        "      </tt:Date>\n"
        "    </tt:UTCDateTime>\n"
        "    <tt:LocalDateTime>\n"
        "      <tt:Time>\n"
        "        <tt:Hour>%3</tt:Hour>\n"
        "        <tt:Minute>%4</tt:Minute>\n"
        "        <tt:Second>%5</tt:Second>\n"
        "      </tt:Time>\n"
        "      <tt:Date>\n"
        "        <tt:Year>%6</tt:Year>\n"
        "        <tt:Month>%7</tt:Month>\n"
        "        <tt:Day>%8</tt:Day>\n"
        "      </tt:Date>\n"
        "    </tt:LocalDateTime>\n"
        "  </tds:SystemDateAndTime>\n"
        "</tds:GetSystemDateAndTimeResponse>\n"
    ).arg(daylightSavings ? "true" : "false", tz)
     .arg(time.hour()).arg(time.minute()).arg(time.second())
     .arg(date.year()).arg(date.month()).arg(date.day()).toUtf8();
}

QString OnvifServer::generateMessageId() const {
    return QUuid::createUuid().toString().mid(1, 36);
}

QString OnvifServer::getServiceUrl(OnvifServiceType type) const {
    switch (type) {
    case OnvifServiceType::Device:
        return getDeviceServiceUrl();
    case OnvifServiceType::Media:
    case OnvifServiceType::Media2:
        return getMediaServiceUrl();
    default:
        return getDeviceServiceUrl();
    }
}
