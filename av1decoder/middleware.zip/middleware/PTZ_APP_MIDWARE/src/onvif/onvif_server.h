#ifndef ONVIF_SERVER_H
#define ONVIF_SERVER_H

#include <QObject>
#include <QHostAddress>
#include <QUdpSocket>
#include <QTcpServer>
#include <QMap>
#include <QTimer>
#include <memory>

// ONVIF 服务器配置
struct OnvifServerConfig {
    QString deviceName = "PTZ Camera";
    QString manufacturer = "Custom";
    QString model = "PTZ-ONVIF";
    QString firmwareVersion = "1.0.0";
    QString serialNumber = "SN123456789";
    QString hardwareId = "HW001";

    // 网络配置
    QString ipAddress;
    int httpPort = 8080;
    int rtspPort = 554;

    // RTSP流配置
    QString rtspPath = "/live/stream/channel0";

    // 设备UUID (必须唯一)
    QString uuid;
    
    // 视频分辨率（动态更新）
    int videoWidth = 1920;
    int videoHeight = 1080;
};

// ONVIF服务类型
enum class OnvifServiceType {
    Device,
    Media,
    Media2,
    PTZ,
    Imaging,
    Events,
    Analytics
};

class OnvifServer : public QObject {
    Q_OBJECT

public:
    explicit OnvifServer(QObject* parent = nullptr);
    ~OnvifServer();

    // 启动/停止ONVIF服务
    bool start(const OnvifServerConfig& config);
    void stop();
    bool isRunning() const;

    // 获取服务URL
    QString getDeviceServiceUrl() const;
    QString getMediaServiceUrl() const;

    // 更新RTSP路径（当流改变时）
    void setRtspPath(const QString& path);
    
    // 更新视频分辨率（动态获取编码器实际输出分辨率）
    void setVideoResolution(int width, int height);
    int videoWidth() const { return config_.videoWidth; }
    int videoHeight() const { return config_.videoHeight; }

private slots:
    // WS-Discovery 处理
    void onDiscoveryDatagram();

    // HTTP服务处理
    void onNewHttpConnection();
    void onHttpReadyRead();

    // 定期发送Hello消息
    void sendHelloMessage();

private:
    // WS-Discovery相关
    bool initDiscoverySocket();
    void processProbeRequest(const QByteArray& request, const QHostAddress& sender, quint16 port);
    void sendProbeMatch(const QString& messageId, const QHostAddress& sender, quint16 port);
    void sendResolveMatch(const QString& messageId, const QHostAddress& sender, quint16 port);

    // HTTP服务相关
    void handleHttpRequest(class QTcpSocket* socket, const QByteArray& request);
    QByteArray handleDeviceServiceRequest(const QString& action, const QByteArray& body);
    QByteArray handleMediaServiceRequest(const QString& action, const QByteArray& body);

    // SOAP响应生成
    QByteArray createSoapEnvelope(const QByteArray& body) const;
    QByteArray createFaultResponse(const QString& faultCode, const QString& faultString) const;

    // 各种ONVIF响应生成
    QByteArray createGetCapabilitiesResponse() const;
    QByteArray createGetDeviceInformationResponse() const;
    QByteArray createGetNetworkInterfacesResponse() const;
    QByteArray createGetProfilesResponse() const;
    QByteArray createGetStreamUriResponse() const;
    QByteArray createGetVideoSourcesResponse() const;
    QByteArray createGetServicesResponse() const;
    QByteArray createGetSystemDateAndTimeResponse() const;

    // 工具函数
    QString generateMessageId() const;
    QString getServiceUrl(OnvifServiceType type) const;

private:
    OnvifServerConfig config_;
    bool running_ = false;

    // WS-Discovery socket (多播)
    QUdpSocket* discoverySocket_ = nullptr;
    QHostAddress discoveryMulticastAddr_;
    static constexpr quint16 DISCOVERY_PORT = 3702;

    // HTTP服务器
    QTcpServer* httpServer_ = nullptr;
    QMap<QTcpSocket*, QByteArray> httpBuffers_;

    // 定时发送Hello消息
    QTimer* helloTimer_ = nullptr;
};

#endif // ONVIF_SERVER_H
