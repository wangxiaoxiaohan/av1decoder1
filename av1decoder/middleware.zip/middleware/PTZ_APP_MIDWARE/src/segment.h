#pragma once
#ifdef _WIN32
#define DLL_EXPORT __declspec(dllexport)
#else
#define DLL_EXPORT
#endif
#ifdef __cplusplus
extern "C"
{
#endif
// device_type: 0=CPU, 1=CUDA
// DLL_EXPORT int init_model_gpu(const char* model_path, int device_type);
#define TDLAS_THRESHOLD 30.0f
    DLL_EXPORT int init_model(const char *model_path);
    // DLL_EXPORT int process_image(const cv::Mat& input_bgr, cv::Mat& output_bgr);
    DLL_EXPORT int process_image_yuv420sp(const unsigned char *input_yuv, int width, int height, unsigned char *output_yuv, unsigned char *heatmap_yuv, float tdlas);
    DLL_EXPORT void release_model();
#ifdef __cplusplus
}
#endif