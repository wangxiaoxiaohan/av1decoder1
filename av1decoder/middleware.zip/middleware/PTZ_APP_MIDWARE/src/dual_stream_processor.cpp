#include "dual_stream_processor.h"
#include "player.h"
#include "frame_provider.h"
#include "stitched_streamer.h"
#include <QDebug>

DualStreamProcessor::DualStreamProcessor(QObject *parent)
    : QObject(parent)
    , m_visiblePlayer(nullptr)
    , m_infraredPlayer(nullptr)
    , m_visibleProvider(nullptr)
    , m_infraredProvider(nullptr)
    , m_streamer(nullptr)
    , m_timer(nullptr)
    , m_running(false)
{
    // Initialize components
    m_visiblePlayer = new splayer(); // Parentless initially, or we can set parent if splayer supports it. 
                                     // splayer inherits QObject, so we can set parent.
    m_visiblePlayer->setParent(this);

    m_infraredPlayer = new splayer();
    m_infraredPlayer->setParent(this);

    m_visibleProvider = new FrameProvider(this);
    m_infraredProvider = new FrameProvider(this);

    m_streamer = std::make_unique<StitchedStreamer>();
    
    m_timer = new QTimer(this);
    connect(m_timer, &QTimer::timeout, this, &DualStreamProcessor::onTick);

    // Connect Players to Providers
    connect(m_visiblePlayer, &splayer::newFrameAvailable, 
            m_visibleProvider, &FrameProvider::onNewVideoContentReceived);
    connect(m_infraredPlayer, &splayer::newFrameAvailable, 
            m_infraredProvider, &FrameProvider::onNewVideoContentReceived);
}

DualStreamProcessor::~DualStreamProcessor()
{
    stop();
    // QObject children (players, providers, timer) will be automatically deleted.
    // m_streamer is a unique_ptr, so it cleans itself up.
}

bool DualStreamProcessor::start(const QString& visibleUrl, const QString& infraredUrl, const QString& outputUrl)
{
    if (m_running) {
        qWarning() << "DualStreamProcessor: Already running";
        return true;
    }

    qDebug() << "DualStreamProcessor: Starting with"
             << "\n  Visible:" << visibleUrl
             << "\n  Infrared:" << infraredUrl
             << "\n  Output:" << outputUrl;

    // Start Players
    m_visiblePlayer->prepare(visibleUrl);
    m_visiblePlayer->play();
    
    m_infraredPlayer->prepare(infraredUrl);
    m_infraredPlayer->play();

    // Start Streamer
    // Assuming h264, 25fps, 4Mbps
    bool streamerStarted = m_streamer->start(m_visibleProvider, m_infraredProvider, 
                                          outputUrl, "h264", 25, 4000, "rtsp");

    if (!streamerStarted) {
        qCritical() << "DualStreamProcessor: Stitched Streamer failed to start:" << m_streamer->lastError();
        stop();
        return false;
    }

    // Start Tick Timer (10ms)
    m_timer->start(10);
    m_running = true;
    return true;
}

void DualStreamProcessor::stop()
{
    if (!m_running) return;

    qDebug() << "DualStreamProcessor: Stopping";
    
    if (m_timer->isActive()) {
        m_timer->stop();
    }

    if (m_streamer) {
        m_streamer->stop();
    }

    if (m_visiblePlayer) {
        m_visiblePlayer->stop();
    }

    if (m_infraredPlayer) {
        m_infraredPlayer->stop();
    }

    m_running = false;
}

void DualStreamProcessor::onTick()
{
    if (m_streamer && m_running) {
        m_streamer->tick();
    }
}

bool DualStreamProcessor::getOutputResolution(int& width, int& height) const
{
    if (!m_streamer || !m_running) {
        return false;
    }
    
    width = m_streamer->outputWidth();
    height = m_streamer->outputHeight();
    
    // 只有当分辨率有效时才返回 true
    return (width > 0 && height > 0);
}
