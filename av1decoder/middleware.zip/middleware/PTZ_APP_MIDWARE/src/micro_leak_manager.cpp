
#include "micro_leak_manager.h"
#include "gasDeviceDetApi.h"
#include "overlay.h"
#include "frame_provider.h"
#include "playermanager.h"
#include <QDebug>
#include <QFile>
#include <QDir>
#include <QDateTime>
#include <cmath>
MicroLeakManager* MicroLeakManager::m_instance = nullptr;

MicroLeakManager* MicroLeakManager::instance()
{
    if (!m_instance) {
        m_instance = new MicroLeakManager();
    }
    return m_instance;
}

MicroLeakManager::MicroLeakManager(QObject* parent)
    : QObject(parent)
    , m_workerThread(nullptr)
    , m_worker(nullptr)
    , m_initialized(false)
{
    m_workerThread = new QThread();
    m_worker = new MicroLeakWorker();
    m_worker->moveToThread(m_workerThread);

    connect(m_worker, &MicroLeakWorker::processingCompleted, this, &MicroLeakManager::processingFinished);
    connect(m_worker, &MicroLeakWorker::errorOccurred, this, &MicroLeakManager::errorOccurred);
    
    connect(m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    connect(m_workerThread, &QThread::finished, m_workerThread, &QThread::deleteLater);

    m_workerThread->start();
}

MicroLeakManager::~MicroLeakManager()
{
    if (m_workerThread) {
        m_workerThread->quit();
        m_workerThread->wait();
    }
}

bool MicroLeakManager::initialize(const QString& configPath)
{
    QMutexLocker locker(&m_mutex);
    if (m_initialized) return true;

    bool result = false;
    QMetaObject::invokeMethod(m_worker, "init", Qt::BlockingQueuedConnection, 
                              Q_RETURN_ARG(bool, result),
                              Q_ARG(QString, configPath));
    
    m_initialized = result;
    return m_initialized;
}

void MicroLeakManager::processAsync(const QByteArray& yuvData, int width, int height, float tdlas, int channelIndex, qint64 timestamp)
{
    if (!m_initialized) return;
    QMetaObject::invokeMethod(m_worker, "process", Qt::QueuedConnection,
                              Q_ARG(QByteArray, yuvData),
                              Q_ARG(int, width),
                              Q_ARG(int, height),
                              Q_ARG(float, tdlas),
                              Q_ARG(int, channelIndex),
                              Q_ARG(qint64, timestamp));
}

bool MicroLeakManager::isAvailable() const
{
    return m_initialized;
}

// Worker Implementation

MicroLeakWorker::MicroLeakWorker(QObject* parent)
    : QObject(parent)
    , m_detectorHandle(nullptr)
    , m_initSuccess(false)
    , m_WindyDirection(0)
    , m_rng()
    , m_frameCount(0)
    , m_rngInitialized(false)
{
}

MicroLeakWorker::~MicroLeakWorker()
{
    if (m_detectorHandle) {
        gasDeviceDet_destroy(&m_detectorHandle);
        m_detectorHandle = nullptr;
    }
}

bool MicroLeakWorker::init(const QString& configPath)
{
    qDebug() << "MicroLeakWorker initializing with config:" << configPath;
    
    QByteArray configPathBytes = configPath.toLocal8Bit();

    m_detectorHandle = gasDeviceDet_create(configPathBytes.constData(),&m_WindyDirection);
    
    if (!m_detectorHandle) {
        qWarning() << "Failed to create gas detector handle";
        return false;
    }

    // Load LUT
    QString lutPath = QDir(configPath).filePath("heatmap_lut.json");
    loadLut(lutPath);

    // Setup default params (reference gaussiandemo.cpp)
    m_params.x_range = {100.0, 2000.0};
    m_params.y_range = {-500.0, 500.0};
    m_params.z = 0.0;
    m_params.stability_class = "D";
    m_params.nx = 100;
    m_params.ny = 80;
    m_params.irregularity_strength = 0.7f;
    m_params.irregularity_scale = 15;
    m_params.clip_min_ratio = 1e-4f;
    m_params.visible_min_ratio = 0.05f;
    m_params.visible_quantile = 0.85f;
    m_params.width_px = 128;
    m_params.height_px = 108;
    m_params.num_directions = 4;
    m_params.direction_spread = 0.7f;
    m_params.random_rotation = true;
    m_params.rotation_min_angle = 10.0f;
    m_params.rotation_max_angle = 60.0f;

    m_initSuccess = true;
    return true;
}

void MicroLeakWorker::loadLut(const QString& path)
{
    std::string stdPath = path.toStdString();
    if (!load_heatmap_lut(stdPath, m_lut)) {
        qWarning() << "Failed to load heatmap LUT from:" << path;
    } else {
        qDebug() << "Loaded heatmap LUT, size:" << m_lut.size();
    }
}

void MicroLeakWorker::process(const QByteArray& yuvData, int width, int height, float tdlas, int channelIndex, qint64 timestamp)
{
    if (!m_detectorHandle || yuvData.isEmpty()) {
        emit errorOccurred("Invalid state or data");
        return;
    }
    // Copy data because overlay modifies it
    QByteArray dstData = yuvData;
    unsigned char* pDst = reinterpret_cast<unsigned char*>(dstData.data());

    int offsetX = 0;
    int offsetY = 0;
    int tdlasX = width / 2;
    int tdlasY = height / 2;

    float tofDistance = PlayerManager::instance()->getTofDistance(channelIndex);
    if (tofDistance > 0.0f) {
        double kx = 0.0;
        double bx = 0.0;
        double ky = 0.0;
        double by = 0.0;
        FrameProvider::getScreenCursorParams(kx, bx, ky, by);
        double d = static_cast<double>(tofDistance);
        if (d > 0.0) {
            double x = kx / d + bx;
            double y = ky / d + by;
            if (x >= 0.0 && x < static_cast<double>(width) &&
                y >= 0.0 && y < static_cast<double>(height)) {
                tdlasX = static_cast<int>(x);
                tdlasY = static_cast<int>(y);
            }
        }
    }





    // 0. Detect
    // Note: gasDeviceDet_detect signature takes `unsigned char *data`.
    // It's unclear if it modifies data. Assuming it reads.
    // Also `channel` should be 1 for YUV? Demo uses 1.
    float sizeRatio;
    gasDeviceDet_detect(m_detectorHandle, pDst, width, height, 1, tdlasX, tdlasY, &offsetX, &offsetY,&sizeRatio);
    qDebug() << "!!!!!!!!!!!!!!!!!! wh Detection sizeRatio:" << sizeRatio;

    PositionMode position_mode;
    if (m_WindyDirection == 0)
    {
        m_params.rotation_min_angle = 0.0f;
        m_params.rotation_max_angle = 45.0f;
        position_mode = POSITION_BOTTOM_LEFT;
    }
    else if (m_WindyDirection == 1)
    {
        m_params.rotation_min_angle = 45.0f;
        m_params.rotation_max_angle = 90.0f;
        position_mode = POSITION_BOTTOM_LEFT;
    }
    else if (m_WindyDirection == 2)
    {
        m_params.rotation_min_angle = 45.0f;
        m_params.rotation_max_angle = 90.0f;
        position_mode = POSITION_BOTTOM_RIGHT;
    }
    else if (m_WindyDirection == 3)
    {
        m_params.rotation_min_angle = 0.0f;
        m_params.rotation_max_angle = 45.0f;
        position_mode = POSITION_BOTTOM_RIGHT;
    }
    else if (m_WindyDirection == 4)
    {
        m_params.rotation_min_angle = -45.0f;
        m_params.rotation_max_angle = 0.0f;
        position_mode = POSITION_TOP_RIGHT;
    }
    else if (m_WindyDirection == 5)
    {
        m_params.rotation_min_angle = -90.0f;
        m_params.rotation_max_angle = -45.0f;
        position_mode = POSITION_TOP_RIGHT;
    }
    else if (m_WindyDirection == 6)
    {
        m_params.rotation_min_angle = -90.0f;
        m_params.rotation_max_angle = -45.0f;
        position_mode = POSITION_TOP_LEFT;
    }
    else if (m_WindyDirection == 7)
    {
        m_params.rotation_min_angle = -45.0f;
        m_params.rotation_max_angle = 0.0f;
        position_mode = POSITION_TOP_LEFT;
    }
    else
    {
        if (offsetX > tdlasX){
            position_mode = POSITION_BOTTOM_RIGHT;
        }
        else{
            position_mode = POSITION_BOTTOM_LEFT;
        }
    }

    // 1. Generate Plume
    // Randomize stability class as in demo?
    // Demo: "C" or "D"
    // For consistency, let's just pick one or randomize lightly.
    // We can use a static counter or random generator.
    // For now, stick to default "D" or what's in params.
    
    // Create Plume object
    GaussianPlumeModel::GaussianPlume plume(
        100.0,
        3.0,
        50.0,
        55.0
    );
    
    if (!m_rngInitialized) {
        std::random_device rd;
        m_rng.seed(rd());
        m_rngInitialized = true;
    }
    
    m_frameCount++;
    if (m_frameCount % 5 == 0) {
        std::random_device rd;
        m_rng.seed(rd());
    }
    
    int actual_width = 0;
    int actual_height = 0;
    int old_width_px = m_params.width_px;
    m_params.width_px  *= sizeRatio;
    std::vector<unsigned char> plumeImage = GaussianPlumeModel::concentrationMapIrregular(plume, m_params, &m_rng, &actual_width, &actual_height);
    m_params.width_px = old_width_px;

    // 2. Render Heatmap
    render_heatmap(plumeImage.data(), actual_width, actual_height,  m_lut);

    // 3. Overlay
    // Overlay plume onto dstData
    overlay(plumeImage.data(), actual_width, actual_height, 
            pDst, width, height,
            offsetX, offsetY, tdlasX, tdlasY, position_mode);

    // 4. Convert to RGB QImage
    QImage result = yuvToRgb(pDst, width, height);
    
    emit processingCompleted(result, true, channelIndex, timestamp);
}

QImage MicroLeakWorker::yuvToRgb(const unsigned char* yuv, int width, int height)
{
    // Simple YUV NV12 to RGB conversion
    // Assuming NV12 (YUV420SP)
    
    QImage image(width, height, QImage::Format_RGB888);
    uchar* rgbData = image.bits();
    int rgbStride = image.bytesPerLine();

    const uchar* yData = yuv;
    const uchar* uvData = yuv + width * height;

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int Y = yData[y * width + x];
            int uvIndex = (y / 2) * width + (x & ~1);
            int U = uvData[uvIndex] - 128;
            int V = uvData[uvIndex + 1] - 128;

            // Standard conversion
            int R = Y + 1.402 * V;
            int G = Y - 0.344136 * U - 0.714136 * V;
            int B = Y + 1.772 * U;

            // Clamp
            R = (R < 0) ? 0 : (R > 255) ? 255 : R;
            G = (G < 0) ? 0 : (G > 255) ? 255 : G;
            B = (B < 0) ? 0 : (B > 255) ? 255 : B;

            int rgbIndex = y * rgbStride + x * 3;
            rgbData[rgbIndex] = R;
            rgbData[rgbIndex + 1] = G;
            rgbData[rgbIndex + 2] = B;
        }
    }
    return image;
}
