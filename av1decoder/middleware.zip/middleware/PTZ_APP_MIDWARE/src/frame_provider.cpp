#include "frame_provider.h"
#ifndef PTZ_SERVER_MODE
#include "devicemodel.h"
#include "playermanager.h"
#endif
#include <QImage>
#include <QPainter>
#include <QDateTime>
#include <QRandomGenerator>
#include <QVideoFrame>
#include <QDebug>
#include <QVideoWidget>
#include <QFile>
#include <QStandardPaths>
#include <QDir>
#include <QMutexLocker>
#include <QUrl>
#include <QTimer>
#include <QCoreApplication>

#include <QVideoSurfaceFormat>
#include <QAbstractVideoSurface>



double FrameProvider::s_screenCursorKx = 0.0;
double FrameProvider::s_screenCursorBx = 0.0;
double FrameProvider::s_screenCursorKy = 0.0;
double FrameProvider::s_screenCursorBy = 0.0;

FrameProvider::FrameProvider(QObject* parent) : nosignal_count_(6){
    nosignal_timer_.setInterval(1000);
    connect(&nosignal_timer_, &QTimer::timeout, this, &FrameProvider::OnNoSignalTimeout);
    m_channelIndex = -1;
    m_tofCrosshairEnabled = false;
}

FrameProvider::~FrameProvider(){
    // Properly stop and clear all video surfaces
    for(const auto &surface : m_surfaces) {
        if(surface && surface->isActive()) {
            surface->stop();
        }
    }
    m_surfaces.clear();
}

QAbstractVideoSurface* FrameProvider::videoSurface() const{
    // Return first active surface or nullptr
    for(const auto &surface : m_surfaces) {
        if(surface && surface->isActive()) {
            return surface.data();
        }
    }
    return nullptr;
}

void FrameProvider::setVideoSurface(QAbstractVideoSurface* surface){
    if(surface && !m_surfaces.contains(QPointer<QAbstractVideoSurface>(surface))) {
        m_surfaces.append(QPointer<QAbstractVideoSurface>(surface));
        if(m_format.isValid()){
            QVideoSurfaceFormat fmt = surface->nearestFormat(m_format);
            surface->start(fmt);
        }
    }
}

void FrameProvider::removeVideoSurface(QAbstractVideoSurface *surface)
{
    if(surface){
        if(surface->isActive()){
            surface->stop();
        }
        // Remove all instances of this surface from our list
        QPointer<QAbstractVideoSurface> pointer(surface);
        m_surfaces.removeAll(pointer);
    }
}

void FrameProvider::setFormat(int width, int heigth, QVideoFrame::PixelFormat format){
    //qDebug() << "FrameProvider: setFormat called with" << width << "x" << heigth << "format:" << format;
    
    QSize size(width, heigth);
    QVideoSurfaceFormat vsformat(size, format);
    
    //qDebug() << "FrameProvider: Created format:" << vsformat.frameSize() << "pixelFormat:" << vsformat.pixelFormat();
    //qDebug() << "FrameProvider: Format valid:" << vsformat.isValid();
    
    m_format = vsformat;

    // Negotiate and start each surface with new format
    auto it = m_surfaces.begin();
    while (it != m_surfaces.end()) {
        QPointer<QAbstractVideoSurface> surface = *it;
        // QPointer automatically becomes null when object is destroyed
        if (!surface) {
            // Remove null pointer from list
            it = m_surfaces.erase(it);
            continue;
        }
        
        if(surface->isActive()) {
            //qDebug() << "FrameProvider: Stopping active surface";
            surface->stop();
        }
        QVideoSurfaceFormat fmt = surface->nearestFormat(m_format);
        //qDebug() << "FrameProvider: Nearest format:" << fmt.frameSize() << "pixelFormat:" << fmt.pixelFormat();
        //qDebug() << "FrameProvider: Nearest format valid:" << fmt.isValid();
        bool started = surface->start(fmt);
        //qDebug() << "FrameProvider: Surface start result:" << started;
        ++it;
    }
}

void FrameProvider::setChannelIndex(int channelIndex){
    m_channelIndex = channelIndex;
}

void FrameProvider::setTofCrosshairEnabled(bool enabled){
    m_tofCrosshairEnabled = enabled;
}

void FrameProvider::setScreenCursorParams(double kx, double bx, double ky, double by){
    s_screenCursorKx = kx;
    s_screenCursorBx = bx;
    s_screenCursorKy = ky;
    s_screenCursorBy = by;
}

void FrameProvider::getScreenCursorParams(double& kx, double& bx, double& ky, double& by){
    kx = s_screenCursorKx;
    bx = s_screenCursorBx;
    ky = s_screenCursorKy;
    by = s_screenCursorBy;
}

void FrameProvider::setUpdatesEnabled(bool enabled)
{
    QMutexLocker locker(&m_frameMutex);
    m_updatesEnabled = enabled;
    qDebug() << "FrameProvider: updates enabled set to" << enabled << "for channel" << m_channelIndex;
}

void FrameProvider::onNewVideoContentReceived(const QVideoFrame& frame){
    {
        QMutexLocker locker(&m_frameMutex);
        if (!m_updatesEnabled) {
            return;
        }
    }

    // qDebug() << "FrameProvider::onNewVideoContentReceived called with frame:" 
    //          << "width=" << frame.width() 
    //          << "height=" << frame.height() 
    //          << "valid=" << frame.isValid()
    //          << "surfaces count=" << m_surfaces.size();
    if (!frame.isValid()) {
        qWarning() << "FrameProvider: Received invalid frame";
        return;
    }
    
    QVideoFrame processedFrame = frame;
    if (m_tofCrosshairEnabled && m_channelIndex >= 0) {
        processedFrame = drawTofCrosshair(frame);
    }
    
    {
        QMutexLocker locker(&m_frameMutex);
        m_currentFrame = processedFrame;
    }
    
    // Update format if needed
    if(m_format.frameWidth() != processedFrame.width() || m_format.frameHeight() != processedFrame.height() || m_format.pixelFormat() != processedFrame.pixelFormat()){
        qDebug() << "FrameProvider: Updating format from" << m_format.frameWidth() << "x" << m_format.frameHeight() 
                 << "to" << processedFrame.width() << "x" << processedFrame.height();
        setFormat(processedFrame.width(), processedFrame.height(), processedFrame.pixelFormat());
    }

    // Present frame to all active surfaces
    int activeSurfaces = 0;
    int presentedFrames = 0;
    
    // Use an iterator to safely remove invalid surfaces during iteration
    auto it = m_surfaces.begin();
    while (it != m_surfaces.end()) {
        // Double check updates enabled status before processing surfaces
        {
            QMutexLocker locker(&m_frameMutex);
            if (!m_updatesEnabled) {
                return;
            }
        }

        QPointer<QAbstractVideoSurface> surface = *it;
        // Check if surface is still valid (QPointer automatically becomes null when object is destroyed)
        if (!surface) {
            // Remove invalid surface and continue to next
            it = m_surfaces.erase(it);
            continue;
        }
        
        activeSurfaces++;
        // 如果表面不活跃，尝试重新激活
        if(!surface->isActive()) {
            qDebug() << "FrameProvider: Reactivating inactive surface";
            if(m_format.isValid()) {
                QVideoSurfaceFormat fmt = surface->nearestFormat(m_format);
                bool started = surface->start(fmt);
                qDebug() << "FrameProvider: Surface start result:" << started;
            }
        }
        
        // 现在尝试显示帧
        if(surface->isActive()) {
            bool presented = surface->present(processedFrame);
            if (presented) {
                presentedFrames++;
            }
        } else {
            qWarning() << "FrameProvider: Surface is not active, cannot present frame";
        }
        
        ++it;
    }
}

QString FrameProvider::captureCurrentFrame(const QString& fileName, bool isAlarmCapture) {
#ifdef PTZ_SERVER_MODE
    return QString();
#else
    QMutexLocker locker(&m_frameMutex);
    
    if (!m_currentFrame.isValid()) {
        qWarning() << "FrameProvider: No current frame available to capture";
        return QString();
    }
    
    qDebug() << "FrameProvider: Capturing frame on demand, frame size:" << m_currentFrame.width() << "x" << m_currentFrame.height() << "isAlarmCapture:" << isAlarmCapture;
    
    // 按需转换当前帧为QImage（只在需要时才转换，节省资源）
    QImage currentImage = videoFrameToImage(m_currentFrame);
    if (currentImage.isNull()) {
        qWarning() << "FrameProvider: Failed to convert frame to image";
        return QString();
    }
    
    qDebug() << "FrameProvider: Frame converted to image, size:" << currentImage.size();
    
    // 获取格式和分辨率设置
    QString format, resolution;
    int quality = 95;
    
    DeviceModel* deviceModel = DeviceModel::instance();
    if (deviceModel) {
        if (isAlarmCapture) {
            format = deviceModel->getStorageSettings("alarmPhotoFormat");
            quality = deviceModel->getStorageSettings("alarmPhotoQuality").toInt();
            resolution = deviceModel->getStorageSettings("alarmPhotoResolution");
        } else {
            format = deviceModel->getStorageSettings("photoFormat");
            quality = deviceModel->getStorageSettings("photoQuality").toInt();
            resolution = deviceModel->getStorageSettings("photoRatio");
        }
        
        // 确保有默认值
        if (format.isEmpty()) format = "JPEG";
        if (quality <= 0 || quality > 100) quality = 95;
        if (resolution.isEmpty()) resolution = "original";
    } else {
        format = "JPEG";
        quality = 95;
        resolution = "original";
    }
    
    qDebug() << "FrameProvider: Using format:" << format << "quality:" << quality << "resolution:" << resolution;
    
    // 处理分辨率设置（支持中文和英文的原始分辨率）
    QImage finalImage = currentImage;
    if (resolution != "original" && resolution != "原始分辨率" && !currentImage.isNull()) {
        QSize targetSize;
        QSize originalSize = currentImage.size();
        
        if (resolution == "16:9") {
            // 16:9 比例，保持原图宽度，计算对应高度
            int newWidth = originalSize.width();
            int newHeight = (newWidth * 9) / 16;
            targetSize = QSize(newWidth, newHeight);
        } else if (resolution == "4:3") {
            // 4:3 比例，保持原图宽度，计算对应高度
            int newWidth = originalSize.width();
            int newHeight = (newWidth * 3) / 4;
            targetSize = QSize(newWidth, newHeight);
        } else if (resolution == "1920x1080") {
            targetSize = QSize(1920, 1080);
        } else if (resolution == "1280x720") {
            targetSize = QSize(1280, 720);
        } else if (resolution == "640x480") {
            targetSize = QSize(640, 480);
        } else if (resolution == "320x240") {
            targetSize = QSize(320, 240);
        }
        
        if (targetSize.isValid() && targetSize != originalSize) {
            finalImage = currentImage.scaled(targetSize, Qt::IgnoreAspectRatio, Qt::SmoothTransformation);
            qDebug() << "FrameProvider: Image resized from" << originalSize << "to" << finalImage.size() << "for resolution:" << resolution;
        } else {
            qDebug() << "FrameProvider: Using original resolution:" << originalSize << "for resolution:" << resolution;
        }
    } else {
        qDebug() << "FrameProvider: Using original resolution:" << currentImage.size();
    }
    
    // 根据抓拍类型获取相应的存储路径
    QString photoPath;
    
    if (isAlarmCapture) {
        // 报警抓拍使用alarmPhotoPath
        photoPath = "D:/ZG_Client/Alarm_Photo"; // 默认报警抓拍路径
        if (deviceModel) {
            QString savedAlarmPhotoPath = deviceModel->getStorageSettings("alarmPhotoPath");
            if (!savedAlarmPhotoPath.isEmpty()) {
                photoPath = savedAlarmPhotoPath;
            }
        }
        qDebug() << "FrameProvider: Using alarm photo path:" << photoPath;
    } else {
        // 普通抓拍使用photoPath
        photoPath = "D:/ZG_Client/Photo"; // 默认普通抓拍路径
        if (deviceModel) {
            QString savedPhotoPath = deviceModel->getStorageSettings("photoPath");
            if (!savedPhotoPath.isEmpty()) {
                photoPath = savedPhotoPath;
            }
        }
        qDebug() << "FrameProvider: Using normal photo path:" << photoPath;
    }
    
    // 确保路径存在
    QDir photoDir(photoPath);
    if (!photoDir.exists()) {
        if (!photoDir.mkpath(".")) {
            qWarning() << "FrameProvider: Failed to create photo directory:" << photoPath;
            // 回退到应用程序目录
            QDir appDir(QCoreApplication::applicationDirPath());
            photoPath = appDir.absoluteFilePath("captured_frames");
            if (!QDir(photoPath).exists()) {
                QDir().mkpath(photoPath);
            }
        }
    }
    
    // 生成文件名（包含完整路径）
    QString finalFileName = fileName;
    if (finalFileName.isEmpty()) {
        QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss_zzz");
        QString prefix = isAlarmCapture ? "alarm_" : "frame_";
        QString extension = format.toLower();
        QString fileNameOnly = QString("%1%2.%3").arg(prefix).arg(timestamp).arg(extension);
        finalFileName = photoDir.absoluteFilePath(fileNameOnly);
    } else {
        // 如果传入了文件名，确保使用完整路径
        QFileInfo fileInfo(fileName);
        if (fileInfo.isRelative()) {
            finalFileName = photoDir.absoluteFilePath(fileName);
        }
    }
    
    QString absolutePath = finalFileName;
    qDebug() << "FrameProvider: Attempting to save frame to:" << absolutePath;
    
    // 保存图片，使用配置的格式和质量
    if (finalImage.save(absolutePath, format.toUpper().toUtf8().constData(), quality)) {
        qDebug() << "FrameProvider: Frame captured successfully:" << absolutePath;
        
        // 验证文件是否确实保存成功
        QFileInfo fileInfo(absolutePath);
        if (fileInfo.exists() && fileInfo.size() > 0) {
            qDebug() << "FrameProvider: File verified, size:" << fileInfo.size() << "bytes";
            
            // 返回file://URL格式，供QML使用
            QString fileUrl = QUrl::fromLocalFile(absolutePath).toString();
            qDebug() << "FrameProvider: Returning URL:" << fileUrl;
            return fileUrl;
        } else {
            qWarning() << "FrameProvider: File not found or empty after save";
            return QString();
        }
    } else {
        qWarning() << "FrameProvider: Failed to save frame to:" << absolutePath;
        return QString();
    }
#endif
}

QImage FrameProvider::getCurrentFrameAsImage() const {
    QMutexLocker locker(&m_frameMutex);
    
    if (!m_currentFrame.isValid()) {
        qWarning() << "FrameProvider: No current frame available";
        return QImage();
    }
    
    // 按需转换（只在调用时转换）
    return videoFrameToImage(m_currentFrame);
}

QImage FrameProvider::videoFrameToImage(const QVideoFrame& frame) const {
    if (!frame.isValid()) {
        return QImage();
    }
    
    QVideoFrame cloneFrame(frame);
    if (!cloneFrame.map(QAbstractVideoBuffer::ReadOnly)) {
        qWarning() << "Failed to map video frame";
        return QImage();
    }
    
    QImage image;
    
    // 根据不同的像素格式进行转换
    switch (cloneFrame.pixelFormat()) {
        case QVideoFrame::Format_YUV420P: {
            // YUV420P 转换为 RGB
            int width = cloneFrame.width();
            int height = cloneFrame.height();
            
            const uchar* yData = cloneFrame.bits(0);
            const uchar* uData = cloneFrame.bits(1);  
            const uchar* vData = cloneFrame.bits(2);
            
            if (!yData || !uData || !vData) {
                qWarning() << "Invalid YUV420P data pointers";
                break;
            }
            
            int yStride = cloneFrame.bytesPerLine(0);
            int uStride = cloneFrame.bytesPerLine(1);
            int vStride = cloneFrame.bytesPerLine(2);
            
            image = QImage(width, height, QImage::Format_RGB888);
            uchar* rgbData = image.bits();
            int rgbStride = image.bytesPerLine();
            
            // 优化的YUV到RGB转换
            for (int y = 0; y < height; ++y) {
                for (int x = 0; x < width; ++x) {
                    int yIndex = y * yStride + x;
                    int uvIndex = (y / 2) * uStride + (x / 2);
                    
                    int Y = yData[yIndex];
                    int U = uData[uvIndex] - 128;
                    int V = vData[uvIndex] - 128;
                    
                    // 改进的YUV到RGB转换公式
                    int R = qBound(0, Y + ((1436 * V) >> 10), 255);
                    int G = qBound(0, Y - ((354 * U + 732 * V) >> 10), 255);
                    int B = qBound(0, Y + ((1814 * U) >> 10), 255);
                    
                    int rgbIndex = y * rgbStride + x * 3;
                    rgbData[rgbIndex] = R;
                    rgbData[rgbIndex + 1] = G;
                    rgbData[rgbIndex + 2] = B;
                }
            }
            break;
        }
        case QVideoFrame::Format_RGB32:
        case QVideoFrame::Format_ARGB32: {
            image = QImage(cloneFrame.bits(), cloneFrame.width(), cloneFrame.height(), 
                          cloneFrame.bytesPerLine(), QImage::Format_RGB32);
            break;
        }
        case QVideoFrame::Format_RGB24: {
            image = QImage(cloneFrame.bits(), cloneFrame.width(), cloneFrame.height(), 
                          cloneFrame.bytesPerLine(), QImage::Format_RGB888);
            break;
        }
        default: {
            qWarning() << "Unsupported pixel format for frame conversion:" << cloneFrame.pixelFormat();
            // 尝试使用Qt的转换
            image = QImage(cloneFrame.bits(), cloneFrame.width(), cloneFrame.height(), 
                          cloneFrame.bytesPerLine(), QImage::Format_RGB888);
            break;
        }
    }
    
    cloneFrame.unmap();
    return image;
}

QVideoFrame FrameProvider::drawTofCrosshair(const QVideoFrame& frame){
#ifdef PTZ_SERVER_MODE
    return frame;
#else
    if (!frame.isValid()) {
        return frame;
    }
    if (!m_tofCrosshairEnabled || m_channelIndex < 0) {
        return frame;
    }
    float tofDistance = PlayerManager::instance()->getTofDistance(m_channelIndex);
    if (tofDistance <= 0.0f) {
        return frame;
    }
    QImage image = videoFrameToImage(frame);
    if (image.isNull()) {
        return frame;
    }
    double d = static_cast<double>(tofDistance);
    if (d <= 0.0) {
        return frame;
    }
    double rawX = s_screenCursorKx / d + s_screenCursorBx;
    double rawY = s_screenCursorKy / d + s_screenCursorBy;
    double clampedX = qBound(0.0, rawX, static_cast<double>(image.width() - 1));
    double clampedY = qBound(0.0, rawY, static_cast<double>(image.height() - 1));
    double halfSize = 10.0;
    double x0 = qBound(0.0, clampedX - halfSize, static_cast<double>(image.width() - 1));
    double x1 = qBound(0.0, clampedX + halfSize, static_cast<double>(image.width() - 1));
    double y0 = qBound(0.0, clampedY - halfSize, static_cast<double>(image.height() - 1));
    double y1 = qBound(0.0, clampedY + halfSize, static_cast<double>(image.height() - 1));
    // qDebug() << "TOF crosshair channel" << m_channelIndex << "d" << d << "rawX" << rawX << "rawY" << rawY
    //          << "clampedX" << clampedX << "clampedY" << clampedY
    //          << "x0" << x0 << "x1" << x1 << "y0" << y0 << "y1" << y1
    //          << "image size" << image.width() << image.height();
    QPainter painter(&image);
    painter.setRenderHint(QPainter::Antialiasing, false);
    QPen pen(QColor(0, 255, 0));
    pen.setWidth(2);
    painter.setPen(pen);
    painter.drawLine(QPointF(clampedX, y0), QPointF(clampedX, y1));
    painter.drawLine(QPointF(x0, clampedY), QPointF(x1, clampedY));
    painter.end();
    QImage rgbImage = image.convertToFormat(QImage::Format_RGB888);
    int width = rgbImage.width();
    int height = rgbImage.height();
    if (width <= 0 || height <= 0) {
        return frame;
    }
    QVideoFrame resultFrame(width * height * 3 / 2, QSize(width, height), width, QVideoFrame::Format_YUV420P);
    if (!resultFrame.map(QAbstractVideoBuffer::WriteOnly)) {
        return frame;
    }
    uchar* yData = resultFrame.bits(0);
    uchar* uData = resultFrame.bits(1);
    uchar* vData = resultFrame.bits(2);
    int yStride = resultFrame.bytesPerLine(0);
    int uStride = resultFrame.bytesPerLine(1);
    int vStride = resultFrame.bytesPerLine(2);
    const uchar* rgbData = rgbImage.constBits();
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int rgbIndex = (y * width + x) * 3;
            int yIndex = y * yStride + x;
            int r = rgbData[rgbIndex];
            int g = rgbData[rgbIndex + 1];
            int b = rgbData[rgbIndex + 2];
            int Y = (66 * r + 129 * g + 25 * b + 128) >> 8;
            Y = qBound(0, Y, 255);
            yData[yIndex] = static_cast<uchar>(Y);
            if (x % 2 == 0 && y % 2 == 0) {
                int uvIndex = (y / 2) * (width / 2) + (x / 2);
                int U = (-38 * r - 74 * g + 112 * b + 128) >> 8;
                int V = (112 * r - 94 * g - 18 * b + 128) >> 8;
                U = qBound(0, U + 128, 255);
                V = qBound(0, V + 128, 255);
                uData[uvIndex] = static_cast<uchar>(U);
                vData[uvIndex] = static_cast<uchar>(V);
            }
        }
    }
    resultFrame.unmap();
    return resultFrame;
#endif
}

Q_INVOKABLE bool FrameProvider::mbIsNoSignal(){
    return nosignal_count_ == 0 ? true : false;
}

void FrameProvider::OnNoSignalTimeout(){
    nosignal_count_ > 0 ? nosignal_count_-- : nosignal_count_ = 0;
}

void FrameProvider::clearFrameData()
{
    qDebug() << "FrameProvider::clearFrameData called";
    
    // 清理当前帧数据
    {
        QMutexLocker locker(&m_frameMutex);
        m_currentFrame = QVideoFrame(); // 重置为空帧
    }
    
    // 停止所有视频表面
    for (auto it = m_surfaces.begin(); it != m_surfaces.end(); ++it) {
        QPointer<QAbstractVideoSurface> surface = *it;
        if (surface && surface->isActive()) {
            qDebug() << "FrameProvider: Stopping video surface";
            surface->stop();
        }
    }
    
    // 重置格式
    m_format = QVideoSurfaceFormat();
    
    // 重置无信号相关状态
    nosignal_count_ = 0;
    if (nosignal_timer_.isActive()) {
        nosignal_timer_.stop();
    }
    
    // 清理缓存图像
    first_buf_img_ = QImage();
    second_buf_img_ = QImage();
    
    qDebug() << "FrameProvider: Frame data cleared successfully";
}

void FrameProvider::disconnectAll()
{
    qDebug() << "FrameProvider::disconnectAll called";
    
    // 断开这个对象的所有信号和槽连接
    disconnect(this, nullptr, nullptr, nullptr);
    
    // 断开所有连接到这个对象的信号
    QObject::disconnect(nullptr, nullptr, this, nullptr);
    
    qDebug() << "FrameProvider: All connections disconnected";
}
