#ifndef ZLM_RTSP_FORWARD_SERVER_H
#define ZLM_RTSP_FORWARD_SERVER_H

#include <cstdint>
#include <mutex>
#include <string>
#include <unordered_map>

#include <mk_mediakit.h>

class ZlmRtspForwardServer {
public:
    using ProxyId = uint64_t;

    struct StartOptions {
        uint16_t rtsp_port = 554;
        bool rtsp_ssl = false;
        int thread_num = 0;
        int log_level = 0;
        int log_mask = LOG_CONSOLE;
        std::string ini_path;
        std::string log_file_path;
        int log_file_days = 0;
        std::string ssl_path;
        std::string ssl_pwd;
    };

    struct ProxyOptions {
        std::string vhost = "__defaultVhost__";
        std::string app = "live";
        std::string stream = "proxy";
        bool hls_enabled = false;
        bool mp4_enabled = false;
        int retry_count = -1;
    };

    ZlmRtspForwardServer() = default;
    ~ZlmRtspForwardServer();

    bool start(const StartOptions& options);
    bool start();
    void stop();
    bool isRunning() const;
    uint16_t rtspPort() const;

    ProxyId addRtspProxy(const std::string& url, const ProxyOptions& options);
    ProxyId addRtspProxy(const std::string& url);
    void removeProxy(ProxyId id);

private:
    struct ProxyCloseUserData {
        ZlmRtspForwardServer* self = nullptr;
        ProxyId id = 0;
    };

    struct ProxyPlayResultUserData {
        ZlmRtspForwardServer* self = nullptr;
        ProxyId id = 0;
    };

    static void API_CALL onProxyClose(void* user_data, int err, const char* what, int sys_err);
    static void API_CALL onProxyPlayResult(void* user_data, int err, const char* what, int sys_err);
    static void API_CALL freeProxyCloseUserData(void* user_data);
    static void API_CALL freeProxyPlayResultUserData(void* user_data);

    void releaseProxyLocked(ProxyId id);

    mutable std::mutex mutex_;
    bool env_inited_ = false;
    bool running_ = false;
    uint16_t rtsp_port_ = 0;
    ProxyId next_proxy_id_ = 1;
    std::unordered_map<ProxyId, mk_proxy_player> proxies_;
};

#endif
