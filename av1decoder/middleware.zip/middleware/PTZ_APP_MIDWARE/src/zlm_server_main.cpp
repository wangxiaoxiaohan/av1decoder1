#include "zlm_rtsp_forward_server.h"
#include "dual_stream_processor.h"
#include "onvif/onvif_server.h"

#include <QGuiApplication>
#include <QTimer>
#include <QDebug>
#include <QNetworkInterface>

#include <atomic>
#include <csignal>
#include <cstdint>
#include <cstdlib>
#include <iostream>
#include <string>
#include <thread>
#include <vector>

namespace {
std::atomic<bool> g_stop{false};

void handleSignal(int) {
    g_stop.store(true);
}

uint16_t parsePort(const char* s, uint16_t fallback) {
    if (!s || !*s) {
        return fallback;
    }
    const long v = std::strtol(s, nullptr, 10);
    if (v <= 0 || v > 65535) {
        return fallback;
    }
    return static_cast<uint16_t>(v);
}
}

int main(int argc, char** argv) {
    // Ensure Qt runs in offscreen mode (headless)
    qputenv("QT_QPA_PLATFORM", "offscreen");

    QGuiApplication app(argc, argv);

    std::signal(SIGINT, handleSignal);
    std::signal(SIGTERM, handleSignal);

    // Default configuration
    uint16_t port = 554;
    // You can parse arguments to populate this list dynamically in the future
    // For now, we just demonstrate one group as per original code, but structured for more.
    struct StreamConfig {
        QString visibleUrl;
        QString infraredUrl;
        QString outputUrl;
    };
    
    std::vector<StreamConfig> configs;

    // Example: Add default config
    // Note: In a real scenario, you might read these from a config file
    StreamConfig defaultCfg;
    if (argc >= 4) {
        defaultCfg.visibleUrl = QString::fromLocal8Bit(argv[2]);
        defaultCfg.infraredUrl = QString::fromLocal8Bit(argv[3]);
    } else {
        defaultCfg.visibleUrl = "rtsp://admin:123456@192.168.1.190/video2";
        defaultCfg.infraredUrl = "rtsp://admin:system123@192.168.1.2:554/live?channel=0&subtype=1";
    }

    configs.push_back(defaultCfg);

    if (argc >= 2) port = parsePort(argv[1], 554);

    std::cout << "Usage: " << argv[0] << " [port] [visible_rtsp_url] [infrared_rtsp_url]\n";
    std::cout << "Using Port: " << port << "\n";

    ZlmRtspForwardServer server;
    ZlmRtspForwardServer::StartOptions opt;
    opt.log_mask = LOG_CONSOLE;
    opt.rtsp_port = port;

    if (!server.start(opt)) {
        std::cerr << "ZLMediaKit RTSP server start failed\n";
        return 1;
    }

    std::cout << "ZLMediaKit RTSP server started on port " << server.rtspPort() << "\n";

    // 获取本机IP地址
    QString localIp;
    const auto interfaces = QNetworkInterface::allInterfaces();
    for (const auto& iface : interfaces) {
        if (iface.flags() & QNetworkInterface::IsUp &&
            iface.flags() & QNetworkInterface::IsRunning &&
            !(iface.flags() & QNetworkInterface::IsLoopBack)) {
            for (const auto& addr : iface.addressEntries()) {
                if (addr.ip().protocol() == QAbstractSocket::IPv4Protocol) {
                    localIp = addr.ip().toString();
                    break;
                }
            }
        }
        if (!localIp.isEmpty()) break;
    }

    if (localIp.isEmpty()) {
        localIp = "192.168.1.199"; // 默认IP
    }

    std::cout << "Local IP: " << localIp.toStdString() << "\n";

    // 启动ONVIF服务
    OnvifServer onvifServer(&app);
    OnvifServerConfig onvifConfig;
    onvifConfig.deviceName = "PTZ Dual Stream Camera";
    onvifConfig.manufacturer = "Custom";
    onvifConfig.model = "PTZ-ONVIF-DS";
    onvifConfig.firmwareVersion = "1.0.0";
    onvifConfig.serialNumber = "SN001";
    onvifConfig.hardwareId = "PTZ001";
    onvifConfig.ipAddress = localIp;
    onvifConfig.httpPort = 8082;  // ONVIF HTTP服务端口 (Changed from 8080 to avoid conflict)
    onvifConfig.rtspPort = server.rtspPort();

    if (onvifServer.start(onvifConfig)) {
        std::cout << "ONVIF server started on port " << onvifConfig.httpPort << "\n";
        std::cout << "Device Service URL: " << onvifServer.getDeviceServiceUrl().toStdString() << "\n";
        std::cout << "Media Service URL: " << onvifServer.getMediaServiceUrl().toStdString() << "\n";
    } else {
        std::cerr << "Failed to start ONVIF server\n";
    }

    std::vector<DualStreamProcessor*> processors;

    int index = 0;
    for (auto& cfg : configs) {
        // 使用海康兼容的 RTSP 路径格式
        QString outputUrl = QString("rtsp://%1/Streaming/Channels/10%2").arg(localIp).arg(index);
        std::cout << "Configuring Group " << index << ":\n";
        std::cout << "  Vis: " << cfg.visibleUrl.toStdString() << "\n";
        std::cout << "  IR:  " << cfg.infraredUrl.toStdString() << "\n";
        std::cout << "  Out: " << outputUrl.toStdString() << "\n";

        // 更新 ONVIF 的 RTSP 路径（使用第一个流）
        if (index == 0) {
            onvifServer.setRtspPath(QString("/Streaming/Channels/10%1").arg(index));
            std::cout << "  ONVIF RTSP Path: /Streaming/Channels/10" << index << "\n";
        }

        DualStreamProcessor* processor = new DualStreamProcessor(&app);
        if (processor->start(cfg.visibleUrl, cfg.infraredUrl, outputUrl)) {
            processors.push_back(processor);
        } else {
            std::cerr << "Failed to start processor for group " << index << "\n";
        }
        index++;
    }

    // Main Loop Timer for Stop Signal and ONVIF resolution update
    QTimer timer;
    QObject::connect(&timer, &QTimer::timeout, [&app, &processors, &onvifServer]() {
        if (g_stop.load()) {
            app.quit();
            return;
        }
        
        // 定期更新 ONVIF 分辨率（使用第一个处理器的分辨率）
        if (!processors.empty()) {
            int width = 0, height = 0;
            if (processors[0]->getOutputResolution(width, height)) {
                onvifServer.setVideoResolution(width, height);
            }
        }
    });
    timer.start(100); // Check stop signal and update resolution every 100ms

    // Run Qt Event Loop
    int ret = app.exec();

    // Cleanup
    // Processors are children of 'app', so they will be deleted when app is destroyed.
    // But we can stop them explicitly to be safe/clean.
    for (auto* p : processors) {
        p->stop();
    }
    
    server.stop();
    std::cout << "Server stopped.\n";

    return ret;
}
