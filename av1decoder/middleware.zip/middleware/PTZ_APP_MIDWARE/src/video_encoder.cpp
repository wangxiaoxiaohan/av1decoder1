#include "video_encoder.h"

#include <QAbstractVideoBuffer>
#include <QVideoFrame>

extern "C" {
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
#include <libavutil/error.h>
#include <libavutil/imgutils.h>
#include <libavutil/opt.h>
#include <libswscale/swscale.h>
}

static QString ffmpegErrorToString(int errnum)
{
    char buf[AV_ERROR_MAX_STRING_SIZE] = {0};
    av_strerror(errnum, buf, sizeof(buf));
    return QString::fromUtf8(buf);
}

static AVPixelFormat qtVideoPixelFormatToAv(QVideoFrame::PixelFormat fmt)
{
    switch (fmt) {
        case QVideoFrame::Format_YUV420P:
            return AV_PIX_FMT_YUV420P;
        case QVideoFrame::Format_NV12:
            return AV_PIX_FMT_NV12;
        case QVideoFrame::Format_RGB32:
        case QVideoFrame::Format_ARGB32:
            return AV_PIX_FMT_BGRA;
        case QVideoFrame::Format_RGB24:
            return AV_PIX_FMT_RGB24;
        default:
            return AV_PIX_FMT_NONE;
    }
}

VideoEncoder::VideoEncoder()
    : m_requested(false),
      m_active(false),
      m_swsCtx(nullptr),
      m_fmtCtx(nullptr),
      m_codecCtx(nullptr),
      m_stream(nullptr),
      m_frame(nullptr),
      m_frameIndex(0)
{
}

VideoEncoder::~VideoEncoder()
{
    stop();
}

bool VideoEncoder::start(const VideoEncodingConfig& config)
{
    if (m_requested || m_active) {
        return false;
    }
    if (config.filePath.isEmpty()) {
        m_lastError = "filePath is empty";
        return false;
    }
    if (config.fps <= 0) {
        m_lastError = "fps is invalid";
        return false;
    }
    if (config.bitrateKbps <= 0) {
        m_lastError = "bitrateKbps is invalid";
        return false;
    }

    m_config = config;
    m_lastError.clear();
    m_requested = true;
    m_active = false;
    m_frameIndex = 0;
    cleanup();
    return true;
}

void VideoEncoder::stop()
{
    if (!m_requested && !m_active) {
        return;
    }

    if (m_codecCtx) {
        avcodec_send_frame(m_codecCtx, nullptr);
        AVPacket* pkt = av_packet_alloc();
        if (!pkt) {
            m_lastError = "av_packet_alloc failed";
        } else {
            while (true) {
                av_packet_unref(pkt);
                int ret = avcodec_receive_packet(m_codecCtx, pkt);
                if (ret == 0) {
                    if (m_fmtCtx && m_stream) {
                        av_packet_rescale_ts(pkt, m_codecCtx->time_base, m_stream->time_base);
                        pkt->stream_index = m_stream->index;
                        av_interleaved_write_frame(m_fmtCtx, pkt);
                    }
                    continue;
                }
                break;
            }
            av_packet_free(&pkt);
        }
    }

    if (m_fmtCtx) {
        av_write_trailer(m_fmtCtx);
        if (!(m_fmtCtx->oformat->flags & AVFMT_NOFILE) && m_fmtCtx->pb) {
            avio_closep(&m_fmtCtx->pb);
        }
    }

    cleanup();
    m_requested = false;
    m_active = false;
}

void VideoEncoder::encodeFrameIfNeeded(const QVideoFrame& frame)
{
    if (!m_requested && !m_active) {
        return;
    }
    if (!frame.isValid()) {
        return;
    }
    if (!m_active) {
        if (!ensureInitialized(frame)) {
            m_requested = false;
            m_active = false;
            return;
        }
        m_active = true;
    }
    if (!m_codecCtx || !m_fmtCtx || !m_stream || !m_frame) {
        m_lastError = "encoder not initialized";
        m_requested = false;
        m_active = false;
        cleanup();
        return;
    }

    QVideoFrame inFrame(frame);
    if (!inFrame.map(QAbstractVideoBuffer::ReadOnly)) {
        m_lastError = "failed to map input frame";
        return;
    }

    AVPixelFormat inFmt = qtVideoPixelFormatToAv(inFrame.pixelFormat());
    if (inFmt == AV_PIX_FMT_NONE) {
        inFmt = AV_PIX_FMT_BGRA;
    }

    if (m_frame->width != inFrame.width() || m_frame->height != inFrame.height()) {
        m_lastError = "frame size changed during encoding";
        inFrame.unmap();
        stop();
        return;
    }

    int ret = av_frame_make_writable(m_frame);
    if (ret < 0) {
        m_lastError = "av_frame_make_writable failed: " + ffmpegErrorToString(ret);
        inFrame.unmap();
        return;
    }

    if (inFmt == AV_PIX_FMT_YUV420P) {
        const uint8_t* srcData[4] = {inFrame.bits(0), inFrame.bits(1), inFrame.bits(2), nullptr};
        int srcLinesize[4] = {inFrame.bytesPerLine(0), inFrame.bytesPerLine(1), inFrame.bytesPerLine(2), 0};
        av_image_copy(m_frame->data, m_frame->linesize, srcData, srcLinesize, AV_PIX_FMT_YUV420P, inFrame.width(), inFrame.height());
    } else {
        const uint8_t* srcData[4] = {inFrame.bits(0), inFrame.bits(1), inFrame.bits(2), inFrame.bits(3)};
        int srcLinesize[4] = {inFrame.bytesPerLine(0), inFrame.bytesPerLine(1), inFrame.bytesPerLine(2), inFrame.bytesPerLine(3)};
        if (!m_swsCtx) {
            m_swsCtx = sws_getContext(
                inFrame.width(),
                inFrame.height(),
                inFmt,
                inFrame.width(),
                inFrame.height(),
                AV_PIX_FMT_YUV420P,
                SWS_BILINEAR,
                nullptr,
                nullptr,
                nullptr
            );
            if (!m_swsCtx) {
                m_lastError = "sws_getContext failed";
                inFrame.unmap();
                stop();
                return;
            }
        }
        sws_scale(m_swsCtx, srcData, srcLinesize, 0, inFrame.height(), m_frame->data, m_frame->linesize);
    }
    inFrame.unmap();

    m_frame->pts = m_frameIndex;
    m_frame->pkt_dts = m_frameIndex;
    m_frameIndex++;
    ret = avcodec_send_frame(m_codecCtx, m_frame);
    if (ret < 0) {
        m_lastError = "avcodec_send_frame failed: " + ffmpegErrorToString(ret);
        return;
    }

    AVPacket* pkt = av_packet_alloc();
    if (!pkt) {
        m_lastError = "av_packet_alloc failed";
        return;
    }
    while (true) {
        av_packet_unref(pkt);
        ret = avcodec_receive_packet(m_codecCtx, pkt);
        if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF) {
            break;
        }
        if (ret < 0) {
            m_lastError = "avcodec_receive_packet failed: " + ffmpegErrorToString(ret);
            break;
        }
        av_packet_rescale_ts(pkt, m_codecCtx->time_base, m_stream->time_base);
        pkt->stream_index = m_stream->index;
        int writeRet = av_interleaved_write_frame(m_fmtCtx, pkt);
        if (writeRet < 0) {
            m_lastError = "av_interleaved_write_frame failed: " + ffmpegErrorToString(writeRet);
            break;
        }
    }
    av_packet_free(&pkt);
}

bool VideoEncoder::ensureInitialized(const QVideoFrame& firstFrame)
{
    if (!m_requested) {
        return false;
    }
    if (m_fmtCtx || m_codecCtx || m_stream || m_frame) {
        return true;
    }

    static bool s_networkInited = false;
    if (!s_networkInited) {
        avformat_network_init();
        s_networkInited = true;
    }

    QString codecLower = m_config.codec.trimmed().toLower();
    AVCodecID codecId = AV_CODEC_ID_H264;
    const char* encoderName = nullptr;
    // if (codecLower == "h265" || codecLower == "hevc" || codecLower == "x265") {
    //     codecId = AV_CODEC_ID_HEVC;
    //     encoderName = "libx265";
    // } else {
    //     codecId = AV_CODEC_ID_H264;
    //     encoderName = "libx264";
    // }
     codecId = AV_CODEC_ID_H264;
     encoderName = "libx264";
    const AVCodec* codec = avcodec_find_encoder_by_name(encoderName);
    if (!codec) {
        codec = avcodec_find_encoder(codecId);
    }
    if (!codec) {
        m_lastError = "encoder not found for codec: " + m_config.codec;
        return false;
    }

    QByteArray formatUtf8 = m_config.format.toUtf8();
    QByteArray fileUtf8 = m_config.filePath.toUtf8();
    int ret = avformat_alloc_output_context2(&m_fmtCtx, nullptr,
                                            formatUtf8.isEmpty() ? nullptr : formatUtf8.constData(),
                                            fileUtf8.constData());
    if (ret < 0 || !m_fmtCtx) {
        m_lastError = "avformat_alloc_output_context2 failed: " + ffmpegErrorToString(ret);
        cleanup();
        return false;
    }

    av_opt_set_int(m_fmtCtx, "flush_packets", 1, AV_OPT_SEARCH_CHILDREN);
    m_fmtCtx->flags |= AVFMT_FLAG_NOBUFFER;

    m_stream = avformat_new_stream(m_fmtCtx, nullptr);
    if (!m_stream) {
        m_lastError = "avformat_new_stream failed";
        cleanup();
        return false;
    }

    m_codecCtx = avcodec_alloc_context3(codec);
    if (!m_codecCtx) {
        m_lastError = "avcodec_alloc_context3 failed";
        cleanup();
        return false;
    }

    int width = firstFrame.width();
    int height = firstFrame.height();
    if (width <= 0 || height <= 0) {
        m_lastError = "invalid frame size";
        cleanup();
        return false;
    }

    m_codecCtx->codec_id = codecId;
    m_codecCtx->codec_type = AVMEDIA_TYPE_VIDEO;
    m_codecCtx->width = width;
    m_codecCtx->height = height;
    m_codecCtx->pix_fmt = AV_PIX_FMT_YUV420P;
    m_codecCtx->time_base = AVRational{1, m_config.fps};
    m_codecCtx->framerate = AVRational{m_config.fps, 1};
    m_codecCtx->bit_rate = static_cast<int64_t>(m_config.bitrateKbps) * 1000;
    m_codecCtx->gop_size = m_config.fps;
    m_codecCtx->max_b_frames = 0;
    m_codecCtx->keyint_min = m_config.fps;

    if (m_fmtCtx->oformat && (m_fmtCtx->oformat->flags & AVFMT_GLOBALHEADER)) {
        m_codecCtx->flags |= AV_CODEC_FLAG_GLOBAL_HEADER;
    }

    AVDictionary* opts = nullptr;
    if (codecId == AV_CODEC_ID_H264) {
        av_dict_set(&opts, "preset", "ultrafast", 0);
        av_dict_set(&opts, "tune", "zerolatency", 0);
        av_dict_set(&opts, "profile", "baseline", 0);
        av_dict_set(&opts, "level", "3.1", 0);
        av_dict_set(&opts, "x264opts", "keyint=25:min-keyint=25:no-scenecut:force-cfr", 0);
    } else if (codecId == AV_CODEC_ID_HEVC) {
        av_dict_set(&opts, "preset", "ultrafast", 0);
        av_dict_set(&opts, "tune", "zerolatency", 0);
    }

    ret = avcodec_open2(m_codecCtx, codec, &opts);
    av_dict_free(&opts);
    if (ret < 0) {
        m_lastError = "avcodec_open2 failed: " + ffmpegErrorToString(ret);
        cleanup();
        return false;
    }

    m_stream->time_base = m_codecCtx->time_base;
    ret = avcodec_parameters_from_context(m_stream->codecpar, m_codecCtx);
    if (ret < 0) {
        m_lastError = "avcodec_parameters_from_context failed: " + ffmpegErrorToString(ret);
        cleanup();
        return false;
    }

    if (!(m_fmtCtx->oformat->flags & AVFMT_NOFILE)) {
        AVDictionary* ioOpts = nullptr;
        const QString urlLower = m_config.filePath.trimmed().toLower();
        if (urlLower.contains("://")) {
            av_dict_set(&ioOpts, "rw_timeout", "5000000", 0);
        }

        ret = avio_open2(&m_fmtCtx->pb, fileUtf8.constData(), AVIO_FLAG_WRITE, nullptr, &ioOpts);
        av_dict_free(&ioOpts);
        if (ret < 0) {
            m_lastError = "avio_open failed: " + ffmpegErrorToString(ret);
            cleanup();
            return false;
        }
    }

    AVDictionary* muxOpts = nullptr;
    if (m_config.format.trimmed().toLower() == "flv") {
        av_dict_set(&muxOpts, "flvflags", "no_duration_filesize", 0);
    }

    ret = avformat_write_header(m_fmtCtx, &muxOpts);
    av_dict_free(&muxOpts);
    if (ret < 0) {
        m_lastError = "avformat_write_header failed: " + ffmpegErrorToString(ret);
        cleanup();
        return false;
    }

    m_frame = av_frame_alloc();
    if (!m_frame) {
        m_lastError = "av_frame_alloc failed";
        cleanup();
        return false;
    }
    m_frame->format = m_codecCtx->pix_fmt;
    m_frame->width = m_codecCtx->width;
    m_frame->height = m_codecCtx->height;
    ret = av_frame_get_buffer(m_frame, 32);
    if (ret < 0) {
        m_lastError = "av_frame_get_buffer failed: " + ffmpegErrorToString(ret);
        cleanup();
        return false;
    }

    m_frameIndex = 0;
    return true;
}

void VideoEncoder::cleanup()
{
    if (m_swsCtx) {
        sws_freeContext(m_swsCtx);
        m_swsCtx = nullptr;
    }
    if (m_frame) {
        av_frame_free(&m_frame);
    }
    if (m_codecCtx) {
        avcodec_free_context(&m_codecCtx);
    }
    if (m_fmtCtx) {
        if (m_fmtCtx->pb && !(m_fmtCtx->oformat->flags & AVFMT_NOFILE)) {
            avio_closep(&m_fmtCtx->pb);
        }
        avformat_free_context(m_fmtCtx);
        m_fmtCtx = nullptr;
    }
    m_stream = nullptr;
    m_frameIndex = 0;
}
