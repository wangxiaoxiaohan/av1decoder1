#include "stitched_streamer.h"

#include <QVideoFrame>
#include <QAbstractVideoBuffer>
#include <QDateTime>

extern "C" {
#include <libavutil/imgutils.h>
#include <libswscale/swscale.h>
#include <libavutil/frame.h>
}

static AVPixelFormat qtVideoPixelFormatToAv(QVideoFrame::PixelFormat fmt)
{
    switch (fmt) {
    case QVideoFrame::Format_YUV420P:
        return AV_PIX_FMT_YUV420P;
    case QVideoFrame::Format_NV12:
        return AV_PIX_FMT_NV12;
    case QVideoFrame::Format_RGB32:
    case QVideoFrame::Format_ARGB32:
        return AV_PIX_FMT_BGRA;
    case QVideoFrame::Format_RGB24:
        return AV_PIX_FMT_RGB24;
    default:
        return AV_PIX_FMT_NONE;
    }
}

StitchedStreamer::StitchedStreamer()
    : m_visibleProvider(nullptr)
    , m_infraredProvider(nullptr)
    , m_requested(false)
    , m_lastEncodeMs(0)
    , m_outWidth(0)
    , m_outHeight(0)
    , m_visibleOutWidth(0)
    , m_infraredOutWidth(0)
    , m_visibleInFmt(QVideoFrame::Format_Invalid)
    , m_infraredInFmt(QVideoFrame::Format_Invalid)
    , m_visibleInWidth(0)
    , m_visibleInHeight(0)
    , m_infraredInWidth(0)
    , m_infraredInHeight(0)
    , m_visibleSws(nullptr)
    , m_infraredSws(nullptr)
    , m_outFrame(nullptr)
{
}

StitchedStreamer::~StitchedStreamer()
{
    stop();
}

bool StitchedStreamer::start(FrameProvider* visibleProvider,
                             FrameProvider* infraredProvider,
                             const QString& outputUrl,
                             const QString& codec,
                             int fps,
                             int bitrateKbps,
                             const QString& format)
{
    if (!visibleProvider || !infraredProvider) {
        m_lastError = "invalid providers";
        return false;
    }
    if (outputUrl.isEmpty()) {
        m_lastError = "output url is empty";
        return false;
    }
    if (fps <= 0 || bitrateKbps <= 0) {
        m_lastError = "invalid fps or bitrate";
        return false;
    }

    m_visibleProvider = visibleProvider;
    m_infraredProvider = infraredProvider;

    m_encoderConfig.filePath = outputUrl;
    m_encoderConfig.codec = codec;
    m_encoderConfig.format = format;
    m_encoderConfig.fps = fps;
    m_encoderConfig.bitrateKbps = bitrateKbps;

    resetPipeline();

    if (!m_encoder.start(m_encoderConfig)) {
        m_lastError = m_encoder.lastError();
        m_requested = false;
        return false;
    }

    m_requested = true;
    m_lastEncodeMs = 0;
    m_lastError.clear();
    return true;
}

void StitchedStreamer::stop()
{
    if (!m_requested) {
        return;
    }

    m_encoder.stop();
    resetPipeline();

    m_visibleProvider = nullptr;
    m_infraredProvider = nullptr;
    m_requested = false;
}

void StitchedStreamer::setProviders(FrameProvider* visibleProvider,
                                    FrameProvider* infraredProvider)
{
    m_visibleProvider = visibleProvider;
    m_infraredProvider = infraredProvider;
}

void StitchedStreamer::tick()
{
    if (!m_requested) {
        return;
    }

    qint64 nowMs = QDateTime::currentMSecsSinceEpoch();
    if (m_encoderConfig.fps > 0) {
        qint64 interval = 1000 / m_encoderConfig.fps;
        if (m_lastEncodeMs > 0 && nowMs - m_lastEncodeMs < interval) {
            return;
        }
    }

    if (!m_visibleProvider || !m_infraredProvider) {
        return;
    }

    QVideoFrame visibleFrame = m_visibleProvider->getCurrentFrame();
    QVideoFrame infraredFrame = m_infraredProvider->getCurrentFrame();

    if (!visibleFrame.isValid() || !infraredFrame.isValid()) {
        return;
    }

    int prevOutW = m_outWidth;
    int prevOutH = m_outHeight;
    if (!ensurePipelineForFrames(visibleFrame, infraredFrame)) {
        return;
    }
    if ((prevOutW != 0 && prevOutH != 0) && (m_outWidth != prevOutW || m_outHeight != prevOutH)) {
        m_encoder.stop();
        if (!m_encoder.start(m_encoderConfig)) {
            m_lastError = m_encoder.lastError();
            m_requested = false;
            return;
        }
    }

    if (!composeToOutput(visibleFrame, infraredFrame)) {
        return;
    }

    if (!m_outFrame) {
        return;
    }

    QVideoFrame outFrame;
    int bufferSize = av_image_get_buffer_size(AV_PIX_FMT_YUV420P, m_outWidth, m_outHeight, 32);
    if (bufferSize <= 0) {
        return;
    }

    outFrame = QVideoFrame(bufferSize, QSize(m_outWidth, m_outHeight), m_outWidth, QVideoFrame::Format_YUV420P);
    if (!outFrame.map(QAbstractVideoBuffer::WriteOnly)) {
        return;
    }

    uint8_t* dstData[4] = {
        outFrame.bits(0),
        outFrame.bits(1),
        outFrame.bits(2),
        nullptr
    };
    int dstLinesize[4] = {
        outFrame.bytesPerLine(0),
        outFrame.bytesPerLine(1),
        outFrame.bytesPerLine(2),
        0
    };

    const uint8_t* srcData[4] = {
        m_outFrame->data[0],
        m_outFrame->data[1],
        m_outFrame->data[2],
        nullptr
    };
    int srcLinesize[4] = {
        m_outFrame->linesize[0],
        m_outFrame->linesize[1],
        m_outFrame->linesize[2],
        0
    };

    av_image_copy(dstData, dstLinesize, srcData, srcLinesize, AV_PIX_FMT_YUV420P, m_outWidth, m_outHeight);

    outFrame.unmap();

    m_encoder.encodeFrameIfNeeded(outFrame);
    m_lastEncodeMs = nowMs;
}

void StitchedStreamer::resetPipeline()
{
    if (m_visibleSws) {
        sws_freeContext(m_visibleSws);
        m_visibleSws = nullptr;
    }
    if (m_infraredSws) {
        sws_freeContext(m_infraredSws);
        m_infraredSws = nullptr;
    }
    if (m_outFrame) {
        av_frame_free(&m_outFrame);
        m_outFrame = nullptr;
    }
    m_outWidth = 0;
    m_outHeight = 0;
    m_visibleOutWidth = 0;
    m_infraredOutWidth = 0;
    m_visibleInFmt = QVideoFrame::Format_Invalid;
    m_infraredInFmt = QVideoFrame::Format_Invalid;
    m_visibleInWidth = 0;
    m_visibleInHeight = 0;
    m_infraredInWidth = 0;
    m_infraredInHeight = 0;
}

bool StitchedStreamer::ensurePipelineForFrames(const QVideoFrame& visibleFrame, const QVideoFrame& infraredFrame)
{
    int visW = visibleFrame.width();
    int visH = visibleFrame.height();
    int irW = infraredFrame.width();
    int irH = infraredFrame.height();
    QVideoFrame::PixelFormat visQtFmt = visibleFrame.pixelFormat();
    QVideoFrame::PixelFormat irQtFmt = infraredFrame.pixelFormat();

    if (visW <= 0 || visH <= 0 || irW <= 0 || irH <= 0) {
        return false;
    }

    int targetHeight = visH > irH ? visH : irH;
    if (targetHeight & 1) {
        targetHeight += 1;
    }
    int visOutW = visW * targetHeight / visH;
    int irOutW = irW * targetHeight / irH;
    if (visOutW & 1) {
        visOutW += 1;
    }
    if (irOutW & 1) {
        irOutW += 1;
    }

    if (visOutW <= 0 || irOutW <= 0) {
        return false;
    }

    int outW = visOutW + irOutW;
    if (outW & 1) {
        outW += 1;
    }

    if (m_outFrame &&
        m_outWidth == outW &&
        m_outHeight == targetHeight &&
        m_visibleOutWidth == visOutW &&
        m_infraredOutWidth == irOutW &&
        m_visibleInWidth == visW &&
        m_visibleInHeight == visH &&
        m_infraredInWidth == irW &&
        m_infraredInHeight == irH &&
        m_visibleInFmt == visQtFmt &&
        m_infraredInFmt == irQtFmt) {
        return true;
    }

    resetPipeline();

    m_outFrame = av_frame_alloc();
    if (!m_outFrame) {
        m_lastError = "failed to alloc out frame";
        return false;
    }
    m_outFrame->format = AV_PIX_FMT_YUV420P;
    m_outFrame->width = outW;
    m_outFrame->height = targetHeight;
    int ret = av_frame_get_buffer(m_outFrame, 32);
    if (ret < 0) {
        av_frame_free(&m_outFrame);
        m_lastError = "failed to get frame buffer";
        return false;
    }

    AVPixelFormat visFmt = qtVideoPixelFormatToAv(visQtFmt);
    AVPixelFormat irFmt = qtVideoPixelFormatToAv(irQtFmt);

    if (visFmt == AV_PIX_FMT_NONE) {
        visFmt = AV_PIX_FMT_BGRA;
    }
    if (irFmt == AV_PIX_FMT_NONE) {
        irFmt = AV_PIX_FMT_BGRA;
    }

    m_visibleSws = sws_getContext(visW, visH, visFmt,
                                  visOutW, targetHeight, AV_PIX_FMT_YUV420P,
                                  SWS_BILINEAR, nullptr, nullptr, nullptr);
    m_infraredSws = sws_getContext(irW, irH, irFmt,
                                   irOutW, targetHeight, AV_PIX_FMT_YUV420P,
                                   SWS_BILINEAR, nullptr, nullptr, nullptr);
    if (!m_visibleSws || !m_infraredSws) {
        m_lastError = "failed to create sws context";
        return false;
    }

    m_outWidth = outW;
    m_outHeight = targetHeight;
    m_visibleOutWidth = visOutW;
    m_infraredOutWidth = irOutW;
    m_visibleInFmt = visQtFmt;
    m_infraredInFmt = irQtFmt;
    m_visibleInWidth = visW;
    m_visibleInHeight = visH;
    m_infraredInWidth = irW;
    m_infraredInHeight = irH;

    return true;
}

bool StitchedStreamer::composeToOutput(const QVideoFrame& visibleFrame, const QVideoFrame& infraredFrame)
{
    if (!m_outFrame || !m_visibleSws || !m_infraredSws) {
        return false;
    }

    QVideoFrame vis(visibleFrame);
    QVideoFrame ir(infraredFrame);
    if (!vis.map(QAbstractVideoBuffer::ReadOnly)) {
        return false;
    }
    if (!ir.map(QAbstractVideoBuffer::ReadOnly)) {
        vis.unmap();
        return false;
    }

    const uint8_t* visData[4] = {
        vis.bits(0),
        vis.bits(1),
        vis.bits(2),
        vis.bits(3)
    };
    int visLinesize[4] = {
        vis.bytesPerLine(0),
        vis.bytesPerLine(1),
        vis.bytesPerLine(2),
        vis.bytesPerLine(3)
    };

    const uint8_t* irData[4] = {
        ir.bits(0),
        ir.bits(1),
        ir.bits(2),
        ir.bits(3)
    };
    int irLinesize[4] = {
        ir.bytesPerLine(0),
        ir.bytesPerLine(1),
        ir.bytesPerLine(2),
        ir.bytesPerLine(3)
    };

    av_frame_make_writable(m_outFrame);

    uint8_t* dstVisData[4];
    int dstVisLinesize[4];
    uint8_t* dstIrData[4];
    int dstIrLinesize[4];

    dstVisData[0] = m_outFrame->data[0];
    dstVisLinesize[0] = m_outFrame->linesize[0];
    dstIrData[0] = m_outFrame->data[0] + m_visibleOutWidth;
    dstIrLinesize[0] = m_outFrame->linesize[0];

    dstVisData[1] = m_outFrame->data[1];
    dstVisLinesize[1] = m_outFrame->linesize[1];
    dstIrData[1] = m_outFrame->data[1] + m_visibleOutWidth / 2;
    dstIrLinesize[1] = m_outFrame->linesize[1];

    dstVisData[2] = m_outFrame->data[2];
    dstVisLinesize[2] = m_outFrame->linesize[2];
    dstIrData[2] = m_outFrame->data[2] + m_visibleOutWidth / 2;
    dstIrLinesize[2] = m_outFrame->linesize[2];

    dstVisData[3] = nullptr;
    dstVisLinesize[3] = 0;
    dstIrData[3] = nullptr;
    dstIrLinesize[3] = 0;

    sws_scale(m_visibleSws,
              visData, visLinesize,
              0, vis.height(),
              dstVisData, dstVisLinesize);

    sws_scale(m_infraredSws,
              irData, irLinesize,
              0, ir.height(),
              dstIrData, dstIrLinesize);

    vis.unmap();
    ir.unmap();
    return true;
}
