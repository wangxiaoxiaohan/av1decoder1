#ifndef DEVICEMODEL_H
#define DEVICEMODEL_H

#include <QObject>
#include <QAbstractListModel>
#include <QString>
#include <QList>
#include <QSet>
#include <QMap>
#include "devicetreemodel.h"

// 前向声明
class HikvisionCtrl;
class FrameProvider;

enum channel_index {
    live_index_0 = 0,
    live_index_1 = 1,
    live_index_2 = 2,
    live_index_3 = 3,
    live_index_4 = 4,
    live_index_5 = 5,
    live_index_6 = 6,
    live_index_7 = 7,
    live_index_8 = 8,
    live_index_9 = 9,
    record_index_1 = 10,
    record_index_2 = 11,
    record_index_3 = 12,
    record_index_4 = 13,   
    record_index_5 = 14,
    record_index_6 = 15,
    record_index_7 = 16,
    record_index_8 = 17,
};

// 设备信息结构
struct DeviceInfo {
    QString deviceId;           // 设备唯一标识
    QString deviceName;         // 设备名称
    QString deviceType;         // 设备类型 (PTZ, 固定, 热成像等)
    
    // 分离的IP地址配置
    QString visibleLightIp;     // 可见光设备IP地址
    QString infraredIp;         // 红外设备IP地址
    QString tdlasIp;            // TDLAS设备IP地址
    QString modbusIp;           // Modbus设备IP地址
    QString tofIp;              // TOF设备IP地址
    QString hikvisionIp;        // 海康设备IP地址
    
    int port;                   // 端口号
    int tdlasPort;              // TDLAS设备端口号
    int modbusPort;             // Modbus设备端口号
    int tofPort;                // TOF设备端口号
    
    // 分离的用户名和密码配置
    QString visibleLightUsername;  // 可见光设备用户名
    QString visibleLightPassword;  // 可见光设备密码
    QString infraredUsername;      // 红外设备用户名
    QString infraredPassword;      // 红外设备密码
    
    // 海康设备配置
    QString hikvisionUsername;     // 海康设备用户名
    QString hikvisionPassword;     // 海康设备密码
    int hikvisionPort;             // 海康设备端口号
    int infraredDownloadChannel;   // 红外下载通道
    int visibleLightDownloadChannel; // 可见光下载通道
    
    // 报警配置
    int alarmConcentration;     // 报警浓度值 (ppm)
    int alarmRecordDuration;    // 报警录制时长 (秒)
    int alarmOutputDuration;    // 报警输出时长(声光) (秒)
    int alarmDetectionDuration; // 报警定点检测时长 (秒)
    int cruiseIntervalDuration; // 巡航间隔时长 (毫秒)
    
    // 气体报警设置
    bool gasAlarmEnabled;       // 启用气体泄漏报警
    bool autoCaptureEnabled;    // 报警自动抓拍
    bool alarmOutputEnabled;    // 报警输出（音频）
    
    // 实时流地址
    QString visibleLightUrl;    // 可见光实时流地址
    QString infraredUrl;        // 红外实时流地址
    
    // 录像流地址
    QString visibleLightRecordUrl;  // 可见光录像流地址
    QString infraredRecordUrl;      // 红外录像流地址
    QString recordUrlbase;          // 录像URL基础部分 (如: rtsp://admin:WANG234WH@192.168.1.102:554/Streaming/tracks)
    QString groupName;          // 所属园区/分组
    bool isOnline;              // 在线状态
    bool hikvisionOnline;       // 海康设备在线状态
    bool isSelected;            // 是否被选中
    int channelIndex;           // 在显示通道中的索引
    bool isInfraredSelected;    // 是否红外被选中 (true=红外, false=可见光)
    
    // 设备状态字段
    bool laserState;            // 激光状态 (默认false)
    bool wiperState;            // 雨刷状态 (默认false)
    bool flapState;             // 挡板状态 (默认false)
    int scanMode;               // 扫描状态 (0=无扫描, 1=线扫, 2=轨迹扫描, 3=巡航, 默认0)
    QString panoramaPath;       // 全景图路径
};

// 设备分组结构
struct DeviceGroup {
    QString groupName;          // 分组名称
    QList<DeviceInfo> devices;  // 分组下的设备列表
    bool isExpanded;            // 是否展开
};

class DeviceModel : public QAbstractListModel
{
    Q_OBJECT

    Q_PROPERTY(int totalDevices READ getTotalDevices NOTIFY deviceCountsChanged)
    Q_PROPERTY(int onlineDevices READ getOnlineDevices NOTIFY deviceCountsChanged)
    Q_PROPERTY(int offlineDevices READ getOfflineDevices NOTIFY deviceCountsChanged)

public:
    enum DeviceRoles {
        DeviceIdRole = Qt::UserRole + 1,
        DeviceNameRole,
        DeviceTypeRole,
        VisibleLightIpRole,
        InfraredIpRole,
        TdlasIpRole,
        ModbusIpRole,
        TofIpRole,
        HikvisionIpRole,         // 海康设备IP地址
        PortRole,
        TdlasPortRole,
        ModbusPortRole,
        TofPortRole,
        VisibleLightUsernameRole,
        VisibleLightPasswordRole,
        InfraredUsernameRole,
        InfraredPasswordRole,
        HikvisionUsernameRole,      // 海康设备用户名
        HikvisionPasswordRole,      // 海康设备密码
        HikvisionPortRole,          // 海康设备端口
        InfraredDownloadChannelRole, // 红外下载通道
        VisibleLightDownloadChannelRole, // 可见光下载通道
        AlarmConcentrationRole,     // 报警浓度值
        AlarmRecordDurationRole,    // 报警录制时长
        AlarmOutputDurationRole,    // 报警输出时长
        AlarmDetectionDurationRole, // 报警定点检测时长
        CruiseIntervalDurationRole, // 巡航间隔时长
        GasAlarmEnabledRole,       // 启用气体泄漏报警
        AutoCaptureEnabledRole,    // 报警自动抓拍
        AlarmOutputEnabledRole,    // 报警输出（音频）
        VisibleLightUrlRole,
        InfraredUrlRole,
        VisibleLightRecordUrlRole,
        InfraredRecordUrlRole,
        RecordUrlbaseRole,           // 录像URL基础部分
        GroupNameRole,
        IsOnlineRole,
        HikvisionOnlineRole,     // 海康在线状态
        IsSelectedRole,
        ChannelIndexRole,
        IsInfraredSelectedRole,    // 是否红外被选中
        LaserStateRole,            // 激光状态
        WiperStateRole,            // 雨刷状态
        FlapStateRole,             // 挡板状态
        ScanModeRole,              // 扫描状态
        PanoramaPathRole           // 全景图路径
    };

    explicit DeviceModel(QObject *parent = nullptr);
    
    // 单例模式
    static DeviceModel* instance();
    
    // QAbstractListModel接口
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;
    
    // 设备管理方法
    Q_INVOKABLE void addDevice(const DeviceInfo &device, bool saveToFile = true);
    Q_INVOKABLE void addDevice(const QVariantMap &deviceData);
    Q_INVOKABLE void removeDevice(const QString &deviceId);
    Q_INVOKABLE void modifyDevice(const QString &deviceId, const QVariantMap &deviceData);
    Q_INVOKABLE void updateDevice(const DeviceInfo &device);
    Q_INVOKABLE DeviceInfo getDevice(const QString &deviceId);
    Q_INVOKABLE DeviceInfo getDeviceByIndex(int index);
    Q_INVOKABLE QList<DeviceInfo> getAllDevices() const;
    Q_INVOKABLE void selectDevice(const QString &deviceId);
    Q_INVOKABLE void setDeviceOnlineStatus(const QString &deviceId, bool isOnline);
    Q_INVOKABLE void setDeviceChannelIndex(const QString &deviceId, int channelIndex);
    Q_INVOKABLE int getDeviceChannelIndex(const QString &deviceId);
    Q_INVOKABLE int getChannelCount();
    Q_INVOKABLE void clearAllDevices();
    QList<int> getAllDeviceChannelIndexes() const;
    
    // 红外选中状态管理方法
    Q_INVOKABLE void setDeviceInfraredSelected(const QString &deviceId, bool isInfraredSelected);
    Q_INVOKABLE bool getDeviceInfraredSelected(const QString &deviceId);
    Q_INVOKABLE bool getSelectedDeviceInfraredSelected();
    
    // 设备状态管理方法
    Q_INVOKABLE void setDeviceLaserState(const QString &deviceId, bool laserState);
    Q_INVOKABLE bool getDeviceLaserState(const QString &deviceId);
    Q_INVOKABLE void setDeviceWiperState(const QString &deviceId, bool wiperState);
    Q_INVOKABLE bool getDeviceWiperState(const QString &deviceId);
    Q_INVOKABLE void setDeviceFlapState(const QString &deviceId, bool flapState);
    Q_INVOKABLE bool getDeviceFlapState(const QString &deviceId);
    Q_INVOKABLE void setDeviceScanMode(const QString &deviceId, int scanMode);
    Q_INVOKABLE int getDeviceScanMode(const QString &deviceId);

    // 全景图管理
    Q_INVOKABLE void updateDevicePanoramaPath(const QString &deviceId, const QString &path);
    Q_INVOKABLE QString getDevicePanoramaPath(const QString &deviceId);
    Q_INVOKABLE int getSelectedDeviceScanMode();
    
    // 分组管理方法
    Q_INVOKABLE QList<DeviceGroup> getDeviceGroups() const;
    Q_INVOKABLE void addDeviceGroup(const QString &groupName);
    Q_INVOKABLE void removeDeviceGroup(const QString &groupName);
    Q_INVOKABLE void modifyDeviceGroupName(const QString &oldName, const QString &newName);
    Q_INVOKABLE void expandDeviceGroup(const QString &groupName, bool expanded);
    
    Q_INVOKABLE int getTotalDevices() const;
    Q_INVOKABLE int getOnlineDevices() const;
    Q_INVOKABLE int getOfflineDevices() const;
    
    // QML友好的方法
    Q_INVOKABLE QStringList getDeviceGroupNames() const;
    Q_INVOKABLE QVariantList getAllDevicesAsVariant() const;
    Q_INVOKABLE QVariantMap getDeviceAsVariant(const QString &deviceId) const;
    
    // 树形模型管理
    Q_INVOKABLE DeviceTreeModel* getTreeModel() const;
    Q_INVOKABLE void setTreeModel(DeviceTreeModel* treeModel);
    
    // 播放器管理方法
    Q_INVOKABLE QString getVisibleLightUrl(const QString &deviceId);
    Q_INVOKABLE QString getInfraredUrl(const QString &deviceId);
    Q_INVOKABLE QString getSelectedDeviceVisibleLightUrl();
    Q_INVOKABLE QString getSelectedDeviceInfraredUrl();
    Q_INVOKABLE QString getVisibleLightRecordUrl(const QString &deviceId);
    Q_INVOKABLE QString getInfraredRecordUrl(const QString &deviceId);
    Q_INVOKABLE QString getSelectedDeviceVisibleLightRecordUrl();
    Q_INVOKABLE QString getSelectedDeviceInfraredRecordUrl();
    Q_INVOKABLE QString getRecordUrlbase(const QString &deviceId);
    Q_INVOKABLE QString getSelectedDeviceRecordUrlbase();
    Q_INVOKABLE QString getDeviceUrlByChannelIndex(int channelIndex, bool isVisibleLight = true);
    
    // 录像流带时间参数的URL生成方法
    Q_INVOKABLE QString generateTimedRecordUrl(const QString &deviceId, bool isVisibleLight, const QString &timeStr);
    Q_INVOKABLE QString getSelectedDeviceTimedVisibleLightRecordUrl(const QString &timeStr);
    Q_INVOKABLE QString getSelectedDeviceTimedInfraredRecordUrl(const QString &timeStr);
    Q_INVOKABLE QString getDeviceRecordUrlByChannelIndex(int channelIndex, bool isVisibleLight = true);
    Q_INVOKABLE QString getDeviceIdByChannelIndex(int channelIndex);
    
    // IP地址管理方法
    Q_INVOKABLE QString getVisibleLightIp(const QString &deviceId);
    Q_INVOKABLE QString getInfraredIp(const QString &deviceId);
    Q_INVOKABLE QString getTdlasIp(const QString &deviceId);
    Q_INVOKABLE QString getModbusIp(const QString &deviceId);
    Q_INVOKABLE QString getTofIp(const QString &deviceId);
    Q_INVOKABLE QString getHikvisionIp(const QString &deviceId);
    Q_INVOKABLE QString getSelectedDeviceVisibleLightIp();
    Q_INVOKABLE QString getSelectedDeviceInfraredIp();
    Q_INVOKABLE QString getSelectedDeviceTdlasIp();
    Q_INVOKABLE QString getSelectedDeviceModbusIp();
    Q_INVOKABLE QString getSelectedDeviceTofIp();
    Q_INVOKABLE QString getSelectedDeviceHikvisionIp();
    
    // 用户名和密码管理方法
    Q_INVOKABLE QString getVisibleLightUsername(const QString &deviceId);
    Q_INVOKABLE QString getVisibleLightPassword(const QString &deviceId);
    Q_INVOKABLE QString getInfraredUsername(const QString &deviceId);
    Q_INVOKABLE QString getInfraredPassword(const QString &deviceId);
    Q_INVOKABLE QString getHikvisionUsername(const QString &deviceId);
    Q_INVOKABLE QString getHikvisionPassword(const QString &deviceId);
    Q_INVOKABLE int getHikvisionPort(const QString &deviceId);
    Q_INVOKABLE QString getSelectedDeviceVisibleLightUsername();
    Q_INVOKABLE QString getSelectedDeviceVisibleLightPassword();
    Q_INVOKABLE QString getSelectedDeviceInfraredUsername();
    Q_INVOKABLE QString getSelectedDeviceInfraredPassword();
    Q_INVOKABLE QString getSelectedDeviceHikvisionUsername();
    Q_INVOKABLE QString getSelectedDeviceHikvisionPassword();
    Q_INVOKABLE int getSelectedDeviceHikvisionPort();
    Q_INVOKABLE int getInfraredDownloadChannel(const QString &deviceId);
    Q_INVOKABLE int getVisibleLightDownloadChannel(const QString &deviceId);
    Q_INVOKABLE int getSelectedDeviceInfraredDownloadChannel();
    Q_INVOKABLE int getSelectedDeviceVisibleLightDownloadChannel();
    Q_INVOKABLE int getSelectedDeviceChannelIndex();
    Q_INVOKABLE QString getSelectedDeviceId();
    
    // 报警配置管理方法
    Q_INVOKABLE int getAlarmConcentration(const QString &deviceId);
    Q_INVOKABLE int getAlarmRecordDuration(const QString &deviceId);
    Q_INVOKABLE int getAlarmOutputDuration(const QString &deviceId);
    Q_INVOKABLE int getAlarmDetectionDuration(const QString &deviceId);
    Q_INVOKABLE void setAlarmDetectionDuration(const QString &deviceId, int duration);
    Q_INVOKABLE int getCruiseIntervalDuration(const QString &deviceId);
    Q_INVOKABLE void setCruiseIntervalDuration(const QString &deviceId, int duration);
    Q_INVOKABLE int getSelectedDeviceAlarmConcentration();
    Q_INVOKABLE int getSelectedDeviceAlarmRecordDuration();
    Q_INVOKABLE int getSelectedDeviceAlarmOutputDuration();
    Q_INVOKABLE int getSelectedDeviceAlarmDetectionDuration();
    Q_INVOKABLE void setSelectedDeviceAlarmDetectionDuration(int duration);
    Q_INVOKABLE int getSelectedDeviceCruiseIntervalDuration();
    Q_INVOKABLE void setSelectedDeviceCruiseIntervalDuration(int duration);
    
    Q_INVOKABLE bool getGasAlarmEnabled(const QString &deviceId);
    Q_INVOKABLE void setGasAlarmEnabled(const QString &deviceId, bool enabled);
    Q_INVOKABLE bool getAutoCaptureEnabled(const QString &deviceId);
    Q_INVOKABLE void setAutoCaptureEnabled(const QString &deviceId, bool enabled);
    Q_INVOKABLE bool getAlarmOutputEnabled(const QString &deviceId);
    Q_INVOKABLE void setAlarmOutputEnabled(const QString &deviceId, bool enabled);
    Q_INVOKABLE bool getSelectedDeviceGasAlarmEnabled();
    Q_INVOKABLE void setSelectedDeviceGasAlarmEnabled(bool enabled);
    Q_INVOKABLE bool getSelectedDeviceAutoCaptureEnabled();
    Q_INVOKABLE void setSelectedDeviceAutoCaptureEnabled(bool enabled);
    Q_INVOKABLE bool getSelectedDeviceAlarmOutputEnabled();
    Q_INVOKABLE void setSelectedDeviceAlarmOutputEnabled(bool enabled);
    
    // 数据持久化
    Q_INVOKABLE void saveDevicesToFile(const QString &filename, const DeviceInfo &device);
    Q_INVOKABLE void loadDevicesFromFile(const QString &filename);
    Q_INVOKABLE void loadDefaultDevices(); // 加载默认设备配置
    
    // 分组信息持久化
    Q_INVOKABLE void saveGroupsToFile();
    Q_INVOKABLE void loadGroupsFromFile();
    
    // 设备状态检查
    Q_INVOKABLE void checkDeviceStatus(); // 检查所有设备在线状态
    
    // 设备重复检查
    Q_INVOKABLE bool isDeviceIdExists(const QString &deviceId) const;
    Q_INVOKABLE bool isDeviceNameExists(const QString &deviceName) const;
    Q_INVOKABLE bool isChannelExists(int channelIndex) const;
    
    // 海康设备在线状态
    Q_INVOKABLE bool getHikvisionOnline(const QString &deviceId);
    Q_INVOKABLE bool getSelectedDeviceHikvisionOnline();

    // 网络检测方法
    Q_INVOKABLE bool pingDevice(const QString &ipAddress); // ping指定IP地址，返回是否在线
    
    // HikvisionCtrl 设置方法
    Q_INVOKABLE void setHikvisionCtrl(HikvisionCtrl* hikvisionCtrl);
    
    // 存储设置管理方法
    Q_INVOKABLE void saveStorageSettings(const QString &settingsJson);
    Q_INVOKABLE QString getStorageSettings(const QString &key);
    
    // 录像设置管理方法
    Q_INVOKABLE void saveVideoSettings(const QString &settingsJson);
    Q_INVOKABLE QString getVideoSettings(const QString &key);
    


    // 注册通道的FrameProvider
    void setChannelFrameProviders(int channelIndex, FrameProvider* vl, FrameProvider* ir);
    
    // 初始化指定通道的设备
    Q_INVOKABLE void initializeChannelDevice(int channelIndex);

signals:
    void deviceAdded(const QString &deviceId);
    void deviceRemoved(const QString &deviceId);
    void deviceUpdated(const QString &deviceId);
    void deviceSelected(const QString &deviceId);
    void deviceStatusChanged(const QString &deviceId, bool isOnline);
    void deviceUrlChanged(const QString &deviceId);
    void deviceCountsChanged();
    void treeModelChanged(); // 树模型数据变化信号

private slots:
    // 通道查找相关槽函数
    void onChannelLookupCompleted(const QString& nvrIp, const QString& ipcIp, int channelNumber);
    void onChannelLookupFailed(const QString& nvrIp, const QString& ipcIp, const QString& errorMessage);
    void onDeviceStatusComputed(const QString& deviceId, bool isOnline, bool hikvisionOnline);

private:
    QMap<int, FrameProvider*> m_channelFrameProvidersVL;
    QMap<int, FrameProvider*> m_channelFrameProvidersIR;
    QMap<int, QString> m_initializedChannels;
    static DeviceModel* m_instance;
    QList<DeviceInfo> m_devices;
    QList<DeviceGroup> m_deviceGroups;
    QString m_selectedDeviceId;
    DeviceTreeModel* m_treeModel;
    HikvisionCtrl* m_hikvisionCtrl;  // 添加 HikvisionCtrl 成员变量
    
    void updateDeviceGroups();
    int findDeviceIndex(const QString &deviceId) const;
    int findGroupIndex(const QString &groupName) const;
    
    // 辅助方法：生成录像URL
    QString generateRecordUrl(const QString& recordUrlBase, const QString& hikvisionIp, 
                             int hikvisionPort, const QString& hikvisionUsername, 
                             const QString& hikvisionPassword, const QString& ipcIp);
};

// 声明DeviceInfo为Qt元类型，使其可以在QML中使用
Q_DECLARE_METATYPE(DeviceInfo)

#endif // DEVICEMODEL_H
