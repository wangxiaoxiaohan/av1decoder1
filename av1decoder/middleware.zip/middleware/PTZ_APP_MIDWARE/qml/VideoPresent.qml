import QtQuick 2.15
import QtQuick.Window 2.15
import QtQuick.Controls 2.15
import QtQuick.Layouts 1.15
import QtMultimedia 5.15
import App 1.0

    Item {
        id: root
        
        // 显示权限不足提示
        function showPermissionToast(message) {
            permissionToast.text = message
            permissionToast.show()
        }
        
        property real visibleLightHeight: parent.height  // 可见光区域默认高度
        property real infraredHeight: parent.height      // 红外光区域默认高度
        property real visibleLightWidth: parent.width / 2  // 可见光区域默认宽度
        property real infraredWidth: parent.width / 2      // 红外光区域默认宽度
        
        property var  visibleSource: null   
        property var  infraredSource: null 
        property bool pipMode: false  // 是否处于画中画模式
        property real pipWidth: 200    // 画中画窗口默认宽度
        property real pipHeight: 200   // 画中画窗口默认高度
        property real pipX: 50         // 画中画窗口默认X位置
        property real pipY: 50         // 画中画窗口默认Y位置
        
        // 双光融合相关属性
        property bool dualFusionMode: false  // 是否处于双光融合模式
        property var dualFusionSource: null  // 双光融合视频源
        
        // 气云成像相关属性
        property bool gasCloudMode: false  // 是否处于气云成像模式
        property var gasCloudVisibleSource: null  // 气云可见光视频源
        property var gasCloudInfraredSource: null  // 气云红外视频源

        // 微漏模式相关属性
        property bool microLeakMode: false
        property var microLeakSource: null
        
        // 全屏模式相关属性
        property bool fullScreenMode: false  // 是否处于全屏模式
        property string fullScreenType: ""   // 全屏显示类型："visible" 或 "infrared"
        
        // 气体浓度报警状态
        property bool gasConcentrationAlarm: false
        
        // 通道号属性
        property int channel: 0
        
        property real tofDistance: -100.0
        property string tofDistanceText: "距离: N/A m"
        property bool tofDataAvailable: false
        property int tofInvalidCount: 0
        property int tdlasConcentration: -1
        property string tdlasConcentrationText: "TDLAS浓度: -- ppm.m"
        property bool tdlasDataAvailable: false
        
        // 点击提示相关属性
        property bool showVisibleLightClickHint: false  // 显示可见光点击提示
        property bool showInfraredClickHint: false      // 显示红外光点击提示
        
        // 判断是否为普通模式（未开启任何特殊模式）
        property bool isNormalMode: !pipMode && !dualFusionMode && !gasCloudMode && !microLeakMode && !fullScreenMode

        property real kx: typeof screenCursorKx !== "undefined" ? screenCursorKx : 3.70
        property real bx: typeof screenCursorBx !== "undefined" ? screenCursorBx : 3.22
        property real ky: typeof screenCursorKy !== "undefined" ? screenCursorKy : 3.6
        property real by: typeof screenCursorBy !== "undefined" ? screenCursorBy : 3.83

        // 监听双光融合模式变化
        onDualFusionModeChanged: {
            // 检查是否允许切换到双光融合模式
            if (dualFusionMode && !isNormalMode) {
                console.warn("=== 阻止双光融合模式切换 ===");
                console.warn("当前不在普通模式，无法切换到双光融合模式");
                console.warn("pipMode:", pipMode, "gasCloudMode:", gasCloudMode, "fullScreenMode:", fullScreenMode);
                
                // 阻止切换，恢复到false
                dualFusionMode = false;
                return;
            }
            
            console.log("=== 双光融合模式切换成功 ===");
            console.log("dualFusionMode:", dualFusionMode);
            updateInfraredDisplay();
        }
        
        // 监听气云成像模式变化
        onGasCloudModeChanged: {
            // 检查是否允许切换到气云模式
            if (gasCloudMode && !isNormalMode) {
                console.warn("=== 阻止气云模式切换 ===");
                console.warn("当前不在普通模式，无法切换到气云模式");
                console.warn("pipMode:", pipMode, "dualFusionMode:", dualFusionMode, "fullScreenMode:", fullScreenMode);
                
                // 阻止切换，恢复到false
                gasCloudMode = false;
                return;
            }
            
            console.log("=== 气云模式切换成功 ===");
            console.log("gasCloudMode:", gasCloudMode);
            updateDisplay();
        }

        // 监听微漏模式变化
        onMicroLeakModeChanged: {
            if (microLeakMode && !isNormalMode) {
                console.warn("=== 阻止微漏模式切换 ===");
                microLeakMode = false;
                return;
            }
            console.log("=== 微漏模式切换成功 ===");
            updateDisplay();
        }
        
        // 监听全屏模式变化
        onFullScreenModeChanged: {
            console.log("=== 全屏模式状态变化 ===");
            console.log("fullScreenMode:", fullScreenMode);
            console.log("fullScreenType:", fullScreenType);
            updateDisplay();
        }
        
        // 更新显示逻辑
        function updateInfraredDisplay() {
            // 模式切换逻辑已通过source属性自动处理
        }
        
        function updateDisplay() {
            // 模式切换逻辑已通过source属性自动处理
            // 全屏模式的显示更新也通过属性绑定自动处理
            // console.log("=== 显示更新 ===");
            // console.log("fullScreenMode:", fullScreenMode, "fullScreenType:", fullScreenType);
            // console.log("isNormalMode:", isNormalMode);
        }
        
        // 监听gasConcentrationAlarm属性变化
        onGasConcentrationAlarmChanged: {
            // console.log("=== VideoPresent 报警状态变化 ===");
            // console.log("gasConcentrationAlarm:", gasConcentrationAlarm);
            // console.log("alarmBorder.visible:", alarmBorder.visible);
            // console.log("alarmBorder.opacity:", alarmBorder.opacity);
        }
        
        onTofDistanceChanged: {
            console.log("=== tofDistance:", tofDistance);
            if (tofDistance >= 0 && tofDistance <= 6000) {
                root.tofDistanceText = "距离: " + tofDistance.toFixed(2) + " m"
                root.tofDataAvailable = true
                root.tofInvalidCount = 0
            } else {
                if (root.tofDataAvailable) {
                    root.tofInvalidCount += 1
                    if (root.tofInvalidCount > 5) {
                        root.tofDataAvailable = false
                        root.tofDistanceText = "距离: N/A m"
                        root.tofInvalidCount = 0
                    }
                } else {
                    root.tofDistanceText = "距离: N/A m"
                }
            }
        }
        
        onTdlasConcentrationChanged: {
            if (tdlasConcentration >= 0) {
                root.tdlasConcentrationText = "TDLAS浓度: " + tdlasConcentration.toFixed(2) + " ppm.m";
                root.tdlasDataAvailable = true;
            } else {
                root.tdlasConcentrationText = "TDLAS浓度: -- ppm.m";
                root.tdlasDataAvailable = false;
            }
        }
        
        // 根据通道号获取设备ID
        function getDeviceIdByChannel(channelIndex) {
            try {
                console.log("=== 根据通道号获取设备ID ===");
                console.log("通道号:", channelIndex);
                
                // 使用新的DeviceModel方法直接获取设备ID
                var deviceId = DeviceModel.getDeviceIdByChannelIndex(channelIndex);
                console.log("获取到的设备ID:", deviceId);
                
                if (deviceId !== "") {
                    console.log("成功找到设备:", deviceId);
                    return deviceId;
                } else {
                    console.warn("未找到通道", channelIndex, "对应的设备");
                    return "";
                }
            } catch (error) {
                console.error("获取设备ID时出错:", error);
                return "";
            }
        }
        
        // 更新当前设备
        function updateCurrentDevice() {
            try {
                console.log("=== 开始更新当前设备 ===");
                console.log("当前通道:", root.channel);
                
                var deviceId = getDeviceIdByChannel(root.channel);
                console.log("获取到的设备ID:", deviceId);
                
                if (deviceId !== "") {
                    console.log("=== 更新当前设备 ===");
                    console.log("通道:", root.channel, "设备ID:", deviceId);
                    deviceProxy.setCurrentDevice(deviceId);
                    
                    // 更新DeviceModel的选中设备，确保HwTreeView同步更新
                    if (DeviceModel && DeviceModel.getSelectedDeviceId() !== deviceId) {
                        DeviceModel.selectDevice(deviceId);
                        console.log("更新DeviceModel选中设备为:", deviceId);
                    }
                    
                    console.log("设备更新完成");
                } else {
                    console.warn("无法获取通道", root.channel, "对应的设备ID");
                }
            } catch (error) {
                console.error("更新当前设备时出错:", error);
            }
        }
        
        // 处理视频区域点击事件
        function handleVideoAreaClick(clickedArea) {
            console.log("=== 处理视频区域点击事件 ===");
            console.log("点击区域:", clickedArea);
            console.log("当前通道:", root.channel);
            
            // 切换设备到当前通道对应的设备
            updateCurrentDevice();
            
            // 根据点击区域设置设备的红外选中状态
            var deviceId = getDeviceIdByChannel(root.channel);
            if (deviceId !== "") {
                if (clickedArea === "visible") {
                    // 点击可见光区域，设置为可见光被选中
                    DeviceModel.setDeviceInfraredSelected(deviceId, false);
                    console.log("设备", deviceId, "设置为可见光被选中");
                } else if (clickedArea === "infrared") {
                    // 点击红外光区域，设置为红外被选中
                    DeviceModel.setDeviceInfraredSelected(deviceId, true);
                    console.log("设备", deviceId, "设置为红外被选中");
                }
            }
            
            // 根据点击区域显示相应的闪烁提示
            if (clickedArea === "visible") {
                showVisibleLightClickHint = true;
                // 300毫秒后停止闪烁
                clickHintTimer.interval = 300;
                clickHintTimer.repeat = false;
                clickHintTimer.start();
            } else if (clickedArea === "infrared") {
                showInfraredClickHint = true;
                // 300毫秒后停止闪烁
                clickHintTimer.interval = 300;
                clickHintTimer.repeat = false;
                clickHintTimer.start();
            }
        }
        
        // 处理视频区域双击事件
        function handleVideoAreaDoubleClick(clickedArea) {
            console.log("=== 处理视频区域双击事件 ===");
            console.log("点击区域:", clickedArea);
            console.log("当前模式 - isNormalMode:", isNormalMode, "fullScreenMode:", fullScreenMode);
            console.log("模式状态 - pipMode:", pipMode, "dualFusionMode:", dualFusionMode, "gasCloudMode:", gasCloudMode);
            
            // 如果当前处于全屏模式，则退出全屏模式
            if (fullScreenMode) {
                console.log("退出全屏模式");
                fullScreenMode = false;
                fullScreenType = "";
                return;
            }
            
            // 只有在普通模式下才允许进入全屏模式
            if (isNormalMode) {
                console.log("进入全屏模式，类型:", clickedArea);
                fullScreenMode = true;
                fullScreenType = clickedArea;
                
                // 更新当前设备
                updateCurrentDevice();
                
                // 根据点击区域设置设备的红外选中状态
                var deviceId = getDeviceIdByChannel(root.channel);
                if (deviceId !== "") {
                    if (clickedArea === "visible") {
                        DeviceModel.setDeviceInfraredSelected(deviceId, false);
                        console.log("设备", deviceId, "设置为可见光被选中（全屏模式）");
                    } else if (clickedArea === "infrared") {
                        DeviceModel.setDeviceInfraredSelected(deviceId, true);
                        console.log("设备", deviceId, "设置为红外被选中（全屏模式）");
                    }
                }
            } else {
                console.log("=== 阻止进入全屏模式 ===");
                console.log("当前不在普通模式，无法进入全屏模式");
                console.log("pipMode:", pipMode, "dualFusionMode:", dualFusionMode, "gasCloudMode:", gasCloudMode);
            }
        }
        
        // 点击提示定时器
        Timer {
            id: clickHintTimer
            onTriggered: {
                showVisibleLightClickHint = false;
                showInfraredClickHint = false;
            }
        }
        
        // 视频实际显示区域计算属性
        property real visibleVideoWidth: visibleLightOutput.contentRect.width
        property real visibleVideoHeight: visibleLightOutput.contentRect.height
        property real visibleVideoX: visibleLightOutput.contentRect.x
        property real visibleVideoY: visibleLightOutput.contentRect.y
        
        // 红外视频的宽高比
        property real infraredAspectRatio: 16/9  // 默认值，可以根据实际视频调整

        Layout.fillWidth: true
        Layout.fillHeight: true
        
        // 顶部栏 - 显示设备名称和控制按钮
        Row {
            id: topBar
            anchors.left: parent.left
            anchors.right: parent.right
            anchors.top: parent.top
            height: 40
            z: 15 // 确保在最顶层
            
            // 左侧设备名称
            Text {
                id: deviceNameText
                anchors.verticalCenter: parent.verticalCenter
                anchors.left: parent.left
                anchors.leftMargin: 10
                color: "#ffffff"
                font.pixelSize: 16
                font.bold: true
                text: {
                    var deviceId = root.getDeviceIdByChannel(root.channel);
                    if (deviceId !== "") {
                        // 尝试获取设备名称
                        if (typeof DeviceModel !== "undefined") {
                            var device = DeviceModel.getDeviceAsVariant(deviceId);
                            if (device && device.deviceName) {
                                return "设备: " + device.deviceName;
                            }
                        }
                        return "设备: " + deviceId;
                    }
                    return "未连接设备";
                }
            }
            
            // 右侧控制按钮
                Row {
                id: controlButtons
                anchors.verticalCenter: parent.verticalCenter
                anchors.right: parent.right
                anchors.rightMargin: 10
                spacing: 10
                
                // 设备信息按钮
                Button {
                    id: deviceInfoButtonTop
                    width: 24
                    height: 24
                    background: Image {
                        source: "information.png"
                        fillMode: Image.PreserveAspectFit
                    }
                    onClicked: {
                        console.log("设备信息按钮被点击");
                        // 更新当前设备为当前通道对应的设备
                        updateCurrentDevice();
                        
                        var deviceName = "";
                        var deviceId = getDeviceIdByChannel(root.channel);
                        if (deviceId !== "") {
                            var deviceData = DeviceModel.getDeviceAsVariant(deviceId);
                            if (deviceData) {
                                deviceName = deviceData.deviceName || "";
                            }
                        }
                        
                        var component = Qt.createComponent("DeviceInfoDialog.qml");
                        if (component.status !== Component.Ready) {
                            console.error("设备信息组件未准备好:", component.errorString());
                            return;
                        }
                        var dialog = component.createObject(ApplicationWindow.overlay, {"parent": root, "topBar": topBar, "deviceName": deviceName});
                        if (dialog) {
                            dialog.open();
                        }
                    }
                }
                
                // 气体泄漏报警设置按钮
                Button {
                    id: gasAlarmSettingButtonTop
                    width: 24
                    height: 24
                    background: Image {
                        source: "warnning_setting.png"
                        fillMode: Image.PreserveAspectFit
                    }
                    onClicked: {
                        console.log("气体泄漏报警设置按钮被点击");
                        // 更新当前设备为当前通道对应的设备
                        updateCurrentDevice();
                        var component = Qt.createComponent("GasAlarmSettingDialog.qml");
                        if (component.status !== Component.Ready) {
                            console.error("气体泄漏报警设置组件未准备好:", component.errorString());
                            return;
                        }
                        var dialog = component.createObject(ApplicationWindow.overlay, {"parent": root, "topBar": topBar});
                        if (dialog) {
                            dialog.open();
                        }
                    }
                }

                Button {
                    id: startRtspStreamButton
                    width: 80
                    height: 26
                    text: "开始推流"
                    onClicked: {
                        console.log("开始推流按钮被点击, channel:", root.channel);
                        var ok = playerManager.startStitchedStream(
                                    root.channel,
                                    "rtsp://192.168.2.199/live/stream",
                                    "h265",
                                    25,
                                    2000);
                        if (!ok) {
                            console.error("启动拼接推流失败, channel:", root.channel,
                                          "error:", playerManager.stitchedStreamLastError(root.channel));
                        } else {
                            console.log("启动拼接推流成功, channel:", root.channel);
                        }
                    }
                }

            }
        }
        
        // 气体浓度报警边框 - 在最顶层显示
        Rectangle {
            id: alarmBorder
            anchors.fill: parent
            color: "transparent"
            border.color: gasConcentrationAlarm ? "#FF0000" : "transparent"
            border.width: gasConcentrationAlarm ? 4 : 0
            z: 100  // 确保在最顶层
            visible: gasConcentrationAlarm
        
            
            // 闪烁动画
            SequentialAnimation on opacity {
                running: gasConcentrationAlarm
                loops: Animation.Infinite
                NumberAnimation { to: 1.0; duration: 500 }
                NumberAnimation { to: 0.3; duration: 500 }
            }
            
        }
        
        // 可见光视频区域
        Rectangle {
            id: visibleLightRect
            anchors.left: parent.left
            anchors.top: topBar.bottom
            width: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "visible")) ? root.width : root.visibleLightWidth
            height: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "visible")) ? (root.height - topBar.height) : (root.visibleLightHeight - topBar.height)
            color: "gray"

            Text {
                text: "可见光"
                anchors.centerIn: parent
                color: "white"
                visible: !root.pipMode && !(root.fullScreenMode && root.fullScreenType === "visible")
            }

            VideoOutput {
                id: visibleLightOutput
                anchors.fill: parent
                source: root.microLeakMode ? root.microLeakSource : (root.gasCloudMode ? root.gasCloudVisibleSource : visibleSource)
                fillMode: VideoOutput.Stretch

                Component.onDestruction: {
                    if (visibleSource) {
                        visibleSource.removeVideoSurface(visibleLightOutput.videoSurface);
                    }
                    if (root.gasCloudVisibleSource) {
                        root.gasCloudVisibleSource.removeVideoSurface(visibleLightOutput.videoSurface);
                    }
                    if (root.microLeakSource) {
                        root.microLeakSource.removeVideoSurface(visibleLightOutput.videoSurface);
                    }
                }
                
                // 视频实际显示区域变化时更新计算属性
                onContentRectChanged: {
                    if (root.pipMode) {
                        // 重新计算红外窗口的限制区域
                        updateInfraredConstraints();
                    }
                }
            }
            
            // 可见光区域点击事件
            MouseArea {
                id: visibleLightMouseArea
                anchors.fill: parent
                enabled: !root.pipMode || (root.fullScreenMode && root.fullScreenType === "visible")  // 在PIP模式下禁用，但在可见光全屏模式下启用
                
                onClicked: {
                    console.log("=== 可见光区域被点击 ===");
                    root.handleVideoAreaClick("visible");
                }
                
                onDoubleClicked: {
                    console.log("=== 可见光区域被双击 ===");
                    root.handleVideoAreaDoubleClick("visible");
                }
            }
            
            // 全屏模式提示文本
            Text {
                text: "可见光全屏模式 - 双击退出"
                anchors {
                    top: parent.top
                    left: parent.left
                    margins: 20
                }
                color: "#00BFFF"
                font.pixelSize: 16
                font.bold: true
                visible: root.fullScreenMode && root.fullScreenType === "visible"
                z: 200
                
                // 添加背景以提高可见性
                Rectangle {
                    anchors.fill: parent
                    anchors.margins: -8
                    color: Qt.rgba(0, 0, 0, 0.7)
                    radius: 5
                    z: -1
                }
                
                // 淡入淡出动画
                SequentialAnimation on opacity {
                    running: root.fullScreenMode && root.fullScreenType === "visible"
                    loops: Animation.Infinite
                    NumberAnimation { to: 1.0; duration: 2000 }
                    NumberAnimation { to: 0.5; duration: 2000 }
                }
            }
            
            // 可见光点击提示边框
            Rectangle {
                id: visibleLightClickBorder
                anchors.fill: parent
                color: "transparent"
                border.color: showVisibleLightClickHint ? "#00BFFF" : "transparent"
                border.width: showVisibleLightClickHint ? 3 : 0
                z: 101  // 在报警边框之上
                visible: showVisibleLightClickHint
                
                // 闪烁动画
                SequentialAnimation on opacity {
                    running: showVisibleLightClickHint
                    loops: Animation.Infinite
                    NumberAnimation { to: 1.0; duration: 300 }
                    NumberAnimation { to: 0.3; duration: 300 }
                }
            }

        }

        // 红外光视频 - 在PIP模式或红外全屏模式下占满整个VideoPresent
        VideoOutput {
            id: infraredOutput
            anchors.top: topBar.bottom
            anchors.fill: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "infrared")) ? root : undefined
            width: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "infrared")) ? root.width : root.infraredWidth
            height: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "infrared")) ? (root.height - topBar.height) : (root.infraredHeight - topBar.height)
            x: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "infrared")) ? 0 : visibleLightRect.width
            y: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "infrared")) ? topBar.height : topBar.height
            z: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "infrared")) ? 5 : 2
            visible: !root.pipMode && !(root.fullScreenMode && root.fullScreenType === "visible")
            
            // 简洁的source属性设置，避免重复
            source: root.gasCloudMode ? root.gasCloudInfraredSource : 
                   (root.dualFusionMode ? root.dualFusionSource : infraredSource)
            fillMode: VideoOutput.Stretch
            
            Component.onCompleted: {
                // 组件初始化完成
                console.log("=== 红外VideoOutput初始化完成 ===");
                console.log("初始source:", source);
                console.log("初始dualFusionMode:", root.dualFusionMode);
            }
            
            onSourceChanged: {
                console.log("=== 红外VideoOutput source变化 ===");
                console.log("新source:", source);
                console.log("dualFusionMode:", root.dualFusionMode);
                console.log("dualFusionSource:", root.dualFusionSource);
                console.log("infraredSource:", infraredSource);
                console.log("pipMode:", root.pipMode);
                console.log("infraredOutput.visible:", infraredOutput.visible);
                
                if (source && source.metaData && source.metaData.resolution) {
                    var resolution = source.metaData.resolution;
                    infraredAspectRatio = resolution.width / resolution.height;
                }
            }
            
            Component.onDestruction: {
                if (infraredSource) {
                    infraredSource.removeVideoSurface(infraredOutput.videoSurface);
                }
                if (root.dualFusionSource) {
                    root.dualFusionSource.removeVideoSurface(infraredOutput.videoSurface);
                }
                if (root.gasCloudInfraredSource) {
                    root.gasCloudInfraredSource.removeVideoSurface(infraredOutput.videoSurface);
                }
            }
            
            // 当视频内容区域变化时，更新宽高比
            onContentRectChanged: {
                if (!root.pipMode && contentRect.width > 0 && contentRect.height > 0) {
                    infraredAspectRatio = contentRect.width / contentRect.height;
                }
            }
        }
        
        // 红外光区域点击事件
        MouseArea {
            id: infraredMouseArea
            anchors.fill: infraredOutput
            enabled: !root.pipMode || (root.fullScreenMode && root.fullScreenType === "infrared")  // 在PIP模式下禁用，但在红外全屏模式下启用
            
            onClicked: {
                console.log("=== 红外光区域被点击 ===");
                root.handleVideoAreaClick("infrared");
            }
            
            onDoubleClicked: {
                console.log("=== 红外光区域被双击 ===");
                root.handleVideoAreaDoubleClick("infrared");
            }
        }
        
        // 红外全屏模式提示文本
        Text {
            text: "红外全屏模式 - 双击退出"
            anchors {
                top: infraredOutput.top
                left: infraredOutput.left
                margins: 20
            }
            color: "#FF6B35"
            font.pixelSize: 16
            font.bold: true
            visible: root.fullScreenMode && root.fullScreenType === "infrared"
            z: 200
            
            // 添加背景以提高可见性
            Rectangle {
                anchors.fill: parent
                anchors.margins: -8
                color: Qt.rgba(0, 0, 0, 0.7)
                radius: 5
                z: -1
            }
            
            // 淡入淡出动画
            SequentialAnimation on opacity {
                running: root.fullScreenMode && root.fullScreenType === "infrared"
                loops: Animation.Infinite
                NumberAnimation { to: 1.0; duration: 2000 }
                NumberAnimation { to: 0.5; duration: 2000 }
            }
        }
        
        // 红外光点击提示边框
        Rectangle {
            id: infraredClickBorder
            anchors.fill: infraredOutput
            color: "transparent"
            border.color: showInfraredClickHint ? "#00BFFF" : "transparent"
            border.width: showInfraredClickHint ? 3 : 0
            z: 101  // 在报警边框之上
            visible: showInfraredClickHint
            
            // 闪烁动画
            SequentialAnimation on opacity {
                running: showInfraredClickHint
                loops: Animation.Infinite
                NumberAnimation { to: 1.0; duration: 300 }
                NumberAnimation { to: 0.3; duration: 300 }
            }
        }

        // 非PIP模式且非全屏模式下的红外背景
        Rectangle {
            id: infraredBackground
            anchors.fill: infraredOutput
            color: "gray"
            visible: !root.pipMode && !root.dualFusionMode && !root.gasCloudMode && !root.fullScreenMode  // 只在非PIP模式、非双光融合模式且非全屏模式下显示
            z: 0  // 在红外视频下方
            
            Text {
                text: "红外光"
                anchors.centerIn: parent
                color: "white"
            }
        }

        // TOF距离显示 - 在可见光视频区域内部显示
        Text {
            id: tofDistanceText
            anchors {
                top: visibleLightRect.top
                right: visibleLightRect.right
                margins: Math.max(10, root.width * 0.02)
            }
            text: root.tofDistanceText
            color:  "#00FF00"   // 使用root前缀
            // 基础大小18，根据组件宽度进行缩放，设置最小值防止过小
            font.pixelSize: Math.max(12, Math.min(18, root.width * 0.03))
            font.bold: true
            visible: true // 使用root前缀
            z: 200  // 提高z值，确保在最顶层显示
            
            // 添加背景以提高可见性
            Rectangle {
                anchors.fill: parent
                anchors.margins: -5
                color: Qt.rgba(0, 0, 0, 0.5)
                radius: 3
                z: -1
            }
            
            // 调试信息
            onTextChanged: {
                console.log("=== TOF距离文本变化 ===");
                console.log("新文本:", text);
                console.log("颜色:", color);
                console.log("位置:", x, y);
                console.log("可见性:", visible);
                console.log("z值:", z);
            }
            
            // 添加闪烁动画效果
            SequentialAnimation on opacity {
                running: root.tofDataAvailable  // 使用root前缀
                loops: Animation.Infinite
                NumberAnimation { to: 1.0; duration: 1000 }
                NumberAnimation { to: 0.7; duration: 1000 }
            }
        }
        
        Text {
            id: tdlasConcentrationDisplay
            anchors {
                top: tofDistanceText.bottom
                right: tofDistanceText.right
                topMargin: Math.max(4, root.width * 0.01)
            }
            text: root.tdlasConcentrationText
            color: root.tdlasDataAvailable ? "#FFD700" : "#888888"
            // 基础大小16，根据组件宽度进行缩放，设置最小值防止过小
            font.pixelSize: Math.max(10, Math.min(16, root.width * 0.025))
            font.bold: true
            visible: root.tdlasDataAvailable
            z: 200
            
            Rectangle {
                anchors.fill: parent
                anchors.margins: -5
                color: Qt.rgba(0, 0, 0, 0.5)
                radius: 3
                z: -1
            }
        }

        // 红外窗口 - 在PIP模式下作为视口显示红外视频
        Item {
            id: infraredRect
            width: root.pipMode ? root.pipWidth : root.infraredWidth
            height: root.pipMode ? root.pipHeight : root.infraredHeight
            visible: root.pipMode && !root.fullScreenMode  // 在全屏模式下不显示PIP窗口
            
            // 根据模式调整位置
            x: root.pipMode ? root.pipX : visibleLightRect.width
            y: root.pipMode ? root.pipY : 0
            z: root.pipMode ? 15 : 0  // 提高z值，确保在控制按钮之上
            
            // 在PIP模式下，这个Item作为裁剪区域
            clip: root.pipMode
            
            // 添加边框以显示红外窗口边界
            Rectangle {
                id: pipBorder
                anchors.fill: parent
                color: "transparent"
                border.color: "#40FFFFFF"
                border.width: 2
                visible: root.pipMode
                z: 1
            }
            
            // PIP模式下的红外视频视口
            VideoOutput {
                id: infraredViewport
                width: root.width
                height: root.height
                x: root.pipMode ? -infraredRect.x : 0
                y: root.pipMode ? -infraredRect.y : 0
                visible: root.pipMode
                
                // 简洁的source设置
                source: root.gasCloudMode ? root.gasCloudInfraredSource : 
                       (root.dualFusionMode ? root.dualFusionSource : infraredSource)
                fillMode: VideoOutput.Stretch

                Component.onCompleted: {
                    // PIP红外视口组件初始化完成
                    console.log("=== PIP红外视口组件初始化完成 ===");
                }

                Component.onDestruction: {
                    if (infraredSource) {
                        infraredSource.removeVideoSurface(infraredViewport.videoSurface);
                    }
                    if (root.dualFusionSource) {
                        root.dualFusionSource.removeVideoSurface(infraredViewport.videoSurface);
                    }
                    if (root.gasCloudInfraredSource) {
                        root.gasCloudInfraredSource.removeVideoSurface(infraredViewport.videoSurface);
                    }
                }
                
                // 当视频源变化时的处理
                onSourceChanged: {
                    console.log("=== PIP红外视口source变化 ===");
                    console.log("新source:", source);
                }
            }
            
            // 拖动控制 - 移到infraredRect层级，只覆盖红外窗口区域
            MouseArea {
                id: dragArea
                anchors.fill: parent  // 现在填充的是infraredRect，不是整个屏幕
                drag.target: root.pipMode ? infraredRect : undefined
                drag.axis: Drag.XAndYAxis
                drag.minimumX: visibleVideoX
                drag.maximumX: visibleVideoX + visibleVideoWidth - infraredRect.width
                drag.minimumY: visibleVideoY
                drag.maximumY: visibleVideoY + visibleVideoHeight - infraredRect.height
                
                // 拖动限制会在updateInfraredConstraints函数中动态设置
                visible: root.pipMode
                z: 2  // 确保在边框之上
                
                onPressed: {
                    console.log("=== 红外窗口拖动开始 ===");
                }
                
                onReleased: {
                    console.log("=== 红外窗口拖动结束 ===");
                    console.log("最终位置:", infraredRect.x, infraredRect.y);
                    // 更新持久化位置
                    if (root.pipMode) {
                        root.pipX = infraredRect.x;
                        root.pipY = infraredRect.y;
                    }
                }
            }
            
            // 缩放控制手柄 - 右下角，移到infraredRect层级
            Rectangle {
                id: resizeHandle
                width: 16
                height: 16
                color: "transparent"
                visible: root.pipMode
                anchors.right: parent.right
                anchors.bottom: parent.bottom
                anchors.rightMargin: 0   // 向左移动4像素
                anchors.bottomMargin: 0  // 向上移动4像素
                z: 3  // 确保在拖动区域之上
                
                Rectangle {
                    width: 10
                    height: 10
                    radius: 5
                    color: "#80FFFFFF"
                    border.color: "#FFFFFF"
                    border.width: 1
                    anchors.centerIn: parent
                }
                
                MouseArea {
                    anchors.fill: parent
                    cursorShape: Qt.SizeFDiagCursor
                    
                    property point startPos
                    property real startWidth
                    property real startHeight
                    
                    onPressed: {
                        startPos = Qt.point(mouseX, mouseY)
                        startWidth = infraredRect.width
                        startHeight = infraredRect.height
                        console.log("=== 红外窗口缩放开始 ===");
                        console.log("起始大小:", startWidth, "x", startHeight);
                    }
                    
                    onPositionChanged: {
                        if (pressed && root.pipMode) {
                            var deltaX = mouseX - startPos.x
                            var deltaY = mouseY - startPos.y
                            
                            // 计算新宽度，确保不会太小
                            var newWidth = Math.max(100, startWidth + deltaX)
                            
                            // 确保不会超出可见光视频的右边界
                            newWidth = Math.min(newWidth, visibleVideoX + visibleVideoWidth - infraredRect.x)
                            
                            // 计算新高度，确保不会太小
                            var newHeight = Math.max(75, startHeight + deltaY)
                            
                            // 确保不会超出可见光视频的底边界
                            newHeight = Math.min(newHeight, visibleVideoY + visibleVideoHeight - infraredRect.y)
                            
                            // 设置新宽度和高度
                            root.pipWidth = newWidth
                            root.pipHeight = newHeight
                            infraredRect.width = newWidth
                            infraredRect.height = newHeight
                        }
                    }
                    
                    onReleased: {
                        console.log("=== 红外窗口缩放结束 ===");
                        console.log("最终大小:", infraredRect.width, "x", infraredRect.height);
                    }
                }
            }
        }
        
        // 控制按钮组
        Row {
            id: controlButtonsRow
            z: 12 // 确保按钮在最顶层
            spacing: 5
            
            // 根据不同模式设置锚定位置
            anchors {
                right: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "visible")) ? visibleLightRect.right : parent.right
                bottom: (root.pipMode || (root.fullScreenMode && root.fullScreenType === "visible")) ? visibleLightRect.bottom : infraredOutput.bottom
                rightMargin: 10
                bottomMargin: 10
            }
            
            Button {
                id: cameraButton
                hoverEnabled: true
                width: 16
                height: 16
                
                background: Image {
                    source: cameraButton.hovered ? "CaptureIconBlue.png" : "CaptureIconGray.png"
                    fillMode: Image.PreserveAspectFit
                }
                onClicked: {
                    // 检查抓拍权限
                    // var permissions = UserManager.getCurrentUserPermissions();
                    // if (!permissions["snapshot"]) {
                    //     showPermissionToast("您没有抓拍权限");
                    //     return;
                    // }
                    
                    console.log("=== Camera button clicked - 开始抓帧 ===");
                    console.log("通道:", root.channel);
                    
                    // 获取存储设置中的抓拍图片保存路径
                    var photoPath = DeviceModel.getStorageSettings("photoPath");
                    if (!photoPath || photoPath === "") {
                        photoPath = "D:/ZG_Client/Photo"; // 默认路径
                        console.log("使用默认抓拍图片路径:", photoPath);
                    } else {
                        console.log("使用配置的抓拍图片路径:", photoPath);
                    }
                    
                    // 获取当前时间戳
                    var timestamp = new Date().toISOString().replace(/[:.]/g, '').replace('T', '_').replace('Z', '');
                    
                    // 抓取可见光帧（普通抓拍）
                    var visibleImagePath = "";
                    if (root.visibleSource) {
                        // 不再传入硬编码的文件名，让FrameProvider根据设置生成文件名
                        visibleImagePath = root.visibleSource.captureCurrentFrame("", false);
                        if (visibleImagePath) {
                            console.log("可见光帧抓取成功:", visibleImagePath);
                        } else {
                            console.warn("可见光帧抓取失败");
                        }
                    } else {
                        console.warn("可见光视频源未设置");
                    }
                    
                    // 抓取红外帧（普通抓拍）
                    var infraredImagePath = "";
                    if (root.infraredSource) {
                        // 不再传入硬编码的文件名，让FrameProvider根据设置生成文件名
                        infraredImagePath = root.infraredSource.captureCurrentFrame("", false);
                        if (infraredImagePath) {
                            console.log("红外帧抓取成功:", infraredImagePath);
                        } else {
                            console.warn("红外帧抓取失败");
                        }
                    } else {
                        console.warn("红外视频源未设置");
                    }
                    
                    // 如果处于双光融合模式，也抓取融合帧（普通抓拍）
                    if (root.dualFusionMode && root.dualFusionSource) {
                        // 不再传入硬编码的文件名，让FrameProvider根据设置生成文件名
                        var fusionImagePath = root.dualFusionSource.captureCurrentFrame("", false);
                        if (fusionImagePath) {
                            console.log("双光融合帧抓取成功:", fusionImagePath);
                        } else {
                            console.warn("双光融合帧抓取失败");
                        }
                    }
                    
                    // 如果处于气云成像模式，也抓取气云帧
                    if (root.gasCloudMode) {
                        if (root.gasCloudVisibleSource) {
                            // 不再传入硬编码的文件名，让FrameProvider根据设置生成文件名
                            var gasCloudVisiblePath = root.gasCloudVisibleSource.captureCurrentFrame("", false);
                            if (gasCloudVisiblePath) {
                                console.log("气云可见光帧抓取成功:", gasCloudVisiblePath);
                            } else {
                                console.warn("气云可见光帧抓取失败");
                            }
                        }
                        
                        if (root.gasCloudInfraredSource) {
                            // 不再传入硬编码的文件名，让FrameProvider根据设置生成文件名
                            var gasCloudInfraredPath = root.gasCloudInfraredSource.captureCurrentFrame("", false);
                            if (gasCloudInfraredPath) {
                                console.log("气云红外帧抓取成功:", gasCloudInfraredPath);
                            } else {
                                console.warn("气云红外帧抓取失败");
                            }
                        }
                    }
                    
                    console.log("=== 抓帧完成 ===");
                }
            }
            
            Button {
                id: recordButton
                width: 16
                height: 16
                property bool isRecordOn: false
                property bool isManualRecording: false
                background: Image {
                    source:{
                        if (recordButton.isManualRecording) {
                            "RecordBlue.png"  // 手动录制时显示蓝色
                        } else {
                            recordButton.hovered ? "RecordBlue.png" : "RecordGray.png"
                        } 
                    }
                    fillMode: Image.PreserveAspectFit
                }
                onClicked: {
                    // // 检查录像权限
                    // var permissions = UserManager.getCurrentUserPermissions();
                    // if (!permissions["record"]) {
                    //     showPermissionToast("您没有手动录像权限");
                    //     return;
                    // }
                    
                    try {
                        // 获取当前通道对应的设备ID
                        var deviceId = getDeviceIdByChannel(root.channel);
                        if (deviceId === "") {
                            console.warn("无法获取通道", root.channel, "对应的设备ID");
                            return;
                        }
                        
                        var deviceInfo = DeviceModel.getDeviceAsVariant(deviceId);
                        if (!deviceInfo) {
                            console.warn("无法获取设备信息，设备ID:", deviceId);
                            return;
                        }
                        
                        var deviceCode = deviceInfo.deviceId || deviceId;
                        var deviceName = deviceInfo.deviceName || deviceId;
                        
                        // 获取视频录制路径
                        var videoPath = DeviceModel.getVideoSettings("manualVideoPath");
                        if (!videoPath || videoPath === "") {
                            videoPath = "D:/ZG_Client/Video"; // 默认路径
                            console.log("使用默认视频录制路径:", videoPath);
                        } else {
                            console.log("使用配置的视频录制路径:", videoPath);
                        }
                        
                        // 生成时间戳
                        var now = new Date();
                        var timestamp = now.getFullYear() + 
                                      ("0" + (now.getMonth() + 1)).slice(-2) + 
                                      ("0" + now.getDate()).slice(-2) + 
                                      ("0" + now.getHours()).slice(-2) + 
                                      ("0" + now.getMinutes()).slice(-2) + 
                                      ("0" + now.getSeconds()).slice(-2);
                        
                        // 生成文件名
                        var visibleVideoName = "Device" + ("0" + root.channel).slice(-2) + "_VISV_" + timestamp + ".ts";
                        var infraredVideoName = "Device" + ("0" + root.channel).slice(-2) + "_IRV_" + timestamp + ".ts";
                        
                        var visibleVideoPath = videoPath + "/" + visibleVideoName;
                        var infraredVideoPath = videoPath + "/" + infraredVideoName;
                        
                        if (recordButton.isManualRecording) {
                            // 停止录制
                            console.log("停止录制可见光和红外视频");
                            
                            // 获取可见光和红外播放器
                            var visiblePlayer = playerManager.getPlayer(root.channel, PlayerManager.VisibleLightLive);
                            var infraredPlayer = playerManager.getPlayer(root.channel, PlayerManager.InfraredLive);
                            
                            // 停止可见光录制
                            if (visiblePlayer && visiblePlayer.isRecording()) {
                                console.log("开始停止可见光录制");
                                visiblePlayer.stopRecording();
                                console.log("已停止可见光录制");
                                
                                // 停止可见光录像的数据库记录
                                ManualRecordingManager.stopRecording(deviceCode, "visible");
                            }
                            
                            // 停止红外录制
                            if (infraredPlayer && infraredPlayer.isRecording()) {
                                console.log("开始停止红外录制");
                                infraredPlayer.stopRecording();
                                console.log("已停止红外录制");
                                
                                // 停止红外录像的数据库记录
                                ManualRecordingManager.stopRecording(deviceCode, "infrared");
                            }
                            
                            // 停止微漏模式录制 (如果处于微漏模式)
                            if (root.microLeakMode) {
                                // TODO: Implement micro-leak recording logic if needed.
                                // Currently micro-leak processes frames but doesn't have a dedicated "recording player".
                                // The visible player might be recording the raw stream, not the overlay.
                                // If overlay recording is needed, it would require a different approach (e.g. recording the processed QImage).
                            }

                            recordButton.isManualRecording = false;
                        } else {
                            // 开始录制
                            console.log("开始录制可见光和红外视频");
                            console.log("可见光视频路径:", visibleVideoPath);
                            console.log("红外视频路径:", infraredVideoPath);
                            
                            // 获取可见光和红外播放器
                            var visiblePlayer = playerManager.getPlayer(root.channel, PlayerManager.VisibleLightLive);
                            var infraredPlayer = playerManager.getPlayer(root.channel, PlayerManager.InfraredLive);
                            
                            // 开始可见光录制
                            if (visiblePlayer) {
                                visiblePlayer.startRecording(visibleVideoPath, "ts");
                                console.log("已开始可见光录制");
                                
                                // 开始可见光录像的数据库记录
                                ManualRecordingManager.startRecording(deviceCode, deviceName, "visible");
                            } else {
                                console.warn("无法获取可见光播放器，录制失败");
                            }
                            
                            // 开始红外录制
                            if (infraredPlayer) {
                                infraredPlayer.startRecording(infraredVideoPath, "ts");
                                console.log("已开始红外录制");
                                
                                // 开始红外录像的数据库记录
                                ManualRecordingManager.startRecording(deviceCode, deviceName, "infrared");
                            } else {
                                console.warn("无法获取红外播放器，录制失败");
                            }
                            
                            recordButton.isManualRecording = true;
                        }
                    } catch (error) {
                        console.error("录制操作失败:", error);
                    }
                }
            }
            
            Button {
                id: lightButton
                width: 16
                height: 16
                property bool isLightOn: true
                background: Image {
                    source: {
                        if (lightButton.isLightOn) {
                            lightButton.hovered ? "BlueLightning.png" : "GrayLightning.png"
                        } else {
                            "RedLightning.png"
                        }
                    }          
                    fillMode: Image.PreserveAspectFit
                }
                onClicked: {
                    lightButton.isLightOn = !lightButton.isLightOn
                }
            }

            Button {
                id: muteButton
                width: 16
                height: 16
                property bool isMute: true
                background: Image {
                    source:{
                        if (muteButton.isMute) {
                            muteButton.hovered ? "VolumeIconBlue.png" : "VolumeIconGray.png"
                        } else {
                            "mute.png"
                        }
                    }
                    fillMode: Image.PreserveAspectFit
                }
                onClicked: {
                    muteButton.isMute = !muteButton.isMute
                }
            }

            Button {
                id: speakerButton  
                width: 16
                height: 16
                property bool isMicOn: true
                background: Image {
                    source:{
                        if (speakerButton.isMicOn) {
                            speakerButton.hovered ? "MicrophoneIconBlue.png" : "MicrophoneIconGray.png"
                        } else {
                            "NoMic.png"
                        }
                    }
                    fillMode: Image.PreserveAspectFit
                }
                onClicked: {
                    speakerButton.isMicOn = !speakerButton.isMicOn
                }
            }

            Button {
                id: settingButton
                width: 16
                height: 16

                background: Image {
                    source: settingButton.hovered ? "SettingsIconBlue.png" : "SettingsIconGray.png"
                    fillMode: Image.PreserveAspectFit
                }
                onClicked: {
                    console.log("SETTING button clicked");
                    
                    // 检查系统配置权限
                    // var permissions = UserManager.getCurrentUserPermissions();
                    // if (!permissions["systemConfig"]) {
                    //     // 显示权限不足提示
                    //     showPermissionToast("您没有系统配置权限");
                    //     return;
                    // }
                    
                    // 更新当前设备为当前通道对应的设备
                    updateCurrentDevice();
                    var component = Qt.createComponent("Setting.qml");
                    console.log("SETTING Component created with status:", component.status);
                    
                    if (component.status !== Component.Ready) {
                        console.error("SETTING Component not ready, status:", component.status);
                        console.error("SETTING Component error string:", component.errorString());
                        return;
                    }
                    
                    var dialog = component.createObject(root);
                    if (dialog == null) {
                        console.error("SETTING Failed to create component object");
                        console.error("SETTING Component error string:", component.errorString());
                        return;
                    }
                    dialog.show();
                }
            }
        }
        
        // 右上角控制按钮组 - 仅保留手动录制状态指示器
        Row {
            id: topRightButtons
            z: 13 // 确保在最顶层
            spacing: 10
            anchors.top: topBar.bottom
            anchors.topMargin: 10
            anchors.right: parent.right
            anchors.rightMargin: 10
            
            // 手动录制状态指示器
            Rectangle {
                id: manualRecordingIndicator
                visible: recordButton.isManualRecording
                width: 15
                height: 15
                radius: 8
                color: "#ff0000"
                border.color: "#ffffff"
                border.width: 1
                
                // 闪烁动画
                SequentialAnimation {
                    id: recordingBlinkAnimation
                    loops: Animation.Infinite
                    PropertyAnimation { target: manualRecordingIndicator; property: "opacity"; to: 0.3; duration: 500 }
                    PropertyAnimation { target: manualRecordingIndicator; property: "opacity"; to: 1.0; duration: 500 }
                }
                
                Component.onCompleted: {
                    if (visible) recordingBlinkAnimation.start();
                }
                
                onVisibleChanged: {
                    if (visible) {
                        recordingBlinkAnimation.start();
                    } else {
                        recordingBlinkAnimation.stop();
                        manualRecordingIndicator.opacity = 1.0;
                    }
                }
            }
        }

        // 更新红外窗口的约束条件
        function updateInfraredConstraints() {
            if (!root.pipMode) return;
            
            console.log("=== 更新红外窗口约束条件 ===");
            
            // 获取可见光视频的实际显示区域
            var videoRect = visibleLightOutput.contentRect;
            console.log("可见光视频区域:", videoRect.x, videoRect.y, videoRect.width, videoRect.height);
            
            // 设置拖动限制
            dragArea.drag.minimumX = videoRect.x;
            dragArea.drag.maximumX = Math.max(videoRect.x, videoRect.x + videoRect.width - infraredRect.width);
            dragArea.drag.minimumY = videoRect.y;
            dragArea.drag.maximumY = Math.max(videoRect.y, videoRect.y + videoRect.height - infraredRect.height);
            
            console.log("拖动限制 - X:", dragArea.drag.minimumX, "到", dragArea.drag.maximumX);
            console.log("拖动限制 - Y:", dragArea.drag.minimumY, "到", dragArea.drag.maximumY);
            
            // 如果当前位置超出了限制，调整位置
            var needUpdate = false;
            var newX = infraredRect.x;
            var newY = infraredRect.y;
            
            if (infraredRect.x < videoRect.x) {
                newX = videoRect.x;
                needUpdate = true;
            } else if (infraredRect.x + infraredRect.width > videoRect.x + videoRect.width) {
                newX = Math.max(videoRect.x, videoRect.x + videoRect.width - infraredRect.width);
                needUpdate = true;
            }
            
            if (infraredRect.y < videoRect.y) {
                newY = videoRect.y;
                needUpdate = true;
            } else if (infraredRect.y + infraredRect.height > videoRect.y + videoRect.height) {
                newY = Math.max(videoRect.y, videoRect.y + videoRect.height - infraredRect.height);
                needUpdate = true;
            }
            
            if (needUpdate) {
                console.log("调整红外窗口位置从", infraredRect.x, infraredRect.y, "到", newX, newY);
                infraredRect.x = newX;
                infraredRect.y = newY;
                root.pipX = newX;
                root.pipY = newY;
            }
        }
        
        // 监听PIP模式变化
        onPipModeChanged: {
            // 检查是否允许切换到PIP模式
            if (pipMode && !isNormalMode) {
                console.warn("=== 阻止PIP模式切换 ===");
                console.warn("当前不在普通模式，无法切换到PIP模式");
                console.warn("dualFusionMode:", dualFusionMode, "gasCloudMode:", gasCloudMode, "fullScreenMode:", fullScreenMode);
                
                // 阻止切换，恢复到false
                pipMode = false;
                return;
            }
            
            console.log("=== PIP模式切换成功 ===");
            console.log("pipMode:", pipMode);
            
            if (pipMode) {
                // 设置初始大小为200x200
                root.pipWidth = 200;
                root.pipHeight = 200;
                
                // 获取可见光视频的实际显示区域
                var videoRect = visibleLightOutput.contentRect;
                console.log("初始化PIP - 可见光视频区域:", videoRect.x, videoRect.y, videoRect.width, videoRect.height);
                
                // 设置初始位置（右下角，留出边距）
                if (videoRect.width > 0 && videoRect.height > 0) {
                    root.pipX = Math.max(videoRect.x, videoRect.x + videoRect.width - root.pipWidth - 20);
                    root.pipY = Math.max(videoRect.y, videoRect.y + videoRect.height - root.pipHeight - 20);
                } else {
                    // 如果视频区域还没有准备好，使用默认位置
                    root.pipX = root.width - root.pipWidth - 20;
                    root.pipY = root.height - root.pipHeight - 20;
                }
                
                console.log("初始化PIP位置:", root.pipX, root.pipY);
                console.log("初始化PIP大小:", root.pipWidth, root.pipHeight);
                
                infraredRect.width = root.pipWidth;
                infraredRect.height = root.pipHeight;
                infraredRect.x = root.pipX;
                infraredRect.y = root.pipY;
                
                // 延迟更新约束条件，确保视频区域已经准备好
                Qt.callLater(updateInfraredConstraints);
            }
        }
        
        // Toast提示组件
        Rectangle {
            id: permissionToast
            width: 300
            height: 50
            color: "#333333"
            radius: 8
            opacity: 0
            anchors.centerIn: parent
            z: 1000
            
            property string text: ""
            
            Text {
                anchors.centerIn: parent
                text: permissionToast.text
                color: "white"
                font.pixelSize: 14
            }
            
            function show() {
                opacity = 1
                hideTimer.start()
            }
            
            Timer {
                id: hideTimer
                interval: 2000
                onTriggered: {
                    permissionToast.opacity = 0
                }
            }
            
            Behavior on opacity {
                NumberAnimation {
                    duration: 300
                }
            }
        }

    }
