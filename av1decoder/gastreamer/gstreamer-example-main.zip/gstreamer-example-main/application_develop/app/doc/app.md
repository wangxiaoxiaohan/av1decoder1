# App

为了完成应用程序与GStreamer Pipeline的数据交互，GStreamer提供了两个插件：

- [GstAppSink](https://gstreamer.freedesktop.org/documentation/applib/gstappsink.html) – 应用程序从管道中提取GstSample的简便方法
- [GstAppSrc](https://gstreamer.freedesktop.org/documentation/applib/gstappsrc.html) – 应用程序向管道中注入GstBuffer的简单方法
- **Github:[gstreamer-app](https://github.com/gesanqiu/gstreamer-example/tree/main/application_develop/app)**

