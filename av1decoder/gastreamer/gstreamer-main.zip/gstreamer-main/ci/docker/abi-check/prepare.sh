#! /bin/bash

set -eux

bash ./ci/docker/abi-check/install-abi-check-cache.sh
