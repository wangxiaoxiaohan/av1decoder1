# GstValidate API reference

This is GstValidate API reference but note that the GstValidate is not
totally stable and might very well change even between minor versions.

The override API should be mostly stable still.
