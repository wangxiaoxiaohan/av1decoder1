# GStreamer design documents

This section gathers the various GStreamer design documents.
These documents are the technical documents that have been produce while
developing or refactoring parts of the GStreamer design to explain the
problems and the design solutions we came up to solve them.
