For any GStreamer usage questions or application development support
please head over to our new GStreamer Discourse forum at
https://discourse.gstreamer.org instead, or find us on the
GStreamer Matrix room at https://matrix.to/#/#gstreamer:gstreamer.org

