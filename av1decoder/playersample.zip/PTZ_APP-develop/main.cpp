#include <QGuiApplication>
#include <QtWidgets/QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <sstream>
#include <iostream>
//#include <curl/curl.h>
#include <json/json.h>
#include <tinyxml2.h>
#include <gst/gst.h>
#include <QTimer>
#include <QThread>
#include <QDateTime>
#include <QDir>

//#include "producer.h"
#include "src/frame_provider.h"

#include "src/ptz_device_cgi.h"
#include "src/ptz_device_manager.h"
#include "src/thermal_device_manager.h"
#include "src/device_proxy.h"
#include "src/player.h"
#include "src/thermal_ctl.h"
#include "src/hikvision_ctrl.h"
#include "src/model/alarmmodel.h"
#include "src/model/cruisemodel.h"
#include "src/model/presetmodel.h"
#include "src/model/usermodel.h"
#include "src/model/logmodel.h"
#include "src/model/devicemodel.h"
#include "src/model/devicetreemodel.h"
#include "src/playermanager.h"
#include "src/alarm_audio_player.h"
#include "src/hikvision_recorder.h"
#include "src/image_fusion_manager.h"
#include "src/gas_cloud_manager.h"

#include "src/alarmlog.h"
#include "src/alarmvideoplayer.h"
#include "src/history_video_player.h"
#include "src/tdlas_data_manager.h"
#include <QRandomGenerator>
 using namespace std;

int main(int argc, char* argv[]){
    QApplication app(argc, argv);
    QQmlApplicationEngine engine;
    QQmlContext* ctx = engine.rootContext();


    
    // 创建设备管理器
    PtzDeviceManager* ptzDeviceManager = PtzDeviceManager::instance();
    ThermalDeviceManager* thermalDeviceManager = ThermalDeviceManager::instance();
    
    // 创建设备代理
    DeviceProxy* deviceProxy = new DeviceProxy();
    

    

    // 创建HikvisionCtrl - 保持在主线程
    HikvisionCtrl* hikvisionCtrl = new HikvisionCtrl();
    
    // 创建HikvisionRecorder实例
    HikvisionRecorder* hikvisionRecorder = new HikvisionRecorder();
    
    // 设置context property
    engine.rootContext()->setContextProperty("hikvisionCtrl", hikvisionCtrl);
    engine.rootContext()->setContextProperty("hikvisionRecorder", hikvisionRecorder);
    engine.rootContext()->setContextProperty("ptzDeviceManager", ptzDeviceManager);
    engine.rootContext()->setContextProperty("thermalDeviceManager", thermalDeviceManager);
    engine.rootContext()->setContextProperty("deviceProxy", deviceProxy);
    
    // 为了向后兼容，保留旧的名称
    engine.rootContext()->setContextProperty("ptzCgisingleton", deviceProxy);
    engine.rootContext()->setContextProperty("tmCtl", deviceProxy);


//=====================
    qmlRegisterSingletonInstance("App.AlarmLog", 1, 0, "AlarmLog", AlarmLog::instance());
    
    // 注册TDLAS数据管理器
    qmlRegisterSingletonInstance("App.TdlasDataManager", 1, 0, "TdlasDataManager", TdlasDataManager::instance());
    
    // 注册历史视频播放器类型
    qmlRegisterType<HistoryVideoPlayer>("App", 1, 0, "HistoryVideoPlayer");
    
    // 注册 splayer 类型到 QML
    qmlRegisterType<splayer>("App", 1, 0, "SPlayer");


    // 确保应用退出时清理
    QObject::connect(&app, &QGuiApplication::aboutToQuit, hikvisionCtrl, &QObject::deleteLater);
    QObject::connect(&app, &QGuiApplication::aboutToQuit, deviceProxy, &QObject::deleteLater);
    
    
    qmlRegisterType<FrameProvider>("Local", 1, 0, "FrameProvider");
    
    // qmlRegisterType<PtzDeviceCgi>("Local", 1, 0, "PtzDeviceCgi");

    qmlRegisterSingletonInstance<AlarmModel>("App", 1, 0, "AlarmModel", AlarmModel::instance());
    qmlRegisterSingletonInstance<CruiseModel>("App", 1, 0, "CruiseModel", CruiseModel::instance());
    qmlRegisterSingletonInstance<PresetModel>("App", 1, 0, "PresetModel", PresetModel::instance());
    qmlRegisterSingletonInstance<UserModel>("App", 1, 0, "UserModel", UserModel::instance());
    qmlRegisterSingletonInstance<LogModel>("App", 1, 0, "LogModel", LogModel::instance());


    // 注册设备模型
    qmlRegisterSingletonInstance<DeviceModel>("App", 1, 0, "DeviceModel", DeviceModel::instance());
    
    
    // 注册设备树形模型
    qmlRegisterType<DeviceTreeModel>("App", 1, 0, "DeviceTreeModel");
    
    // 注册报警音频播放器
    qmlRegisterSingletonInstance<AlarmAudioPlayer>("App", 1, 0, "AlarmAudioPlayer", AlarmAudioPlayer::instance());
    
    // 注册图像融合管理器
    qmlRegisterSingletonInstance<ImageFusionManager>("App", 1, 0, "ImageFusionManager", ImageFusionManager::instance());
    
    // 注册气云分割管理器
    qmlRegisterSingletonInstance<GasCloudManager>("App", 1, 0, "GasCloudManager", GasCloudManager::instance());
    

    // 立即初始化图像融合管理器
    qDebug() << "=== 立即初始化图像融合管理器 ===";
    ImageFusionManager* fusionManager = ImageFusionManager::instance();
    qDebug() << "ImageFusionManager instance created:" << fusionManager;
    
    // 获取应用程序目录
    QString appDir = QCoreApplication::applicationDirPath();
    qDebug() << "Application directory:" << appDir;
    
    // 构建配置文件的绝对路径 - 从build目录回到项目根目录
    QString projectDir = QDir(appDir).absoluteFilePath("./");
    QString configPath = QDir(projectDir).absoluteFilePath("config/dual/calibration_params.json");
    qDebug() << "Project directory:" << projectDir;
    qDebug() << "Config file absolute path:" << configPath;
    
    // 检查配置文件是否存在
    QFile configFile(configPath);
    qDebug() << "Config file exists:" << configFile.exists();
    qDebug() << "Config file path:" << configFile.fileName();
    qDebug() << "Current working directory:" << QDir::currentPath();
    
    bool fusionInitialized = fusionManager->initializeFusion(configPath);
    qDebug() << "initializeFusion returned:" << fusionInitialized;
    
    // 检查初始化状态
    qDebug() << "isFusionAvailable:" << fusionManager->isFusionAvailable();
    qDebug() << "getFusionStatus:" << fusionManager->getFusionStatus();
    
    if (fusionInitialized) {
        qDebug() << "图像融合管理器初始化成功";
    } else {
        qWarning() << "图像融合管理器初始化失败";
    }
    qDebug() << "=== 图像融合管理器初始化完成 ===";
    
    // 立即初始化气云分割管理器
    qDebug() << "=== 立即初始化气云分割管理器 ===";
    GasCloudManager* gasCloudManager = GasCloudManager::instance();
    qDebug() << "GasCloudManager instance created:" << gasCloudManager;
    
    // 构建模型文件和配置文件的路径
    QString modelPath = QDir(projectDir).absoluteFilePath("config/segment/unet_0627_320_256.onnx");
    QString calibrationPath = QDir(projectDir).absoluteFilePath("config/segment/calibration_params.json");
    qDebug() << "Model file path:" << modelPath;
    qDebug() << "Calibration file path:" << calibrationPath;
    
    // 检查文件是否存在
    QFile modelFile(modelPath);
    QFile calibrationFile(calibrationPath);
    qDebug() << "Model file exists:" << modelFile.exists();
    qDebug() << "Calibration file exists:" << calibrationFile.exists();
    
    bool gasCloudInitialized = gasCloudManager->initializeGasCloud(modelPath, calibrationPath);
    qDebug() << "initializeGasCloud returned:" << gasCloudInitialized;
    
    // 检查初始化状态
    qDebug() << "isGasCloudAvailable:" << gasCloudManager->isGasCloudAvailable();
    qDebug() << "getGasCloudStatus:" << gasCloudManager->getGasCloudStatus();
    
    if (gasCloudInitialized) {
        qDebug() << "气云分割管理器初始化成功";
    } else {
        qWarning() << "气云分割管理器初始化失败";
    }
    qDebug() << "=== 气云分割管理器初始化完成 ===";
    
    // 先创建设备树形模型并设置到设备模型中
    DeviceTreeModel* deviceTreeModel = new DeviceTreeModel();
    DeviceModel::instance()->setTreeModel(deviceTreeModel);
    
    // 设置HikvisionCtrl实例到DeviceModel（在加载设备之前）
    DeviceModel::instance()->setHikvisionCtrl(hikvisionCtrl);
    
    // 然后加载设备配置
    DeviceModel::instance()->loadDefaultDevices();
    
    // 连接设备选择信号到预置位和巡航模型
    QObject::connect(DeviceModel::instance(), &DeviceModel::deviceSelected,
                     PresetModel::instance(), &PresetModel::setCurrentDevice);
    QObject::connect(DeviceModel::instance(), &DeviceModel::deviceSelected,
                     CruiseModel::instance(), &CruiseModel::setCurrentDevice);
    
    // 设置初始选中的设备（如果有的话）
    auto allDevices = DeviceModel::instance()->getAllDevices();
    if (!allDevices.isEmpty()) {
        QString firstDeviceId = allDevices.first().deviceId;
        // 设置到业务模型
        PresetModel::instance()->setCurrentDevice(firstDeviceId);
        CruiseModel::instance()->setCurrentDevice(firstDeviceId);
        // 设置到设备模型，作为全局选中设备，供回放/切换使用
        DeviceModel::instance()->selectDevice(firstDeviceId);
        qDebug() << "设置初始设备为选中设备:" << firstDeviceId;
    }

    //---------------------------------------------------------------------

    // 注册PlayerManager枚举到QML - 必须在创建实例之前注册
    qmlRegisterUncreatableMetaObject(PlayerManager::staticMetaObject, "App", 1, 0, "PlayerManager", "PlayerManager is not creatable");
    // 创建播放器管理器
    PlayerManager* playerManager = PlayerManager::instance();
    engine.rootContext()->setContextProperty("playerManager", playerManager);
    
    // 创建AlarmVideoPlayer实例并注册为上下文属性
    AlarmVideoPlayer* alarmVideoPlayer = AlarmVideoPlayer::instance();
    // 设置HikvisionCtrl实例到AlarmVideoPlayer
    alarmVideoPlayer->setHikvisionCtrl(hikvisionCtrl);
    engine.rootContext()->setContextProperty("AlarmVideoPlayer", alarmVideoPlayer);
    
    // 创建两个独立的HistoryVideoPlayer实例并设置HikvisionCtrl
    HistoryVideoPlayer* visibleLightHistoryPlayer = new HistoryVideoPlayer();
    visibleLightHistoryPlayer->setHikvisionCtrl(hikvisionCtrl);
    engine.rootContext()->setContextProperty("visibleLightHistoryPlayer", visibleLightHistoryPlayer);
    
    // 创建第二个HistoryVideoPlayer实例
    HistoryVideoPlayer* infraredHistoryPlayer = new HistoryVideoPlayer();
    infraredHistoryPlayer->setHikvisionCtrl(hikvisionCtrl);
    engine.rootContext()->setContextProperty("infraredHistoryPlayer", infraredHistoryPlayer);

    int channelCount = DeviceModel::instance()->getChannelCount();
    playerManager->initializePlayers(channelCount);

    // 为每个通道创建FrameProvider
    FrameProvider frameProviderVisibleLight[channelCount];
    FrameProvider frameProviderInfrared[channelCount];
    FrameProvider frameProviderVisibleLightRecord[channelCount];
    FrameProvider frameProviderInfraredRecord[channelCount];
    FrameProvider frameProviderDualFusion[channelCount]; 
    FrameProvider frameProviderGasCloudVisible[channelCount];
    FrameProvider frameProviderGasCloudInfrared[channelCount];
    
    QList<int> allChannels = DeviceModel::instance()->getAllDeviceChannelIndexes();
    for (int i = 0; i < channelCount; ++i) {
        //frameprovider和channel的映射关系写死，不用判断
        QString indexStr = QString::number(i);
        engine.rootContext()->setContextProperty("frameProviderVisibleLight" + indexStr, &frameProviderVisibleLight[i]);
        engine.rootContext()->setContextProperty("frameProviderInfrared" + indexStr, &frameProviderInfrared[i]);
        engine.rootContext()->setContextProperty("frameProviderVisibleLightRecord" + indexStr, &frameProviderVisibleLightRecord[i]);
        engine.rootContext()->setContextProperty("frameProviderInfraredRecord" + indexStr, &frameProviderInfraredRecord[i]);
        engine.rootContext()->setContextProperty("frameProviderDualFusion" + indexStr, &frameProviderDualFusion[i]);
        engine.rootContext()->setContextProperty("frameProviderGasCloudVisible" + indexStr, &frameProviderGasCloudVisible[i]);
        engine.rootContext()->setContextProperty("frameProviderGasCloudInfrared" + indexStr, &frameProviderGasCloudInfrared[i]); 
        if (allChannels.contains(i)) {
            // 使用新的映射表系统：先分配播放器，再设置FrameProvider
            int playerIndex = playerManager->allocatePlayerForChannel(i);
            if (playerIndex >= 0) {
                playerManager->setChannelFrameProvider(i, PlayerManager::VisibleLightLive, &frameProviderVisibleLight[i]); 
                playerManager->setChannelFrameProvider(i, PlayerManager::InfraredLive, &frameProviderInfrared[i]);   
                playerManager->setChannelFrameProvider(i, PlayerManager::VisibleLightRecord, &frameProviderVisibleLightRecord[i]);  
                playerManager->setChannelFrameProvider(i, PlayerManager::InfraredRecord, &frameProviderInfraredRecord[i]);    
                
                // 设置通道i的双光融合FrameProvider
                playerManager->setDualFusionProvider(i, &frameProviderDualFusion[i]);
                
                // 设置通道i的气云成像FrameProvider
                playerManager->setGasCloudVisibleProvider(i, &frameProviderGasCloudVisible[i]);
                playerManager->setGasCloudInfraredProvider(i, &frameProviderGasCloudInfrared[i]);
            }
        }
    }


    playerManager->updatePlayerUrls();
    engine.rootContext()->setContextProperty("playerManager", playerManager);
    
    
//-------------------------------------------------------------------------
        qDebug() << "=== 所有设备初始化完成 ===";

    engine.load(QStringLiteral("qrc:/main.qml"));
    QObject* rootObject = engine.rootObjects().value(0);
    QObject* item = rootObject->findChild<QObject*>("main_window");

    // 根据设备模型初始化播放器URL

        
        // 初始化所有设备 - 使用分离的IP地址和用户名密码
        auto devices = DeviceModel::instance()->getAllDevices();
        
        // 准备批量初始化通道信息的数据
        QStringList hikvisionIps;
        QStringList hikvisionUsernames; 
        QStringList hikvisionPasswords;
        QStringList visibleLightIps;
        QStringList infraredIps;
        
        for (const auto& device : devices) {
            // 初始化PTZ设备 - 使用可见光IP和用户名密码，以及TDLAS、Modbus、TOF信息
            if (!device.visibleLightIp.isEmpty()) {
                qDebug() << "=== 初始化PTZ设备 ===";
                qDebug() << "设备ID:" << device.deviceId;
                qDebug() << "可见光IP:" << device.visibleLightIp;
                qDebug() << "TDLAS IP:" << device.tdlasIp << "端口:" << device.tdlasPort;
                qDebug() << "Modbus IP:" << device.modbusIp << "端口:" << device.modbusPort;
                qDebug() << "TOF IP:" << device.tofIp << "端口:" << device.tofPort;
                
                ptzDeviceManager->initializeDevice(
                    device.deviceId, 
                    device.visibleLightUsername, 
                    device.visibleLightPassword, 
                    device.visibleLightIp, 
                    device.tdlasIp, 
                    device.tdlasPort,
                    device.modbusIp,
                    device.modbusPort,
                    device.tofIp,
                    device.tofPort
                );
                
                qDebug() << "PTZ设备初始化完成";
                
                // 收集海康NVR通道信息用于批量初始化
                if (!device.hikvisionIp.isEmpty()) {
                    hikvisionIps.append(device.hikvisionIp);
                    hikvisionUsernames.append(device.hikvisionUsername);
                    hikvisionPasswords.append(device.hikvisionPassword);
                    visibleLightIps.append(device.visibleLightIp);
                }
            }
            
            // 初始化热成像设备 - 使用红外IP和用户名密码
            if (!device.infraredIp.isEmpty()) {
                qDebug() << "=== 初始化热成像设备 ===";
                qDebug() << "设备ID:" << device.deviceId;
                qDebug() << "红外IP:" << device.infraredIp;
                
                thermalDeviceManager->initializeDevice(device.deviceId, device.infraredUsername, device.infraredPassword, device.infraredIp);
                
                qDebug() << "热成像设备初始化完成";
                
                // 收集红外设备信息用于通道查询
                if (!device.hikvisionIp.isEmpty()) {
                    hikvisionIps.append(device.hikvisionIp);
                    hikvisionUsernames.append(device.hikvisionUsername);
                    hikvisionPasswords.append(device.hikvisionPassword);
                    infraredIps.append(device.infraredIp);
                }
            }
        }
        
        // 异步初始化海康NVR通道信息
        qDebug() << "=== 开始异步初始化海康NVR通道信息 ===";
        if (!hikvisionIps.isEmpty()) {
            // 先初始化可见光设备通道
            if (!visibleLightIps.isEmpty()) {
                qDebug() << "初始化可见光设备通道信息，设备数量:" << visibleLightIps.size();
                hikvisionCtrl->initializeChannelInfo(hikvisionIps, hikvisionUsernames, hikvisionPasswords, visibleLightIps);
            }
            
            // 再初始化红外设备通道
            if (!infraredIps.isEmpty()) {
                qDebug() << "初始化红外设备通道信息，设备数量:" << infraredIps.size();
                hikvisionCtrl->initializeChannelInfo(hikvisionIps, hikvisionUsernames, hikvisionPasswords, infraredIps);
            }
        }
        qDebug() << "=== 海康NVR通道信息初始化请求已发送 ===";
        

        //-----------------------------------------------------------------------

    return app.exec();
}
