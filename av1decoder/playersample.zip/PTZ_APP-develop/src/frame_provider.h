#ifndef FRAMEPRODER_H
#define FRAMEPRODER_H

#include <QObject>
#include <QAbstractVideoSurface>
#include <QVideoSurfaceFormat>
#include <QMediaPlayer>
#include <QVideoProbe>
#include <QTimer>
#include <QList>
#include <QVideoFrame>
#include <QImage>
#include <QMutex>
#include <QPointer>
//#include "custom_video_surface.h"

class FrameProvider : public QObject{
Q_OBJECT
    Q_PROPERTY(QAbstractVideoSurface* videoSurface READ videoSurface WRITE setVideoSurface)
public:
    explicit FrameProvider(QObject* parent = nullptr);
    virtual ~FrameProvider();

    QAbstractVideoSurface* videoSurface() const;
    void setVideoSurface(QAbstractVideoSurface* surface);
    Q_INVOKABLE void removeVideoSurface(QAbstractVideoSurface *surface);
    void setFormat(int width, int heigth, QVideoFrame::PixelFormat format);
    void onNewVideoContentReceived(const QVideoFrame& frame);
    
    // 获取当前帧的QImage表示（按需转换）
    Q_INVOKABLE QImage getCurrentFrameAsImage() const;
    
    // 获取当前帧的原始QVideoFrame（避免转换）
    QVideoFrame getCurrentFrame() const { 
        QMutexLocker locker(&m_frameMutex);
        return m_currentFrame; 
    }
    
    // 截图功能
    Q_INVOKABLE QString captureCurrentFrame(const QString& fileName = QString());
    
    // 无信号检测
    Q_INVOKABLE bool mbIsNoSignal();
    
    // 清理方法：重置帧数据和表面状态
    Q_INVOKABLE void clearFrameData();
    
    // 断开所有连接
    Q_INVOKABLE void disconnectAll();

public slots:
    void OnNoSignalTimeout();
private:
    // Support multiple video surfaces for broadcasting frames
    // Use QPointer to automatically track surface validity
    QList<QPointer<QAbstractVideoSurface>> m_surfaces;
    QVideoSurfaceFormat m_format;
    QTimer nosignal_timer_;
    unsigned int nosignal_count_;
    QImage first_buf_img_;
    QImage second_buf_img_;
    
    // 新增成员变量：存储最新的帧（按需转换，不预先保存QImage）
    QVideoFrame m_currentFrame;
    mutable QMutex m_frameMutex;
    
    // 辅助方法：将VideoFrame转换为QImage
    QImage videoFrameToImage(const QVideoFrame& frame) const;
};

#endif // FRAMEPRODER_H
