#ifndef PRESET_MODEL_H
#define PRESET_MODEL_H

#include <QAbstractListModel>
#include <QList>
#include <QObject>
#include <QString>
#include <QHash>
#include <QVariantMap>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QStandardPaths>
#include <QDir>
#include <QDebug>

struct PresetData {
    QString deviceId;      // 设备ID，用于区分不同设备
    QString number;        // 预置位号码
    QString name;          // 预置位名称
    bool status;           // 预置位状态
};

class PresetModel : public QAbstractListModel {
    Q_OBJECT

public:
    enum Roles {
        DeviceIdRole = Qt::UserRole + 1,
        NumberRole,
        NameRole,
        StatusRole
    };

    QHash<int, QByteArray> roleNames() const override {
        return { 
            {DeviceIdRole, "deviceId"},
            {NumberRole, "number"},
            {NameRole, "name"},
            {StatusRole, "status"}
        };
    }
    
    explicit PresetModel(QObject *parent = nullptr);
    
    static PresetModel* instance() {
        static PresetModel _instance;
        return &_instance;
    }
    
    // 添加预置位
    Q_INVOKABLE void addPreset(const QString &deviceId, const PresetData &preset);
    Q_INVOKABLE void addPreset(const QString &deviceId, const QVariantMap &map);
    
    // 删除预置位
    Q_INVOKABLE void removePreset(const QString &deviceId, int index);
    Q_INVOKABLE void removePresetByNumber(const QString &deviceId, const QString &number);
    
    // 修改预置位
    Q_INVOKABLE void modifyPreset(const QString &deviceId, int index, const PresetData &preset);
    Q_INVOKABLE void modifyPreset(const QString &deviceId, int index, const QVariantMap &map);
    Q_INVOKABLE void modifyPresetByNumber(const QString &deviceId, const QString &number, const QVariantMap &map);
    
    // 查询预置位
    Q_INVOKABLE QList<PresetData> getPresetsForDevice(const QString &deviceId);
    Q_INVOKABLE PresetData getPresetByNumber(const QString &deviceId, const QString &number);
    Q_INVOKABLE int getPresetCount(const QString &deviceId);
    
    // 设备管理
    Q_INVOKABLE void clearPresetsForDevice(const QString &deviceId);
    Q_INVOKABLE QStringList getDeviceIds();
    
    // 数据持久化
    Q_INVOKABLE void savePresetsToFile();
    Q_INVOKABLE void loadPresetsFromFile();
    Q_INVOKABLE void savePresetsForDevice(const QString &deviceId);
    Q_INVOKABLE void loadPresetsForDevice(const QString &deviceId);
    
    // 当前选中设备
    Q_INVOKABLE void setCurrentDevice(const QString &deviceId);
    Q_INVOKABLE QString getCurrentDevice() const;
    
    // QAbstractListModel 接口实现
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    
    // 测试数据
    Q_INVOKABLE void addSampleData();
    Q_INVOKABLE void clearData();
    
signals:
    void presetAdded(const QString &deviceId, const QString &number);
    void presetRemoved(const QString &deviceId, const QString &number);
    void presetModified(const QString &deviceId, const QString &number);
    void currentDeviceChanged(const QString &deviceId);
    
private:
    QHash<QString, QList<PresetData>> m_devicePresets; // 按设备ID分组的预置位数据
    QString m_currentDeviceId; // 当前选中的设备ID
    
    QString getConfigDir() const;
    QString getPresetFilePath(const QString &deviceId) const;
    QString getGlobalPresetFilePath() const;
    void updateModel(); // 更新模型显示当前设备的预置位
    int findPresetIndex(const QString &deviceId, const QString &number) const;
};

// Function to register the model with QML
void registerPresetModel();

#endif // PRESET_MODEL_H 