#include "cruisemodel.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QStandardPaths>
#include <QDir>
#include <QDebug>
#include <QCoreApplication>

CruiseModel::CruiseModel(QObject *parent) 
    : QAbstractListModel(parent)
{
    // 在构造函数中加载所有设备的巡航数据
    loadCruisesFromFile();
}

// 添加巡航
void CruiseModel::addCruise(const QString &deviceId, const CruiseData &cruise)
{
    if (deviceId.isEmpty()) return;
    
    CruiseData newCruise = cruise;
    newCruise.deviceId = deviceId;
    
    if (!m_deviceCruises.contains(deviceId)) {
        m_deviceCruises[deviceId] = QList<CruiseData>();
    }
    
    // 检查是否已存在相同编号的巡航
    int existingIndex = findCruiseIndex(deviceId, cruise.cruiseNumber);
    if (existingIndex >= 0) {
        qWarning() << "巡航编号已存在:" << cruise.cruiseNumber << "设备:" << deviceId;
        return;
    }
    
    m_deviceCruises[deviceId].append(newCruise);
    
    // 如果是当前设备，更新模型显示
    if (deviceId == m_currentDeviceId) {
        updateModel();
    }
    
    // 保存到文件
    saveCruisesForDevice(deviceId);
    
    emit cruiseAdded(deviceId, cruise.cruiseNumber);
    qDebug() << "巡航已添加:" << cruise.cruiseName << "编号:" << cruise.cruiseNumber << "设备:" << deviceId;
}

void CruiseModel::addCruise(const QString &deviceId, const QVariantMap &map)
{
    CruiseData cruise;
    cruise.cruiseNumber = map["cruiseNumber"].toString();
    cruise.cruiseName = map["cruiseName"].toString();
    
    if (map.contains("presetPoints")) {
        QVariantList pointsList = map["presetPoints"].toList();
        for (const QVariant &point : pointsList) {
            cruise.presetPoints.append(point.toInt());
        }
    }
    
    addCruise(deviceId, cruise);
}

// 删除巡航
void CruiseModel::removeCruise(const QString &deviceId, int index)
{
    if (!m_deviceCruises.contains(deviceId) || 
        index < 0 || index >= m_deviceCruises[deviceId].size()) {
        return;
    }
    
    QString cruiseNumber = m_deviceCruises[deviceId][index].cruiseNumber;
    m_deviceCruises[deviceId].removeAt(index);
    
    // 如果是当前设备，更新模型显示
    if (deviceId == m_currentDeviceId) {
        updateModel();
    }
    
    // 保存到文件
    saveCruisesForDevice(deviceId);
    
    emit cruiseRemoved(deviceId, cruiseNumber);
    qDebug() << "巡航已删除:" << cruiseNumber << "设备:" << deviceId;
}

void CruiseModel::removeCruiseByNumber(const QString &deviceId, const QString &cruiseNumber)
{
    int index = findCruiseIndex(deviceId, cruiseNumber);
    if (index >= 0) {
        removeCruise(deviceId, index);
    }
}

// 修改巡航
void CruiseModel::modifyCruise(const QString &deviceId, int index, const CruiseData &cruise)
{
    if (!m_deviceCruises.contains(deviceId) || 
        index < 0 || index >= m_deviceCruises[deviceId].size()) {
        return;
    }
    
    CruiseData newCruise = cruise;
    newCruise.deviceId = deviceId;
    
    QString oldNumber = m_deviceCruises[deviceId][index].cruiseNumber;
    m_deviceCruises[deviceId][index] = newCruise;
    
    // 如果是当前设备，更新模型显示
    if (deviceId == m_currentDeviceId) {
        updateModel();
    }
    
    // 保存到文件
    saveCruisesForDevice(deviceId);
    
    emit cruiseModified(deviceId, cruise.cruiseNumber);
    qDebug() << "巡航已修改:" << cruise.cruiseName << "编号:" << cruise.cruiseNumber << "设备:" << deviceId;
}

void CruiseModel::modifyCruise(const QString &deviceId, int index, const QVariantMap &map)
{
    CruiseData cruise;
    cruise.cruiseNumber = map["cruiseNumber"].toString();
    cruise.cruiseName = map["cruiseName"].toString();
    
    if (map.contains("presetPoints")) {
        QVariantList pointsList = map["presetPoints"].toList();
        for (const QVariant &point : pointsList) {
            cruise.presetPoints.append(point.toInt());
        }
    }
    
    modifyCruise(deviceId, index, cruise);
}

void CruiseModel::modifyCruiseByNumber(const QString &deviceId, const QString &cruiseNumber, const QVariantMap &map)
{
    int index = findCruiseIndex(deviceId, cruiseNumber);
    if (index >= 0) {
        modifyCruise(deviceId, index, map);
    }
}

// 查询巡航
QList<CruiseData> CruiseModel::getCruisesForDevice(const QString &deviceId)
{
    if (m_deviceCruises.contains(deviceId)) {
        return m_deviceCruises[deviceId];
    }
    return QList<CruiseData>();
}

CruiseData CruiseModel::getCruiseByNumber(const QString &deviceId, const QString &cruiseNumber)
{
    int index = findCruiseIndex(deviceId, cruiseNumber);
    if (index >= 0 && m_deviceCruises.contains(deviceId)) {
        return m_deviceCruises[deviceId][index];
    }
    return CruiseData();
}

int CruiseModel::getCruiseCount(const QString &deviceId)
{
    if (m_deviceCruises.contains(deviceId)) {
        return m_deviceCruises[deviceId].size();
    }
    return 0;
}

// 设备管理
void CruiseModel::clearCruisesForDevice(const QString &deviceId)
{
    if (m_deviceCruises.contains(deviceId)) {
        m_deviceCruises[deviceId].clear();
        
        // 如果是当前设备，更新模型显示
        if (deviceId == m_currentDeviceId) {
            updateModel();
        }
        
        // 保存到文件
        saveCruisesForDevice(deviceId);
        
        qDebug() << "设备巡航已清空:" << deviceId;
    }
}

QStringList CruiseModel::getDeviceIds()
{
    return m_deviceCruises.keys();
}

// 当前选中设备
void CruiseModel::setCurrentDevice(const QString &deviceId)
{
    if (m_currentDeviceId != deviceId) {
        m_currentDeviceId = deviceId;
        updateModel();
        emit currentDeviceChanged(deviceId);
        qDebug() << "当前设备已切换到:" << deviceId;
    }
}

QString CruiseModel::getCurrentDevice() const
{
    return m_currentDeviceId;
}

// QAbstractListModel 接口实现
int CruiseModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    if (m_currentDeviceId.isEmpty() || !m_deviceCruises.contains(m_currentDeviceId)) {
        return 0;
    }
    return m_deviceCruises[m_currentDeviceId].size();
}

QVariant CruiseModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || m_currentDeviceId.isEmpty() || 
        !m_deviceCruises.contains(m_currentDeviceId) ||
        index.row() >= m_deviceCruises[m_currentDeviceId].size()) {
        return QVariant();
    }

    const CruiseData &item = m_deviceCruises[m_currentDeviceId][index.row()];
    
    switch(role) {
    case DeviceIdRole:
        return item.deviceId;
    case CruiseNumberRole:
        return item.cruiseNumber;
    case CruiseNameRole:
        return item.cruiseName;
    case PresetPointsRole: {
        QVariantList points;
        for (int point : item.presetPoints) {
            points.append(point);
        }
        return points;
    }
    default:
        return QVariant();
    }
}

// 数据持久化
void CruiseModel::saveCruisesToFile()
{
    for (const QString &deviceId : m_deviceCruises.keys()) {
        saveCruisesForDevice(deviceId);
    }
}

void CruiseModel::loadCruisesFromFile()
{
    // 加载全局巡航配置文件
    QString globalFilePath = getGlobalCruiseFilePath();
    QFile globalFile(globalFilePath);
    
    if (globalFile.exists() && globalFile.open(QIODevice::ReadOnly)) {
        QJsonDocument doc = QJsonDocument::fromJson(globalFile.readAll());
        QJsonObject rootObj = doc.object();
        
        m_deviceCruises.clear();
        
        for (auto it = rootObj.begin(); it != rootObj.end(); ++it) {
            QString deviceId = it.key();
            QJsonArray cruisesArray = it.value().toArray();
            
            QList<CruiseData> cruiseList;
            for (const auto &cruiseValue : cruisesArray) {
                QJsonObject cruiseObj = cruiseValue.toObject();
                CruiseData cruise;
                cruise.deviceId = deviceId;
                cruise.cruiseNumber = cruiseObj["cruiseNumber"].toString();
                cruise.cruiseName = cruiseObj["cruiseName"].toString();
                
                QJsonArray pointsArray = cruiseObj["presetPoints"].toArray();
                for (const auto &pointValue : pointsArray) {
                    cruise.presetPoints.append(pointValue.toInt());
                }
                
                cruiseList.append(cruise);
            }
            
            m_deviceCruises[deviceId] = cruiseList;
        }
        
        updateModel();
        qDebug() << "巡航配置已从全局文件加载:" << globalFilePath;
    } else {
        qDebug() << "全局巡航配置文件不存在，将创建新文件:" << globalFilePath;
    }
}

void CruiseModel::saveCruisesForDevice(const QString &deviceId)
{
    // 保存单个设备的巡航到设备专用文件
    QString deviceFilePath = getCruiseFilePath(deviceId);
    QDir().mkpath(QFileInfo(deviceFilePath).path());
    
    QFile deviceFile(deviceFilePath);
    if (deviceFile.open(QIODevice::WriteOnly)) {
        QJsonArray cruisesArray;
        
        if (m_deviceCruises.contains(deviceId)) {
            for (const auto &cruise : m_deviceCruises[deviceId]) {
                QJsonObject cruiseObj;
                cruiseObj["cruiseNumber"] = cruise.cruiseNumber;
                cruiseObj["cruiseName"] = cruise.cruiseName;
                
                QJsonArray pointsArray;
                for (int point : cruise.presetPoints) {
                    pointsArray.append(point);
                }
                cruiseObj["presetPoints"] = pointsArray;
                
                cruisesArray.append(cruiseObj);
            }
        }
        
        QJsonDocument doc(cruisesArray);
        deviceFile.write(doc.toJson());
        qDebug() << "设备巡航配置已保存:" << deviceFilePath;
    }
    
    // 同时更新全局配置文件
    QString globalFilePath = getGlobalCruiseFilePath();
    QDir().mkpath(QFileInfo(globalFilePath).path());
    
    QJsonObject globalObj;
    for (const QString &devId : m_deviceCruises.keys()) {
        QJsonArray cruisesArray;
        for (const auto &cruise : m_deviceCruises[devId]) {
            QJsonObject cruiseObj;
            cruiseObj["cruiseNumber"] = cruise.cruiseNumber;
            cruiseObj["cruiseName"] = cruise.cruiseName;
            
            QJsonArray pointsArray;
            for (int point : cruise.presetPoints) {
                pointsArray.append(point);
            }
            cruiseObj["presetPoints"] = pointsArray;
            
            cruisesArray.append(cruiseObj);
        }
        globalObj[devId] = cruisesArray;
    }
    
    QFile globalFile(globalFilePath);
    if (globalFile.open(QIODevice::WriteOnly)) {
        QJsonDocument doc(globalObj);
        globalFile.write(doc.toJson());
        qDebug() << "全局巡航配置已更新:" << globalFilePath;
    }
}

void CruiseModel::loadCruisesForDevice(const QString &deviceId)
{
    QString filePath = getCruiseFilePath(deviceId);
    QFile file(filePath);
    
    if (file.exists() && file.open(QIODevice::ReadOnly)) {
        QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
        QJsonArray cruisesArray = doc.array();
        
        QList<CruiseData> cruiseList;
        for (const auto &cruiseValue : cruisesArray) {
            QJsonObject cruiseObj = cruiseValue.toObject();
            CruiseData cruise;
            cruise.deviceId = deviceId;
            cruise.cruiseNumber = cruiseObj["cruiseNumber"].toString();
            cruise.cruiseName = cruiseObj["cruiseName"].toString();
            
            QJsonArray pointsArray = cruiseObj["presetPoints"].toArray();
            for (const auto &pointValue : pointsArray) {
                cruise.presetPoints.append(pointValue.toInt());
            }
            
            cruiseList.append(cruise);
        }
        
        m_deviceCruises[deviceId] = cruiseList;
        
        // 如果是当前设备，更新模型显示
        if (deviceId == m_currentDeviceId) {
            updateModel();
        }
        
        qDebug() << "设备巡航配置已加载:" << filePath;
    } else {
        qDebug() << "设备巡航配置文件不存在:" << filePath;
    }
}

// 测试数据
void CruiseModel::addSampleData()
{
    // 为默认设备添加示例数据
    QString sampleDeviceId = "device_001";
    
    CruiseData cruise1;
    cruise1.cruiseNumber = "1";
    cruise1.cruiseName = "巡航路线1";
    cruise1.presetPoints = {1, 2, 3, 4};
    addCruise(sampleDeviceId, cruise1);
    
    CruiseData cruise2;
    cruise2.cruiseNumber = "2";
    cruise2.cruiseName = "巡航路线2";
    cruise2.presetPoints = {5, 6, 7, 8};
    addCruise(sampleDeviceId, cruise2);
    
    CruiseData cruise3;
    cruise3.cruiseNumber = "3";
    cruise3.cruiseName = "巡航路线3";
    cruise3.presetPoints = {1, 3, 5, 7};
    addCruise(sampleDeviceId, cruise3);
    
    CruiseData cruise4;
    cruise4.cruiseNumber = "4";
    cruise4.cruiseName = "巡航路线4";
    cruise4.presetPoints = {2, 4, 6, 8};
    addCruise(sampleDeviceId, cruise4);
}

void CruiseModel::clearData()
{
    beginResetModel();
    m_deviceCruises.clear();
    m_currentDeviceId.clear();
    endResetModel();
    
    // 清空所有配置文件
    QString configDir = getConfigDir();
    QDir dir(configDir);
    QStringList filters;
    filters << "cruise_*.json" << "cruises_global.json";
    QFileInfoList files = dir.entryInfoList(filters, QDir::Files);
    
    for (const QFileInfo &fileInfo : files) {
        QFile::remove(fileInfo.absoluteFilePath());
        qDebug() << "已删除巡航配置文件:" << fileInfo.absoluteFilePath();
    }
}

// 私有方法
QString CruiseModel::getConfigDir() const
{
    QString appDir = QCoreApplication::applicationDirPath();
    QString configDir = QDir(appDir).absoluteFilePath("config/cruises");
    return configDir;
}

QString CruiseModel::getCruiseFilePath(const QString &deviceId) const
{
    QString configDir = getConfigDir();
    return QDir(configDir).absoluteFilePath(QString("cruise_%1.json").arg(deviceId));
}

QString CruiseModel::getGlobalCruiseFilePath() const
{
    QString configDir = getConfigDir();
    return QDir(configDir).absoluteFilePath("cruises_global.json");
}

void CruiseModel::updateModel()
{
    beginResetModel();
    endResetModel();
}

int CruiseModel::findCruiseIndex(const QString &deviceId, const QString &cruiseNumber) const
{
    if (!m_deviceCruises.contains(deviceId)) {
        return -1;
    }
    
    const QList<CruiseData> &cruises = m_deviceCruises[deviceId];
    for (int i = 0; i < cruises.size(); ++i) {
        if (cruises[i].cruiseNumber == cruiseNumber) {
            return i;
        }
    }
    return -1;
}

// 注册模型到QML的函数
void registerCruiseModel() {
    // 注册已在main.cpp中完成
} 