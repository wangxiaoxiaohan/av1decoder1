#include "hikvision_ctrl.h"
#include <QUuid>
#include <QUrl>
#include <QDebug>
#include <QJsonDocument>
#include <QCryptographicHash>
#include <QDateTime>
#include <QXmlStreamReader>
#include <QXmlStreamWriter>
#include <QTimer>
#include <cstring>
#include <curl/curl.h>

// CURL 写回调函数
static size_t HikvisionWriteCallback(void* contents, size_t size, size_t nmemb, void* userp)
{
    const size_t totalSize = size * nmemb;
    QByteArray* buffer = static_cast<QByteArray*>(userp);
    buffer->append(static_cast<char*>(contents), static_cast<int>(totalSize));
    return totalSize;
}

// 新增：响应头回调函数，用于提取Cookie
static size_t HikvisionHeaderCallback(char* buffer, size_t size, size_t nitems, void* userdata)
{
    size_t totalSize = size * nitems;
    QString header = QString::fromUtf8(buffer, totalSize).trimmed();
    
    // 查找Set-Cookie头
    if (header.startsWith("Set-Cookie:", Qt::CaseInsensitive)) {
        QString* cookiePtr = static_cast<QString*>(userdata);
        QString cookieValue = header.mid(11).trimmed(); // 跳过"Set-Cookie:"
        
        // 提取Cookie值（到分号为止）
        int semicolonPos = cookieValue.indexOf(';');
        if (semicolonPos > 0) {
            cookieValue = cookieValue.left(semicolonPos);
        }
        
        *cookiePtr = cookieValue;
        qDebug() << "获取到Cookie:" << cookieValue;
    }
    
    return totalSize;
}

HikvisionCtrl::HikvisionCtrl(QObject* parent)
    : QObject(parent)
    , m_curl(nullptr)
    , m_headers(nullptr)
{
    // 初始化 CURL
    curl_global_init(CURL_GLOBAL_DEFAULT);
    m_curl = curl_easy_init();
    
    // 硬编码认证信息和服务器IP
    m_serverIp = "192.168.1.102";  // 可以根据需要修改
    m_username = "admin";
    m_password = "WANG234WH";
    
    // 连接信号和槽，确保异步执行
    connect(this, &HikvisionCtrl::searchRecordingRequested,
            this, &HikvisionCtrl::doSearchRecording,
            Qt::QueuedConnection);
    
    // 新增：连接通道查找的信号和槽
    connect(this, &HikvisionCtrl::channelLookupRequested,
            this, &HikvisionCtrl::doChannelLookup,
            Qt::QueuedConnection);
}

HikvisionCtrl::~HikvisionCtrl()
{
    if (m_headers) {
        curl_slist_free_all(m_headers);
    }
    if (m_curl) {
        curl_easy_cleanup(m_curl);
    }
    curl_global_cleanup();
}

void HikvisionCtrl::searchRecording(const QString& searchId, int trackId, 
                                   const QString& startTime, const QString& endTime, 
                                   int maxResults, int searchResultPosition)
{
    // 只发信号，不做耗时工作
    emit searchRecordingRequested(searchId, trackId, startTime, endTime, maxResults, searchResultPosition);
}

// 新增：异步通道查找接口
void HikvisionCtrl::findChannelByIPAsync(const QString& deviceIp, int port,
                                        const QString& username, const QString& password,
                                        const QString& ipcIp)
{
    qDebug() << "异步查找通道，NVR IP:" << deviceIp << "IPC IP:" << ipcIp;
    emit channelLookupRequested(deviceIp, port, username, password, ipcIp, false);
}

// 修改后的同步接口，优先检查缓存
int HikvisionCtrl::findChannelByIP(const QString& deviceIp, int port,
                                  const QString& username, const QString& password,
                                  const QString& ipcIp)
{
    qDebug() << "Finding channel for IPC IP:" << ipcIp << "on NVR:" << deviceIp;
    
    // // 首先检查缓存
    // ChannelInfo cachedInfo = getChannelFromCache(deviceIp, ipcIp);
    // if (cachedInfo.isValid) {
    //     qDebug() << "从缓存中找到通道信息，通道号:" << cachedInfo.channelNumber;
    //     return cachedInfo.channelNumber;
    // }
    
    qDebug() << "缓存中没有找到通道信息，进行实时查询";
    qDebug() << "Using ISAPI interface with credentials:" << username << "password:" << password;

    // 尝试多个不同的ISAPI路径来获取通道信息
    QStringList possibleUrls = {
        QString("http://%1/ISAPI/System/Video/inputs").arg(deviceIp),
        QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels").arg(deviceIp),
        QString("http://%1/ISAPI/Streaming/channels").arg(deviceIp),
        QString("http://%1/ISAPI/System/channels").arg(deviceIp)
    };
    
    // 临时保存当前认证信息
    QString originalServerIp = m_serverIp;
    QString originalUsername = m_username;
    QString originalPassword = m_password;
    
    // 设置临时认证信息
    m_serverIp = deviceIp;
    m_username = username;
    m_password = password;
    
    QString response;
    bool success = false;
    QString successUrl;
    
    // 尝试每个可能的URL，直到找到一个有效的
    for (const QString& url : possibleUrls) {
        qDebug() << "Trying ISAPI URL:" << url;
        
        if (sendHttpRequest(url, "GET", QString(), &response)) {
            // 检查响应是否包含错误信息
            if (!response.contains("Invalid Operation") && !response.contains("notSupport")) {
                success = true;
                successUrl = url;
                qDebug() << "Successfully got response from:" << url;
                break;
            } else {
                qDebug() << "URL not supported:" << url;
            }
        } else {
            qDebug() << "Failed to connect to:" << url;
        }
    }
    
    // 恢复原始认证信息
    m_serverIp = originalServerIp;
    m_username = originalUsername;
    m_password = originalPassword;
    
    if (!success) {
        qCritical() << "Failed to get channel info via any ISAPI endpoint";
        qCritical() << "Last response:" << response;
        return -1;
    }
    
    qDebug() << "Channel info response:" << response;
    
    // 解析XML响应，查找匹配的IP通道
    int channel = parseChannelInfoForIP(response, ipcIp);
    
    if (channel > 0) {
        qDebug() << "Found IPC" << ipcIp << "on channel" << channel;
        // 更新缓存
        updateChannelCache(deviceIp, ipcIp, channel < 32 ? channel + 32 : channel);
    } else {
        qWarning() << "IPC" << ipcIp << "not found on NVR" << deviceIp;
    }

    return channel < 32 ? channel + 32 : channel;
}

// 新增：强制更新通道信息
void HikvisionCtrl::forceUpdateChannelInfo(const QString& deviceIp, int port,
                                          const QString& username, const QString& password,
                                          const QString& ipcIp)
{
    qDebug() << "强制更新通道信息，NVR IP:" << deviceIp << "IPC IP:" << ipcIp;
    
    // 清除缓存中的对应条目
    QString cacheKey = generateCacheKey(deviceIp, ipcIp);
    m_channelCache.remove(cacheKey);
    
    // 发起异步查询请求
    emit channelLookupRequested(deviceIp, port, username, password, ipcIp, true);
}

// 新增：批量初始化通道信息
void HikvisionCtrl::initializeChannelInfo(const QStringList& deviceIps, 
                                         const QStringList& usernames,
                                         const QStringList& passwords,
                                         const QStringList& ipcIps,
                                         int port)
{
    qDebug() << "开始批量初始化通道信息，设备数量:" << deviceIps.size();
    
    if (deviceIps.size() != usernames.size() || deviceIps.size() != passwords.size() || deviceIps.size() != ipcIps.size()) {
        qWarning() << "批量初始化参数数量不匹配";
        emit channelInitializationCompleted();
        return;
    }
    
    // 为每个设备发起异步查询
    for (int i = 0; i < deviceIps.size(); ++i) {
        findChannelByIPAsync(deviceIps[i], port, usernames[i], passwords[i], ipcIps[i]);
    }
    
    // 注意：这里简化处理，实际应该等待所有查询完成后再发信号
    // 可以通过计数器来跟踪完成状态
    QTimer::singleShot(5000, this, &HikvisionCtrl::channelInitializationCompleted);
}

// 新增：获取缓存的通道信息
int HikvisionCtrl::getCachedChannelNumber(const QString& nvrIp, const QString& ipcIp)
{
    ChannelInfo info = getChannelFromCache(nvrIp, ipcIp);
    return info.isValid ? info.channelNumber : -1;
}

// 新增：检查缓存是否有效
bool HikvisionCtrl::isChannelCacheValid(const QString& nvrIp, const QString& ipcIp)
{
    ChannelInfo info = getChannelFromCache(nvrIp, ipcIp);
    return info.isValid;
}

// 新增：清除所有缓存
void HikvisionCtrl::clearChannelCache()
{
    qDebug() << "清除所有通道缓存，当前缓存数量:" << m_channelCache.size();
    m_channelCache.clear();
}

// 新增：异步通道查找处理函数
void HikvisionCtrl::doChannelLookup(const QString& deviceIp, int port,
                                   const QString& username, const QString& password,
                                   const QString& ipcIp, bool forceUpdate)
{
    qDebug() << "执行异步通道查找，NVR IP:" << deviceIp << "IPC IP:" << ipcIp << "强制更新:" << forceUpdate;
    
    // 如果不是强制更新，先检查缓存
    if (!forceUpdate) {
        ChannelInfo cachedInfo = getChannelFromCache(deviceIp, ipcIp);
        if (cachedInfo.isValid) {
            qDebug() << "从缓存中找到通道信息，直接返回";
            emit channelLookupCompleted(deviceIp, ipcIp, cachedInfo.channelNumber);
            return;
        }
    }
    
    // 执行实际的查找逻辑（复用现有的findChannelByIP逻辑）
    int channel = findChannelByIP(deviceIp, port, username, password, ipcIp);
    
    if (channel > 0) {
        emit channelLookupCompleted(deviceIp, ipcIp, channel);
    } else {
        emit channelLookupFailed(deviceIp, ipcIp, "无法找到对应的通道号");
    }
}

// 新增：生成缓存键
QString HikvisionCtrl::generateCacheKey(const QString& nvrIp, const QString& ipcIp)
{
    return QString("%1|%2").arg(nvrIp).arg(ipcIp);
}

// 新增：更新通道缓存
void HikvisionCtrl::updateChannelCache(const QString& nvrIp, const QString& ipcIp, int channelNumber)
{
    QString cacheKey = generateCacheKey(nvrIp, ipcIp);
    ChannelInfo info(channelNumber, nvrIp, ipcIp);
    m_channelCache[cacheKey] = info;
    qDebug() << "更新通道缓存，键:" << cacheKey << "通道:" << channelNumber;
}

// 新增：从缓存获取通道信息
ChannelInfo HikvisionCtrl::getChannelFromCache(const QString& nvrIp, const QString& ipcIp)
{
    QString cacheKey = generateCacheKey(nvrIp, ipcIp);
    if (m_channelCache.contains(cacheKey)) {
        ChannelInfo info = m_channelCache[cacheKey];
        
        // 检查缓存是否过期（例如，1小时后过期）
        QDateTime now = QDateTime::currentDateTime();
        if (info.lastUpdated.secsTo(now) < 3600) {  // 1小时 = 3600秒
            return info;
        } else {
            qDebug() << "缓存过期，移除过期条目:" << cacheKey;
            m_channelCache.remove(cacheKey);
        }
    }
    
    return ChannelInfo();  // 返回无效的缓存信息
}

int HikvisionCtrl::parseChannelInfoForIP(const QString& xmlResponse, const QString& ipcIp)
{
    qDebug() << "Parsing channel info for IP:" << ipcIp;
    
    QXmlStreamReader reader(xmlResponse);
    int channelId = -1;
    bool inChannel = false;
    QString currentChannelId;
    QString currentChannelIp;
    
    // 支持多种通道类型的XML节点名称
    QStringList channelNodeNames = {
        "VideoInputChannel", 
        "InputProxyChannel", 
        "StreamingChannel", 
        "Channel"
    };
    
    // 支持多种IP地址字段的XML节点名称
    QStringList ipFieldNames = {
        "ipAddress",
        "IPAddress", 
        "ip",
        "address",
        "deviceAddress"
    };
    
    QString currentChannelType;
    
    while (!reader.atEnd()) {
        reader.readNext();
        
        if (reader.isStartElement()) {
            // 检查是否是任何类型的通道节点
            QString elementName = reader.name().toString();
            if (channelNodeNames.contains(elementName)) {
                inChannel = true;
                currentChannelType = elementName;
                currentChannelId.clear();
                currentChannelIp.clear();
                qDebug() << "Found channel node:" << elementName;
            } else if (inChannel && reader.name() == "id") {
                currentChannelId = reader.readElementText();
                qDebug() << "Channel ID:" << currentChannelId;
            } else if (inChannel && ipFieldNames.contains(elementName)) {
                // 直接读取IP地址
                currentChannelIp = reader.readElementText();
                qDebug() << "Found IP address:" << currentChannelIp << "in field:" << elementName;
            } else if (inChannel && (reader.name() == "sourceInputPortDescriptor" || 
                                   reader.name() == "inputPort" || 
                                   reader.name() == "deviceInfo" ||
                                   reader.name() == "networkInfo")) {
                // 在这些容器节点中查找IP地址信息
                QString containerName = reader.name().toString();
                while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == containerName)) {
                    reader.readNext();
                    if (reader.isStartElement()) {
                        QString subElementName = reader.name().toString();
                        if (ipFieldNames.contains(subElementName)) {
                            currentChannelIp = reader.readElementText();
                            qDebug() << "Found IP address:" << currentChannelIp << "in container:" << containerName;
                            break;
                        }
                    }
                }
            }
        } else if (reader.isEndElement()) {
            QString elementName = reader.name().toString();
            if (channelNodeNames.contains(elementName) && elementName == currentChannelType) {
                // 检查当前通道是否匹配目标IP
                qDebug() << "End of channel node. Channel ID:" << currentChannelId << "IP:" << currentChannelIp;
                if (!currentChannelIp.isEmpty() && currentChannelIp == ipcIp) {
                    bool ok;
                    int id = currentChannelId.toInt(&ok);
                    if (ok) {
                        channelId = id;
                        qDebug() << "Found matching channel:" << channelId << "for IP:" << ipcIp;
                        break;
                    } else {
                        qDebug() << "Channel ID is not a valid integer:" << currentChannelId;
                    }
                }
                inChannel = false;
                currentChannelType.clear();
            }
        }
    }
    
    if (reader.hasError()) {
        qCritical() << "XML parsing error:" << reader.errorString();
        return -1;
    }
    
    if (channelId == -1) {
        qWarning() << "No channel found for IP:" << ipcIp;
        qDebug() << "Complete XML response:" << xmlResponse;
        
        // 尝试输出所有找到的通道信息用于调试
        QXmlStreamReader debugReader(xmlResponse);
        qDebug() << "=== Debug: All channels found in response ===";
        while (!debugReader.atEnd()) {
            debugReader.readNext();
            if (debugReader.isStartElement() && channelNodeNames.contains(debugReader.name().toString())) {
                QString debugChannelId, debugChannelIp;
                QString channelType = debugReader.name().toString();
                
                while (!debugReader.atEnd() && !(debugReader.isEndElement() && debugReader.name() == channelType)) {
                    debugReader.readNext();
                    if (debugReader.isStartElement()) {
                        if (debugReader.name() == "id") {
                            debugChannelId = debugReader.readElementText();
                        } else if (ipFieldNames.contains(debugReader.name().toString())) {
                            debugChannelIp = debugReader.readElementText();
                        }
                    }
                }
                qDebug() << "Channel found - Type:" << channelType << "ID:" << debugChannelId << "IP:" << debugChannelIp;
            }
        }
        qDebug() << "=== End debug info ===";
    }
    
    return channelId;
}

void HikvisionCtrl::doSearchRecording(const QString& searchId, int trackId, 
                                     const QString& startTime, const QString& endTime, 
                                     int maxResults, int searchResultPosition)
{
    // 构建请求URL
    QString url = QString("http://%1/ISAPI/ContentMgmt/search").arg(m_serverIp);
    
    // 创建XML请求体
    QString xmlData = createSearchXml(searchId, trackId, startTime, endTime, maxResults, searchResultPosition);
    
    qDebug() << "发送海康录像查询请求到:" << url;
    qDebug() << "请求体:" << xmlData;
    
    // 发送POST请求
    QString response;
    if (sendHttpRequest(url, "POST", xmlData, &response)) {
        qDebug() << "海康录像查询响应:" << response;
        // 解析XML响应
        QJsonObject result = parseSearchResult(response);
        emit recordingSearchCompleted(result);
        
        // 如果有录像结果，自动准备第一个录像的RTSP流
        if (result.contains("matchList")) {
            QJsonArray matchList = result["matchList"].toArray();
            if (!matchList.isEmpty()) {
                QJsonObject firstMatch = matchList.first().toObject();
                if (firstMatch.contains("mediaSegmentDescriptor")) {
                    QJsonObject mediaDesc = firstMatch["mediaSegmentDescriptor"].toObject();
                    if (mediaDesc.contains("playbackURI")) {
                        QString playbackUri = mediaDesc["playbackURI"].toString();
                        qDebug() << "找到录像播放URI:" << playbackUri;
                        
                    }
                }
            }
        }
    } else {
        qCritical() << "海康录像查询失败";
        emit recordingSearchCompleted(QJsonObject());
    }
}

QString HikvisionCtrl::createSearchXml(const QString& searchId, int trackId, 
                                      const QString& startTime, const QString& endTime, 
                                      int maxResults, int searchResultPosition)
{
    QString xml;
    QXmlStreamWriter writer(&xml);
    
    // 设置格式化输出
    writer.setAutoFormatting(true);
    writer.setAutoFormattingIndent(0); // 不使用缩进，保持原格式
    
    // 手动构建XML以确保格式完全匹配官方示例
    xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    xml += "<CMSearchDescription>\n";
    xml += "<searchID>" + searchId + "</searchID>\n";
    xml += "<trackList>\n";
    xml += "<trackID>" + QString::number(trackId) + "</trackID>\n";
    xml += "</trackList>\n";
    xml += "<timeSpanList>\n";
    xml += "<timeSpan>\n";
    xml += "<startTime>" + startTime + "</startTime>\n";
    xml += "<endTime>" + endTime + "</endTime>\n";
    xml += "</timeSpan>\n";
    xml += "</timeSpanList>\n";
    xml += "<maxResults>" + QString::number(maxResults) + "</maxResults>\n";
    xml += "<searchResultPosition>" + QString::number(searchResultPosition) + "</searchResultPosition>\n";
    xml += "<metadataList>\n";
    xml += "<metadataDescriptor>//recordType.meta.std-cgi.com</metadataDescriptor>\n";
    xml += "</metadataList>\n";
    xml += "</CMSearchDescription>";
    
    return xml;
}

QJsonObject HikvisionCtrl::parseSearchResult(const QString& xmlResponse)
{
    QJsonObject result;
    QXmlStreamReader reader(xmlResponse);
    
    while (!reader.atEnd()) {
        reader.readNext();
        
        if (reader.isStartElement()) {
            if (reader.name() == "searchID") {
                result["searchID"] = reader.readElementText();
            } else if (reader.name() == "responseStatus") {
                result["responseStatus"] = reader.readElementText();
            } else if (reader.name() == "responseStatusStrg") {
                result["responseStatusStrg"] = reader.readElementText();
            } else if (reader.name() == "numOfMatches") {
                result["numOfMatches"] = reader.readElementText().toInt();
            } else if (reader.name() == "matchList") {
                QJsonArray matchArray;
                
                while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "matchList")) {
                    reader.readNext();
                    
                    if (reader.isStartElement() && reader.name() == "searchMatchItem") {
                        QJsonObject matchItem;
                        
                        while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "searchMatchItem")) {
                            reader.readNext();
                            
                            if (reader.isStartElement()) {
                                if (reader.name() == "sourceID") {
                                    matchItem["sourceID"] = reader.readElementText();
                                } else if (reader.name() == "trackID") {
                                    matchItem["trackID"] = reader.readElementText();
                                } else if (reader.name() == "timeSpan") {
                                    QJsonObject timeSpan;
                                    
                                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "timeSpan")) {
                                        reader.readNext();
                                        
                                        if (reader.isStartElement()) {
                                            if (reader.name() == "startTime") {
                                                timeSpan["startTime"] = reader.readElementText();
                                            } else if (reader.name() == "endTime") {
                                                timeSpan["endTime"] = reader.readElementText();
                                            }
                                        }
                                    }
                                    matchItem["timeSpan"] = timeSpan;
                                } else if (reader.name() == "mediaSegmentDescriptor") {
                                    QJsonObject mediaSegment;
                                    
                                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "mediaSegmentDescriptor")) {
                                        reader.readNext();
                                        
                                        if (reader.isStartElement()) {
                                            if (reader.name() == "contentType") {
                                                mediaSegment["contentType"] = reader.readElementText();
                                            } else if (reader.name() == "codecType") {
                                                mediaSegment["codecType"] = reader.readElementText();
                                            } else if (reader.name() == "playbackURI") {
                                                mediaSegment["playbackURI"] = reader.readElementText();
                                            } else if (reader.name() == "lockStatus") {
                                                mediaSegment["lockStatus"] = reader.readElementText();
                                            } else if (reader.name() == "name") {
                                                mediaSegment["name"] = reader.readElementText();
                                            }
                                        }
                                    }
                                    matchItem["mediaSegmentDescriptor"] = mediaSegment;
                                }
                            }
                        }
                        
                        matchArray.append(matchItem);
                    }
                }
                
                result["matchList"] = matchArray;
            }
        }
    }
    
    if (reader.hasError()) {
        qCritical() << "XML parsing error:" << reader.errorString();
    }
    
    return result;
}

bool HikvisionCtrl::sendHttpRequest(const QString& url, const QString& method, 
                                   const QString& data, QString* response)
{
    if (!m_curl) {
        qCritical() << "CURL not initialized";
        return false;
    }
    
    QByteArray responseData;
    QString receivedCookie;
    
    // 重置 CURL 选项
    curl_easy_reset(m_curl);
    
    // 设置基本选项
    curl_easy_setopt(m_curl, CURLOPT_URL, url.toUtf8().constData());
    curl_easy_setopt(m_curl, CURLOPT_WRITEFUNCTION, HikvisionWriteCallback);
    curl_easy_setopt(m_curl, CURLOPT_WRITEDATA, &responseData);
    
    // 设置响应头回调以提取Cookie
    curl_easy_setopt(m_curl, CURLOPT_HEADERFUNCTION, HikvisionHeaderCallback);
    curl_easy_setopt(m_curl, CURLOPT_HEADERDATA, &receivedCookie);
    
    // 设置超时
    curl_easy_setopt(m_curl, CURLOPT_TIMEOUT, 30L);
    curl_easy_setopt(m_curl, CURLOPT_CONNECTTIMEOUT, 10L);
    
    // 设置 Digest Auth - 使用硬编码的认证信息
    curl_easy_setopt(m_curl, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
    curl_easy_setopt(m_curl, CURLOPT_USERPWD, QString("%1:%2").arg(m_username).arg(m_password).toUtf8().constData());
    
    // 设置请求头
    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/xml");
    headers = curl_slist_append(headers, "Accept: application/xml");
    
    // 如果有Cookie，添加到请求头
    if (!m_cookie.isEmpty()) {
        QString cookieHeader = QString("Cookie: %1").arg(m_cookie);
        headers = curl_slist_append(headers, cookieHeader.toUtf8().constData());
    }
    
    curl_easy_setopt(m_curl, CURLOPT_HTTPHEADER, headers);
    
    // 设置请求方法和数据
    if (method == "POST") {
        curl_easy_setopt(m_curl, CURLOPT_POST, 1L);
        if (!data.isEmpty()) {
            QByteArray postData = data.toUtf8();
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDS, postData.constData());
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDSIZE, postData.size());
        }
    } else if (method == "GET") {
        curl_easy_setopt(m_curl, CURLOPT_HTTPGET, 1L);
    }
    
    // 执行请求
    CURLcode res = curl_easy_perform(m_curl);
    
    // 清理头部
    curl_slist_free_all(headers);
    
    if (res != CURLE_OK) {
        qCritical() << "CURL request failed:" << curl_easy_strerror(res);
        return false;
    }
    
    // 如果收到了新的Cookie，保存它
    if (!receivedCookie.isEmpty()) {
        m_cookie = receivedCookie;
    }
    
    // 检查HTTP状态码
    long httpCode = 0;
    curl_easy_getinfo(m_curl, CURLINFO_RESPONSE_CODE, &httpCode);
    
    if (httpCode != 200) {
        qCritical() << "HTTP request failed with code:" << httpCode;
        qCritical() << "Response:" << QString::fromUtf8(responseData);
        return false;
    }
    
    if (response) {
        *response = QString::fromUtf8(responseData);
    }
    
    qDebug() << "HTTP request successful:" << url;
    return true;
}


bool HikvisionCtrl::authenticateAndGetCookie()
{
    // 如果已有Cookie，先尝试验证是否有效
    if (!m_cookie.isEmpty()) {
        return true;
    }
    
    QString url = QString("http://%1/ISAPI/Security/userCheck").arg(m_serverIp);
    QString response;
    
    // 发送认证请求
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        // 从响应头中提取Cookie
        // 注意：实际实现中需要从CURL获取响应头
        qDebug() << "获取Cookie成功";
        return true;
    }
    
    return false;
}

QString HikvisionCtrl::buildAuthenticatedRtspUrl(const QString& originalUrl)
{
    qDebug() << "=== 开始构建认证RTSP URL ===";
    qDebug() << "原始URL:" << originalUrl;
    
    // 首先解码HTML实体（如 &amp; -> &）
    QString decodedUrl = originalUrl;
    decodedUrl.replace("&amp;", "&");
    qDebug() << "解码HTML实体后:" << decodedUrl;
    
    // 从原始URL中提取参数
    QUrl url(decodedUrl);
    
    // 检查URL是否有效
    if (!url.isValid()) {
        qCritical() << "无效的RTSP URL:" << decodedUrl;
        return QString();
    }
    
    // 获取主机和端口
    QString host = url.host();
    int port = url.port(554); // RTSP默认端口是554
    
    // 构建带用户名密码的RTSP URL
    // 格式: rtsp://username:password@host:port/path?params
    QString authenticatedUrl = QString("rtsp://%1:%2@%3:%4")
        .arg(m_username)
        .arg(m_password)  
        .arg(host)
        .arg(port);
    
    // 添加路径
    authenticatedUrl += url.path();
    
    // 过滤查询参数，只保留时间相关的参数
    if (url.hasQuery()) {
        QString queryString = url.query();
        qDebug() << "原始查询字符串:" << queryString;
        
        // 使用字符串处理方式，更可靠
        QStringList params = queryString.split('&');
        QStringList filteredParams;
        
        qDebug() << "开始过滤参数，总共" << params.size() << "个参数";
        
        for (const QString& param : params) {
            if (param.contains('=')) {
                QString paramName = param.split('=').first().toLower();
                if (paramName == "starttime" ) {
                    filteredParams.append(param);
                    qDebug() << "✓ 保留参数:" << param;
                } else {
                    qDebug() << "✗ 过滤掉参数:" << param;
                }
            }
        }
        
        qDebug() << "过滤后剩余参数:" << filteredParams.size() << "个";
        
        // 如果有过滤后的参数，添加到URL中
        if (!filteredParams.isEmpty()) {
            QString filteredQuery = filteredParams.join('&');
            authenticatedUrl += "?" + filteredQuery;
            qDebug() << "过滤后查询字符串:" << filteredQuery;
        }
    }
    
    qDebug() << "构建的认证RTSP URL:" << authenticatedUrl;
    qDebug() << "=== 认证RTSP URL构建完成 ===";
    return authenticatedUrl;
}

QString HikvisionCtrl::getRtspUrlFromSegment(const QJsonObject& segment)
{
    if (segment.contains("mediaSegmentDescriptor")) {
        QJsonObject mediaDesc = segment["mediaSegmentDescriptor"].toObject();
        if (mediaDesc.contains("playbackURI")) {
            return mediaDesc["playbackURI"].toString();
        }
    }
    return QString();
}