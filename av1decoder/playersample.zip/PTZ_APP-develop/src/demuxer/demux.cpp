#include "src/demuxer/demux.h"
#include <QtDebug>
#include <QCoreApplication>
#include <QDateTime>
#include <iostream>
#include <chrono>
extern "C" {
#include <libavutil/error.h>
}

demuxWorker::demuxWorker(demux *demuxer)
    :mDemuxer(demuxer),
    quit_flag(false)
{

}
demuxWorker::~demuxWorker(){
    qDebug() << "demuxWorker destruct!!";
}
void demuxWorker::quit_threag_flag(){
    qDebug() << "demux receive quit signal";
    quit_flag = true;
}
void demuxWorker::work_thread(){
	//mDemuxer->read_thread();
	int ret;
	AVPacket pkt;
	//qDebug() << "in demux work_thread";
	qDebug() << "in demux work_thread url"<< mDemuxer->getUrl();
	long long loop_count = 0;
    int eagain_count = 0;
    int other_err_count = 0;
    int reconnect_attempts = 0;
	while(!quit_flag){
		// 优先处理URL切换：即使fmtCtx为空也能进行
        //qDebug() << "in demux work_thread loop 111 for url "<< mDemuxer->getUrl();
		if(mDemuxer->switch_flag.load(std::memory_order_acquire)){
			qDebug() << "=== DEMUX: URL switching detected ===";
			qDebug() << "DEMUX: Current fmtCtx address:" << mDemuxer->fmtCtx;
			qDebug() << "DEMUX: Current video_steam_index:" << mDemuxer->video_steam_index;
			qDebug() << "DEMUX: Current audio_steam_index:" << mDemuxer->audio_steam_index;
			
			qDebug() << "DEMUX: Closing current format context...";
			// 如果上层刚设置了 abort_io，这里先保持中断直到我们关闭完成
			if (!mDemuxer->abort_io.load(std::memory_order_acquire)) mDemuxer->abort_io.store(true, std::memory_order_release);
			if(mDemuxer->fmtCtx){
				avformat_close_input(&mDemuxer->fmtCtx);
				qDebug() << "DEMUX: Format context closed";
			}
			// 完成关闭后释放IO中断，便于后续open_input
			mDemuxer->abort_io.store(false, std::memory_order_release);
			qDebug() << "DEMUX: Clearing packet queues...";
			mDemuxer->audio_packq->clear();
			mDemuxer->video_packq->clear();
			mDemuxer->subtitle_packq->clear();
			qDebug() << "DEMUX: Packet queues cleared";
			
			// 重置stream indices
			mDemuxer->video_steam_index = -1;
			mDemuxer->audio_steam_index = -1;
			qDebug() << "DEMUX: Stream indices reset";
			
			// 复制URL，保持switch_flag为true直至open完成，供上层等待
			QString targetUrl = mDemuxer->new_url;
			
			qDebug() << "DEMUX: Opening new URL:" << targetUrl;
			int retOpen = mDemuxer->openFile(targetUrl);
			if(retOpen < 0){
				qCritical() << "DEMUX: Failed to open new URL:" << targetUrl;
				qCritical() << "DEMUX: fmtCtx after failed open:" << mDemuxer->fmtCtx;
				// 打开失败时，清空队列，避免解码器长时间等待
				mDemuxer->video_packq->clear();
				mDemuxer->audio_packq->clear();
			}else{
				qDebug() << "DEMUX: Successfully opened new URL";
				qDebug() << "DEMUX: New fmtCtx address:" << mDemuxer->fmtCtx;
				qDebug() << "DEMUX: New fmtCtx->nb_streams:" << (mDemuxer->fmtCtx ? mDemuxer->fmtCtx->nb_streams : -1);
				qDebug() << "DEMUX: New video stream index:" << mDemuxer->video_steam_index;
				qDebug() << "DEMUX: New audio stream index:" << mDemuxer->audio_steam_index;
			}
			// 切换流程结束，告知上层
			mDemuxer->switch_flag.store(false, std::memory_order_release);
			qDebug() << "=== DEMUX: URL switching completed ===";
			// 切换后先小睡，给上层时间更新
			QThread::msleep(10);
			continue;
		}

		// 如果没有有效的fmtCtx，空闲等待
		if(!mDemuxer->fmtCtx){
			mDemuxer->io_phase.store(0, std::memory_order_release); // IDLE
			QThread::msleep(50);
			continue;
		}
		//qDebug() << "in demux work_thread loop 222 for url "<< mDemuxer->getUrl();
		// 队列过满时限流

		while(mDemuxer->audio_packq->size() > 200 || mDemuxer->video_packq->size() > 100){
			if(mDemuxer->seek_flag){
				break;
			}
			QThread::usleep(100);
		}
        //qDebug() << "in demux work_thread loop 333 for url "<< mDemuxer->getUrl();
		if(mDemuxer->seek_flag){
			mDemuxer->audio_packq->clear();
			mDemuxer->video_packq->clear();
			int ret2 = avformat_seek_file(mDemuxer->fmtCtx, -1, INT64_MIN, mDemuxer->seek_timeStamp, INT64_MAX, 0);
			qDebug() << "demux seek file ret " << ret2;
			mDemuxer->seek_flag = false;
		}

		// 读取数据
		// 标记进入READING阶段
        //qDebug() << "in demux work_thread loop 3.5 for url "<< mDemuxer->getUrl();
        mDemuxer->io_phase.store(2, std::memory_order_release);
        mDemuxer->last_read_time = std::chrono::steady_clock::now();
        //qDebug() << "in demux work_thread loop 3.5.1 for url "<< mDemuxer->getUrl();
        ret = av_read_frame(mDemuxer->fmtCtx,&pkt);
        //qDebug() << "in demux work_thread loop 3.5.1.1 for url "<< mDemuxer->getUrl();
        if (ret < 0) {
            // 若正在切换URL，则回到循环顶部处理切换逻辑
            if (mDemuxer->switch_flag.load(std::memory_order_acquire)) {
                QThread::msleep(1);
                qDebug() << "in demux work_thread loop 3.5.2 for url "<< mDemuxer->getUrl();
                continue;
            }
            // 若是停止触发（abort_io置位），则退出循环以结束线程
            if (mDemuxer->abort_io.load(std::memory_order_acquire)) {
                qDebug() << "demux: read interrupted (ret=" << ret << "), exiting demux loop";
                break;
            }

            // 详细错误日志
            char errbuf[AV_ERROR_MAX_STRING_SIZE] = {0};
            av_strerror(ret, errbuf, sizeof(errbuf));
            if (mDemuxer->fmtCtx && mDemuxer->fmtCtx->pb) {
                qWarning() << "demux: av_read_frame ret=" << ret << ", err=" << errbuf
                           << ", pb->eof=" << (mDemuxer->fmtCtx->pb->eof_reached)
                           << ", pb->error=" << (mDemuxer->fmtCtx->pb->error);
            } else {
                qWarning() << "demux: av_read_frame ret=" << ret << ", err=" << errbuf;
            }

            // 检查是否是由于超时中断导致的错误（AVERROR_EXIT 通常表示被中断回调打断）
            if (ret == AVERROR_EXIT || ret == AVERROR(EINTR)) {
                qWarning() << "demux: av_read_frame interrupted by timeout, attempting immediate reconnect";
                // 关闭当前输入并清空队列
                if (mDemuxer->fmtCtx) {
                    avformat_close_input(&mDemuxer->fmtCtx);
                }
                mDemuxer->audio_packq->clear();
                mDemuxer->video_packq->clear();
                // 短暂退避
                QThread::msleep(100);

                QString targetUrl = mDemuxer->getUrl();
                qInfo() << "DEMUX: Immediate reconnect due to timeout interrupt to " << targetUrl;
                int openRet = mDemuxer->openFile(targetUrl);
                if (openRet < 0) {
                    qWarning() << "DEMUX: Immediate reconnect failed, will retry with normal error handling";
                    other_err_count++;
                    QThread::msleep(500);
                    continue;
                } else {
                    qInfo() << "DEMUX: Immediate reconnect succeeded";
                    reconnect_attempts = 0;
                    eagain_count = 0;
                    other_err_count = 0;
                    continue;
                }
            }

            if (ret == AVERROR_EOF) {
                qWarning() << "demux: EOF reached. Attempting to reconnect to url:" << mDemuxer->getUrl();
                // 关闭当前输入并清空队列
                if (mDemuxer->fmtCtx) {
                    avformat_close_input(&mDemuxer->fmtCtx);
                }
                mDemuxer->audio_packq->clear();
                mDemuxer->video_packq->clear();
                // 小退避
                QThread::msleep(100);

                QString targetUrl = mDemuxer->getUrl();
                qInfo() << "DEMUX: Reconnecting... attempt #" << (reconnect_attempts + 1) << " to " << targetUrl;
                int openRet = mDemuxer->openFile(targetUrl);
                if (openRet < 0) {
                    reconnect_attempts++;
                    int backoff = qMin(2000, 200 * reconnect_attempts); // 线性退避，最大2s
                    qWarning() << "DEMUX: Reconnect failed, backoff ms=" << backoff;
                    QThread::msleep(backoff);
                    continue;
                } else {
                    qInfo() << "DEMUX: Reconnect succeeded";
                    reconnect_attempts = 0;
                    eagain_count = 0;
                    other_err_count = 0;
                    continue;
                }
            } else if (ret == AVERROR(EAGAIN)) {
                // 暂时无数据，轻微退避
                eagain_count++;
                if ((eagain_count % 100) == 0) {
                    qDebug() << "demux: EAGAIN repeated" << eagain_count << "times";
                }
                QThread::msleep(5);
                continue;
            } else {
                // 其他错误，累积计数，必要时重连
                other_err_count++;
                if (other_err_count >= 50) {
                    qWarning() << "demux: too many consecutive errors (" << other_err_count << "), try soft reconnect";
                    if (mDemuxer->fmtCtx) {
                        avformat_close_input(&mDemuxer->fmtCtx);
                    }
                    mDemuxer->audio_packq->clear();
                    mDemuxer->video_packq->clear();
                    QThread::msleep(100);
                    QString targetUrl = mDemuxer->getUrl();
                    int openRet = mDemuxer->openFile(targetUrl);
                    if (openRet < 0) {
                        qWarning() << "DEMUX: soft reconnect failed, will retry later";
                        QThread::msleep(500);
                        continue;
                    }
                    qInfo() << "DEMUX: soft reconnect ok";
                    other_err_count = 0;
                    eagain_count = 0;
                    continue;
                }
                qDebug() << "in demux work_thread loop 3.5.3 for url "<< mDemuxer->getUrl();
                QThread::msleep(10);
                continue;
            }
        }
        //qDebug() << "in demux work_thread loop 444 for url "<< mDemuxer->getUrl();
        if(pkt.stream_index == mDemuxer->audio_steam_index){
            mDemuxer->audio_packq->put(&pkt);
        }else if(pkt.stream_index == mDemuxer->video_steam_index){
            mDemuxer->video_packq->put(&pkt);
        }
        //qDebug() << "in demux work_thread loop 555 for url "<< mDemuxer->getUrl();
        av_packet_unref(&pkt);
        // 成功读取包后，重置错误计数，并更新时间戳以避免超时中断
        eagain_count = 0;
        other_err_count = 0;
        mDemuxer->last_read_time = std::chrono::steady_clock::now();
	}
	qDebug() << "demuxing real quit  threading" ;
	avformat_close_input(&mDemuxer->fmtCtx);
	mDemuxer->video_packq->clear();
	mDemuxer->audio_packq->clear();
}
demux::demux()
{
	//fmtCtx = avformat_alloc_context();
	qDebug() << "demux constructor";
	video_packq = new packetqueue();
	audio_packq = new packetqueue();
	subtitle_packq = new packetqueue();
	mutex = new QMutex();
	seek_timeStamp = 0;
	switch_flag = false;
	abort_io = false;
	// initialize safe defaults
	demuxThread = nullptr;
	worker = nullptr;
	fmtCtx = nullptr;
	audio_steam_index = -1;
	video_steam_index = -1;
	last_read_time = std::chrono::steady_clock::now(); // 初始化时间戳
}
demux::~demux()
{
    delete video_packq;
    delete audio_packq;
    delete subtitle_packq;
    delete mutex;
}
int demux::openFile(QString path){
    qDebug() << "openFile" << path;
    m_url = path;

    std::string path_std = path.toStdString();
    const char* file_path = path_std.c_str();
    qDebug() << "openFile file_path" << file_path;
    AVDictionary *options = NULL;

        // 判断是否是回放(带starttime/endtime参数)，大小写不敏感
    //bool isReplay = path.contains("starttime", Qt::CaseInsensitive) || path.contains("endtime", Qt::CaseInsensitive);
    bool isReplay = false;//回放不回放都是拉流，所以目前全部使用拉流参数
    qDebug() << (isReplay ? "is replay" : "is not replay");

    // 分配格式上下文并设置中断回调，防止阻塞在 av_read_frame/avformat_open_input
    fmtCtx = avformat_alloc_context();
    if (!fmtCtx) {
        qCritical() << "Failed to alloc AVFormatContext";
        return -1;
    }
    // 标记进入OPENING阶段
    io_phase.store(1, std::memory_order_release);
    last_read_time = std::chrono::steady_clock::now();
    fmtCtx->interrupt_callback.callback = [](void *ctx) -> int {
        demux *demuxer = static_cast<demux*>(ctx);
        if (!demuxer) return 0;
        
        // 通用中断（关闭旧流或外部强制）
        if (demuxer->abort_io.load(std::memory_order_acquire)) {
            return 1;
        }
        
        // READING阶段：允许 switch_flag 触发中断
        if (demuxer->io_phase.load(std::memory_order_acquire) == 2 &&
            demuxer->switch_flag.load(std::memory_order_acquire)) {
            return 1;
        }
        
        // 添加超时检查：如果在 READING 阶段超过 5 秒没有数据，触发中断
        auto current_time = std::chrono::steady_clock::now();
        if (demuxer->io_phase.load(std::memory_order_acquire) == 2) {
            auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(current_time - demuxer->last_read_time).count();
            if (duration > 5000) { // 5秒超时
                qWarning() << "demux: interrupt callback triggered due to 5s timeout in READING phase";
                return 1;
            }
        } else {
            demuxer->last_read_time = current_time; // 重置计时器
        }
        
        return 0;
    };
    fmtCtx->interrupt_callback.opaque = this;

    // 根据实时/回放分别设置参数
        if (!isReplay) {
        // 实时流：尽量降低延时
        //这些参数能够降低延迟，避免开画的时候花屏
        av_dict_set(&options, "buffer_size", "65536", 0);
        av_dict_set(&options, "max_delay", "500000", 0);        // 50ms
        av_dict_set(&options, "stimeout", "3000000", 0);       // 3s socket 超时
        av_dict_set(&options, "rw_timeout", "3000000", 0);     // 3s 读写超时
        av_dict_set(&options, "fflags", "nobuffer", 0);
        av_dict_set(&options, "flags", "zerolatency", 0);
        av_dict_set(&options, "rtsp_transport", "tcp", 0);
        av_dict_set(&options, "tune", "zerolatency", 0);
        av_dict_set(&options, "probesize", "50000", 0);
        av_dict_set(&options, "analyzeduration", "0.1", 0);
    } else {
        // 回放：稳定优先，避免过激进的低延迟参数导致打开失败
        av_dict_set(&options, "rtsp_transport", "tcp", 0);
        av_dict_set(&options, "stimeout", "5000000", 0);       // 5s socket 超时
        // 不设置 nobuffer/zerolatency/probesize/analyzeduration
    }

    qDebug() << "open input done asd";
    int ret = avformat_open_input(&fmtCtx, file_path, NULL, &options);
    av_dict_free(&options);
    if(ret < 0){
        qCritical() << "demux open file error!!!!!!!!!!!!!!!!!!! ret=" << ret;
        // 确保 fmtCtx 置空以避免后续误用
        avformat_close_input(&fmtCtx);
        fmtCtx = nullptr;
        return -1;
    }
    qDebug() << "open input done";

    findStreamInfo();

    // if (avformat_find_stream_info(fmtCtx, NULL) < 0) {
    //     qDebug() << "Could not find stream information";
    //     exit(1);
    // }

    // int audio_idx = av_find_best_stream(fmtCtx, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
    // audio_steam_index = (audio_idx < 0) ? -1 : audio_idx;

    // int video_idx = av_find_best_stream(fmtCtx, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    // video_steam_index = (video_idx < 0) ? -1 : video_idx;


    if(audio_steam_index < 0 && video_steam_index < 0)
        return -1;

    qDebug()<< "fmt duration"<< fmtCtx->duration  << " video_steam_index " << video_steam_index << " audio_steam_index " << audio_steam_index;
    return 1;
}

int demux::findStreamInfo(){
    int ret;
    qDebug() << "open input done" ;

    // Manually configure stream info to skip avformat_find_stream_info
    if (fmtCtx->nb_streams == 0) {
        qDebug() << "No streams found in context, manually creating one.";
        AVStream *video_stream = avformat_new_stream(fmtCtx, NULL);
        if (!video_stream) {
            qDebug() << "Failed to create new video stream";
            return -1;
        }

        AVCodecParameters *codecpar = video_stream->codecpar;
        codecpar->codec_type = AVMEDIA_TYPE_VIDEO;
        codecpar->codec_id = AV_CODEC_ID_HEVC;
        codecpar->width = 640;
        codecpar->height = 360;
        codecpar->format = AV_PIX_FMT_YUV420P;
        
        video_stream->time_base = (AVRational){1, 90000};
        video_stream->avg_frame_rate = (AVRational){25, 1};
    }
    
    qDebug() << "Skipping avformat_find_stream_info by manually setting stream info.";

    int audio_idx = av_find_best_stream(fmtCtx, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
    audio_steam_index = (audio_idx < 0) ? -1 : audio_idx;

    int video_idx = av_find_best_stream(fmtCtx, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    video_steam_index = (video_idx < 0) ? -1 : video_idx;

    qDebug() << "Finished finding streams at:" << QDateTime::currentDateTime().toString("hh:mm:ss.zzz");

     if(audio_steam_index < 0 && video_steam_index < 0)
         return -1;

     qDebug()<< "fmt duration"<< fmtCtx->duration  << " video_steam_index " << video_steam_index << " audio_steam_index " << audio_steam_index;
    return 1;
}

int demux::start(QString url){
    int ret = 0;

    qDebug() << "in demux start !!!!!!!!!!!!!" ;
    demuxThread = new QThread;
    this->url = url;
    worker = new demuxWorker(this);
    worker->moveToThread(demuxThread);

    connect(demuxThread, SIGNAL(started()), worker, SLOT(work_thread()));
    connect(this, SIGNAL(quitDemuxThread()), worker, SLOT(quit_threag_flag()), Qt::DirectConnection);

    // connect(demuxThread, SIGNAL(finished()), worker, SLOT(deleteLater()));
    // 移除线程对象自删，避免与stop() wait()竞态
    // connect(demuxThread, SIGNAL(finished()), demuxThread, SLOT(deleteLater()));

    demuxThread->start();

    return ret;
}
int demux::stop(){

    qDebug() << "in demux stop !!!!!!!!!!!!!" ;
    qDebug() << "in demux stop set abort_io true!" ;
    abort_io = true; // ensure interrupt callback returns immediately

    emit quitDemuxThread();

    if(demuxThread){
        qDebug() << "Demux stopping: quitting thread event loop";
        demuxThread->quit();
        demuxThread->wait(5000);
        qDebug() << "Demux thread terminated";
        if(worker){
            delete worker;
            worker = nullptr;
        }
        delete demuxThread;
        demuxThread = nullptr;
    }

    // clear queues
    if(video_packq) video_packq->clear();
    if(audio_packq) audio_packq->clear();
    if(subtitle_packq) subtitle_packq->clear();

    // reset flags
    abort_io = false;
    switch_flag = false;
    return 0;
}

int demux::seek(double timeStamp){
    //std::cout << "timeStamp receive seek signal" <<QDateTime::currentDateTime().toString("hh:mm:ss.zzz ");
    qDebug() << "demux seek timeStamp" << timeStamp;
    seek_flag = true;
    seek_timeStamp = timeStamp;
    return  0;
}

int demux::switchUrl(QString path){
    qDebug() << "DEMUX: switchUrl called with:" << path;
    qDebug() << "DEMUX: Current switch_flag:" << switch_flag;
    qDebug() << "DEMUX: Current fmtCtx:" << fmtCtx;
    
    mutex->lock();
    
    // 检查是否已经在切换中
    if (switch_flag.load(std::memory_order_acquire)) {
        qWarning() << "DEMUX: URL switch already in progress, ignoring new request";
        mutex->unlock();
        return 0;
    }
    
    // 触发IO中断，打断可能阻塞中的 av_read_frame
    abort_io.store(true, std::memory_order_release);
    new_url = path;
    switch_flag.store(true, std::memory_order_release);
    qDebug() << "DEMUX: Switch flag set to true";
    qDebug() << "DEMUX: New URL set to:" << new_url;
    
    mutex->unlock();
    return 0;
}

bool demux::isSwitching() const {
    return switch_flag.load(std::memory_order_acquire);
}

QString demux::getUrl(){
    return m_url;
}
