#include <iostream>
#include <string>
#include <map>
#include <sstream>
#include <curl/curl.h>
#include <json/json.h>
#include <tinyxml2.h>

#include "src/cgi_common.h"

using namespace std;
using namespace tinyxml2;

size_t WriteCallback(void* contents, size_t size, size_t nmemb, void* userp){
    size_t totalSize = size * nmemb;
    ((string*) userp)->append((char*) contents, totalSize);
    return totalSize;
}

const char* Login(const char* user, const char* pwd, const char* ip){
    string username(user);
    string password(pwd);
    string server_ip(ip);

    string url = "http://" + server_ip + "/cgi-bin/getuid?username=" + username + "&password=" + password;

    cout << "Login url "  << url;
    CURL* curl;
    CURLcode res;
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();

    if(curl){
        string response_body;

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_body);

        res = curl_easy_perform(curl);

        if(res != CURLE_OK){
            cerr << "CURL request failed: " << curl_easy_strerror(res) << endl;
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return nullptr;
        }

        cout << "HTTP Response Body: " << response_body << endl;

        tinyxml2::XMLDocument doc;
        doc.Parse(response_body.c_str());

        //XMLElement* contentElem = doc.FirstChildElement("root")->FirstChildElement("content");
        XMLElement* contentElem = doc.FirstChildElement("uid");
        
        if(contentElem != nullptr){
            //const char* uid = contentElem->GetText();
            const char* uid = strdup(contentElem->GetText());
            cout << "UID: " << uid << endl;
            // Free the allocated memory before returning
            free((void*)uid);

            curl_easy_cleanup(curl);
            curl_global_cleanup();

            
            return uid;
        }else{
            cerr << "Failed to find <content> element in the XML response." << endl;
        }

        curl_easy_cleanup(curl);
    }

    curl_global_cleanup();
    return nullptr;
}

bool KeepAlive(const char* ip, const char* uid){
    stringstream fullURL;
    fullURL << "http://" << ip << "/cgi-bin/keep_alive?uid=" << uid;

    CURL* curl;
    CURLcode res;
    string responseBody;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if(!curl){
        cerr << "Curl initialization failed" << endl;
        curl_global_cleanup();
        return false;
    }

    curl_easy_setopt(curl, CURLOPT_URL, fullURL.str().c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK){
        cerr << "Curl request failed: " << curl_easy_strerror(res) << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    long http_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    cout << "HTTP Status: " << http_code << endl;

    cout << "Response Body: " << endl;
    cout << responseBody << endl;

    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if(xmlErr != XML_SUCCESS){
        cerr << "Error parsing XML: " << doc.ErrorStr() << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    XMLElement* rootElement = doc.RootElement();
    if(!rootElement){
        cerr << "Invalid XML format or no root element found" << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    for(const XMLAttribute* attr = rootElement->FirstAttribute(); attr != nullptr; attr = attr->Next()){
        cout << attr->Name() << ": " << attr->Value() << endl;
    }

    cout << "alive" << endl;

    curl_easy_cleanup(curl);
    curl_global_cleanup();
    return true;
}

bool ConfigImg(const char* ip, const char* uid, const char* imgconf_str){
    Json::CharReaderBuilder reader;
    Json::Value root;
    string errs;

    string imgconf_str_cpp(imgconf_str);
    istringstream s(imgconf_str_cpp);

    if(!Json::parseFromStream(reader, s, &root, &errs)){
        cerr << "Error parsing JSON: " << errs << endl;
        return false;
    }

    if(root.isNull()){
        return false;
    }

    map<string, int> jmp;
    for(const auto& key: root.getMemberNames()){
        jmp[key] = root[key].asInt();
    }

    stringstream params;
    for(auto it = jmp.begin(); it != jmp.end(); ++it){
        if(it != jmp.begin()){
            params << "&";
        }
        params << it->first << "=" << it->second;
    }

    params << "&uid=" << uid;

    string url = "http://" + string(ip) + "/cgi-bin/image?" + params.str();

    CURL* curl;
    CURLcode res;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if(!curl){
        cerr << "Error initializing CURL" << endl;
        return false;
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, NULL);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK){
        cerr << "CURL error: " << curl_easy_strerror(res) << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    long http_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    cout << "HTTP Status: " << http_code << endl;

    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse("<xml_data>");
    if(xmlErr != XML_SUCCESS){
        cerr << "Error parsing XML: " << doc.ErrorStr() << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    XMLElement* rootElement = doc.RootElement();
    if(rootElement == nullptr || string(rootElement->Name()) != "image"){
        cerr << "Invalid XML format or no <image> tag found" << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    int count = 0;
    for(const XMLAttribute* attr = rootElement->FirstAttribute(); attr != nullptr; attr = attr->Next()){
        if(count >= 10) break;
        cout << attr->Name() << ": " << attr->Value() << endl;
        count++;
    }

    cout << "alive" << endl;

    curl_easy_cleanup(curl);
    curl_global_cleanup();

    return true;
}

bool ConfigOSD(const char* ip, const char* uid, const char* osdconf_str){
    Json::CharReaderBuilder readerBuilder;
    Json::Value root;
    string errs;

    string str_cpp(osdconf_str);
    istringstream s(str_cpp);

    bool parsingSuccessful = Json::parseFromStream(readerBuilder, s, &root, &errs);

    if(!parsingSuccessful){
        cerr << "Failed to parse the JSON: " << errs << endl;
        return false;
    }

    map<string, string> params;

    for(const auto& key: root.getMemberNames()){
        if(root[key].isString()){
            params[key] = root[key].asString();
        }
    }

    params["uid"] = uid;

    // 创建用于URL编码的curl句柄
    CURL* curl = curl_easy_init();
    if (!curl) {
        cerr << "Failed to initialize curl for URL encoding" << endl;
        return false;
    }

    stringstream fullURL;
    fullURL << "http://" << ip << "/cgi-bin/osd?";
    for(auto& param: params){
        char* encoded_value = curl_easy_escape(curl, param.second.c_str(), param.second.length());
        if (encoded_value) {
            fullURL << param.first << "=" << encoded_value << "&";
            curl_free(encoded_value); // 释放CURL分配的内存
        }
    }

    string url = fullURL.str();
    // 移除末尾的&符号
    if (url.back() == '&') {
        url.pop_back();
    }

    cout << "ConfigOSD: " << url << endl;

    // 继续使用现有的curl句柄进行请求
    CURLcode res;
    string responseBody;

    curl_easy_reset(curl); // 重置curl选项
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

    res = curl_easy_perform(curl);
    cout << "config osd HTTP Status: " << res << endl;
    cout << "config osd Response Body: " << responseBody << endl;
    
    if(res != CURLE_OK){
        cerr << "CURL error: " << curl_easy_strerror(res) << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    long http_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    cout << "HTTP Status Code: " << http_code << endl;
    
    curl_easy_cleanup(curl);
    curl_global_cleanup();

    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if(xmlErr != XML_SUCCESS){
        cerr << "XML parsing error: " << doc.ErrorStr() << endl;
        return false;
    }

    XMLElement* rootElement = doc.RootElement();
    if(!rootElement){
        cerr << "No root element found in XML response" << endl;
        return false;
    }

    if(string(rootElement->Name()) != "osd"){
        cerr << "Root element is not 'osd'" << endl;
        return false;
    }

    for(const XMLAttribute* attr = rootElement->FirstAttribute(); attr != nullptr; attr = attr->Next()){
        cout << attr->Name() << ": " << attr->Value() << endl;
    }

    cout << "alive" << endl;
    return true;
}

bool ConfigUserOSD(const std::string& ip, const std::string& uid, const std::string& osdconf_str){
    Json::CharReaderBuilder readerBuilder;
    Json::Value jsonData;
    std::istringstream osdconf_stream(osdconf_str);
    std::string errs;

    if(!Json::parseFromStream(readerBuilder, osdconf_stream, &jsonData, &errs)){
        std::cerr << "JSON parsing error: " << errs << std::endl;
        return false;
    }

    // 创建用于URL编码的curl句柄
    CURL* curl = curl_easy_init();
    if (!curl) {
        std::cerr << "Failed to initialize curl for URL encoding" << std::endl;
        return false;
    }

    std::string url = "http://" + ip + "/cgi-bin/userosd?";
    for(const auto& key: jsonData.getMemberNames()){
        std::string value = jsonData[key].asString();
        char* encoded_value = curl_easy_escape(curl, value.c_str(), value.length());
        if (encoded_value) {
            url += key + "=" + std::string(encoded_value) + "&";
            curl_free(encoded_value); // 释放CURL分配的内存
        }
    }

    // 添加uid参数
    char* encoded_uid = curl_easy_escape(curl, uid.c_str(), uid.length());
    if (encoded_uid) {
        url += "uid=" + std::string(encoded_uid);
        curl_free(encoded_uid);
    } else {
        url += "uid=" + uid;  // 降级处理，如果编码失败使用原始值
    }

    cout << "ConfigUserOSD: " << url << endl;

    // 重置curl选项用于HTTP请求
    curl_easy_reset(curl);
    CURLcode res;
    std::string response_body;
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_body);

    res = curl_easy_perform(curl);
    std::cout << "config user osd Response Body: " << std::endl << response_body << std::endl;
    
    if(res != CURLE_OK){
        std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
        curl_easy_cleanup(curl);
        return false;
    }

    long response_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
    std::cout << "HTTP Status: " << response_code << std::endl;

    tinyxml2::XMLDocument doc;
    if(doc.Parse(response_body.c_str()) != tinyxml2::XML_SUCCESS){
        std::cerr << "Error parsing XML" << std::endl;
        curl_easy_cleanup(curl);
        return false;
    }

    tinyxml2::XMLElement* root = doc.RootElement();
    if(root == nullptr || std::string(root->Name()) != "osd"){
        std::cerr << "Root element is not 'osd'" << std::endl;
        curl_easy_cleanup(curl);
        return false;
    }

    curl_easy_cleanup(curl);
    return true;
}

bool ConfigVideoEncoding(const std::string& ip, const std::string& uid, int index, const std::string& audioconf_str){
    Json::CharReaderBuilder readerBuilder;
    Json::Value jsonData;
    std::istringstream osdconf_stream(audioconf_str);
    std::string errs;

    if(!Json::parseFromStream(readerBuilder, osdconf_stream, &jsonData, &errs)){
        std::cerr << "JSON parsing error: " << errs << std::endl;
        return false;
    }

    // 根据index参数构建URL，支持stream1和stream2
    std::string stream_path;
    if(index == 0){
        stream_path = "stream1";
    }else{
        stream_path = "stream2";
    }
    
    std::string url = "http://" + ip + "/cgi-bin/videoencoder/" + stream_path + "?";
    for(const auto& key: jsonData.getMemberNames()){
        url += key + "=" + jsonData[key].asString() + "&";
    }
    url += "uid=" + uid;

    qDebug() << "ConfigVideoEncoding url:" << url.c_str();
    CURL* curl;
    CURLcode res;
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();

    if(curl){
        std::string response_body;
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_body);

        res = curl_easy_perform(curl);
        if(res != CURLE_OK){
            std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return false;
        }

        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        std::cout << "HTTP Status: " << response_code << std::endl;
        std::cout << "Response Body: " << std::endl << response_body << std::endl;

        tinyxml2::XMLDocument doc;
        if(doc.Parse(response_body.c_str()) != tinyxml2::XML_SUCCESS){
            std::cerr << "Error parsing XML" << std::endl;
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return false;
        }

        tinyxml2::XMLElement* root = doc.RootElement();
        if(root == nullptr || std::string(root->Name()) != "osd"){
            std::cerr << "Root element is not 'osd'" << std::endl;
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return false;
        }

        curl_easy_cleanup(curl);
    }

    curl_global_cleanup();
    return true;
}

bool ConfigAudioEncoding(const std::string& ip, const std::string& uid, const std::string& audioconf_str){
    Json::CharReaderBuilder readerBuilder;
    Json::Value jsonData;
    std::istringstream osdconf_stream(audioconf_str);
    std::string errs;

    if(!Json::parseFromStream(readerBuilder, osdconf_stream, &jsonData, &errs)){
        std::cerr << "JSON parsing error: " << errs << std::endl;
        return false;
    }

    std::string url = "http://" + ip + "/cgi-bin/audioencoder?";
    for(const auto& key: jsonData.getMemberNames()){
        url += key + "=" + jsonData[key].asString() + "&";
    }
    url += "uid=" + uid;

    CURL* curl;
    CURLcode res;
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();

    if(curl){
        std::string response_body;
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response_body);

        res = curl_easy_perform(curl);
        if(res != CURLE_OK){
            std::cerr << "curl_easy_perform() failed: " << curl_easy_strerror(res) << std::endl;
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return false;
        }

        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        std::cout << "HTTP Status: " << response_code << std::endl;
        std::cout << "Response Body: " << std::endl << response_body << std::endl;

        tinyxml2::XMLDocument doc;
        if(doc.Parse(response_body.c_str()) != tinyxml2::XML_SUCCESS){
            std::cerr << "Error parsing XML" << std::endl;
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return false;
        }

        tinyxml2::XMLElement* root = doc.RootElement();
        if(root == nullptr || std::string(root->Name()) != "osd"){
            std::cerr << "Root element is not 'osd'" << std::endl;
            curl_easy_cleanup(curl);
            curl_global_cleanup();
            return false;
        }

        curl_easy_cleanup(curl);
    }

    curl_global_cleanup();
    return true;
}

bool ConfigNetWork(const std::string& ip, const std::string& uid, const std::string& audioconf_str){
    Json::CharReaderBuilder readerBuilder;
    Json::Value jsonData;
    std::istringstream osdconf_stream(audioconf_str);
    std::string errs;

    if(!Json::parseFromStream(readerBuilder, osdconf_stream, &jsonData, &errs)){
        std::cerr << "JSON parsing error: " << errs << std::endl;
        return false;
    }

    std::string url = "http://" + ip + "/cgi-bin/network?";
    for(const auto& key: jsonData.getMemberNames()){
        url += key + "=" + jsonData[key].asString() + "&";
    }
    url += "uid=" + uid;

    CURL* curl;
    CURLcode res;
    string responseBody;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if(!curl){
        curl_global_cleanup();
        return false;
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK){
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    long http_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    cout << "HTTP Status: " << http_code << endl;

    cout << "Response Body: " << endl;
    cout << responseBody << endl;

    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if(xmlErr != XML_SUCCESS){
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    XMLElement* rootElement = doc.RootElement();
    if(!rootElement){
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    if(string(rootElement->Name()) != "osd"){
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    for(const XMLAttribute* attr = rootElement->FirstAttribute(); attr != nullptr; attr = attr->Next()){
        cout << attr->Name() << ": " << attr->Value() << endl;
    }

    cout << "alive" << endl;

    curl_easy_cleanup(curl);
    curl_global_cleanup();
    return true;
}

bool SteeringWithSpeed(const std::string& ip, const std::string& uid, int towards, int speed){

    string url_bulk;
    switch (towards) {
        case STEERING_UP:
            url_bulk = "/cgi-bin/ptz_ctrl?move_x=0&move_y=1&speed=" + to_string(speed) + "&uid=" + uid;
        break;
        case STEERING_DOWN:
            url_bulk = "/cgi-bin/ptz_ctrl?move_x=0&move_y=-1&speed=" + to_string(speed) + "&uid=" + uid;
        break;
        case STEERING_LEFT:
            url_bulk = "/cgi-bin/ptz_ctrl?move_x=-1&move_y=0&speed=" + to_string(speed) + "&uid=" + uid;
        break;
        case STEERING_RIGHT:
            url_bulk = "/cgi-bin/ptz_ctrl?move_x=1&move_y=0&speed=" + to_string(speed) + "&uid=" + uid;
        break;        
    }
    string url = "http://" + ip + url_bulk;

    CURL* curl;
    CURLcode res;
    string responseBody;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if(!curl){
        curl_global_cleanup();
        return false;
    }
    cout << "steering url "  << url;

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK){
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    long http_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    cout << "HTTP Status: " << http_code << endl;

    cout << "Response Body: " << endl;
    cout << responseBody << endl;

    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if(xmlErr != XML_SUCCESS){
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    XMLElement* rootElement = doc.RootElement();
    if(!rootElement){
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    // if(string(rootElement->Name()) != "osd"){
    //     curl_easy_cleanup(curl);
    //     curl_global_cleanup();
    //     return false;
    // }

    for(const XMLAttribute* attr = rootElement->FirstAttribute(); attr != nullptr; attr = attr->Next()){
        cout << attr->Name() << ": " << attr->Value() << endl;
    }

    cout << "alive" << endl;

    curl_easy_cleanup(curl);
    curl_global_cleanup();
    return true;
}
bool sendCgiCommand(const std::string& url){
    CURL* curl;
    CURLcode res;
    string responseBody;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if(!curl){
        curl_global_cleanup();
        return false;
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK){
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    long http_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    cout << "HTTP Status: " << http_code << endl;

    cout << "Response Body: " << endl;
    cout << responseBody << endl;


    curl_easy_cleanup(curl);
    curl_global_cleanup();
    return true;
}

bool TurnStop(const std::string& ip, const std::string& uid){

    string url = "http://" + ip + "/cgi-bin/ptz_ctrl?stop=1&uid=" + uid;

    return sendCgiCommand(url);


}
bool setZoomIn(const std::string& ip, const std::string& uid,int val){
    string url = "http://" + ip + "/cgi-bin/ptz_ctrl?zoom="+ std::to_string(val)  +"&uid=" + uid;
    cout << "setZoomIn url: " << url  <<endl;
    return sendCgiCommand(url);
 }
 bool setFocus(const std::string& ip, const std::string& uid,int val){
    string url = "http://" + ip + "/cgi-bin/ptz_ctrl?focus="+ std::to_string(val)  +"&uid=" + uid;
    cout << "setFocus url: " << url  <<endl;
    return sendCgiCommand(url);

 }
 bool setAperture(const std::string& ip, const std::string& uid,int val){
    string url = "http://" + ip + "/cgi-bin/ptz_ctrl?iris="+ std::to_string(val)  +"&uid=" + uid;
    cout << "setAperture url: " << url  <<endl;
    return sendCgiCommand(url);

 }
 bool setPreset(const std::string& ip, const std::string& uid,int id){
    string url = "http://" + ip + "/cgi-bin/ptz_ctrl?add_preset="+ std::to_string(id)  +"&uid=" + uid;
    cout << "setPreset url: " << url  <<endl;

    return sendCgiCommand(url);

 }
 bool callPreset(const std::string& ip, const std::string& uid,int id){
    string url = "http://" + ip + "/cgi-bin/ptz_ctrl?call_preset="+ std::to_string(id)  +"&uid=" + uid;
    cout << "callPreset url: " << url  <<endl;

    return sendCgiCommand(url);

 }
 bool deletePreset(const std::string& ip, const std::string& uid,int id){
    string url = "http://" + ip + "/cgi-bin/ptz_ctrl?delete_preset="+ std::to_string(id)  +"&uid=" + uid;
    cout << "deletePreset url: " << url  <<endl;
    return sendCgiCommand(url);
 
 }

bool GetNetworkConfig(const std::string& ip, const std::string& uid, std::map<std::string, std::string>& config) {
    std::string url = "http://" + ip + "/cgi-bin/network?uid=" + uid;
    qDebug() << "GetNetworkConfig url: " << url.c_str();
    CURL* curl;
    CURLcode res;
    std::string responseBody;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if(!curl) {
        curl_global_cleanup();
        return false;
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK) {
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    long http_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    std::cout << "HTTP Status: " << http_code << std::endl;

    std::cout << "Response Body: " << std::endl;
    std::cout << responseBody << std::endl;

    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if(xmlErr != XML_SUCCESS) {
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    XMLElement* rootElement = doc.RootElement();
    if(!rootElement || std::string(rootElement->Name()) != "network") {
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return false;
    }

    // 解析网络配置参数
    for(const XMLAttribute* attr = rootElement->FirstAttribute(); attr != nullptr; attr = attr->Next()) {
        config[attr->Name()] = attr->Value();
        std::cout << attr->Name() << ": " << attr->Value() << std::endl;
    }

    curl_easy_cleanup(curl);
    curl_global_cleanup();
    return true;
}