#include <QGuiApplication>
#include <QtWidgets/QApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <sstream>
#include <iostream>
//#include <curl/curl.h>
#include <json/json.h>
#include <tinyxml2.h>
//#include <gst/gst.h>
#include <QTimer>
#include <QThread>
#include <QDateTime>
#include <QDir>

//#include "producer.h"
#include "src/frame_provider.h"

#include "src/ptz_device_cgi.h"
#include "src/ptz_device_manager.h"
#include "src/thermal_device_manager.h"
#include "src/device_proxy.h"
#include "src/player.h"
#include "src/thermal_ctl.h"
#include "src/hikvision_ctrl.h"
#include "src/model/alarmmodel.h"
#include "src/model/cruisemodel.h"
#include "src/model/presetmodel.h"
#include "src/model/usermodel.h"
#include "src/model/logmodel.h"
#include "src/model/devicemodel.h"
#include "src/model/devicetreemodel.h"
#include "src/filemanager.h"
#include "src/playermanager.h"
#include "src/alarm_audio_player.h"
#include "src/hikvision_recorder.h"
#include "src/image_fusion_manager.h"
#include "src/gas_cloud_manager.h"
#include "src/micro_leak_manager.h"
#include "src/cruise_record_manager.h"
#include "src/panorama_manager.h"

#include "src/alarmlog.h"
#include "src/systemlog.h"
#include "src/usermanager.h"
#include "src/versionmanager.h"
#include "src/alarmvideoplayer.h"
#include "src/history_video_player.h"
#include "src/tdlas_data_manager.h"
#include "src/manualrecordingmanager.h"
#include "src/alarmrecordingmanager.h"
#include <QRandomGenerator>
 using namespace std;

int main(int argc, char* argv[]){
    QApplication app(argc, argv);
    QQmlApplicationEngine engine;
    QQmlContext* ctx = engine.rootContext();


    
    // 创建设备管理器
    PtzDeviceManager* ptzDeviceManager = PtzDeviceManager::instance();
    ThermalDeviceManager* thermalDeviceManager = ThermalDeviceManager::instance();
    
    // 创建设备代理
    DeviceProxy* deviceProxy = new DeviceProxy();
    

    

    // 创建HikvisionCtrl - 保持在主线程
    HikvisionCtrl* hikvisionCtrl = new HikvisionCtrl();
    
    // 创建HikvisionRecorder实例
    HikvisionRecorder* hikvisionRecorder = new HikvisionRecorder();
    
    // 设置context property
    engine.rootContext()->setContextProperty("hikvisionCtrl", hikvisionCtrl);
    engine.rootContext()->setContextProperty("hikvisionRecorder", hikvisionRecorder);
    engine.rootContext()->setContextProperty("ptzDeviceManager", ptzDeviceManager);
    engine.rootContext()->setContextProperty("thermalDeviceManager", thermalDeviceManager);
    engine.rootContext()->setContextProperty("deviceProxy", deviceProxy);
    
    // 为了向后兼容，保留旧的名称
    engine.rootContext()->setContextProperty("ptzCgisingleton", deviceProxy);
    engine.rootContext()->setContextProperty("tmCtl", deviceProxy);
    engine.rootContext()->setContextProperty("UserManager", UserManager::instance());


//=====================
    qmlRegisterSingletonInstance("App.AlarmLog", 1, 0, "AlarmLog", AlarmLog::instance());
    qmlRegisterSingletonInstance("App.SystemLog", 1, 0, "SystemLog", SystemLog::instance());
    
    // 注册TDLAS数据管理器
    qmlRegisterSingletonInstance("App.TdlasDataManager", 1, 0, "TdlasDataManager", TdlasDataManager::instance());
    
    // 注册历史视频播放器类型
    qmlRegisterType<HistoryVideoPlayer>("App", 1, 0, "HistoryVideoPlayer");
    
    // 注册 splayer 类型到 QML
    qmlRegisterType<splayer>("App", 1, 0, "SPlayer");


    // 确保应用退出时清理
    QObject::connect(&app, &QGuiApplication::aboutToQuit, hikvisionCtrl, &QObject::deleteLater);
    QObject::connect(&app, &QGuiApplication::aboutToQuit, deviceProxy, &QObject::deleteLater);
    
    // 确保应用退出时保存分组信息并重置扫描状态
    QObject::connect(&app, &QGuiApplication::aboutToQuit, [deviceProxy]() {
        qDebug() << "应用退出，执行清理操作...";
        
        // 首先停止所有设备的扫描活动
        if (deviceProxy) {
            qDebug() << "停止所有设备的扫描活动...";
            deviceProxy->stopCruise();
            deviceProxy->setLineScanActive(false);  // 停止线扫
            deviceProxy->setTrajectoryScanActive(false);  // 停止轨迹扫描
        }
        
        // 重置所有设备的扫描状态为0（无扫描）
        DeviceModel* deviceModel = DeviceModel::instance();
        if (deviceModel) {
            auto allDevices = deviceModel->getAllDevices();
            for (const auto& device : allDevices) {
                int currentScanMode = deviceModel->getDeviceScanMode(device.deviceId);
                if (currentScanMode != 0) {
                    qDebug() << "重置设备" << device.deviceId << "的扫描状态从" << currentScanMode << "到0";
                    deviceModel->setDeviceScanMode(device.deviceId, 0);
                }
            }
        }
        
        // 保存分组信息
        if (deviceModel) {
            deviceModel->saveGroupsToFile();
            qDebug() << "分组信息已保存";
        }
        
        qDebug() << "应用退出清理操作完成";
    });
    
    
    qmlRegisterType<FrameProvider>("Local", 1, 0, "FrameProvider");
    
    // qmlRegisterType<PtzDeviceCgi>("Local", 1, 0, "PtzDeviceCgi");

    qmlRegisterSingletonInstance<AlarmModel>("App", 1, 0, "AlarmModel", AlarmModel::instance());
    qmlRegisterSingletonInstance<CruiseModel>("App", 1, 0, "CruiseModel", CruiseModel::instance());
    qmlRegisterSingletonInstance<PresetModel>("App", 1, 0, "PresetModel", PresetModel::instance());
    qmlRegisterSingletonInstance<UserModel>("App", 1, 0, "UserModel", UserModel::instance());
    qmlRegisterSingletonInstance<LogModel>("App", 1, 0, "LogModel", LogModel::instance());
    qmlRegisterSingletonInstance<FileManager>("App", 1, 0, "FileManager", FileManager::instance());


    // 注册设备模型
    qmlRegisterSingletonInstance<DeviceModel>("App", 1, 0, "DeviceModel", DeviceModel::instance());
    
    
    // 注册设备树形模型
    qmlRegisterType<DeviceTreeModel>("App", 1, 0, "DeviceTreeModel");
    
    // 注册报警音频播放器
    qmlRegisterSingletonInstance<AlarmAudioPlayer>("App", 1, 0, "AlarmAudioPlayer", AlarmAudioPlayer::instance());
    
    // 注册图像融合管理器
    qmlRegisterSingletonInstance<ImageFusionManager>("App", 1, 0, "ImageFusionManager", ImageFusionManager::instance());
    
    // 注册气云分割管理器
    qmlRegisterSingletonInstance<GasCloudManager>("App", 1, 0, "GasCloudManager", GasCloudManager::instance());
    
    // 注册手动录像管理器
    qmlRegisterSingletonInstance<ManualRecordingManager>("App", 1, 0, "ManualRecordingManager", ManualRecordingManager::instance());
    
    // 注册报警录像管理器
    qmlRegisterSingletonInstance<AlarmRecordingManager>("App", 1, 0, "AlarmRecordingManager", AlarmRecordingManager::instance());
    
    // 注册巡检记录管理器
    qmlRegisterSingletonInstance<CruiseRecordManager>("App", 1, 0, "CruiseRecordManager", CruiseRecordManager::instance());

    // 注册全景图管理器
    qmlRegisterSingletonInstance("App.PanoramaManager", 1, 0, "PanoramaManager", PanoramaManager::instance());

    // 注册版本管理器
    qmlRegisterSingletonInstance("App", 1, 0, "VersionManager", VersionManager::instance());
    
    // 注册AlarmRecordingManager到QML
    engine.rootContext()->setContextProperty("AlarmRecordingManager", AlarmRecordingManager::instance());
    

    // 立即初始化图像融合管理器
    qDebug() << "=== 立即初始化图像融合管理器 ===";
    ImageFusionManager* fusionManager = ImageFusionManager::instance();
    qDebug() << "ImageFusionManager instance created:" << fusionManager;
    
    // 获取应用程序目录
    QString appDir = QCoreApplication::applicationDirPath();
    qDebug() << "Application directory:" << appDir;
    
    // 构建配置文件的绝对路径 - 从build目录回到项目根目录
    QString projectDir = QDir(appDir).absoluteFilePath("./");
    QString configPath = QDir(projectDir).absoluteFilePath("config/dual/calibration_params.json");
    qDebug() << "Project directory:" << projectDir;
    qDebug() << "Config file absolute path:" << configPath;
    
    // 检查配置文件是否存在
    QFile configFile(configPath);
    qDebug() << "Config file exists:" << configFile.exists();
    qDebug() << "Config file path:" << configFile.fileName();
    qDebug() << "Current working directory:" << QDir::currentPath();
    
    bool fusionInitialized = fusionManager->initializeFusion(configPath);
    qDebug() << "initializeFusion returned:" << fusionInitialized;
    
    // 检查初始化状态
    qDebug() << "isFusionAvailable:" << fusionManager->isFusionAvailable();
    qDebug() << "getFusionStatus:" << fusionManager->getFusionStatus();
    
    if (fusionInitialized) {
        qDebug() << "图像融合管理器初始化成功";
    } else {
        qWarning() << "图像融合管理器初始化失败";
    }
    qDebug() << "=== 图像融合管理器初始化完成 ===";
    
    // 立即初始化气云分割管理器
    qDebug() << "=== 立即初始化气云分割管理器 ===";
    GasCloudManager* gasCloudManager = GasCloudManager::instance();
    qDebug() << "GasCloudManager instance created:" << gasCloudManager;
    
    // 构建模型文件和配置文件的路径
    QString modelPath = QDir(projectDir).absoluteFilePath("config/segment/unet_0627_320_256.onnx");
    QString calibrationPath = QDir(projectDir).absoluteFilePath("config/segment/calibration_params.json");
    qDebug() << "Model file path:" << modelPath;
    qDebug() << "Calibration file path:" << calibrationPath;
    
    // 检查文件是否存在
    QFile modelFile(modelPath);
    QFile calibrationFile(calibrationPath);
    qDebug() << "Model file exists:" << modelFile.exists();
    qDebug() << "Calibration file exists:" << calibrationFile.exists();
    
    bool gasCloudInitialized = gasCloudManager->initializeGasCloud(modelPath, calibrationPath);
    qDebug() << "initializeGasCloud returned:" << gasCloudInitialized;
    
    // 检查初始化状态
    qDebug() << "isGasCloudAvailable:" << gasCloudManager->isGasCloudAvailable();
    qDebug() << "getGasCloudStatus:" << gasCloudManager->getGasCloudStatus();
    
    if (gasCloudInitialized) {
        qDebug() << "气云分割管理器初始化成功";
    } else {
        qWarning() << "气云分割管理器初始化失败";
    }
    qDebug() << "=== 气云分割管理器初始化完成 ===";

    // 初始化微漏管理器
    qDebug() << "=== 初始化微漏管理器 ===";
    MicroLeakManager* microLeakManager = MicroLeakManager::instance();
    QString microLeakConfigPath = QDir(projectDir).absoluteFilePath("config/microleak");
    qDebug() << "MicroLeak config path:" << microLeakConfigPath;
    
    bool microLeakInitialized = microLeakManager->initialize(microLeakConfigPath);
    if (microLeakInitialized) {
        qDebug() << "微漏管理器初始化成功";
    } else {
        qWarning() << "微漏管理器初始化失败";
    }
    qDebug() << "=== 微漏管理器初始化完成 ===";
    
    // 先创建设备树形模型并设置到设备模型中
    DeviceTreeModel* deviceTreeModel = new DeviceTreeModel();
    DeviceModel::instance()->setTreeModel(deviceTreeModel);
    
    // 设置HikvisionCtrl实例到DeviceModel（在加载设备之前）
    DeviceModel::instance()->setHikvisionCtrl(hikvisionCtrl);
    
    // 然后加载设备配置
    DeviceModel::instance()->loadDefaultDevices();
    
    // 连接设备选择信号到预置位和巡航模型
    QObject::connect(DeviceModel::instance(), &DeviceModel::deviceSelected,
                     PresetModel::instance(), &PresetModel::setCurrentDevice);
    QObject::connect(DeviceModel::instance(), &DeviceModel::deviceSelected,
                     CruiseModel::instance(), &CruiseModel::setCurrentDevice);
    
    // 设置初始选中的设备（优先选择通道0的设备）
    auto allDevices = DeviceModel::instance()->getAllDevices();
    if (!allDevices.isEmpty()) {
        QString targetDeviceId = allDevices.first().deviceId;
        
        // 查找通道0的设备
        for (const auto& device : allDevices) {
            if (device.channelIndex == 0) {
                targetDeviceId = device.deviceId;
                break;
            }
        }
        
        // 设置到业务模型
        PresetModel::instance()->setCurrentDevice(targetDeviceId);
        CruiseModel::instance()->setCurrentDevice(targetDeviceId);
        // 设置到设备模型，作为全局选中设备，供回放/切换使用
        DeviceModel::instance()->selectDevice(targetDeviceId);
        qDebug() << "设置初始设备为选中设备:" << targetDeviceId;
    }

    //---------------------------------------------------------------------

    // 注册PlayerManager枚举到QML - 必须在创建实例之前注册
    qmlRegisterUncreatableMetaObject(PlayerManager::staticMetaObject, "App", 1, 0, "PlayerManager", "PlayerManager is not creatable");
    // 创建播放器管理器
    PlayerManager* playerManager = PlayerManager::instance();
    engine.rootContext()->setContextProperty("playerManager", playerManager);
    
    // 创建AlarmVideoPlayer实例并注册为上下文属性
    AlarmVideoPlayer* alarmVideoPlayer = AlarmVideoPlayer::instance();
    // 设置HikvisionCtrl实例到AlarmVideoPlayer
    alarmVideoPlayer->setHikvisionCtrl(hikvisionCtrl);
    engine.rootContext()->setContextProperty("AlarmVideoPlayer", alarmVideoPlayer);
    
    // 创建两个独立的HistoryVideoPlayer实例并设置HikvisionCtrl
    HistoryVideoPlayer* visibleLightHistoryPlayer = new HistoryVideoPlayer();
    visibleLightHistoryPlayer->setHikvisionCtrl(hikvisionCtrl);
    engine.rootContext()->setContextProperty("visibleLightHistoryPlayer", visibleLightHistoryPlayer);
    
    // 创建第二个HistoryVideoPlayer实例
    HistoryVideoPlayer* infraredHistoryPlayer = new HistoryVideoPlayer();
    infraredHistoryPlayer->setHikvisionCtrl(hikvisionCtrl);
    engine.rootContext()->setContextProperty("infraredHistoryPlayer", infraredHistoryPlayer);

    // 先加载UI
    engine.load(QStringLiteral("qrc:/RootWindow.qml"));
    QObject* rootObject = engine.rootObjects().value(0);
    QObject* item = rootObject->findChild<QObject*>("main_window");

    // 创建延时器，在UI显示后再初始化设备和播放器
    QTimer* initTimer = new QTimer();
    initTimer->setSingleShot(true);
    
    // 使用lambda表达式来延时执行初始化逻辑
    QObject::connect(initTimer, &QTimer::timeout, [&]() {
        qDebug() << "=== 开始延时初始化设备和播放器 ===";
        
        int channelCount = DeviceModel::instance()->getChannelCount();
        playerManager->initializePlayers(channelCount);

        // 为每个通道创建FrameProvider
        static FrameProvider frameProviderVisibleLight[10];  // 使用静态数组避免栈溢出
        static FrameProvider frameProviderInfrared[10];
        static FrameProvider frameProviderVisibleLightRecord[10];
        static FrameProvider frameProviderInfraredRecord[10];
        static FrameProvider frameProviderDualFusion[10]; 
        static FrameProvider frameProviderGasCloudVisible[10];
        static FrameProvider frameProviderGasCloudInfrared[10];
        
        QList<int> allChannels = DeviceModel::instance()->getAllDeviceChannelIndexes();
        for (int i = 0; i < channelCount && i < 10; ++i) {
            //frameprovider和channel的映射关系写死，不用判断
            QString indexStr = QString::number(i);
            engine.rootContext()->setContextProperty("frameProviderVisibleLight" + indexStr, &frameProviderVisibleLight[i]);
            engine.rootContext()->setContextProperty("frameProviderInfrared" + indexStr, &frameProviderInfrared[i]);
            engine.rootContext()->setContextProperty("frameProviderVisibleLightRecord" + indexStr, &frameProviderVisibleLightRecord[i]);
            engine.rootContext()->setContextProperty("frameProviderInfraredRecord" + indexStr, &frameProviderInfraredRecord[i]);
            engine.rootContext()->setContextProperty("frameProviderDualFusion" + indexStr, &frameProviderDualFusion[i]);
            engine.rootContext()->setContextProperty("frameProviderGasCloudVisible" + indexStr, &frameProviderGasCloudVisible[i]);
            engine.rootContext()->setContextProperty("frameProviderGasCloudInfrared" + indexStr, &frameProviderGasCloudInfrared[i]); 

            playerManager->setChannelFrameProvider(i, PlayerManager::VisibleLightLive, &frameProviderVisibleLight[i]); 
            playerManager->setChannelFrameProvider(i, PlayerManager::InfraredLive, &frameProviderInfrared[i]);   
            playerManager->setChannelFrameProvider(i, PlayerManager::VisibleLightRecord, &frameProviderVisibleLightRecord[i]);  
            playerManager->setChannelFrameProvider(i, PlayerManager::InfraredRecord, &frameProviderInfraredRecord[i]);    
            
            // 设置通道i的双光融合FrameProvider
            playerManager->setDualFusionProvider(i, &frameProviderDualFusion[i]);
            
            // 设置通道i的气云成像FrameProvider
            playerManager->setGasCloudVisibleProvider(i, &frameProviderGasCloudVisible[i]);
            playerManager->setGasCloudInfraredProvider(i, &frameProviderGasCloudInfrared[i]);
        }

        //playerManager->updatePlayerUrls();
        engine.rootContext()->setContextProperty("playerManager", playerManager);
        
        // 注册所有通道的FrameProvider到DeviceModel，以便后续懒加载
        for (int i = 0; i < channelCount && i < 10; ++i) {
             DeviceModel::instance()->setChannelFrameProviders(i, &frameProviderVisibleLight[i], &frameProviderInfrared[i]);
        }
        
        // 启动时仅初始化通道0的设备
        qDebug() << "=== 启动时仅初始化通道0 ===";
        DeviceModel::instance()->initializeChannelDevice(0);
        qDebug() << "=== 初始设备加载完成 ===";
    });
    
    // 延时2秒后开始初始化设备和播放器
    initTimer->start(2000);
        

        //-----------------------------------------------------------------------

    return app.exec();
}
