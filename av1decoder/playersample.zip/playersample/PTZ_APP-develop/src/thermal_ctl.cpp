#include "thermal_ctl.h"
#include <QVariantMap>
#include <QJsonObject>
#include <QJsonDocument>
#include <QJsonArray>
#include <QJsonValue>
#include <thread>
#include <QList>
#include <QUrl>
#include <curl/curl.h>
#include <json/json.h>
#include <tinyxml2.h>
#include <cstring>
#include <unistd.h>
#include <QDebug>
#include <openssl/evp.h>
#include <openssl/aes.h>
#include <openssl/rand.h>
#include <QByteArray>
#include <QCryptographicHash>

#define THERMAL_IP "192.168.1.123"
#define THERMAL_USER "admin"
#define THERMAL_PASSWORD "ahYaoEznlTShKsgubjdDng=="

#define DENOISE2DLEVEL  2
#define DENOISE3DLEVEL  3
#define DETAILENHANCELEVEL 4
#define FlIPMODE  4
#define RANGELEVEL  4
#define COORDX  4
#define COORDY  4

static  size_t ThermalWriteCallback(void* contents, size_t size, size_t nmemb, void* userp)
{
    const size_t totalSize = size * nmemb;
    QByteArray* buffer = static_cast<QByteArray*>(userp);
    buffer->append(static_cast<char*>(contents), static_cast<int>(totalSize));
    return totalSize;
}

ThermalCtl::ThermalCtl(QObject* parent)
: QObject(parent), mLoginRetryCount(0)
{
    // 初始化登录重试定时器
    mLoginRetryTimer = new QTimer(this);
    mLoginRetryTimer->setSingleShot(true); // 设置为单次触发
    connect(mLoginRetryTimer, &QTimer::timeout, this, &ThermalCtl::retryLoginThermal);
    
    QTimer* timer_alive = new QTimer(this);
    timer_alive->setInterval(5000);
    connect(timer_alive, &QTimer::timeout, this, &ThermalCtl::mvKeepAlive);
    timer_alive->start();
    qDebug() << "Thermal keepalive timer started with 5 second interval";

    // 连接所有信号和槽，确保异步执行
    connect(this, &ThermalCtl::setPseudoModeRequested,
            this, &ThermalCtl::doSetPseudoMode,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::enhanceInfraRedRequested,
            this, &ThermalCtl::doEnhanceInfraRed,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::setThermalImageParamsRequested,
            this, &ThermalCtl::doSetThermalImageParams,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::rebootThermalRequested,
            this, &ThermalCtl::doRebootThermal,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::factoryResetThermalRequested,
            this, &ThermalCtl::doFactoryResetThermal,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::setRecordCtrlRequested,
            this, &ThermalCtl::doSetRecordCtrl,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::setRecordScheduleRequested,
            this, &ThermalCtl::doSetRecordSchedule,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::setSnapScheduleRequested,
            this, &ThermalCtl::doSetSnapSchedule,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::addOnvifUserRequested,
            this, &ThermalCtl::doAddOnvifUser,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::setOnvifAuthRequested,
            this, &ThermalCtl::doSetOnvifAuth,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::changeOnvifUserPasswordRequested,
            this, &ThermalCtl::doChangeOnvifUserPassword,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::deleteOnvifUserRequested,
            this, &ThermalCtl::doDeleteOnvifUser,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::setGb28181ConfigRequested,
            this, &ThermalCtl::doSetGb28181Config,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::mvKeepAliveRequested,
            this, &ThermalCtl::doMvKeepAlive,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::setFocusZoomRequested,
            this, &ThermalCtl::doSetFocusZoom,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::ptzOperationRequested,
            this, &ThermalCtl::doPtzOperation,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::ptzStopFocusRequested,
            this, &ThermalCtl::doPtzStopFocus,
            Qt::QueuedConnection);
    connect(this, &ThermalCtl::loginThermalRequested,
            this, &ThermalCtl::doLoginThermal,
            Qt::QueuedConnection);

}


void ThermalCtl::LoginThermal(QString ip, QString user, QString passwd, QString deviceName, QString deviceId)
{
    // 只发信号，不做耗时工作
    qDebug() << "ThermalCtl::LoginThermal ip:" << ip << "user:" << user << "passwd:" << passwd << "deviceName:" << deviceName << "deviceId:" << deviceId;
    emit loginThermalRequested(ip, user, passwd, deviceName, deviceId);
}

void ThermalCtl::doLoginThermal(QString ip, QString user, QString passwd, QString deviceName, QString deviceId)
{
    // 无论登录是否成功，都先设置设备信息，以便后续异常报警使用
    mDeviceName = deviceName.isEmpty() ? ip : deviceName;
    mDeviceId = deviceId;
    
    QString encodedUser = QUrl::toPercentEncoding(user);
    // Encrypt password using AES-CBC as specified in API documentation
    QString encryptedPwd = encryptPassword(passwd);

    QString url = QString("http://%1/v1/token/").arg(ip); // Remove query params from URL
    QString post_fields = QString("username=%1&password=%2")
                            .arg(QString::fromUtf8(QUrl::toPercentEncoding(user)))
                            .arg(encryptedPwd);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();

    if (curl) {
        // Set POST options
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, post_fields.toUtf8().constData());
        
        // Set headers
        headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

        // Set timeout options
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 5L);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "doLoginThermal thermal CURL request failed:" << curl_easy_strerror(res);
            qCritical() << "Login URL:" << url;
            qCritical() << "Login parameters:" << post_fields;
            curl_easy_cleanup(curl);
            
            // 检查是否需要重试
            if (mLoginRetryCount < MAX_LOGIN_RETRY_COUNT) {
                // 保存登录信息用于重试
                mPendingIp = ip;
                mPendingUser = user;
                mPendingPasswd = passwd;
                mPendingDeviceName = deviceName;
                mPendingDeviceId = deviceId;
                
                // 启动重试定时器
                mLoginRetryTimer->start(LOGIN_RETRY_DELAY_MS);
                qDebug() << "Login failed due to network error, will retry in" << LOGIN_RETRY_DELAY_MS << "ms, attempt" << (mLoginRetryCount + 1) << "of" << MAX_LOGIN_RETRY_COUNT;
            } else {
                qCritical() << "Login failed after" << MAX_LOGIN_RETRY_COUNT << "attempts, giving up";
                mLoginRetryCount = 0; // 重置重试计数器
            }
            return ;
        }

        qDebug() << "thermal HTTP Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            // 检查是否需要重试
            if (mLoginRetryCount < MAX_LOGIN_RETRY_COUNT) {
                // 保存登录信息用于重试
                mPendingIp = ip;
                mPendingUser = user;
                mPendingPasswd = passwd;
                mPendingDeviceName = deviceName;
                mPendingDeviceId = deviceId;
                
                // 启动重试定时器
                mLoginRetryTimer->start(LOGIN_RETRY_DELAY_MS);
                qDebug() << "Login failed due to JSON parse error, will retry in" << LOGIN_RETRY_DELAY_MS << "ms, attempt" << (mLoginRetryCount + 1) << "of" << MAX_LOGIN_RETRY_COUNT;
            } else {
                qCritical() << "Login failed after" << MAX_LOGIN_RETRY_COUNT << "attempts, giving up";
                mLoginRetryCount = 0; // 重置重试计数器
            }
            return ;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal Login failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            // 检查是否需要重试
            if (mLoginRetryCount < MAX_LOGIN_RETRY_COUNT) {
                // 保存登录信息用于重试
                mPendingIp = ip;
                mPendingUser = user;
                mPendingPasswd = passwd;
                mPendingDeviceName = deviceName;
                mPendingDeviceId = deviceId;
                
                // 启动重试定时器
                mLoginRetryTimer->start(LOGIN_RETRY_DELAY_MS);
                qDebug() << "Login failed with code" << code << ", will retry in" << LOGIN_RETRY_DELAY_MS << "ms, attempt" << (mLoginRetryCount + 1) << "of" << MAX_LOGIN_RETRY_COUNT;
            } else {
                qCritical() << "Login failed after" << MAX_LOGIN_RETRY_COUNT << "attempts, giving up";
                mLoginRetryCount = 0; // 重置重试计数器
            }
            return ;
        }

        if (!rootObj.contains("Data") || !rootObj["Data"].isString()) {
            qCritical() << "thermal Invalid response format: Missing or invalid Data field";
            curl_easy_cleanup(curl);
            
            // 检查是否需要重试
            if (mLoginRetryCount < MAX_LOGIN_RETRY_COUNT) {
                // 保存登录信息用于重试
                mPendingIp = ip;
                mPendingUser = user;
                mPendingPasswd = passwd;
                mPendingDeviceName = deviceName;
                mPendingDeviceId = deviceId;
                
                // 启动重试定时器
                mLoginRetryTimer->start(LOGIN_RETRY_DELAY_MS);
                qDebug() << "Login failed due to invalid response format, will retry in" << LOGIN_RETRY_DELAY_MS << "ms, attempt" << (mLoginRetryCount + 1) << "of" << MAX_LOGIN_RETRY_COUNT;
            } else {
                qCritical() << "Login failed after" << MAX_LOGIN_RETRY_COUNT << "attempts, giving up";
                mLoginRetryCount = 0; // 重置重试计数器
            }
            return ;
        }

        QString token= rootObj.value("Data").toString();

        qDebug() << "thermal Parsed token:" << token;
        mServerIp = ip;
        mToken = token;
        mUsername =  user;
        mPassWord = passwd;
        
        // 登录成功，重置重试计数器
        mLoginRetryCount = 0;

        curl_easy_cleanup(curl);
        return ;
    }
    return ;
}

void ThermalCtl::retryLoginThermal()
{
    // 增加重试计数器
    mLoginRetryCount++;
    
    qDebug() << "Retrying login for device" << mPendingDeviceName << ", attempt" << mLoginRetryCount << "of" << MAX_LOGIN_RETRY_COUNT;
    
    // 使用保存的登录信息重试登录
    doLoginThermal(mPendingIp, mPendingUser, mPendingPasswd, mPendingDeviceName, mPendingDeviceId);
}


void ThermalCtl::mvKeepAlive() {
    // 只发信号，不做耗时工作
    qDebug() << "Thermal keepalive timer triggered, mServerIp:" << mServerIp << "mToken empty:" << mToken.isEmpty();
    emit mvKeepAliveRequested();
}

void ThermalCtl::doMvKeepAlive(){
    // 检查是否已登录，如果未登录则发送设备异常报警
    if (mServerIp.isEmpty() || mToken.isEmpty()) {
        qDebug() << "Thermal device not logged in, sending device exception alarm";
        addDeviceExceptionAlarm("001", "网络异常", "红外机芯");
        return;
    }
    
    QString url = QString("http://%1/v1/token/").arg(mServerIp); // Remove query params from URL


    CURL* curl;
    CURLcode res;
    QByteArray responseData;
    qDebug() << "thermal mvKeepAlive url:" << url;
    struct curl_slist* headers = nullptr;
    //headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());

    curl = curl_easy_init();

    if (curl) {
        // Set PUT options
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");  // Set custom request method to PUT
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        
        // Set timeout options
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);        // 10秒超�?        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 5L);  // 5秒连接超�?        
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "doMvKeepAlive thermal CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            // 发送设备异常报警 - 网络异常
            addDeviceExceptionAlarm("001", "网络异常", "红外机芯");
            // keepalive失败后继续运行，下次timer触发时会再次尝试
            return;
        }

        qDebug() << "thermal mvKeepAlive Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal keepalive failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            // 发送设备异常报警 - 网络异常
            addDeviceExceptionAlarm("001", "网络异常", "红外机芯");
            return;
        }



        if (!rootObj.contains("Data") || !rootObj["Data"].isObject()) {
            qCritical() << "thermal Invalid response format: Missing or invalid Data field";
            curl_easy_cleanup(curl);
            
            return;
        }

        QJsonObject dataObj = rootObj["Data"].toObject();
        if (!dataObj.contains("Token") || !dataObj["Token"].isString()) {
            qCritical() << "thermal Invalid response format: Missing or invalid Token field";
            curl_easy_cleanup(curl);
            
            return;
        }

        QString newToken = dataObj["Token"].toString();
        mToken = newToken; // Update the token
        qDebug() << "thermal Updated token:" << mToken;

        //enhanceInfraRed();
        curl_easy_cleanup(curl);
        
        return;
    }

    

    return;
}
void ThermalCtl::setPseudoMode(int mode) {
    // 只发信号，不做耗时工作
    emit setPseudoModeRequested(mode);
}

void ThermalCtl::doSetPseudoMode(int mode){
    QString url = QString("http://%1/v1/camera/videoin/thermal/pallete?chn=0&debug=false").arg(mServerIp);

    int palletteNo = 0;
    switch(mode){
        case WHITE_HOT:
            palletteNo = 0;
            break;
        case BLACK_HOT:
            palletteNo = 1;
            break;
        case IRON_RED:
            palletteNo = 4;
            break;
        case CYANIDE_BLUE: 
            palletteNo = 13;
            break;
        case RAINBOW:
            palletteNo = 2;
            break;
        case INVERSE_RAINBOW:
            palletteNo = 3;
            break;
        case RED_BROWN:
            palletteNo = 12;
            break;  
        case HOT_IRON:
            palletteNo = 7;
            break;
        case COOL_COLOR:
            palletteNo = 8;
            break;
        case FIRE:  
            palletteNo = 9;
            break;
    }
    // Prepare the JSON request body
    QJsonObject requestBody;
    requestBody["PalleteNo"] = palletteNo;
    QJsonArray threshold;
    threshold.append(0);
    requestBody["Threshold"] = threshold;

    QJsonDocument doc(requestBody);
    QString jsonString = doc.toJson(QJsonDocument::Compact);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "doSetPseudoMode thermal CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return;
        }

        qDebug() << "thermal setPseudoMode Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal setPseudoMode failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return;
        }

        curl_easy_cleanup(curl);
        
    } else {
        
    }
}
void ThermalCtl::enhanceInfraRed(bool brightMutation,
                               bool denoise2DEnable, int denoise2DLevel,
                               bool denoise3DEnable, int denoise3DLevel,
                               bool ddeEnable, int ddeLevel,
                               int flipMode,
                               bool regionalEnable, int regionalLevel,
                               int coordX, int coordY){
    // 只发信号，不做耗时工作
    emit enhanceInfraRedRequested(brightMutation, denoise2DEnable, denoise2DLevel,
                                 denoise3DEnable, denoise3DLevel, ddeEnable, ddeLevel,
                                 flipMode, regionalEnable, regionalLevel, coordX, coordY);
}

void ThermalCtl::doEnhanceInfraRed(bool brightMutation,
                               bool denoise2DEnable, int denoise2DLevel,
                               bool denoise3DEnable, int denoise3DLevel,
                               bool ddeEnable, int ddeLevel,
                               int flipMode,
                               bool regionalEnable, int regionalLevel,
                               int coordX, int coordY){
    QString url = QString("http://%1/v1/camera/videoin/thermal/enhance?chn=0").arg(mServerIp);

    // Prepare the JSON request body
    QJsonObject requestBody;
    requestBody["BrightMutationSuppression"] = brightMutation;

    QJsonObject denoise2D;
    denoise2D["Enable"] = denoise2DEnable;
    denoise2D["Level"] = denoise2DLevel;
    requestBody["Denoise2D"] = denoise2D;

    QJsonObject denoise3D;
    denoise3D["Enable"] = denoise3DEnable;
    denoise3D["Level"] = denoise3DLevel;
    requestBody["Denoise3D"] = denoise3D;

    QJsonObject detailEnhance;
    detailEnhance["Enable"] = ddeEnable;
    detailEnhance["Level"] = ddeLevel;
    requestBody["DetailEnhance"] = detailEnhance;

    requestBody["FlipMode"] = flipMode;

    QJsonObject regionalVideoEnhance;
    regionalVideoEnhance["Enable"] = regionalEnable;
    
    QJsonObject range;
    range["Level"] = regionalLevel;
    
    QJsonArray region;
    QJsonObject coord;
    coord["X"] = coordX;
    coord["Y"] = coordY;
    region.append(coord);
    
    range["Region"] = region;
    regionalVideoEnhance["Range"] = range;
    requestBody["RegionalVideoEnhance"] = regionalVideoEnhance;

    //qDebug() << " enhanceInfraRed body:" << debugDoc.toJson(QJsonDocument::Indented);

    QJsonDocument doc(requestBody);
    QString jsonString = doc.toJson(QJsonDocument::Compact);


    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    //headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "doEnhanceInfraRed thermal CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return;
        }

        qDebug() << "thermal enhanceInfraRed Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal enhance failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return;
        }

        curl_easy_cleanup(curl);
        
    } else {
        
    } 
}

void ThermalCtl::setThermalImageParams(int brightness, int contrast, int flipMode) {
    // 只发信号，不做耗时工作
    emit setThermalImageParamsRequested(brightness, contrast, flipMode);
}

QJsonObject ThermalCtl::getThermalImageParams(bool defaultConfig) {
    // 只发信号，不做耗时工作
    emit getThermalImageParamsRequested(defaultConfig);
    return dogetThermalImageParams(defaultConfig);
}

void ThermalCtl::doSetThermalImageParams(int brightness, int contrast, int flipMode) {
    QString url = QString("http://%1/v1/camera/videoin/thermal/param?chn=0").arg(mServerIp);

    // Prepare the JSON request body
    QJsonObject requestBody;
    requestBody["Luminance"] = brightness;
    requestBody["Contrast"] = contrast;
    requestBody["FlipMode"] = flipMode;

    QJsonDocument doc(requestBody);
    QString jsonString = doc.toJson(QJsonDocument::Compact);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "doSetThermalImageParams thermal CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return;
        }

        qDebug() << "thermal setThermalImageParams Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal setThermalImageParams failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return;
        }

        curl_easy_cleanup(curl);
        
    } else {
        
    }
}

QJsonObject ThermalCtl::dogetThermalImageParams(bool defaultConfig) {
    QString url = QString("http://%1/v1/camera/videoin/thermal/param?default=%2&chn=0")
                      .arg(mServerIp)
                      .arg(defaultConfig ? "true" : "false");

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());

    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "dogetThermalImageParams thermal CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return QJsonObject(); // Return empty object on failure
        }

        qDebug() << "thermal getThermalImageParams Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return QJsonObject(); // Return empty object on failure
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal getThermalImageParams failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return QJsonObject(); // Return empty object on failure
        }

        // Extract the thermal image parameters from the response
        // Check for ImageParam first (original format), then Data field (new format)
        if (rootObj.contains("ImageParam")) {
            QJsonObject imageParam = rootObj.value("ImageParam").toObject();
            curl_easy_cleanup(curl);
            
            return imageParam;
        } else if (rootObj.contains("Data")) {
            QJsonObject dataObj = rootObj.value("Data").toObject();
            
            // Check if Data contains thermal parameters (Luminance, Contrast, FlipMode)
            if (dataObj.contains("Luminance") || dataObj.contains("Contrast") || dataObj.contains("FlipMode")) {
                curl_easy_cleanup(curl);
                return dataObj;
            }
        }
        
        qWarning() << "thermal ImageParam or Data with thermal parameters not found in response";
        curl_easy_cleanup(curl);
        
        return QJsonObject(); // Return empty object if parameters not found

        curl_easy_cleanup(curl);
        
    } else {
        
    }
    
    return QJsonObject(); // Return empty object if curl initialization failed
}

void ThermalCtl::rebootThermal() {
    // 只发信号，不做耗时工作
    emit rebootThermalRequested();
}

void ThermalCtl::doRebootThermal() {
    QString url = QString("http://%1/v1/csystem/magic/reboot").arg(mServerIp);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal reboot CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return;
        }

        qDebug() << "thermal reboot Response:" << responseData;
        
        // For reboot, a 200 response might not contain a JSON response
        if (!responseData.isEmpty()) {
            QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
            if (!jsonDoc.isNull()) {
                QJsonObject rootObj = jsonDoc.object();
                int code = rootObj.value("Code").toInt();

                if (code != 200) {
                    qCritical() << "thermal reboot failed. Code:" << code;
                    qCritical() << "thermal Message:" << rootObj.value("Message").toString();
                    curl_easy_cleanup(curl);
                    
                    return;
                }
            }
        }

        curl_easy_cleanup(curl);
        
    } else {
        
    }
}

void ThermalCtl::factoryResetThermal() {
    // 只发信号，不做耗时工作
    emit factoryResetThermalRequested();
}

void ThermalCtl::doFactoryResetThermal() {
    QString url = QString("http://%1/v1/csystem/maintain/factory").arg(mServerIp);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal factory reset CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return;
        }

        qDebug() << "thermal factory reset Response:" << responseData;
        
        // For factory reset, a 200 response might not contain a JSON response
        if (!responseData.isEmpty()) {
            QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
            if (!jsonDoc.isNull()) {
                QJsonObject rootObj = jsonDoc.object();
                int code = rootObj.value("Code").toInt();

                if (code != 200) {
                    qCritical() << "thermal factory reset failed. Code:" << code;
                    qCritical() << "thermal Message:" << rootObj.value("Message").toString();
                    curl_easy_cleanup(curl);
                    
                    return;
                }
            }
        }

        // API documentation states we need to reboot after factory reset
        rebootThermal();

        curl_easy_cleanup(curl);
        
    } else {
        
    }
}

QJsonObject ThermalCtl::getRecordCtrl(bool defaultConfig) {
    QString url = QString("http://%1/v1/storage/record/ctrl").arg(mServerIp);
    
    if (defaultConfig) {
        url += "?default=true";
    }

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    QJsonObject resultObj;

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal getRecordCtrl CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        qDebug() << "thermal getRecordCtrl Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal getRecordCtrl failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        // Return the actual config data
        if (rootObj.contains("Data") && rootObj["Data"].isObject()) {
            resultObj = rootObj["Data"].toObject();
        } else if (code == 200) {
            // Some APIs directly return data at the root level
            resultObj = rootObj;
        }

        curl_easy_cleanup(curl);
        
        return resultObj;
    }

    
    return resultObj;
}

bool ThermalCtl::setRecordCtrl(int packageTime, int prerecordTime, int streamType) {
    // 只发信号，不做耗时工作
    emit setRecordCtrlRequested(packageTime, prerecordTime, streamType);
    return true; // 立即返回，实际结果在子线程中处理
}

void ThermalCtl::doSetRecordCtrl(int packageTime, int prerecordTime, int streamType) {
    QString url = QString("http://%1/v1/storage/record/ctrl").arg(mServerIp);

    // Prepare the JSON request body
    QJsonObject requestBody;
    requestBody["PackageTime"] = packageTime;
    requestBody["PrerecordTime"] = prerecordTime;
    requestBody["StreamType"] = streamType;

    QJsonDocument doc(requestBody);
    QString jsonString = doc.toJson(QJsonDocument::Compact);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal setRecordCtrl CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal setRecordCtrl Response:" << responseData;

        // If responseData is empty or not a valid JSON, consider it successful
        // since some APIs might return empty response on success
        if (responseData.isEmpty()) {
            curl_easy_cleanup(curl);
            
            return true;
        }

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return false;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal setRecordCtrl failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return false;
        }

        curl_easy_cleanup(curl);
        
        return true;
    }

    
    return false;
}

QJsonObject ThermalCtl::getRecordSchedule(int channel, bool defaultConfig) {
    QString url = QString("http://%1/v1/storage/record/schedule?chn=%2").arg(mServerIp).arg(channel);
    
    if (defaultConfig) {
        url += "&default=true";
    }

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    QJsonObject resultObj;

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal getRecordSchedule CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        qDebug() << "thermal getRecordSchedule Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal getRecordSchedule failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        // Return the actual config data
        if (rootObj.contains("Data") && rootObj["Data"].isObject()) {
            resultObj = rootObj["Data"].toObject();
        } else if (code == 200) {
            // Some APIs directly return data at the root level
            resultObj = rootObj;
        }

        curl_easy_cleanup(curl);
        
        return resultObj;
    }

    
    return resultObj;
}

bool ThermalCtl::setRecordSchedule(int channel, const QJsonObject& scheduleConfig) {
    // 只发信号，不做耗时工作
    emit setRecordScheduleRequested(channel, scheduleConfig);
    return true; // 立即返回，实际结果在子线程中处理
}

void ThermalCtl::doSetRecordSchedule(int channel, const QJsonObject& scheduleConfig) {
    QString url = QString("http://%1/v1/storage/record/schedule?chn=%2").arg(mServerIp).arg(channel);

    QJsonDocument doc(scheduleConfig);
    QString jsonString = doc.toJson(QJsonDocument::Compact);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal setRecordSchedule CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal setRecordSchedule Response:" << responseData;

        // If responseData is empty or not a valid JSON, consider it successful
        // since some APIs might return empty response on success
        if (responseData.isEmpty()) {
            curl_easy_cleanup(curl);
            
            return true;
        }

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return false;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal setRecordSchedule failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return false;
        }

        curl_easy_cleanup(curl);
        
        return true;
    }

    
    return false;
}

QJsonObject ThermalCtl::getSnapSchedule(int channel, bool defaultConfig) {
    QString url = QString("http://%1/v1/storage/snap/schedule?chn=%2").arg(mServerIp).arg(channel);
    
    if (defaultConfig) {
        url += "&default=true";
    }

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    QJsonObject resultObj;

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal getSnapSchedule CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        qDebug() << "thermal getSnapSchedule Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal getSnapSchedule failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        // Return the actual config data
        if (rootObj.contains("Data") && rootObj["Data"].isObject()) {
            resultObj = rootObj["Data"].toObject();
        } else if (code == 200) {
            // Some APIs directly return data at the root level
            resultObj = rootObj;
        }

        curl_easy_cleanup(curl);
        
        return resultObj;
    }

    
    return resultObj;
}
//thermalControl.setSnapSchedule(0, 2, true, true, "08:00:00", "18:00:00")
bool ThermalCtl::setSnapSchedule(int channel, int mode, bool storageFTP, bool storageLocal, QString startTime, QString endTime) {
    // 只发信号，不做耗时工作
    emit setSnapScheduleRequested(channel, mode, storageFTP, storageLocal, startTime, endTime);
    return true; // 立即返回，实际结果在子线程中处理
}

void ThermalCtl::doSetSnapSchedule(int channel, int mode, bool storageFTP, bool storageLocal, QString startTime, QString endTime) {
    QString url = QString("http://%1/v1/storage/snap/schedule?chn=%2").arg(mServerIp).arg(channel);

    // Create JSON manually from the individual parameters
    QJsonObject scheduleConfig;
    scheduleConfig["Mode"] = mode;
    scheduleConfig["StorageFTP"] = storageFTP;
    scheduleConfig["StorageLocal"] = storageLocal;
    
    // Create a default empty schedule object
    QJsonObject weekSchedule;
    QJsonArray weekDayArray;
    
    QJsonObject weekDay;
    QJsonArray sectionArray;
    
    QJsonObject section;
    QJsonArray timeSecArray;
    
    // Add seconds for internal comparison (convert from time string to seconds)
    // Here we just add a placeholder value. The server will handle the actual conversion
    timeSecArray.append(0);
    
    QJsonArray timeStrArray;
    // Format: startTime-endTime, e.g. "00:00:00-23:59:59"
    QString timeRangeStr = QString("%1-%2").arg(startTime).arg(endTime);
    timeStrArray.append(timeRangeStr);
    
    section["TimeSec"] = timeSecArray;
    section["TimeStr"] = timeStrArray;
    
    sectionArray.append(section);
    weekDay["Section"] = sectionArray;
    
    // Create 7 days with the same schedule
    for (int i = 0; i < 7; i++) {
        weekDayArray.append(weekDay);
    }
    
    weekSchedule["WeekDay"] = weekDayArray;
    
    scheduleConfig["Schedule"] = weekSchedule;

    QJsonDocument doc(scheduleConfig);
    QString jsonString = doc.toJson(QJsonDocument::Compact);
    
    qDebug() << "Snapshot schedule JSON:" << jsonString;

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal setSnapSchedule CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal setSnapSchedule Response:" << responseData;

        // If responseData is empty or not a valid JSON, consider it successful
        // since some APIs might return empty response on success
        if (responseData.isEmpty()) {
            curl_easy_cleanup(curl);
            
            return true;
        }

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return false;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal setSnapSchedule failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return false;
        }

        curl_easy_cleanup(curl);
        
        return true;
    }

    
    return false;
}

bool ThermalCtl::addOnvifUser(const QString& name, const QString& password, int group) {
    // 只发信号，不做耗时工作
    emit addOnvifUserRequested(name, password, group);
    return true; // 立即返回，实际结果在子线程中处理
}

void ThermalCtl::doAddOnvifUser(const QString& name, const QString& password, int group) {
    QString url = QString("http://%1/v1/netapp/onvif/add").arg(mServerIp);

    // Prepare the JSON request body
    QJsonObject requestBody;
    requestBody["Name"] = name;
    requestBody["Password"] = password;
    requestBody["Group"] = group;

    QJsonDocument doc(requestBody);
    QString jsonString = doc.toJson(QJsonDocument::Compact);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal addOnvifUser CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal addOnvifUser Response:" << responseData;

        // Check HTTP response code
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            curl_easy_cleanup(curl);
            
            return true;
        } else {
            qCritical() << "thermal addOnvifUser failed with HTTP code:" << response_code;
            curl_easy_cleanup(curl);
            
            return false;
        }
    }

    
    return false;
}

bool ThermalCtl::getOnvifAuth(bool defaultConfig) {
    QString url = QString("http://%1/v1/netapp/onvif/auth").arg(mServerIp);
    
    if (defaultConfig) {
        url += "?default=true";
    }

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal getOnvifAuth CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal getOnvifAuth Response:" << responseData;

        // Check HTTP response code
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            // For a simple boolean response, check if response contains "true" or "false"
            QString responseStr = QString::fromUtf8(responseData);
            bool authEnabled = responseStr.trimmed().toLower() == "true";
            qDebug() << "thermal ONVIF auth enabled:" << authEnabled;
            curl_easy_cleanup(curl);
            
            return authEnabled;
        }

        curl_easy_cleanup(curl);
        
        return false;
    }

    
    return false;
}

bool ThermalCtl::setOnvifAuth(bool authEnabled) {
    // 只发信号，不做耗时工作
    emit setOnvifAuthRequested(authEnabled);
    return true; // 立即返回，实际结果在子线程中处理
}

void ThermalCtl::doSetOnvifAuth(bool authEnabled) {
    QString url = QString("http://%1/v1/netapp/onvif/auth?auth=%2").arg(mServerIp).arg(authEnabled ? "true" : "false");

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal setOnvifAuth CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal setOnvifAuth Response:" << responseData;

        // Check HTTP response code
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            curl_easy_cleanup(curl);
            
            return true;
        } else {
            qCritical() << "thermal setOnvifAuth failed with HTTP code:" << response_code;
            curl_easy_cleanup(curl);
            
            return false;
        }
    }

    
    return false;
}

bool ThermalCtl::changeOnvifUserPassword(const QString& name, const QString& newPassword) {
    // 只发信号，不做耗时工作
    emit changeOnvifUserPasswordRequested(name, newPassword);
    return true; // 立即返回，实际结果在子线程中处理
}

void ThermalCtl::doChangeOnvifUserPassword(const QString& name, const QString& newPassword) {
    QString url = QString("http://%1/v1/netapp/onvif/changepwd").arg(mServerIp);

    // Prepare the JSON request body
    QJsonObject requestBody;
    requestBody["Name"] = name;
    requestBody["NewPassword"] = newPassword;

    QJsonDocument doc(requestBody);
    QString jsonString = doc.toJson(QJsonDocument::Compact);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal changeOnvifUserPassword CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal changeOnvifUserPassword Response:" << responseData;

        // Check HTTP response code
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            curl_easy_cleanup(curl);
            
            return true;
        } else {
            qCritical() << "thermal changeOnvifUserPassword failed with HTTP code:" << response_code;
            if (response_code == 400704) {
                qCritical() << "thermal User does not exist";
            }
            curl_easy_cleanup(curl);
            
            return false;
        }
    }

    
    return false;
}

bool ThermalCtl::deleteOnvifUser(const QString& name) {
    // 只发信号，不做耗时工作
    emit deleteOnvifUserRequested(name);
    return true; // 立即返回，实际结果在子线程中处理
}

void ThermalCtl::doDeleteOnvifUser(const QString& name) {
    QString encodedName = QString::fromUtf8(QUrl::toPercentEncoding(name));
    QString url = QString("http://%1/v1/netapp/onvif/del?name=%2").arg(mServerIp).arg(encodedName);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal deleteOnvifUser CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal deleteOnvifUser Response:" << responseData;

        // Check HTTP response code
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            curl_easy_cleanup(curl);
            
            return true;
        } else {
            qCritical() << "thermal deleteOnvifUser failed with HTTP code:" << response_code;
            curl_easy_cleanup(curl);
            
            return false;
        }
    }

    
    return false;
}

QJsonArray ThermalCtl::getOnvifUsers() {
    QString url = QString("http://%1/v1/netapp/onvif/user").arg(mServerIp);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    QJsonArray resultArray;

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal getOnvifUsers CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return resultArray;
        }

        qDebug() << "thermal getOnvifUsers Response:" << responseData;

        // Check HTTP response code
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
            if (!jsonDoc.isNull() && jsonDoc.isArray()) {
                resultArray = jsonDoc.array();
            } else {
                qCritical() << "thermal Failed to parse ONVIF users JSON response.";
            }
        } else {
            qCritical() << "thermal getOnvifUsers failed with HTTP code:" << response_code;
        }

        curl_easy_cleanup(curl);
        
        return resultArray;
    }

    
    return resultArray;
}

QJsonObject ThermalCtl::getGb28181Config(bool defaultConfig) {
    QString url = QString("http://%1/v1/netapp/gb28181").arg(mServerIp);
    
    if (defaultConfig) {
        url += "?default=true";
    }

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    QJsonObject resultObj;

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal getGb28181Config CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        qDebug() << "thermal getGb28181Config Response:" << responseData;

        // Check HTTP response code
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
            if (!jsonDoc.isNull() && jsonDoc.isObject()) {
                resultObj = jsonDoc.object();
            } else {
                qCritical() << "thermal Failed to parse GB28181 config JSON response.";
            }
        } else {
            qCritical() << "thermal getGb28181Config failed with HTTP code:" << response_code;
        }

        curl_easy_cleanup(curl);
        
        return resultObj;
    }

    
    return resultObj;
}

bool ThermalCtl::setGb28181Config(const QJsonObject& gbConfig) {
    // 只发信号，不做耗时工作
    emit setGb28181ConfigRequested(gbConfig);
    return true; // 立即返回，实际结果在子线程中处理
}

void ThermalCtl::doSetGb28181Config(const QJsonObject& gbConfig) {
    QString url = QString("http://%1/v1/netapp/gb28181").arg(mServerIp);

    QJsonDocument doc(gbConfig);
    QString jsonString = doc.toJson(QJsonDocument::Compact);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_POST, 1L);
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal setGb28181Config CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal setGb28181Config Response:" << responseData;

        // Check HTTP response code
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            curl_easy_cleanup(curl);
            
            return true;
        } else {
            qCritical() << "thermal setGb28181Config failed with HTTP code:" << response_code;
            curl_easy_cleanup(curl);
            
            return false;
        }
    }

    
    return false;
}

QString ThermalCtl::encryptPassword(const QString& password) {
    // AES-CBC encryption parameters from API documentation
    const QString keyAndIV = "YJWL202101010000"; // 15 characters as specified in documentation
    QByteArray keyData = keyAndIV.toUtf8();
    
    // Pad key to 16 bytes for AES-128 (add one null byte)
    QByteArray key = keyData;
    key.resize(16); // This will pad with null bytes to reach 16 bytes
    
    // Use same key as IV as specified in documentation
    QByteArray iv = key;
    
    // Convert password to UTF-8 bytes
    QByteArray plaintext = password.toUtf8();
    
    // Initialize OpenSSL
    EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        qCritical() << "Failed to create EVP_CIPHER_CTX";
        return QString();
    }
    
    // Initialize encryption
    if (EVP_EncryptInit_ex(ctx, EVP_aes_128_cbc(), nullptr, 
                          reinterpret_cast<const unsigned char*>(key.constData()),
                          reinterpret_cast<const unsigned char*>(iv.constData())) != 1) {
        qCritical() << "Failed to initialize AES encryption";
        EVP_CIPHER_CTX_free(ctx);
        return QString();
    }
    
    // Enable PKCS7 padding (this is default for EVP_aes_128_cbc)
    EVP_CIPHER_CTX_set_padding(ctx, 1);
    
    // Prepare output buffer
    QByteArray encrypted;
    encrypted.resize(plaintext.size() + AES_BLOCK_SIZE); // Extra space for padding
    
    int outlen1 = 0, outlen2 = 0;
    
    // Encrypt the data
    if (EVP_EncryptUpdate(ctx, reinterpret_cast<unsigned char*>(encrypted.data()), &outlen1,
                         reinterpret_cast<const unsigned char*>(plaintext.constData()),
                         plaintext.size()) != 1) {
        qCritical() << "Failed to encrypt password data";
        EVP_CIPHER_CTX_free(ctx);
        return QString();
    }
    
    // Finalize encryption (adds padding)
    if (EVP_EncryptFinal_ex(ctx, reinterpret_cast<unsigned char*>(encrypted.data()) + outlen1, &outlen2) != 1) {
        qCritical() << "Failed to finalize password encryption";
        EVP_CIPHER_CTX_free(ctx);
        return QString();
    }
    
    // Resize to actual encrypted size
    encrypted.resize(outlen1 + outlen2);
    
    // Clean up
    EVP_CIPHER_CTX_free(ctx);
    
    // Convert to Base64
    QByteArray base64Encoded = encrypted.toBase64();
    
    // Convert to QString and URL encode
    QString base64String = QString::fromUtf8(base64Encoded);
    QByteArray urlEncoded = QUrl::toPercentEncoding(base64String);
    
    qDebug() << "Password encrypted and encoded successfully";
    return QString::fromUtf8(urlEncoded);
}

// Focus Zoom related APIs
QJsonObject ThermalCtl::getFocusZoom(int channel, bool defaultConfig) {
    QString url = QString("http://%1/camera/videoin/thermal/focusZoom?chn=%2").arg(mServerIp).arg(channel);
    
    if (defaultConfig) {
        url += "&default=true";
    }

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    QJsonObject resultObj;

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal getFocusZoom CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        qDebug() << "thermal getFocusZoom Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal getFocusZoom failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return resultObj;
        }

        // Return the actual config data
        resultObj = rootObj.value("Data").toObject();
        
        curl_easy_cleanup(curl);
        
        return resultObj;
    }

    
    return resultObj;
}

bool ThermalCtl::setFocusZoom(int channel, int digitalZoom, bool debug) {
    // 只发信号，不做耗时工作
    emit setFocusZoomRequested(channel, digitalZoom, debug);
    return true; // 立即返回，实际结果在子线程中处理
}

bool ThermalCtl::ptzOperation(int method) {
    // 只发信号，不做耗时工作
    emit ptzOperationRequested(method);
    return true; // 立即返回，实际结果在子线程中处理
}

bool ThermalCtl::ptzStopFocus() {
    // 只发信号，不做耗时工作
    emit ptzStopFocusRequested();
    return true; // 立即返回，实际结果在子线程中处理
}

void ThermalCtl::doSetFocusZoom(int channel, int digitalZoom, bool debug) {
    QString url = QString("http://%1/camera/videoin/thermal/focusZoom?chn=%2&debug=%3")
                  .arg(mServerIp).arg(channel).arg(debug ? "true" : "false");

    // Prepare the JSON request body
    QJsonObject requestBody;
    requestBody["DigitalZoom"] = digitalZoom;

    QJsonDocument doc(requestBody);
    QString jsonString = doc.toJson(QJsonDocument::Compact);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/json");
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());


    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, jsonString.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal setFocusZoom CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            return false;
        }

        qDebug() << "thermal setFocusZoom Response:" << responseData;

        QJsonDocument jsonDoc = QJsonDocument::fromJson(responseData);
        if (jsonDoc.isNull()) {
            qCritical() << "thermal Failed to parse JSON response.";
            curl_easy_cleanup(curl);
            
            return false;
        }

        QJsonObject rootObj = jsonDoc.object();
        int code = rootObj.value("Code").toInt();

        if (code != 200) {
            qCritical() << "thermal setFocusZoom failed. Code:" << code;
            qCritical() << "thermal Message:" << rootObj.value("Message").toString();
            curl_easy_cleanup(curl);
            
            return false;
        }

        curl_easy_cleanup(curl);
        
        return true;
    }

    
    return false;
}

void ThermalCtl::doPtzOperation(int method) {
    QString url = QString("http://%1/v1/ptz/operation?method=%2").arg(mServerIp).arg(method);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());

    curl = curl_easy_init();
    qDebug() << "thermal ptzOperation url:" << url;
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal ptzOperation CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            // 发送设备异常报警 - 网络异常
            addDeviceExceptionAlarm("001", "网络异常", "红外机芯");
            return;
        }

        qDebug() << "thermal ptzOperation Response:" << responseData;

        // 检查HTTP响应码
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            qDebug() << "thermal ptzOperation successful for method:" << method;
            curl_easy_cleanup(curl);
            return;
        } else if (response_code == 400000) {
            qCritical() << "thermal ptzOperation failed with error code 400000 (操作失败)";
            curl_easy_cleanup(curl);
            
            // 发送设备异常报警 - 操作失败
            addDeviceExceptionAlarm("002", "操作失败", "红外机芯");
            return;
        } else {
            qCritical() << "thermal ptzOperation failed with HTTP code:" << response_code;
            curl_easy_cleanup(curl);
            
            // 发送设备异常报警 - 操作失败
            addDeviceExceptionAlarm("002", "操作失败", "红外机芯");
            return;
        }
    }

    curl_easy_cleanup(curl);
}

void ThermalCtl::doPtzStopFocus() {
    QString url = QString("http://%1/v1/ptz/stopfocus").arg(mServerIp);

    CURL* curl;
    CURLcode res;
    QByteArray responseData;

    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, QString("X-Token: %1").arg(mToken).toUtf8().constData());

    curl = curl_easy_init();
    qDebug() << "thermal ptzStopFocus url:" << url;
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, "PUT");
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        curl_easy_setopt(curl, CURLOPT_URL, url.toUtf8().constData());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, ThermalWriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseData);

        res = curl_easy_perform(curl);

        curl_slist_free_all(headers);

        if (res != CURLE_OK) {
            qCritical() << "thermal ptzStopFocus CURL request failed:" << curl_easy_strerror(res);
            curl_easy_cleanup(curl);
            
            // 发送设备异常报警 - 网络异常
            addDeviceExceptionAlarm("001", "网络异常", "红外机芯");
            return;
        }

        qDebug() << "thermal ptzStopFocus Response:" << responseData;

        // 检查HTTP响应码
        long response_code;
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &response_code);
        
        if (response_code == 200) {
            qDebug() << "thermal ptzStopFocus successful";
            curl_easy_cleanup(curl);
            return;
        } else if (response_code == 400000) {
            qCritical() << "thermal ptzStopFocus failed with error code 400000 (操作失败)";
            curl_easy_cleanup(curl);
            
            // 发送设备异常报警 - 操作失败
            addDeviceExceptionAlarm("002", "操作失败", "红外机芯");
            return;
        } else {
            qCritical() << "thermal ptzStopFocus failed with HTTP code:" << response_code;
            curl_easy_cleanup(curl);
            
            // 发送设备异常报警 - 操作失败
            addDeviceExceptionAlarm("002", "操作失败", "红外机芯");
            return;
        }
    }

    curl_easy_cleanup(curl);
}

void ThermalCtl::addDeviceExceptionAlarm(const QString& exceptionCode, const QString& exceptionName, const QString& exceptionComponent)
{
    qWarning() << "Thermal device exception detected:" << exceptionName << "for device" << mDeviceName << "at" << mServerIp;
    qWarning() << "Device ID:" << mDeviceId << "Device Name:" << mDeviceName;
    // 如果设备ID为空，使用设备名称作为设备编号
    //QString deviceIdentifier = mDeviceId.isEmpty() ? mDeviceName : QString("%1(%2)").arg(mDeviceName, mDeviceId);
    // 创建设备异常报警数据
    AlarmData alarmData = {
        DEVICE_FAULT_ALARM,  // 报警模式：设备异常报警
        "",            // 不需要图片
        "",            // 不需要图片
        QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"),
        "", "", "", "",  // 气体报警字段为空，包括距离字段
        mDeviceId,  // 设备编号显示为"设备名称(设备ID)"或仅设备名称
        mDeviceName,  // 设备名称
        exceptionCode,     // 异常类型编号
        exceptionName,     // 异常类型名称
        exceptionComponent // 异常部件
    };
    QMetaObject::invokeMethod(AlarmModel::instance(), [alarmData]() {
        AlarmModel::instance()->addAlarm(alarmData);
    }, Qt::QueuedConnection);
}

ThermalCtl::~ThermalCtl(){
    // Cleanup curl global environment
    curl_global_cleanup();
}

