#include "history_video_player.h"
#include "model/devicemodel.h"
#include "hikvision_ctrl.h"
#include <QDebug>
#include <QDateTime>
#include <QMutexLocker>
#include <QMetaObject>
#include <QThread>
#include <QTimer>

HistoryVideoPlayer::HistoryVideoPlayer(QObject *parent)
    : QObject(parent)
    , m_player(nullptr)
    , m_playerThread(nullptr)
    , m_frameProvider(nullptr)
    , m_isPlaying(false)
    , m_playerReady(false)
    , m_hikvisionCtrl(nullptr)
{
    qDebug() << "HistoryVideoPlayer created in thread:" << QThread::currentThreadId();
    
    // 创建FrameProvider用于视频显示
    m_frameProvider = new FrameProvider(this);
    qDebug() << "HistoryVideoPlayer: Created FrameProvider:" << m_frameProvider;
}

HistoryVideoPlayer::~HistoryVideoPlayer()
{
    qDebug() << "HistoryVideoPlayer destructor called";
    
    // 确保彻底断开所有连接
    disconnectPlayerConnections();
    
    // 停止播放并清理
    stopHistoryVideo();
    
    // 清理FrameProvider
    if (m_frameProvider) {
        m_frameProvider->disconnectAll();
        m_frameProvider->clearFrameData();
        m_frameProvider->deleteLater();
        m_frameProvider = nullptr;
    }
    
    qDebug() << "HistoryVideoPlayer destructor completed";
}

void HistoryVideoPlayer::setHikvisionCtrl(HikvisionCtrl* hikvisionCtrl)
{
    m_hikvisionCtrl = hikvisionCtrl;
    qDebug() << "HikvisionCtrl set for HistoryVideoPlayer";
}

void HistoryVideoPlayer::playHistoryVideo(const QString& deviceCode, const QString& startTime, const QString& endTime, bool isInfraredVideo)
{
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "HistoryVideoPlayer::playHistoryVideo called with:"
             << "deviceCode:" << deviceCode
             << "startTime:" << startTime
             << "endTime:" << endTime
             << "isInfrared:" << isInfraredVideo;
    
    // 确保FrameProvider存在并清理旧数据
    if (!m_frameProvider) {
        qWarning() << "FrameProvider is null, recreating...";
        m_frameProvider = new FrameProvider(this);
        qDebug() << "HistoryVideoPlayer: Recreated FrameProvider:" << m_frameProvider;
    } else {
        // 清理FrameProvider中的旧帧数据，保留连接
        qDebug() << "Clearing FrameProvider data before new video";
        m_frameProvider->clearFrameData();
    }
    
    // 保存当前播放参数
    m_currentDeviceCode = deviceCode;
    m_currentStartTime = startTime;
    m_currentEndTime = endTime;
    m_currentIsInfrared = isInfraredVideo;
    
    // 构建视频URL
    QString videoUrl = buildHistoryVideoUrl(deviceCode, startTime, endTime, isInfraredVideo);
    if (videoUrl.isEmpty()) {
        qWarning() << "Failed to build video URL for history video";
        emit playbackError("无法构建视频地址");
        return;
    }
    
    qDebug() << "Built history video URL:" << videoUrl;
    
    // 初始化播放器（仅首次创建）
    initializePlayer();
    
    if (!m_player) {
        qWarning() << "Failed to initialize player";
        emit playbackError("播放器初始化失败");
        return;
    }
    
    if (!m_playerReady) {
        // 首次准备
        QMetaObject::invokeMethod(m_player, "prepare", Qt::QueuedConnection, Q_ARG(QString, videoUrl));
        // 延迟启动播放，等待prepare完成
        QTimer::singleShot(300, [this]() {
            if (m_player) {
                QMetaObject::invokeMethod(m_player, "play", Qt::QueuedConnection);
                qDebug() << "HistoryVideoPlayer: Started playback after initial prepare";
            }
        });
        m_playerReady = true;
    } else {
        // 已准备过，快速切换URL
        QMetaObject::invokeMethod(m_player, "fastSwitchUrl", Qt::QueuedConnection, Q_ARG(QString, videoUrl));
        // 恢复播放（如被暂停）
        QTimer::singleShot(100, [this]() {
            if (m_player) {
                QMetaObject::invokeMethod(m_player, "play", Qt::QueuedConnection);
            }
        });
    }
    
    m_isPlaying = true;
    emit playbackStarted();
    
    qDebug() << "History video playback started";
}

void HistoryVideoPlayer::stopHistoryVideo()
{
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "HistoryVideoPlayer::stopHistoryVideo called -> pause";
    
    if (!m_player) {
        m_isPlaying = false;
        emit playbackStopped();
        return;
    }
    
    // 不销毁播放器，仅暂停
    QMetaObject::invokeMethod(m_player, "pause", Qt::QueuedConnection);
    m_isPlaying = false;
    emit playbackStopped();
}

void HistoryVideoPlayer::pauseHistoryVideo()
{
    QMutexLocker locker(&m_mutex);
    if (!m_player) return;
    qDebug() << "HistoryVideoPlayer::pauseHistoryVideo";
    QMetaObject::invokeMethod(m_player, "pause", Qt::QueuedConnection);
    m_isPlaying = false;
}

void HistoryVideoPlayer::resumeHistoryVideo()
{
    QMutexLocker locker(&m_mutex);
    if (!m_player) return;
    qDebug() << "HistoryVideoPlayer::resumeHistoryVideo";
    QMetaObject::invokeMethod(m_player, "play", Qt::QueuedConnection);
    m_isPlaying = true;
}

void HistoryVideoPlayer::fastSwitchHistoryVideo(const QString& deviceCode, const QString& startTime, const QString& endTime, bool isInfraredVideo)
{
    QMutexLocker locker(&m_mutex);
    if (!m_player) {
        playHistoryVideo(deviceCode, startTime, endTime, isInfraredVideo);
        return;
    }
    
    m_currentDeviceCode = deviceCode;
    m_currentStartTime = startTime;
    m_currentEndTime = endTime;
    m_currentIsInfrared = isInfraredVideo;
    
    QString videoUrl = buildHistoryVideoUrl(deviceCode, startTime, endTime, isInfraredVideo);
    if (videoUrl.isEmpty()) {
        qWarning() << "Failed to build video URL for fast switch";
        emit playbackError("无法构建视频地址");
        return;
    }
    qDebug() << "Fast switching to URL:" << videoUrl;
    QMetaObject::invokeMethod(m_player, "fastSwitchUrl", Qt::QueuedConnection, Q_ARG(QString, videoUrl));
    
    // 确保在URL切换完成后启动播放
    QTimer::singleShot(600, [this]() {
        if (m_player) {
            qDebug() << "HistoryVideoPlayer: Ensuring playback after fast switch";
            QMetaObject::invokeMethod(m_player, "play", Qt::QueuedConnection);
        }
    });
    
    // 延迟发出播放开始信号，确保播放器真正开始播放
    QTimer::singleShot(800, [this]() {
        if (m_isPlaying) {
            qDebug() << "HistoryVideoPlayer: Emitting playbackStarted after fast switch";
            emit playbackStarted();
        }
    });
    
    m_isPlaying = true;
}

bool HistoryVideoPlayer::isPlaying() const
{
    QMutexLocker locker(&m_mutex);
    return m_isPlaying;
}

FrameProvider* HistoryVideoPlayer::getFrameProvider() const
{
    qDebug() << "HistoryVideoPlayer::getFrameProvider called, m_frameProvider:" << m_frameProvider;
    return m_frameProvider;
}

void HistoryVideoPlayer::initializePlayer()
{
    qDebug() << "HistoryVideoPlayer::initializePlayer called";
    
    if (m_player && m_playerThread) {
        qDebug() << "Reusing existing player/thread";
        return;
    }
    
    // 创建播放器线程（仅一次）
    m_playerThread = new QThread();
    m_player = new splayer();
    
    // 将播放器移到子线程
    m_player->moveToThread(m_playerThread);
    
    // 设置线程清理
    connect(m_playerThread, &QThread::finished, m_player, &QObject::deleteLater);
    connect(m_playerThread, &QThread::finished, m_playerThread, &QThread::deleteLater);
    
    // 连接播放器信号
    setupPlayerConnections();
    
    // 启动线程
    m_playerThread->start();
    
    qDebug() << "Player thread started with ID:" << m_playerThread;
}

void HistoryVideoPlayer::cleanupPlayer()
{
    qDebug() << "HistoryVideoPlayer::cleanupPlayer called";
    
    if (m_player) {
        // 确保断开所有连接
        disconnectPlayerConnections();
        
        // 停止播放器
        QMetaObject::invokeMethod(m_player, "stop", Qt::QueuedConnection);
        
        // 等待播放器停止，但不要在同一线程中等待
        if (m_playerThread && m_playerThread->isRunning()) {
            QMetaObject::invokeMethod(m_playerThread, "quit", Qt::QueuedConnection);
        }
        
        m_player = nullptr;
        m_playerThread = nullptr;
        m_playerReady = false;
    }
    
    qDebug() << "Player cleanup completed";
}

QString HistoryVideoPlayer::buildHistoryVideoUrl(const QString& deviceCode, const QString& startTime, const QString& endTime, bool isInfraredVideo)
{
    qDebug() << "Building history video URL for device:" << deviceCode;
    
    // 通过deviceCode找到设备信息
    DeviceModel* deviceModel = DeviceModel::instance();
    DeviceInfo deviceInfo = deviceModel->getDevice(deviceCode);
    
    if (deviceInfo.deviceId.isEmpty()) {
        qWarning() << "Device not found:" << deviceCode;
        return QString();
    }
    
    // 获取录像URL基础部分
    QString recordUrlBase = deviceInfo.recordUrlbase;
    if (recordUrlBase.isEmpty()) {
        qWarning() << "Record URL base is empty for device:" << deviceCode;
        return QString();
    }
    
    // 使用HikvisionCtrl查找通道号
    int downloadChannel = -1;
    if (m_hikvisionCtrl) {
        QString nvrIp, nvrUsername, nvrPassword, ipcIp;
        int nvrPort = 8000;
        
        nvrIp = deviceInfo.hikvisionIp;
        nvrUsername = deviceInfo.hikvisionUsername;
        nvrPassword = deviceInfo.hikvisionPassword;
        if (isInfraredVideo) {
            ipcIp = deviceInfo.infraredIp; // 如果是直连IPC，使用相同IP
        } else {
            ipcIp = deviceInfo.visibleLightIp; // 如果是直连IPC，使用相同IP
        }
        
        qDebug() << "Finding channel using HikvisionCtrl for NVR:" << nvrIp << "IPC:" << ipcIp;
        
        // 调用HikvisionCtrl查找通道号
        downloadChannel = m_hikvisionCtrl->findChannelByIP(nvrIp, nvrPort, nvrUsername, nvrPassword, ipcIp);
        
        if (downloadChannel <= 0) {
            qWarning() << "Failed to find channel via HikvisionCtrl, falling back to device config";
            // 如果查找失败，回退到设备配置中的通道号
            downloadChannel = isInfraredVideo ? deviceInfo.infraredDownloadChannel : deviceInfo.visibleLightDownloadChannel;
        } else {
            qDebug() << "Found channel via HikvisionCtrl:" << downloadChannel;
        }
    } else {
        qWarning() << "HikvisionCtrl not available, using device config channel";
        // 如果HikvisionCtrl不可用，使用设备配置中的通道号
        downloadChannel = isInfraredVideo ? deviceInfo.infraredDownloadChannel : deviceInfo.visibleLightDownloadChannel;
    }
    
    // 计算通道追踪号 (tracks后面的通道号)
    int trackChannel;
    if (downloadChannel > 32) {
        // 对于IP通道 (通常>32)
        trackChannel = (downloadChannel - 32) * 100 + 1;
    } else {
        // 对于模拟通道 (通常<=32)
        trackChannel = downloadChannel * 100 + 1;
    }
    
    qDebug() << "Download channel:" << downloadChannel << "Track channel:" << trackChannel;
    
    // 格式化开始和结束时间
    QString formattedStartTime = formatHistoryTime(startTime);
    QString formattedEndTime = formatHistoryTime(endTime);
    
    if (formattedStartTime.isEmpty() || formattedEndTime.isEmpty()) {
        qWarning() << "Failed to format time strings";
        return QString();
    }
    
    qDebug() << "Start time:" << startTime << "->" << formattedStartTime;
    qDebug() << "End time:" << endTime << "->" << formattedEndTime;
    
    // 构建完整的URL
    // 格式: recordUrlbase/trackChannel/?starttime=...&endtime=...
    QString videoUrl = QString("%1/%2/?starttime=%3&endtime=%4")
                          .arg(recordUrlBase)
                          .arg(trackChannel)
                          .arg(formattedStartTime)
                          .arg(formattedEndTime);
    
    qDebug() << "Built history video URL:" << videoUrl;
    return videoUrl;
}

QString HistoryVideoPlayer::formatHistoryTime(const QString& timeStr)
{
    // 输入格式: "HH:mm" 或 "yyyy-MM-dd HH:mm:ss"
    // 输出格式: "yyyyMMddThhmmssZ"
    
    QDateTime dateTime;
    
    // 尝试解析完整的时间格式
    if (timeStr.contains("-")) {
        // 完整日期时间格式: "yyyy-MM-dd HH:mm:ss"
        dateTime = QDateTime::fromString(timeStr, "yyyy-MM-dd HH:mm:ss");
    } else {
        // 只有时间格式: "HH:mm"，需要结合当前日期
        QTime time = QTime::fromString(timeStr, "HH:mm");
        if (time.isValid()) {
            dateTime = QDateTime::currentDateTime();
            dateTime.setTime(time);
        }
    }
    
    if (!dateTime.isValid()) {
        qWarning() << "Invalid time format:" << timeStr;
        return QString();
    }
    
    // 保持本地时间，不转换为UTC
    // 海康威视设备通常使用本地时间进行录像检索
    return dateTime.toString("yyyyMMddThhmmssZ");
}

void HistoryVideoPlayer::setupPlayerConnections()
{
    if (!m_player) {
        return;
    }
    
    // 连接新帧信号到FrameProvider
    connect(m_player, &splayer::newFrameAvailable,
            this, &HistoryVideoPlayer::onPlayerNewFrame,
            Qt::QueuedConnection);
    
    qDebug() << "Player connections established";
}

void HistoryVideoPlayer::disconnectPlayerConnections()
{
    if (!m_player) {
        return;
    }
    
    qDebug() << "HistoryVideoPlayer::disconnectPlayerConnections called";
    
    // 断开播放器与当前对象的所有连接
    disconnect(m_player, &splayer::newFrameAvailable,
               this, &HistoryVideoPlayer::onPlayerNewFrame);
    
    qDebug() << "Player connections disconnected";
}

void HistoryVideoPlayer::onPlayerNewFrame(const QVideoFrame& frame)
{
    static int frameCount = 0;
    frameCount++;
    
    // 每10帧打印一次，避免日志过多
    // if (frameCount % 10 == 1) {
    //     qDebug() << "HistoryVideoPlayer::onPlayerNewFrame #" << frameCount << "frame:" 
    //              << "width=" << frame.width() 
    //              << "height=" << frame.height() 
    //              << "valid=" << frame.isValid()
    //              << "pixelFormat=" << frame.pixelFormat();
    // }
    
    // 将新帧传递给FrameProvider显示
    if (m_frameProvider) {
        if (frameCount % 10 == 1) {
            qDebug() << "Forwarding frame to FrameProvider:" << m_frameProvider;
        }
        // 直接调用而不使用QMetaObject::invokeMethod
        m_frameProvider->onNewVideoContentReceived(frame);
    } else {
        qWarning() << "FrameProvider is null, cannot display frame";
    }
}

void HistoryVideoPlayer::handlePlayerError()
{
    qWarning() << "Player error occurred";
    
    QMutexLocker locker(&m_mutex);
    if (m_isPlaying) {
        m_isPlaying = false;
        emit playbackError("播放器发生错误");
        
        // 清理播放器
        locker.unlock();
        cleanupPlayer();
    }
} 