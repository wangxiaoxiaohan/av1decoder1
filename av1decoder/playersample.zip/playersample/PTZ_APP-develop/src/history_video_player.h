#ifndef HISTORYVIDEOPLAYER_H
#define HISTORYVIDEOPLAYER_H

#include <QObject>
#include <QQmlEngine>
#include <QDateTime>
#include <QString>
#include <QThread>
#include <QMutex>
#include <QPointer>
#include <QTimer>
#include "player.h"
#include "frame_provider.h"

// 前向声明
class HikvisionCtrl;

class HistoryVideoPlayer : public QObject
{
    Q_OBJECT
    QML_ELEMENT

public:
    explicit HistoryVideoPlayer(QObject *parent = nullptr);
    ~HistoryVideoPlayer();

    // QML可调用的方法
    Q_INVOKABLE void playHistoryVideo(const QString& deviceCode, const QString& startTime, const QString& endTime, bool isInfraredVideo);
    Q_INVOKABLE void stopHistoryVideo();
    Q_INVOKABLE bool isPlaying() const;
    Q_INVOKABLE FrameProvider* getFrameProvider() const;
    
    // 设置HikvisionCtrl实例
    void setHikvisionCtrl(HikvisionCtrl* hikvisionCtrl);

    // 暂停/恢复/快速切换
    Q_INVOKABLE void pauseHistoryVideo();
    Q_INVOKABLE void resumeHistoryVideo();
    Q_INVOKABLE void fastSwitchHistoryVideo(const QString& deviceCode, const QString& startTime, const QString& endTime, bool isInfraredVideo);

signals:
    void playbackStarted();
    void playbackStopped();
    void playbackError(const QString& errorMessage);

private slots:
    void onPlayerNewFrame(const QVideoFrame& frame);
    void handlePlayerError();

private:
    void initializePlayer();
    void cleanupPlayer();
    QString buildHistoryVideoUrl(const QString& deviceCode, const QString& startTime, const QString& endTime, bool isInfraredVideo);
    QString formatHistoryTime(const QString& timeStr);
    void setupPlayerConnections();
    void disconnectPlayerConnections();
    
    QPointer<splayer> m_player;
    QPointer<QThread> m_playerThread;
    QPointer<FrameProvider> m_frameProvider;
    
    bool m_isPlaying;
    bool m_playerReady;
    mutable QMutex m_mutex;
    
    // 当前播放参数（用于错误恢复）
    QString m_currentDeviceCode;
    QString m_currentStartTime;
    QString m_currentEndTime;
    bool m_currentIsInfrared;
    
    QPointer<HikvisionCtrl> m_hikvisionCtrl;
};

#endif // HISTORYVIDEOPLAYER_H 