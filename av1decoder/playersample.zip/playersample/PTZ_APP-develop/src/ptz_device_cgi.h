#ifndef PTZ_APP_PTZ_DEVICE_CGI_H
#define PTZ_APP_PTZ_DEVICE_CGI_H

#include <QObject>
#include <string>
#include <QThread>
#include <QTimer>
#include <atomic>
#include <mutex>
#include <vector>
#include <QMap>
#include <QMutex>
#include "src/model/devicemodel.h"

#ifdef _WIN32
#include <winsock2.h>
#endif

// 前向声明
class FrameProvider;
class TdlasWorker;
class ModbusWorker;
class TOFWorker;

// 网络连接互斥管理器
class NetworkConnectionManager : public QObject
{
    Q_OBJECT

public:
    static NetworkConnectionManager* instance();
    
    // 获取网络连接锁
    bool acquireConnectionLock(const QString& ip, int port, const QString& workerType);
    
    // 释放网络连接锁
    void releaseConnectionLock(const QString& ip, int port, const QString& workerType);
    
    // 检查是否可以获取连接锁
    bool canAcquireConnectionLock(const QString& ip, int port, const QString& workerType);

private:
    explicit NetworkConnectionManager(QObject* parent = nullptr);
    ~NetworkConnectionManager();
    
    static NetworkConnectionManager* m_instance;
    QMutex m_mutex;
    QMap<QString, QString> m_activeConnections; // key: "ip:port", value: workerType
};

struct ScanGroupInfo{
    int cruise;
    int line;
    int track;
};


class PtzDeviceCgi : public QObject{
Q_OBJECT

    // 添加气体浓度报警状态属性
    Q_PROPERTY(bool gasConcentrationAlarm READ gasConcentrationAlarm NOTIFY gasConcentrationAlarmChanged)

public:
    explicit PtzDeviceCgi(QObject* parent = nullptr);
    virtual ~PtzDeviceCgi();

    // Q_PROPERTY getter
    bool gasConcentrationAlarm() const;
    // 移除单例方法，改为普通实例化
    // Q_INVOKABLE static PtzDeviceCgi& moGetInstance();
    Q_INVOKABLE void mvInit(QString user, QString passwd, QString ip, QString deviceName = QString(), QString deviceId = QString());

    // 设置帧提供者的方法
    Q_INVOKABLE void setFrameProviders(FrameProvider* visibleLight, FrameProvider* infrared);
    
    // 初始化TDLAS工作器的方法
    void initializeTdlasWorker(const QString& ip, int port);
    
    // 初始化Modbus工作器的方法
    void initializeModbusWorker(const QString& ip, int port);
    Q_INVOKABLE void initializeModbusWorkerFromDevice(const QString& deviceId);
    
    // Modbus相关方法
    Q_INVOKABLE void mvSetVoltage(float value); // 设置电压值（mA）
    Q_INVOKABLE bool mvSendModbusData(const QString& ip, int port, const QVariantList& data);

    // 初始化TOF工作器的方法
    void initializeTofWorker(const QString& ip, int port);
    Q_INVOKABLE void initializeTofWorkerFromDevice(const QString& deviceId);
    
    // TOF相关方法
    Q_INVOKABLE void mvSendSingleRangingCmd();
    Q_INVOKABLE void mvSendContinuousRangingCmd();
    Q_INVOKABLE void mvSendStopRangingCmd();


    Q_INVOKABLE void mvSetDeviceId(std::string var){
        device_id_ = var;
    }

    Q_INVOKABLE std::string msGetDeviceId(){
        return device_id_;
    }

    Q_INVOKABLE void mvSetDeviceName(std::string var){
        deviceName_ = var;
    }
    Q_INVOKABLE std::string msGetDeviceName(){
        return deviceName_;
    }

    Q_INVOKABLE void mvSetWhiteVideoUrl(std::string var){
        white_video_url_ = var;
    }

    Q_INVOKABLE void mvSetInfVideoUrl(std::string var){
        inf_video_url_ = var;
    }

    Q_INVOKABLE std::string msGetWhiteVideoUrl(){
        return white_video_url_;
    }

    Q_INVOKABLE std::string msGetInfVideoUrl(){
        return inf_video_url_;
    }

    Q_INVOKABLE void mvKeepAlive();


    Q_INVOKABLE int mvFreshTdlasWarning();
    //"brightness": 9,
    //"contrast": 9,
    //"saturation": 9,
    //"sharpness": 9,
    //"hlc": 8, r
    //"blc": 8,
    //"nr2d": 8,
    //"nr3d": 8,
    //"tvsystem": 50,
    //"antificker": 0
    Q_INVOKABLE void mvModifyImageSettings(int bright, int contrac, int saturation, int sharpness, int hlc, int blc, int nr2d, int nr3d, int tvsystem, int antificker);

    Q_INVOKABLE void mvModifyOverlapString(bool enable_1, QString str_1, bool enable_2, QString str_2, bool enable_3, QString str_3, bool enable_4, QString str_4);
    //  "encode_mode": "H264",
    //  "resolution": "1080P",
    //  "framerate": "27",
    //  "govlength": "104",
    //  "bitrate": "3000",
    //  "bitrate_control": "VBR"
    Q_INVOKABLE void mvModifyVideoSettings(QString encode_mode, QString resolution, QString framerate, QString govlength, QString bitrate, QString bitrate_control, int index);
    //	"enable": "1",
    //	"encode_type": "G.711",
    //	"samplerate": "8000",
    //	"bitrate": "64000",
    //	"input_volume": "80",
    //	"output_volume": "99",
    //	"amplify": "1"
    Q_INVOKABLE void mvModifyAudioSettings(bool enable_1, QString encode_type, QString samplerate, QString bitrate, QString input_volume, QString output_volume, QString amplify);
    //	"dhcp": "0",
    //	"ipaddr": "192.168.2.160",
    //	"netmask": "255.255.255.0",
    //	"gateway": "192.168.2.1",
    //	"dns1": "114.114.114.114",
    //	"dns2": "192.168.2.1",
    //	"port": "80"
    Q_INVOKABLE void mvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway, QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns, QString dns);

    Q_INVOKABLE void mvTurnUp();
    Q_INVOKABLE void mvTurnDown();

    Q_INVOKABLE void mvTurnLeft();

    Q_INVOKABLE void mvTurnRight();

    Q_INVOKABLE void mvTurnStop();
    Q_INVOKABLE void mvSetTurnSpeed(int speed);

    Q_INVOKABLE void mvSetZoomIn(int val);
    Q_INVOKABLE void mvSetFocus(int val);
    Q_INVOKABLE void mvSetAperture(int val);

    Q_INVOKABLE void mvSetPreset(int id);
    Q_INVOKABLE void mvSetLinePreset(int id);
    Q_INVOKABLE void mvCallPreset(int id);
    Q_INVOKABLE void mvDeletePreset(int id);

    Q_INVOKABLE void mvSetCruiseScan();
    Q_INVOKABLE void mvSetCruiseScan(const QString &cruiseNumber, const QVariantList &presetPoints);

    Q_INVOKABLE void mvSetTrackScan();
    Q_INVOKABLE void mvSetLineScan();

    Q_INVOKABLE void mvSetLight(bool val);
    Q_INVOKABLE void mvSetWiper(bool val);
    Q_INVOKABLE void mvSetAssiFocus(bool val);
    Q_INVOKABLE void mvSetInfFlap(bool val);
    
    // 重启云台功能
    Q_INVOKABLE bool mvReboot();
    
    // 恢复出厂设置功能
    Q_INVOKABLE bool mvFactoryReset(bool retain_network);

    // OSD配置相关函数
    Q_INVOKABLE void ConfigMainOSD(QString enable, QString title);
    Q_INVOKABLE void mvConfigOSD(int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8);
    Q_INVOKABLE void mvConfigTimeOSD(int enable, int show_week, QString time_format, int title_pos_x, int title_pos_y);
    Q_INVOKABLE void mvConfigUserOSD(int title_index, int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8);
    
    Q_INVOKABLE QVariantMap mvGetVideoEncoderCapabilities(int streamIndex);
    Q_INVOKABLE QVariantMap mvGetAudioEncoderCapabilities();

    // 移动侦测配置接口
    Q_INVOKABLE bool mvConfigMotionDetect(bool enable, int sensitivity = 80, int alarmThreshold = 20, 
                                         bool enableNighttime = false, int nightSensitivity = 80, 
                                         int nightAlarmThreshold = 20, QString blockCount = "22x18", 
                                         QString areaValue = "");
                                         
    // 获取当前移动侦测配置
    Q_INVOKABLE QVariantMap mvGetMotionDetectConfig();

    // 配置事件存储设置
    Q_INVOKABLE bool mvConfigEventStorage(bool trigger_recording, int stream, bool record_ftp_upload, 
                                        bool record_email_upload, bool trigger_capture,
                                        bool capture_ftp_upload, bool capture_email_upload,
                                        bool capture_motionDetectAlarm);

    // 获取当前事件存储配置
    Q_INVOKABLE QVariantMap mvGetEventStorageConfig();

    // 获取录像文件路径
    Q_INVOKABLE QString mvGetRecordFilePath(int year, int month, int day, int start_hour, int start_min, int end_hour, int end_min);
    
    // Service port configuration
    Q_INVOKABLE bool mvConfigServicePorts(bool enable_web, bool enable_control, bool enable_rtsp, bool enable_hik,
                                         int webport, int controlport, int rtspport, int hikport);

    // Specific port setting APIs
    Q_INVOKABLE bool mvSetRtspPort(int rtspport);
    Q_INVOKABLE bool mvSetHttpPort(int httpport);

    // 配置计划存储/录像功能
    Q_INVOKABLE bool mvConfigScheduleStorage(bool localEnable, bool remoteEnable, 
                                           int recordFileSize, QString remote_nfs_server,
                                           QString nfs_server_path, int stream,
                                           int jpeginterval, bool enable);
                                           

    Q_INVOKABLE  QList<int> getConcetList(){return concet_list_;}
    //Q_INVOKABLE  QList<AlarmData> getConcetAlarmList(){return concet_alarm_list_;}

    // Snapshot upload function
    Q_INVOKABLE bool mvSnapshotUpload(int stream, int upload_type);

    // 设备异常报警方法
public slots:
    void addDeviceExceptionAlarm(const QString& exceptionCode, const QString& exceptionName, const QString& exceptionComponent);

signals:
    void mvKeepAliveRequested();
    void mvModifyImageSettingsRequested(int bright, int contrac, int saturation, int sharpness, int hlc, int blc, int nr2d, int nr3d, int tvsystem, int antificker);
    void mvModifyVideoSettingsRequested(QString encode_mode, QString resolution, QString framerate, QString govlength, QString bitrate, QString bitrate_control, int index);
    void mvModifyAudioSettingsRequested(bool enable_1, QString encode_type, QString samplerate, QString bitrate, QString input_volume, QString output_volume, QString amplify);
    void mvModifyLocalNetworkPropertyRequested(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway, QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns, QString dns);
    void mvRebootRequested();
    void mvFactoryResetRequested(bool retain_network);
    void ConfigMainOSDRequested(QString enable, QString title);
    void mvConfigOSDRequested(int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8);
    void mvConfigTimeOSDRequested(int enable, int show_week, QString time_format, int title_pos_x, int title_pos_y);
    void mvConfigUserOSDRequested(int title_index, int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8);
    void mvConfigMotionDetectRequested(bool enable, int sensitivity, int alarmThreshold, bool enableNighttime, int nightSensitivity, int nightAlarmThreshold, QString blockCount, QString areaValue);
    void mvConfigEventStorageRequested(bool trigger_recording, int stream, bool record_ftp_upload, bool record_email_upload, bool trigger_capture, bool capture_ftp_upload, bool capture_email_upload, bool capture_motionDetectAlarm);
    void mvConfigServicePortsRequested(bool enable_web, bool enable_control, bool enable_rtsp, bool enable_hik, int webport, int controlport, int rtspport, int hikport);
    void mvSetRtspPortRequested(int rtspport);
    void mvSetHttpPortRequested(int httpport);
    void mvConfigScheduleStorageRequested(bool localEnable, bool remoteEnable, int recordFileSize, QString remote_nfs_server, QString nfs_server_path, int stream, int jpeginterval, bool enable);
    void mvSnapshotUploadRequested(int stream, int upload_type);
    void mvInitRequested(QString user, QString passwd, QString ip, QString deviceName, QString deviceId);
    void mvGetVideoEncoderCapabilitiesRequested(int streamIndex);
    void mvGetAudioEncoderCapabilitiesRequested();
    void mvGetMotionDetectConfigRequested();
    void mvGetEventStorageConfigRequested();
    void mvGetRecordFilePathRequested(int year, int month, int day, int start_hour, int start_min, int end_hour, int end_min);
    void mvSetLightRequested(bool val);
    void mvSetWiperRequested(bool val);
    void mvSetAssiFocusRequested(bool val);
    void mvSetInfFlapRequested(bool val);
    void mvTurnUpRequested();
    void mvTurnDownRequested();
    void mvTurnLeftRequested();
    void mvTurnRightRequested();
    void mvTurnStopRequested();
    void mvSetZoomInRequested(int val);
    void mvSetFocusRequested(int val);
    void mvSetApertureRequested(int val);
    void mvSetPresetRequested(int id);
    void mvCallPresetRequested(int id);
    void mvDeletePresetRequested(int id);
    void gasConcentrationAlarmChanged(bool alarm, QString deviceId);
    void tofDistanceUpdated(QString deviceId, float distance);
    void tofRangingError(QString deviceId, QString errorMessage);

    // 新增的信号，用于在 PtzDeviceCgi 自己的线程中触发 Worker 的实际初始化
    void initializeTdlasWorkerInternalRequested(const QString& ip, int port);
    void initializeModbusWorkerInternalRequested(const QString& ip, int port);
    void initializeTofWorkerInternalRequested(const QString& ip, int port);

private slots:
    void doMvKeepAlive();
    void doMvModifyImageSettings(int bright, int contrac, int saturation, int sharpness, int hlc, int blc, int nr2d, int nr3d, int tvsystem, int antificker);
    void doMvModifyVideoSettings(QString encode_mode, QString resolution, QString framerate, QString govlength, QString bitrate, QString bitrate_control, int index);
    void doMvModifyAudioSettings(bool enable_1, QString encode_type, QString samplerate, QString bitrate, QString input_volume, QString output_volume, QString amplify);
    void doMvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway, QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns, QString dns);
    void doMvReboot();
    void doMvFactoryReset(bool retain_network);
    void doConfigMainOSD(QString enable, QString title);
    void doMvConfigOSD(int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8);
    void doMvConfigTimeOSD(int enable, int show_week, QString time_format, int title_pos_x, int title_pos_y);
    void doMvConfigUserOSD(int title_index, int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8);
    void doMvConfigMotionDetect(bool enable, int sensitivity, int alarmThreshold, bool enableNighttime, int nightSensitivity, int nightAlarmThreshold, QString blockCount, QString areaValue);
    void doMvConfigEventStorage(bool trigger_recording, int stream, bool record_ftp_upload, bool record_email_upload, bool trigger_capture, bool capture_ftp_upload, bool capture_email_upload, bool capture_motionDetectAlarm);
    void doMvConfigServicePorts(bool enable_web, bool enable_control, bool enable_rtsp, bool enable_hik, int webport, int controlport, int rtspport, int hikport);
    void doMvSetRtspPort(int rtspport);
    void doMvSetHttpPort(int httpport);
    void doMvConfigScheduleStorage(bool localEnable, bool remoteEnable, int recordFileSize, QString remote_nfs_server, QString nfs_server_path, int stream, int jpeginterval, bool enable);
    void doMvSnapshotUpload(int stream, int upload_type);
    void doMvInit(QString user, QString passwd, QString ip, QString deviceName, QString deviceId);
    void doMvGetVideoEncoderCapabilities(int streamIndex);
    void doMvGetAudioEncoderCapabilities();
    void doMvGetMotionDetectConfig();
    void doMvGetEventStorageConfig();
    void doMvGetRecordFilePath(int year, int month, int day, int start_hour, int start_min, int end_hour, int end_min);
    void doMvSetLight(bool val);
    void doMvSetWiper(bool val);
    void doMvSetAssiFocus(bool val);
    void doMvSetInfFlap(bool val);
    void doMvTurnUp();
    void doMvTurnDown();
    void doMvTurnLeft();
    void doMvTurnRight();
    void doMvTurnStop();
    void doMvSetZoomIn(int val);
    void doMvSetFocus(int val);
    void doMvSetAperture(int val);
    void doMvSetPreset(int id);
    void doMvCallPreset(int id);
    void doMvDeletePreset(int id);
    void onConcentrationUpdated(int value);

    // 新增的私有槽函数，它们将在 PtzDeviceCgi 所属的线程中执行 Worker 的创建
    void doInitializeTdlasWorkerInternal(const QString& ip, int port);
    void doInitializeModbusWorkerInternal(const QString& ip, int intPort); // 注意这里参数名避免与内部成员冲突
    void doInitializeTofWorkerInternal(const QString& ip, int intPort); // 注意这里参数名避免与内部成员冲突

private:
    // 浓度值到电流值的映射函数
    float mapConcentrationToCurrent(int concentration);

    // 巡航控制辅助方法
    void startCruiseWithPoints(const QVector<int>& points);
    void stopCruise();
    void resumeCruiseIfPaused();
    bool isCruising() const { return m_cruiseActive; }
    
    QThread* m_tdlasThread;
    TdlasWorker* m_tdlasWorker;
    QThread* m_modbusThread;
    ModbusWorker* m_modbusWorker;
    QThread* m_tofThread;
    TOFWorker* m_tofWorker;
    std::string deviceName_;
    std::string device_id_;
    std::string white_video_url_;
    std::string inf_video_url_;
    int concet_;
    bool m_gasConcentrationAlarm;  // 缓存报警状态
    std::string user_;
    std::string passwd_;
    std::string uid_;
    std::string ip_;
    std::string tdls_ip_;
    int tdls_port_;
    std::string modbus_ip_;
    int modbus_port_;
    std::string tof_ip_;
    int tof_port_;
    float m_currentTofDistance;  // 当前TOF距离
    QList<int> concet_list_ ;
    QVector<QVector<int>> presetGroups;
    QVector<QVector<int>> LinePresetGroups;
    int turn_speed_;
    ScanGroupInfo groupInfo;
    QTimer *scanTimer;
    int line_direction;
    int presetIdx;
    
    // 帧提供者指针
    FrameProvider* m_visibleLightProvider;
    FrameProvider* m_infraredProvider;

    // 巡航状态
    QVector<int> m_currentCruisePoints;
    bool m_cruiseActive = false;
    bool m_cruisePausedDueToAlarm = false;

};

class TdlasWorker : public QObject
{
    Q_OBJECT

public:
    TdlasWorker(QString ip, int port, QObject *parent = nullptr);
    ~TdlasWorker();

public slots:
    void process();
    void stop();

signals:
    void concentrationUpdated(int value);
    void finished();
    void rangingError(QString errorMessage); // Add this line

private:
    int connectToServe(const std::string& address, int port);
    std::vector<uint8_t> hexDecode(const std::string& hexString);
    bool SendData(SOCKET sockfd, const std::string& hexString);
    void receivadata(SOCKET sockfd);
    void turnonlaser(SOCKET sockfd);
    void turnofflaser(SOCKET sockfd);


    QString m_ip;
    int m_port;
    std::atomic<bool> m_stopped;
    SOCKET m_sockfd;
    std::mutex m_mutex;
};

class ModbusWorker : public QObject
{
    Q_OBJECT

public:
    // 明确接收 PtzDeviceCgi* 指针用于内部成员，QObject 的父对象仍然可以是 nullptr
    ModbusWorker(QString ip, int port, PtzDeviceCgi* ptzCgiParent, QObject* parent = nullptr);
    ~ModbusWorker();

public slots:
    void process();
    void stop();
    void sendVoltageData(float value);

public:
    // 将sendDataOverTCP移到public部分以便外部调用
    bool sendDataOverTCP(const char* ip, int port, const std::vector<unsigned char>& data);

signals:
    void voltageDataSent(bool success);
    void finished();

private:
    // CRC高位字节表
    static const unsigned char auchCRCHi[256];
    // CRC低位字节表
    static const unsigned char auchCRCLo[256];
    
    unsigned short ModBusCRC16(const unsigned char* puchMsg, unsigned short usDataLen);
    std::vector<unsigned char> setVoltage(float value); // 输入为mA

    QString m_ip;
    int m_port;
    std::atomic<bool> m_isRunning;
    std::mutex m_mutex;
    PtzDeviceCgi* m_parent; // 添加父对象引用

public:
    // Getter方法
    QString getIp() const { return m_ip; }
    int getPort() const { return m_port; }
};

class TOFWorker : public QObject
{
    Q_OBJECT

public:
    // 明确接收 PtzDeviceCgi* 指针用于内部成员，QObject 的父对象仍然可以是 nullptr
    TOFWorker(QString ip, int port, PtzDeviceCgi* ptzCgiParent, QObject* parent = nullptr);
    ~TOFWorker();

public slots:
    void process();
    void stop();
    void sendSingleRangingCmd();
    void sendContinuousRangingCmd();
    void sendStopRangingCmd();
    void startContinuousRanging();

signals:
    void distanceUpdated(float distance);
    void rangingError(QString errorMessage);
    void finished();

private:
    std::vector<unsigned char> createSingleRangingCmd();
    std::vector<unsigned char> createContinuousRangingCmd();
    std::vector<unsigned char> createStopRangingCmd();
    bool sendDataAndReceiveReply(const char* ip, int port, const std::vector<unsigned char>& data, std::vector<unsigned char>& reply);
    bool parseDistanceReply(const std::vector<unsigned char>& reply, float& distance);
    void parseErrorCode(unsigned char errCode);

    QString m_ip;
    int m_port;
    std::atomic<bool> m_isRunning;
    std::mutex m_mutex;
    PtzDeviceCgi* m_parent; // 添加父对象引用

public:
    // Getter方法
    QString getIp() const { return m_ip; }
    int getPort() const { return m_port; }
};

#endif //PTZ_APP_PTZ_DEVICE_CGI_H
