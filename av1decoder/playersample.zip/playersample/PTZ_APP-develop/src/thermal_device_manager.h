#ifndef THERMAL_DEVICE_MANAGER_H
#define THERMAL_DEVICE_MANAGER_H

#include <QObject>
#include <QMap>
#include <QMutex>
#include <QThread>
#include "thermal_ctl.h"
#include "model/devicemodel.h"

class ThermalDeviceManager : public QObject
{
    Q_OBJECT

public:
    static ThermalDeviceManager* instance();
    
    // 设备管理
    Q_INVOKABLE void initializeDevice(const QString &deviceId, const QString &username, const QString &password, const QString &ip);
    Q_INVOKABLE void removeDevice(const QString &deviceId);
    Q_INVOKABLE ThermalCtl* getDevice(const QString &deviceId);
    Q_INVOKABLE QString getCurrentDeviceId();
    Q_INVOKABLE void setCurrentDevice(const QString &deviceId);
    
    // 批量操作
    Q_INVOKABLE void initializeAllDevices();
    Q_INVOKABLE void removeAllDevices();
    
    // 设备状态
    Q_INVOKABLE bool isDeviceInitialized(const QString &deviceId);
    Q_INVOKABLE QStringList getInitializedDevices();
    
    // 便捷方法 - 对当前设备执行操作
    Q_INVOKABLE void setPseudoMode(int mode);
    Q_INVOKABLE void setFocusZoom(int channel, int digitalZoom, bool debug = false);
    Q_INVOKABLE void enhanceInfraRed(bool brightMutation = true, bool denoise2DEnable = true, int denoise2DLevel = 2,
                                    bool denoise3DEnable = true, int denoise3DLevel = 3, bool ddeEnable = true, int ddeLevel = 4,
                                    int flipMode = 4, bool regionalEnable = true, int regionalLevel = 4,
                                    int coordX = 4, int coordY = 4);

signals:
    void deviceInitialized(const QString &deviceId);
    void deviceRemoved(const QString &deviceId);
    void currentDeviceChanged(const QString &deviceId);
    void allDevicesInitialized();

private:
    explicit ThermalDeviceManager(QObject* parent = nullptr);
    ~ThermalDeviceManager();
    
    static ThermalDeviceManager* m_instance;
    
    QMap<QString, ThermalCtl*> m_devices;
    QMap<QString, QThread*> m_deviceThreads;
    QString m_currentDeviceId;
    QMutex m_mutex;
};

#endif // THERMAL_DEVICE_MANAGER_H 