#include "playermanager.h"
#include "model/devicemodel.h"
#include "image_fusion_manager.h"
#include "gas_cloud_manager.h"
#include "micro_leak_manager.h"
#include "ptz_device_manager.h"
#include <QDebug>
#include <QTimer>
#include <QTime>
#include <QQmlEngine>

PlayerManager* PlayerManager::m_instance = nullptr;

PlayerManager::PlayerManager(QObject *parent)
    : QObject(parent)
    , m_maxChannels(9)
    , m_initialized(false)
    , m_currentFusionChannel(-1)
    , m_currentMicroLeakChannel(-1)
    , m_nextPlayerIndex(0)
{
    qDebug() << "PlayerManager created";
    
    // 建立与ImageFusionManager的长久连接
    ImageFusionManager* fusionManager = ImageFusionManager::instance();
    if (fusionManager) {
        connect(fusionManager, &ImageFusionManager::dualFusionCompleted, 
                this, &PlayerManager::onDualFusionCompleted);
    }
    
    // 建立与GasCloudManager的长久连接
    GasCloudManager* gasCloudManager = GasCloudManager::instance();
    if (gasCloudManager) {
        connect(gasCloudManager, &GasCloudManager::gasCloudCompleted, 
                this, &PlayerManager::onGasCloudCompleted);
    }

    // 建立与MicroLeakManager的长久连接
    MicroLeakManager* microLeakManager = MicroLeakManager::instance();
    if (microLeakManager) {
        connect(microLeakManager, &MicroLeakManager::processingFinished,
                this, &PlayerManager::onMicroLeakCompleted);
    }
}

PlayerManager::~PlayerManager()
{
    cleanup();
    qDebug() << "PlayerManager destroyed";
}

PlayerManager* PlayerManager::instance()
{
    if (!m_instance) {
        m_instance = new PlayerManager();
    }
    return m_instance;
}

void PlayerManager::initializePlayers(int maxChannels)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        qDebug() << "Players already initialized";
        return;
    }
    
    m_maxChannels = maxChannels;
    qDebug() << "Initializing" << maxChannels << "players for buffer pool...";
    
    // 预先创建所有播放器作为缓冲池，但不建立channel映射
    for (int i = 0; i < maxChannels; ++i) {
        createPlayerAtIndex(i, -1); // -1表示未映射到任何channel
    }
    
    // 将所有playerIndex标记为可用
    for (int i = 0; i < maxChannels; ++i) {
        m_availablePlayerIndexes.insert(i);
    }
    
    // 初始化算法专用的FrameProvider
    qDebug() << "Initializing algorithm FrameProviders for" << maxChannels << "channels...";
    for (int i = 0; i < maxChannels; ++i) {
        // 创建可见光算法FrameProvider
        if (!m_algorithmVisibleProviders.contains(i)) {
            FrameProvider* visibleProvider = new FrameProvider(this);
            m_algorithmVisibleProviders[i] = visibleProvider;
            qDebug() << "Created visible light algorithm FrameProvider for channel" << i;
        }
        
        // 创建红外光算法FrameProvider
        if (!m_algorithmInfraredProviders.contains(i)) {
            FrameProvider* infraredProvider = new FrameProvider(this);
            m_algorithmInfraredProviders[i] = infraredProvider;
            qDebug() << "Created infrared algorithm FrameProvider for channel" << i;
        }
    }
    
    m_nextPlayerIndex = maxChannels; // 下一个新索引从maxChannels开始
    
    m_initialized = true;
    emit allPlayersInitialized();
    qDebug() << "Buffer pool initialized with" << maxChannels << "players and algorithm FrameProviders";
}

// 旧的createPlayer方法已被废弃，使用createPlayerAtIndex替代

// 旧的destroyPlayer方法已被废弃，使用releasePlayerForChannel替代

void PlayerManager::connectPlayerSignals(splayer* player, int channelIndex, PlayerType playerType)
{
    if (!player) return;
    
    qDebug() << "=== connectPlayerSignals called ===" << "Channel:" << channelIndex << "PlayerType:" << playerType << "Player:" << player;
    
    // 连接状态变化信号
    bool connectionResult = connect(player, &splayer::newFrameAvailable, this, [this, player, channelIndex, playerType](const QVideoFrame &frame) {
        //qDebug() << QTime::currentTime().toString("hh:mm:ss.zzz") << "PlayerManager: Received newFrameAvailable signal from channel" << channelIndex << "playerType" << playerType << "frame valid:" << frame.isValid();
        // 检查当前是否处于双光融合模式或气云成像模式
        bool isDualFusionMode = m_dualFusionMode.contains(channelIndex) && m_dualFusionMode[channelIndex];
        bool isGasCloudMode = m_gasCloudMode.contains(channelIndex) && m_gasCloudMode[channelIndex];
        
        // 决定是否将帧发送到用于显示的FrameProvider
        bool sendToDisplayProvider = true;
        
        // 在气云成像模式下，不发送任何原始帧到用于显示的FrameProvider
        if (isGasCloudMode) {
            sendToDisplayProvider = false;
        }
        // 在双光融合模式下，不发送红外原始帧到用于显示的FrameProvider（但可见光原始帧仍需显示）
        else if (isDualFusionMode && playerType == InfraredLive) {
            sendToDisplayProvider = false;
        }
        
        // 根据判断结果决定是否发送帧到用于显示的FrameProvider
        if (sendToDisplayProvider) {
            FrameProvider* provider = nullptr;
            if (m_frameProviders.contains(channelIndex) && m_frameProviders[channelIndex].contains(playerType)) {
                provider = m_frameProviders[channelIndex][playerType];
            }
            
            if (provider) {
                provider->onNewVideoContentReceived(frame);
            }
        }
        
        // 始终将帧发送到用于算法处理但不显示的FrameProvider（解决双光融合闪烁问题）
        FrameProvider* algorithmProvider = nullptr;
        if (playerType == VisibleLightLive && m_algorithmVisibleProviders.contains(channelIndex)) {
            algorithmProvider = m_algorithmVisibleProviders[channelIndex];
        } else if (playerType == InfraredLive && m_algorithmInfraredProviders.contains(channelIndex)) {
            algorithmProvider = m_algorithmInfraredProviders[channelIndex];
        }
        if (algorithmProvider) {
            algorithmProvider->onNewVideoContentReceived(frame);
        }
        
        // 在气云成像模式下，可见光和红外帧都用于气云分割
        if (playerType == InfraredLive && m_gasCloudMode.contains(channelIndex) && m_gasCloudMode[channelIndex]) {
            // 气云成像模式：触发气云分割
            triggerGasCloud(channelIndex, playerType, frame);
        }
        // 微漏模式：触发微漏检测
        else if (playerType == VisibleLightLive && m_microLeakMode.contains(channelIndex) && m_microLeakMode[channelIndex]) {
            triggerMicroLeak(channelIndex, frame);
        }
        // 在双光融合模式下，红外帧也用于融合
        else if (playerType == InfraredLive && 
            m_dualFusionMode.contains(channelIndex) && m_dualFusionMode[channelIndex]) {
            // 融合模式：触发融合
            triggerDualFusion(channelIndex, playerType, frame);
        }
        
        // 发出状态变化信号
        emit playerStatusChanged(channelIndex, playerType, player->mediaStatus());
    });
    
    qDebug() << "connectPlayerSignals: Connection result for newFrameAvailable:" << connectionResult << "Channel:" << channelIndex << "PlayerType:" << playerType;
    qDebug() << "=== connectPlayerSignals completed ===" << "Channel:" << channelIndex << "PlayerType:" << playerType;
}

splayer* PlayerManager::getPlayer(int channelIndex, PlayerType playerType)
{

    QMutexLocker locker(&m_mutex);

    if (channelIndex < 0) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return nullptr;
    }

    // 使用映射表查找对应的播放器索引
    if (!m_channelToPlayerMap.contains(channelIndex)) {
        qWarning() << "Channel" << channelIndex << "is not mapped to any player";
        return nullptr;
    }

    int playerIndex = m_channelToPlayerMap[channelIndex];
    
    if (!m_players.contains(playerIndex)) {
        qWarning() << "No players found for player index:" << playerIndex;
        return nullptr;
    }
    qDebug() << "@@wh getPlayer: Returning player for channel" << channelIndex << "playerType" << playerType << "playerIndex" << playerIndex;
    splayer* p = m_players[playerIndex].value(playerType, nullptr);
    if (p) {
        QQmlEngine::setObjectOwnership(p, QQmlEngine::CppOwnership);
    }
    return p;
}

splayer* PlayerManager::getPlayer(int channelIndex, bool isVisibleLight)
{
    // 向后兼容的方法
    PlayerType playerType = isVisibleLight ? VisibleLightLive : InfraredLive;
    return getPlayer(channelIndex, playerType);
}


void PlayerManager::updatePlayerUrls()
{
        
    // 根据设备模型更新所有播放器的URL
    for (int i = 0; i < m_maxChannels; ++i) {
        // 更新实时流播放器
        QString visibleLightUrl = DeviceModel::instance()->getDeviceUrlByChannelIndex(i, true);
        if (!visibleLightUrl.isEmpty()) {
            splayer* player = getPlayer(i, VisibleLightLive);
            if (player) {
                player->prepare(visibleLightUrl);
                player->play();
                qDebug() << "Updating visible light live player URL for channel" << i << "to:" << visibleLightUrl;
                m_playerUrls[i][VisibleLightLive] = visibleLightUrl;
                emit playerUrlChanged(i, VisibleLightLive, visibleLightUrl);
            }
        }
        
        QString infraredUrl = DeviceModel::instance()->getDeviceUrlByChannelIndex(i, false);
        if (!infraredUrl.isEmpty()) {
            splayer* player = getPlayer(i, InfraredLive);
            if (player) {
                player->prepare(infraredUrl);
                player->play();
                m_playerUrls[i][InfraredLive] = infraredUrl;
                emit playerUrlChanged(i, InfraredLive, infraredUrl);
            }
        }
        
        // 更新录像流播放器
        QString visibleLightRecordUrl = DeviceModel::instance()->getDeviceRecordUrlByChannelIndex(i, true);
        if (!visibleLightRecordUrl.isEmpty()) {
            splayer* player = getPlayer(i, VisibleLightRecord);
            if (player) {
                player->prepare(visibleLightRecordUrl);
                player->play();
                m_playerUrls[i][VisibleLightRecord] = visibleLightRecordUrl;
                emit playerUrlChanged(i, VisibleLightRecord, visibleLightRecordUrl);
            }
        }
        
        QString infraredRecordUrl = DeviceModel::instance()->getDeviceRecordUrlByChannelIndex(i, false);
        if (!infraredRecordUrl.isEmpty()) {
            splayer* player = getPlayer(i, InfraredRecord);
            if (player) {
                player->prepare(infraredRecordUrl);
                player->play();
                m_playerUrls[i][InfraredRecord] = infraredRecordUrl;
                emit playerUrlChanged(i, InfraredRecord, infraredRecordUrl);
            }
        }
    }
}

void PlayerManager::startAllPlayers()
{
    QMutexLocker locker(&m_mutex);
    
    for (auto channelIt = m_players.begin(); channelIt != m_players.end(); ++channelIt) {
        auto& players = channelIt.value();
        for (auto playerIt = players.begin(); playerIt != players.end(); ++playerIt) {
            splayer* player = playerIt.value();
            if (player) {
                player->play();
            }
        }
    }
    
    qDebug() << "All players started";
}

void PlayerManager::stopAllPlayers()
{
    QMutexLocker locker(&m_mutex);
    qDebug() << "Stopping all players";
    for (auto channelIt = m_players.begin(); channelIt != m_players.end(); ++channelIt) {
        auto& players = channelIt.value();
        for (auto playerIt = players.begin(); playerIt != players.end(); ++playerIt) {
            splayer* player = playerIt.value();
            if (player) {
                player->stop();
            }
        }
    }
    
    qDebug() << "All players stopped";
}

void PlayerManager::pauseAllPlayers()
{
    QMutexLocker locker(&m_mutex);
    
    for (auto channelIt = m_players.begin(); channelIt != m_players.end(); ++channelIt) {
        auto& players = channelIt.value();
        for (auto playerIt = players.begin(); playerIt != players.end(); ++playerIt) {
            splayer* player = playerIt.value();
            if (player) {
                player->pause();
            }
        }
    }
    
    qDebug() << "All players paused";
}

void PlayerManager::resumeAllPlayers()
{
    QMutexLocker locker(&m_mutex);
    
    for (auto channelIt = m_players.begin(); channelIt != m_players.end(); ++channelIt) {
        auto& players = channelIt.value();
        for (auto playerIt = players.begin(); playerIt != players.end(); ++playerIt) {
            splayer* player = playerIt.value();
            if (player) {
                player->play();
            }
        }
    }
    
    qDebug() << "All players resumed";
}


void PlayerManager::setPlayerUrls(int channelIndex, const QString &visibleLightUrl, const QString &infraredUrl)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    
    setPlayerUrl(channelIndex, VisibleLightLive, visibleLightUrl);
    setPlayerUrl(channelIndex, InfraredLive, infraredUrl);
}

// 添加新的方法来快速切换URL（用于录像回放等场景）
void PlayerManager::fastSwitchPlayerUrl(int channelIndex, bool isVisibleLight, const QString &newUrl)
{
    // 向后兼容的方法
    PlayerType playerType = isVisibleLight ? VisibleLightLive : InfraredLive;
    fastSwitchPlayerUrl(channelIndex, playerType, newUrl);
}

QString PlayerManager::getVisibleLightUrl(int channelIndex)
{
    return getPlayerUrl(channelIndex, VisibleLightLive);
}

QString PlayerManager::getInfraredUrl(int channelIndex)
{
    return getPlayerUrl(channelIndex, InfraredLive);
}

bool PlayerManager::isPlayerPlaying(int channelIndex, bool isVisibleLight)
{
    splayer* player = getPlayer(channelIndex, isVisibleLight);
    if (player) {
        return player->mediaStatus() == media_playing;
    }
    return false;
}

int PlayerManager::getPlayerStatus(int channelIndex, bool isVisibleLight)
{
    splayer* player = getPlayer(channelIndex, isVisibleLight);
    if (player) {
        return static_cast<int>(player->mediaStatus());
    }
    return static_cast<int>(media_idle);
}

// 双光融合相关方法实现
void PlayerManager::setDualFusionMode(int channelIndex, bool enabled)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "=== setDualFusionMode called ===";
    qDebug() << "Channel:" << channelIndex << "enabled:" << enabled;
    qDebug() << "Previous mode:" << m_dualFusionMode.value(channelIndex, false);
    
    bool previousMode = m_dualFusionMode.value(channelIndex, false);
    m_dualFusionMode[channelIndex] = enabled;
    qDebug() << "Channel" << channelIndex << "dual fusion mode set to:" << enabled;
    
    // 如果从融合模式切换到普通模式，清理融合相关状态
    if (previousMode && !enabled) {
        qDebug() << "Switching from fusion mode to normal mode, cleaning up...";
        
        // 清理融合提供者的缓存帧
        FrameProvider* fusionProvider = getDualFusionProvider(channelIndex);
        if (fusionProvider) {
            // 发送一个空帧来清理缓存
            fusionProvider->onNewVideoContentReceived(QVideoFrame());
            qDebug() << "Cleared fusion provider cache for channel" << channelIndex;
        }
        
        // 重置当前融合通道
        if (m_currentFusionChannel == channelIndex) {
            m_currentFusionChannel = -1;
            qDebug() << "Reset current fusion channel";
        }
    }
    
    // 发出信号通知QML
    emit dualFusionModeChanged(channelIndex, enabled);
    qDebug() << "dualFusionModeChanged signal emitted";
    qDebug() << "=== setDualFusionMode completed ===";
}

bool PlayerManager::isDualFusionMode(int channelIndex) const
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        return false;
    }
    
    return m_dualFusionMode.value(channelIndex, false);
}

FrameProvider* PlayerManager::getDualFusionProvider(int channelIndex)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        return nullptr;
    }
    
    return m_dualFusionProviders.value(channelIndex, nullptr);
}

void PlayerManager::setDualFusionProvider(int channelIndex, FrameProvider* provider)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    m_dualFusionProviders[channelIndex] = provider;
    qDebug() << "Set dual fusion provider for channel" << channelIndex;
}

// 气云成像相关方法实现
void PlayerManager::setGasCloudMode(int channelIndex, bool enabled)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "=== setGasCloudMode called ===";
    qDebug() << "Channel:" << channelIndex << "enabled:" << enabled;
    qDebug() << "Previous mode:" << m_gasCloudMode.value(channelIndex, false);
    
    bool previousMode = m_gasCloudMode.value(channelIndex, false);
    m_gasCloudMode[channelIndex] = enabled;
    qDebug() << "Channel" << channelIndex << "gas cloud mode set to:" << enabled;
    
    // 如果从气云成像模式切换到普通模式，清理相关状态
    if (previousMode && !enabled) {
        qDebug() << "Switching from gas cloud mode to normal mode, cleaning up...";
        
        // 清理气云成像提供者的缓存帧
        FrameProvider* visibleProvider = getGasCloudVisibleProvider(channelIndex);
        FrameProvider* infraredProvider = getGasCloudInfraredProvider(channelIndex);
        
        if (visibleProvider) {
            visibleProvider->onNewVideoContentReceived(QVideoFrame());
            qDebug() << "Cleared gas cloud visible provider cache for channel" << channelIndex;
        }
        
        if (infraredProvider) {
            infraredProvider->onNewVideoContentReceived(QVideoFrame());
            qDebug() << "Cleared gas cloud infrared provider cache for channel" << channelIndex;
        }
        
        // 重置当前气云成像通道
        if (m_currentGasCloudChannel == channelIndex) {
            m_currentGasCloudChannel = -1;
            qDebug() << "Reset current gas cloud channel";
        }
    }
    
    // 发出信号通知QML
    emit gasCloudModeChanged(channelIndex, enabled);
    qDebug() << "gasCloudModeChanged signal emitted";
    qDebug() << "=== setGasCloudMode completed ===";
}

bool PlayerManager::isGasCloudMode(int channelIndex) const
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        return false;
    }
    
    return m_gasCloudMode.value(channelIndex, false);
}

FrameProvider* PlayerManager::getGasCloudVisibleProvider(int channelIndex)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        return nullptr;
    }
    
    return m_gasCloudVisibleProviders.value(channelIndex, nullptr);
}

FrameProvider* PlayerManager::getGasCloudInfraredProvider(int channelIndex)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        return nullptr;
    }
    
    return m_gasCloudInfraredProviders.value(channelIndex, nullptr);
}

void PlayerManager::setGasCloudVisibleProvider(int channelIndex, FrameProvider* provider)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    m_gasCloudVisibleProviders[channelIndex] = provider;
    qDebug() << "Set gas cloud visible provider for channel" << channelIndex;
}

void PlayerManager::setGasCloudInfraredProvider(int channelIndex, FrameProvider* provider)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    m_gasCloudInfraredProviders[channelIndex] = provider;
    qDebug() << "Set gas cloud infrared provider for channel" << channelIndex;
}

QVideoFrame PlayerManager::imageToVideoFrame(const QImage& image)
{
    if (image.isNull()) {
        return QVideoFrame();
    }
    
    // 确保图像是正确的格式
    QImage rgbImage = image.convertToFormat(QImage::Format_RGB888);
    int width = rgbImage.width();
    int height = rgbImage.height();
    
    // 创建YUV420P格式的QVideoFrame
    QVideoFrame frame(width * height * 3 / 2, QSize(width, height), width, QVideoFrame::Format_YUV420P);
    if (!frame.map(QAbstractVideoBuffer::WriteOnly)) {
        qWarning() << "Failed to map video frame for writing";
        return QVideoFrame();
    }
    
    // 分配YUV数据
    uchar* yData = frame.bits(0);
    uchar* uData = frame.bits(1);
    uchar* vData = frame.bits(2);
    
    int yStride = frame.bytesPerLine(0);
    int uStride = frame.bytesPerLine(1);
    int vStride = frame.bytesPerLine(2);
    
    // 填充YUV数据
    const uchar* rgbData = rgbImage.bits();
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int rgbIndex = (y * width + x) * 3;
            int yIndex = y * yStride + x;
            
            int r = rgbData[rgbIndex];
            int g = rgbData[rgbIndex + 1];
            int b = rgbData[rgbIndex + 2];
            
            // RGB到YUV转换
            int Y = (66 * r + 129 * g + 25 * b + 128) >> 8;
            Y = qBound(0, Y, 255);
            
            yData[yIndex] = static_cast<uchar>(Y);
            
            // 只在偶数像素位置计算U和V（YUV420P格式）
            if (x % 2 == 0 && y % 2 == 0) {
                int uvIndex = (y / 2) * (width / 2) + (x / 2);
                
                int U = (-38 * r - 74 * g + 112 * b + 128) >> 8;
                int V = (112 * r - 94 * g - 18 * b + 128) >> 8;
                
                U = qBound(0, U + 128, 255);
                V = qBound(0, V + 128, 255);
                
                uData[uvIndex] = U;
                vData[uvIndex] = V;
            }
        }
    }
    
    frame.unmap();
    return frame;
}

QByteArray PlayerManager::extractYUVData(const QVideoFrame& frame, int& width, int& height) const
{
    if (!frame.isValid()) {
        qWarning() << "Invalid video frame";
        return QByteArray();
    }
    
    QVideoFrame cloneFrame(frame);
    if (!cloneFrame.map(QAbstractVideoBuffer::ReadOnly)) {
        qWarning() << "Failed to map video frame";
        return QByteArray();
    }
    
    width = cloneFrame.width();
    height = cloneFrame.height();
    
    // 检查是否已经是YUV格式
    if (cloneFrame.pixelFormat() != QVideoFrame::Format_YUV420P) {
        qWarning() << "Frame is not in YUV420P format, cannot extract YUV data directly";
        cloneFrame.unmap();
        return QByteArray();
    }
    
    // 提取YUV数据
    const uchar* yData = cloneFrame.bits(0);
    const uchar* uData = cloneFrame.bits(1);
    const uchar* vData = cloneFrame.bits(2);
    
    if (!yData || !uData || !vData) {
        qWarning() << "Invalid YUV data pointers";
        cloneFrame.unmap();
        return QByteArray();
    }
    
    int yStride = cloneFrame.bytesPerLine(0);
    int uStride = cloneFrame.bytesPerLine(1);
    int vStride = cloneFrame.bytesPerLine(2);
    
    int ySize = height * yStride;
    int uSize = (height / 2) * uStride;
    int vSize = (height / 2) * vStride;
    int totalSize = ySize + uSize + vSize;
    
    QByteArray yuvData(totalSize, 0);
    uchar* dest = reinterpret_cast<uchar*>(yuvData.data());
    
    // 复制Y数据
    for (int i = 0; i < height; ++i) {
        memcpy(dest + i * width, yData + i * yStride, width);
    }
    dest += ySize;
    
    // 复制U数据
    for (int i = 0; i < height / 2; ++i) {
        memcpy(dest + i * (width / 2), uData + i * uStride, width / 2);
    }
    dest += uSize;
    
    // 复制V数据
    for (int i = 0; i < height / 2; ++i) {
        memcpy(dest + i * (width / 2), vData + i * vStride, width / 2);
    }
    
    cloneFrame.unmap();
    return yuvData;
}

QByteArray PlayerManager::convertYUV420PToNV12(const QByteArray& yuv420pData, int width, int height) const
{
    if (yuv420pData.isEmpty()) {
        qWarning() << "Input YUV420P data is empty";
        return QByteArray();
    }
    
    // YUV420P: Y plane + U plane + V plane
    // NV12: Y plane + interleaved UV plane
    int ySize = width * height;
    int uvSize = width * height / 2;  // U和V各占一半
    int totalSize = ySize + uvSize;
    
    QByteArray nv12Data(totalSize, 0);
    uchar* nv12Ptr = reinterpret_cast<uchar*>(nv12Data.data());
    
    // 复制Y平面
    const uchar* yuv420pPtr = reinterpret_cast<const uchar*>(yuv420pData.data());
    memcpy(nv12Ptr, yuv420pPtr, ySize);
    
    // 重新排列UV平面：从分离的U和V平面转换为交错的UV平面
    const uchar* uPlane = yuv420pPtr + ySize;
    const uchar* vPlane = uPlane + (width * height / 4);  // U平面大小
    
    uchar* uvPlane = nv12Ptr + ySize;
    
    // 交错UV数据
    for (int i = 0; i < width * height / 4; ++i) {
        uvPlane[i * 2] = uPlane[i];      // U
        uvPlane[i * 2 + 1] = vPlane[i];  // V
    }
    
    //qDebug() << "Converted YUV420P to NV12: size" << yuv420pData.size() << "->" << nv12Data.size();
    return nv12Data;
}

void PlayerManager::triggerDualFusion(int channelIndex, PlayerType sourceType, const QVideoFrame& frame)
{
    qDebug() << "=== triggerDualFusion called ===";
    qDebug() << "Channel:" << channelIndex << "Source type:" << sourceType;
    
    // 获取双光融合FrameProvider
    FrameProvider* fusionProvider = getDualFusionProvider(channelIndex);
    if (!fusionProvider) {
        qWarning() << "No dual fusion provider for channel" << channelIndex;
        return;
    }
    qDebug() << "Dual fusion provider found:" << fusionProvider;
    
    // 获取可见光和红外的最新帧（从专门用于算法处理的FrameProvider获取，避免闪烁）
    FrameProvider* visibleProvider = m_algorithmVisibleProviders.value(channelIndex, nullptr);
    FrameProvider* infraredProvider = m_algorithmInfraredProviders.value(channelIndex, nullptr);
    
    // 如果算法专用FrameProvider不存在，回退到原来的FrameProvider
    if (!visibleProvider) {
        visibleProvider = m_frameProviders.value(channelIndex).value(VisibleLightLive, nullptr);
    }
    
    if (!infraredProvider) {
        infraredProvider = m_frameProviders.value(channelIndex).value(InfraredLive, nullptr);
    }
    
    if (!visibleProvider || !infraredProvider) {
        qWarning() << "Missing providers - visible:" << visibleProvider << "infrared:" << infraredProvider;
        return;
    }
    qDebug() << "Visible and infrared providers found";
    
    // 直接从QVideoFrame提取YUV数据，避免转换为QImage
    QVideoFrame visibleFrame = visibleProvider->getCurrentFrame();
    QVideoFrame infraredFrame = infraredProvider->getCurrentFrame();
    
    int visibleWidth, visibleHeight, infraredWidth, infraredHeight;
    QByteArray visibleYUV = extractYUVData(visibleFrame, visibleWidth, visibleHeight);
    QByteArray infraredYUV = extractYUVData(infraredFrame, infraredWidth, infraredHeight);
    
    qDebug() << "Visible YUV data:" << (visibleYUV.isEmpty() ? "Empty" : QString("Size %1").arg(visibleYUV.size()));
    qDebug() << "Infrared YUV data:" << (infraredYUV.isEmpty() ? "Empty" : QString("Size %1").arg(infraredYUV.size()));
    
    if (!visibleYUV.isEmpty() && !infraredYUV.isEmpty()) {
        // 将YUV420P数据转换为NV12格式
        QByteArray visibleNV12 = convertYUV420PToNV12(visibleYUV, visibleWidth, visibleHeight);
        QByteArray infraredNV12 = convertYUV420PToNV12(infraredYUV, infraredWidth, infraredHeight);
        
        qDebug() << "Converted to NV12 - Visible:" << (visibleNV12.isEmpty() ? "Empty" : QString("Size %1").arg(visibleNV12.size()));
        qDebug() << "Converted to NV12 - Infrared:" << (infraredNV12.isEmpty() ? "Empty" : QString("Size %1").arg(infraredNV12.size()));
        
        if (!visibleNV12.isEmpty() && !infraredNV12.isEmpty()) {
            // 调用图像融合管理器进行双光融合（使用NV12数据并返回QVideoFrame）
            ImageFusionManager* fusionManager = ImageFusionManager::instance();
            qDebug() << "Fusion manager instance:" << fusionManager;
            
            if (fusionManager) {
                qDebug() << "Fusion manager available:" << fusionManager->isFusionAvailable();
                qDebug() << "Fusion status:" << fusionManager->getFusionStatus();
            }
            
            if (fusionManager && fusionManager->isFusionAvailable()) {
                qDebug() << "Performing dual fusion with NV12 data...";
                
                // 存储当前通道的融合提供者，供槽函数使用
                m_currentFusionChannel = channelIndex;
                
                // 获取当前通道的TOF距离（毫米）
                float tofDistance = getTofDistance(channelIndex);
                qDebug() << "Using TOF distance for fusion:" << tofDistance << "mm";
                
                // 执行异步双光融合算法（使用NV12格式数据和TOF距离）
                fusionManager->performDualFusionWithYUVAsync(
                    visibleNV12, visibleWidth, visibleHeight,
                    infraredNV12, infraredWidth, infraredHeight, tofDistance + 1500);
            } else {
                qWarning() << "ImageFusionManager not available or not initialized";
            }
        } else {
            qWarning() << "One or both NV12 data are empty after conversion, cannot perform fusion";
        }
    } else {
        qWarning() << "One or both YUV data are empty, cannot perform fusion";
    }
    
    qDebug() << "=== triggerDualFusion completed ===";
}

void PlayerManager::triggerGasCloud(int channelIndex, PlayerType sourceType, const QVideoFrame& frame)
{
    //qDebug() << "=== triggerGasCloud called ===";
    //qDebug() << "Channel:" << channelIndex << "Source type:" << sourceType;
    
    // 获取可见光和红外的最新帧（从专门用于算法处理的FrameProvider获取）
    FrameProvider* visibleProvider = m_algorithmVisibleProviders.value(channelIndex, nullptr);
    FrameProvider* infraredProvider = m_algorithmInfraredProviders.value(channelIndex, nullptr);
    
    // 如果算法专用FrameProvider不存在，回退到原来的FrameProvider
    if (!visibleProvider) {
        visibleProvider = m_frameProviders.value(channelIndex).value(VisibleLightLive, nullptr);
    }
    
    if (!infraredProvider) {
        infraredProvider = m_frameProviders.value(channelIndex).value(InfraredLive, nullptr);
    }
    
    if (!visibleProvider || !infraredProvider) {
        qWarning() << "Missing providers - visible:" << visibleProvider << "infrared:" << infraredProvider;
        return;
    }
    //qDebug() << "Visible and infrared providers found";
    
    // 直接从QVideoFrame提取YUV数据，避免转换为QImage
    QVideoFrame visibleFrame = visibleProvider->getCurrentFrame();
    QVideoFrame infraredFrame = infraredProvider->getCurrentFrame();
    
    int visibleWidth, visibleHeight, infraredWidth, infraredHeight;
    QByteArray visibleYUV = extractYUVData(visibleFrame, visibleWidth, visibleHeight);
    QByteArray infraredYUV = extractYUVData(infraredFrame, infraredWidth, infraredHeight);
    
    //qDebug() << "Visible YUV data:" << (visibleYUV.isEmpty() ? "Empty" : QString("Size %1").arg(visibleYUV.size()));
    //qDebug() << "Infrared YUV data:" << (infraredYUV.isEmpty() ? "Empty" : QString("Size %1").arg(infraredYUV.size()));
    
    if (!visibleYUV.isEmpty() && !infraredYUV.isEmpty()) {
        // 将YUV420P数据转换为NV12格式
        QByteArray visibleNV12 = convertYUV420PToNV12(visibleYUV, visibleWidth, visibleHeight);
        QByteArray infraredNV12 = convertYUV420PToNV12(infraredYUV, infraredWidth, infraredHeight);
        
        //qDebug() << "Converted to NV12 - Visible:" << (visibleNV12.isEmpty() ? "Empty" : QString("Size %1").arg(visibleNV12.size()));
        //qDebug() << "Converted to NV12 - Infrared:" << (infraredNV12.isEmpty() ? "Empty" : QString("Size %1").arg(infraredNV12.size()));
        
        if (!visibleNV12.isEmpty() && !infraredNV12.isEmpty()) {
            // 调用气云分割管理器进行气云分割
            GasCloudManager* gasCloudManager = GasCloudManager::instance();
            //qDebug() << "Gas cloud manager instance:" << gasCloudManager;
            
            if (gasCloudManager) {
                //qDebug() << "Gas cloud manager available:" << gasCloudManager->isGasCloudAvailable();
                //qDebug() << "Gas cloud status:" << gasCloudManager->getGasCloudStatus();
            }
            
            if (gasCloudManager && gasCloudManager->isGasCloudAvailable()) {
                //qDebug() << "Performing gas cloud processing with NV12 data...";
                
                // 存储当前通道的气云分割提供者，供槽函数使用
                m_currentGasCloudChannel = channelIndex;
                
                // 获取当前通道对应的设备ID和tdlas浓度值
                QString deviceId = DeviceModel::instance()->getDeviceIdByChannelIndex(channelIndex);
                float tdlasConcentration = 0.0f; // 默认值
                
                if (!deviceId.isEmpty()) {
                    // 获取PtzDeviceCgi实例
                    PtzDeviceCgi* ptzDevice = PtzDeviceManager::instance()->getDevice(deviceId);
                    if (ptzDevice) {
                        // 获取当前tdlas浓度值（ppm转换为float）
                        QList<int> concentrationList = ptzDevice->getConcetList();
                        if (!concentrationList.isEmpty()) {
                            int currentConcentration = concentrationList.last();
                            // 获取设备的气体浓度阈值
                            int alarmThreshold = DeviceModel::instance()->getAlarmConcentration(deviceId);

                            // 如果当前浓度小于阈值，则传递0给气云算法
                            if (currentConcentration < alarmThreshold) {
                                tdlasConcentration = 0.0f;
                                qDebug() << "TDLAS concentration" << currentConcentration << "below threshold" << alarmThreshold << ", using 0 for gas cloud";
                            } else {
                                tdlasConcentration = static_cast<float>(currentConcentration);
                                qDebug() << "TDLAS concentration" << currentConcentration << "above threshold" << alarmThreshold << ", using actual value";
                            }
                        }
                        //qDebug() << "TDLAS concentration for device" << deviceId << ":" << tdlasConcentration << "ppm";
                    } else {
                        qWarning() << "PtzDeviceCgi not found for device" << deviceId;
                    }
                } else {
                    qWarning() << "No device found for channel" << channelIndex;
                }
                
                // 执行异步气云分割算法（使用NV12格式数据）
                gasCloudManager->processGasCloudAsync(
                    visibleNV12, visibleWidth, visibleHeight,
                    infraredNV12, infraredWidth, infraredHeight,
                    2200, // 默认深度值
                    tdlasConcentration); // tdlas浓度值
            } else {
                qWarning() << "GasCloudManager not available or not initialized";
            }
        } else {
            qWarning() << "One or both NV12 data are empty after conversion, cannot perform gas cloud processing";
        }
    } else {
        qWarning() << "One or both YUV data are empty, cannot perform gas cloud processing";
    }
    
    //qDebug() << "=== triggerGasCloud completed ===";
}

void PlayerManager::onDualFusionCompleted(const QVideoFrame& fusedFrame, bool success, const QString& errorMessage)
{
    if (success && fusedFrame.isValid()) {
        // 获取当前通道的融合提供者
        FrameProvider* fusionProvider = getDualFusionProvider(m_currentFusionChannel);
        if (fusionProvider) {
            // 直接将融合后的QVideoFrame发送给双光融合FrameProvider
            fusionProvider->onNewVideoContentReceived(fusedFrame);
            qDebug() << "Fusion frame sent to provider for channel" << m_currentFusionChannel;
        }
    } else {
        qWarning() << "Fusion failed for channel" << m_currentFusionChannel << ":" << errorMessage;
    }
}

void PlayerManager::onGasCloudCompleted(const QVideoFrame& fusionFrame, const QVideoFrame& irHeatmapFrame, bool success, const QString& errorMessage)
{
    if (success) {
        // 获取当前通道的气云成像提供者
        FrameProvider* visibleProvider = getGasCloudVisibleProvider(m_currentGasCloudChannel);
        FrameProvider* infraredProvider = getGasCloudInfraredProvider(m_currentGasCloudChannel);
        
        if (visibleProvider && fusionFrame.isValid()) {
            // 将可见光叠加mask的结果发送给气云可见光FrameProvider
            visibleProvider->onNewVideoContentReceived(fusionFrame);
            qDebug() << "Gas cloud visible frame sent to provider for channel" << m_currentGasCloudChannel;
        }
        
        if (infraredProvider && irHeatmapFrame.isValid()) {
            // 将红外叠加mask的结果发送给气云红外FrameProvider
            infraredProvider->onNewVideoContentReceived(irHeatmapFrame);
            qDebug() << "Gas cloud infrared frame sent to provider for channel" << m_currentGasCloudChannel;
        }
    } else {
        qWarning() << "Gas cloud processing failed for channel" << m_currentGasCloudChannel << ":" << errorMessage;
    }
}

void PlayerManager::cleanup()
{
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "Cleaning up PlayerManager...";
    
    // 停止所有播放器
    stopAllPlayers();
    
    // 销毁所有播放器（清理缓冲池）
    for (auto it = m_players.begin(); it != m_players.end(); ++it) {
        destroyPlayerAtIndex(it.key());
    }
    
    // 清理映射表
    m_channelToPlayerMap.clear();
    m_playerToChannelMap.clear();
    m_availablePlayerIndexes.clear();
    
    // 清理用于算法处理的FrameProvider
    for (auto it = m_algorithmVisibleProviders.begin(); it != m_algorithmVisibleProviders.end(); ++it) {
        delete it.value();
    }
    m_algorithmVisibleProviders.clear();
    
    for (auto it = m_algorithmInfraredProviders.begin(); it != m_algorithmInfraredProviders.end(); ++it) {
        delete it.value();
    }
    m_algorithmInfraredProviders.clear();
    
    m_initialized = false;
    qDebug() << "PlayerManager cleanup completed";
}

void PlayerManager::setFrameProviders(FrameProvider* visibleLightProvider, FrameProvider* infraredProvider)
{
    QMutexLocker locker(&m_mutex);
    
    // 为所有通道设置默认的FrameProvider
    for (int i = 0; i < m_maxChannels; ++i) {
        if (visibleLightProvider) {
            m_frameProviders[i][VisibleLightLive] = visibleLightProvider;
            m_frameProviders[i][VisibleLightRecord] = visibleLightProvider;
        }
        if (infraredProvider) {
            m_frameProviders[i][InfraredLive] = infraredProvider;
            m_frameProviders[i][InfraredRecord] = infraredProvider;
        }
    }
    
    qDebug() << "Set default FrameProviders for all channels";
}

void PlayerManager::setChannelFrameProvider(int channelIndex, bool isVisibleLight, FrameProvider* provider)
{
    // 向后兼容的方法
    PlayerType playerType = isVisibleLight ? VisibleLightLive : InfraredLive;
    setChannelFrameProvider(channelIndex, playerType, provider);
}

void PlayerManager::setChannelFrameProvider(int channelIndex, PlayerType playerType, FrameProvider* provider)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    m_frameProviders[channelIndex][playerType] = provider;
    qDebug() << "Set FrameProvider for channel" << channelIndex << "player type" << playerType;
}

FrameProvider* PlayerManager::getChannelFrameProvider(int channelIndex, PlayerType playerType)
{
    QMutexLocker locker(&m_mutex);
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return nullptr;
    }
    if (!m_frameProviders.contains(channelIndex)) {
        qWarning() << "No FrameProviders for channel" << channelIndex;
        return nullptr;
    }
    FrameProvider* provider = m_frameProviders[channelIndex].value(playerType, nullptr);
    if (provider) {
        QQmlEngine::setObjectOwnership(provider, QQmlEngine::CppOwnership);
    }
    return provider;
}

void PlayerManager::setPlayerUrl(int channelIndex, PlayerType playerType, const QString &url)
{
    if (channelIndex < 0) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    qDebug() << "Setting player URL for channel" << channelIndex << "player type" << playerType << "to:" << url;
    splayer* player = getPlayer(channelIndex, playerType);
    if (player && !url.isEmpty()) {
        player->prepare(url);
        player->play();
        
        // 使用映射表获取播放器索引来存储URL
        int playerIndex = getPlayerIndexForChannel(channelIndex);
        if (playerIndex >= 0) {
            m_playerUrls[playerIndex][playerType] = url;
        }
        emit playerUrlChanged(channelIndex, playerType, url);
    }
}

void PlayerManager::fastSwitchPlayerUrl(int channelIndex, PlayerType playerType, const QString &newUrl)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    
    splayer* player = getPlayer(channelIndex, playerType);
    if (player && !newUrl.isEmpty()) {
        qDebug() << "Fast switching player" << channelIndex << "type" << playerType << "to:" << newUrl;
        player->fastSwitchUrl(newUrl);
        // 使用映射表获取播放器索引来存储URL
        int playerIndex = getPlayerIndexForChannel(channelIndex);
        if (playerIndex >= 0) {
            m_playerUrls[playerIndex][playerType] = newUrl;
        }
        emit playerUrlChanged(channelIndex, playerType, newUrl);
    }
}

QString PlayerManager::getPlayerUrl(int channelIndex, PlayerType playerType)
{
    // 使用映射表获取播放器索引
    int playerIndex = getPlayerIndexForChannel(channelIndex);
    if (playerIndex >= 0 && m_playerUrls.contains(playerIndex) && m_playerUrls[playerIndex].contains(playerType)) {
        return m_playerUrls[playerIndex][playerType];
    }
    return QString();
}

bool PlayerManager::isPlayerPlaying(int channelIndex, PlayerType playerType)
{
    splayer* player = getPlayer(channelIndex, playerType);
    if (player) {
        return player->mediaStatus() == media_playing;
    }
    return false;
}

int PlayerManager::getPlayerStatus(int channelIndex, PlayerType playerType)
{
    splayer* player = getPlayer(channelIndex, playerType);
    if (player) {
        return static_cast<int>(player->mediaStatus());
    }
    return static_cast<int>(media_idle);
}

void PlayerManager::setTofDistance(int channelIndex, float distance)
{
    m_tofDistances[channelIndex] = distance;
}

float PlayerManager::getTofDistance(int channelIndex)
{
    return m_tofDistances.value(channelIndex, 0.0f);
}

int PlayerManager::allocatePlayerForChannel(int channelIndex)
{
    QMutexLocker locker(&m_mutex);
    
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return -1;
    }
    
    if (m_channelToPlayerMap.contains(channelIndex)) {
        return m_channelToPlayerMap[channelIndex];
    }
    
    int assignedIndex = -1;
    if (!m_availablePlayerIndexes.isEmpty()) {
        // 从可用索引池中取出一个索引
        assignedIndex = *m_availablePlayerIndexes.begin();
        m_availablePlayerIndexes.remove(assignedIndex);
    } else {
        // 如果没有可用的索引，则扩容
        assignedIndex = m_nextPlayerIndex++;
        createPlayerAtIndex(assignedIndex, channelIndex);
    }
    
    // 建立channel到playerIndex的映射
    m_channelToPlayerMap[channelIndex] = assignedIndex;
    m_playerToChannelMap[assignedIndex] = channelIndex;
    
    // 如果该索引没有预先创建的播放器，则创建
    if (!m_players.contains(assignedIndex)) {
        createPlayerAtIndex(assignedIndex, channelIndex);
    } else {
        // 更新已存在播放器的信号连接（缓冲池复用）
        for (auto it = m_players[assignedIndex].begin(); it != m_players[assignedIndex].end(); ++it) {
            splayer* player = it.value();
            if (player) {
                disconnect(player, nullptr, this, nullptr);
                connectPlayerSignals(player, channelIndex, it.key());
            }
        }
    }
    
    qDebug() << "Allocated playerIndex" << assignedIndex << "for channel" << channelIndex;
    return assignedIndex;
}

bool PlayerManager::swapChannelMapping(int sourceChannel, int targetChannel)
{
    // 如果任一通道未映射，先尝试分配映射
    if (!m_channelToPlayerMap.contains(sourceChannel)) {
        allocatePlayerForChannel(sourceChannel);
    }
    if (!m_channelToPlayerMap.contains(targetChannel)) {
        allocatePlayerForChannel(targetChannel);
    }

    // 加锁后再次确认映射是否存在，并执行交换
    QMutexLocker locker(&m_mutex);
    if (!m_channelToPlayerMap.contains(sourceChannel) || !m_channelToPlayerMap.contains(targetChannel)) {
        qWarning() << "One or both channels are not mapped:" << sourceChannel << targetChannel;
        return false;
    }

    int sourceIndex = m_channelToPlayerMap[sourceChannel];
    int targetIndex = m_channelToPlayerMap[targetChannel];

    // 交换映射
    m_channelToPlayerMap[sourceChannel] = targetIndex;
    m_channelToPlayerMap[targetChannel] = sourceIndex;
    m_playerToChannelMap[sourceIndex] = targetChannel;
    m_playerToChannelMap[targetIndex] = sourceChannel;

    // 更新玩家的信号连接
    for (auto it = m_players[sourceIndex].begin(); it != m_players[sourceIndex].end(); ++it) {
        splayer* player = it.value();
        if (player) {
            disconnect(player, nullptr, this, nullptr);
            connectPlayerSignals(player, targetChannel, it.key());
        }
    }
    for (auto it = m_players[targetIndex].begin(); it != m_players[targetIndex].end(); ++it) {
        splayer* player = it.value();
        if (player) {
            disconnect(player, nullptr, this, nullptr);
            connectPlayerSignals(player, sourceChannel, it.key());
        }
    }

    qDebug() << "Swapped channel mapping: source" << sourceChannel << "target" << targetChannel;
    return true;
}

void PlayerManager::releasePlayerForChannel(int channelIndex)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_channelToPlayerMap.contains(channelIndex)) {
        qWarning() << "Channel" << channelIndex << "is not mapped to any player";
        return;
    }
    qDebug() << "Releasing playerIndex" << m_channelToPlayerMap[channelIndex] << "for channel" << channelIndex;
    int playerIndex = m_channelToPlayerMap[channelIndex];
    
    // 停止并断开所有播放器，但保留在缓冲池中
    for (auto it = m_players[playerIndex].begin(); it != m_players[playerIndex].end(); ++it) {
        splayer* player = it.value();
        if (player) {
            player->stop();
            disconnect(player, nullptr, this, nullptr);
        }
    }
    
    // 移除映射
    m_channelToPlayerMap.remove(channelIndex);
    m_playerToChannelMap.remove(playerIndex);
    
    // 将playerIndex标记为可用
    m_availablePlayerIndexes.insert(playerIndex);
    
    qDebug() << "Released playerIndex" << playerIndex << "from channel" << channelIndex;
}

bool PlayerManager::isChannelMapped(int channelIndex) const
{
    return m_channelToPlayerMap.contains(channelIndex);
}

int PlayerManager::getPlayerIndexForChannel(int channelIndex) const
{
    return m_channelToPlayerMap.value(channelIndex, -1);
}

int PlayerManager::getChannelForPlayerIndex(int playerIndex) const
{
    return m_playerToChannelMap.value(playerIndex, -1);
}

QList<int> PlayerManager::getMappedChannels() const
{
    return m_channelToPlayerMap.keys();
}

QList<int> PlayerManager::getAvailablePlayerIndexes() const
{
    return m_availablePlayerIndexes.values();
}

void PlayerManager::createPlayerAtIndex(int playerIndex, int channelIndex)
{
    // 检查播放器是否已经存在（缓冲池复用）
    if (m_players.contains(playerIndex)) {
        if (channelIndex >= 0) {
            qDebug() << "Reusing existing players at index" << playerIndex << "for channel" << channelIndex;
            
            // 更新信号连接（因为channelIndex可能变化）
            for (auto it = m_players[playerIndex].begin(); it != m_players[playerIndex].end(); ++it) {
                splayer* player = it.value();
                if (player) {
                    // 先断开旧的信号连接
                    disconnect(player, nullptr, this, nullptr);
                    // 重新建立信号连接
                    connectPlayerSignals(player, channelIndex, it.key());
                }
            }
        }
        return;
    }
    
    // 创建新的播放器（首次创建或扩容）
    // 创建可见光实时播放器
    splayer* visiblePlayer = new splayer();
    QQmlEngine::setObjectOwnership(visiblePlayer, QQmlEngine::CppOwnership);
    connectPlayerSignals(visiblePlayer, channelIndex, PlayerType::VisibleLightLive);
    m_players[playerIndex][PlayerType::VisibleLightLive] = visiblePlayer;
    
    // 创建红外实时播放器
    splayer* infraredPlayer = new splayer();
    QQmlEngine::setObjectOwnership(infraredPlayer, QQmlEngine::CppOwnership);
    connectPlayerSignals(infraredPlayer, channelIndex, PlayerType::InfraredLive);
    m_players[playerIndex][PlayerType::InfraredLive] = infraredPlayer;
    
    // 创建可见光录像播放器
    splayer* visibleRecordPlayer = new splayer();
    QQmlEngine::setObjectOwnership(visibleRecordPlayer, QQmlEngine::CppOwnership);
    connectPlayerSignals(visibleRecordPlayer, channelIndex, PlayerType::VisibleLightRecord);
    m_players[playerIndex][PlayerType::VisibleLightRecord] = visibleRecordPlayer;
    
    // 创建红外录像播放器
    splayer* infraredRecordPlayer = new splayer();
    QQmlEngine::setObjectOwnership(infraredRecordPlayer, QQmlEngine::CppOwnership);
    connectPlayerSignals(infraredRecordPlayer, channelIndex, PlayerType::InfraredRecord);
    m_players[playerIndex][PlayerType::InfraredRecord] = infraredRecordPlayer;
    
    if (channelIndex >= 0) {
        qDebug() << "Created new players at index" << playerIndex << "for channel" << channelIndex;
    } else {
        qDebug() << "Created new players at index" << playerIndex << "for buffer pool";
    }
}

void PlayerManager::destroyPlayerAtIndex(int playerIndex)
{
    if (!m_players.contains(playerIndex)) {
        return;
    }
    qDebug() << "Destroying players at index" << playerIndex;
    // 停止并删除所有播放器类型
    for (auto it = m_players[playerIndex].begin(); it != m_players[playerIndex].end(); ++it) {
        splayer* player = it.value();
        if (player) {
            player->stop();
            player->deleteLater();
        }
    }
    
    // 移除播放器映射
    m_players.remove(playerIndex);
    
    qDebug() << "Destroyed players at index" << playerIndex;
}

void PlayerManager::cleanupDeviceChannels(const QString& deviceId)
{
    DeviceModel* deviceModel = DeviceModel::instance();
    int channelIndex = deviceModel->getDeviceChannelIndex(deviceId);
    if (channelIndex >= 0) {
        releasePlayerForChannel(channelIndex);
    }
}

// 微漏模式相关方法实现
void PlayerManager::setMicroLeakMode(int channelIndex, bool enabled)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) {
        qWarning() << "Invalid channel index:" << channelIndex;
        return;
    }
    
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "=== setMicroLeakMode called ===";
    qDebug() << "Channel:" << channelIndex << "enabled:" << enabled;
    
    bool previousMode = m_microLeakMode.value(channelIndex, false);
    m_microLeakMode[channelIndex] = enabled;
    
    if (previousMode && !enabled) {
        // Cleaning up
        FrameProvider* provider = getMicroLeakProvider(channelIndex);
        if (provider) {
            provider->onNewVideoContentReceived(QVideoFrame());
        }
        if (m_currentMicroLeakChannel == channelIndex) {
            m_currentMicroLeakChannel = -1;
        }
    }
    
    emit microLeakModeChanged(channelIndex, enabled);
}

bool PlayerManager::isMicroLeakMode(int channelIndex) const
{
    return m_microLeakMode.value(channelIndex, false);
}

FrameProvider* PlayerManager::getMicroLeakProvider(int channelIndex)
{
    return m_microLeakProviders.value(channelIndex, nullptr);
}

void PlayerManager::setMicroLeakProvider(int channelIndex, FrameProvider* provider)
{
    if (channelIndex < 0 || channelIndex >= m_maxChannels) return;
    QMutexLocker locker(&m_mutex);
    m_microLeakProviders[channelIndex] = provider;
}

void PlayerManager::triggerMicroLeak(int channelIndex, const QVideoFrame& frame)
{
    // Check if provider exists
    if (!getMicroLeakProvider(channelIndex)) return;

    // Use MicroLeakManager
    MicroLeakManager* manager = MicroLeakManager::instance();
    if (manager && manager->isAvailable()) {
        m_currentMicroLeakChannel = channelIndex;
        
        // Extract YUV from frame (reuse existing helper)
        int w, h;
        QByteArray yuv = extractYUVData(frame, w, h);
        if (!yuv.isEmpty()) {
            QByteArray nv12 = convertYUV420PToNV12(yuv, w, h);
            if (!nv12.isEmpty()) {
                 manager->processAsync(nv12, w, h, 0.0f); // TDLAS passed as 0 for now or fetch from device
            }
        }
    }
}

void PlayerManager::onMicroLeakCompleted(const QImage& resultImage, bool success)
{
    if (success && !resultImage.isNull()) {
        FrameProvider* provider = getMicroLeakProvider(m_currentMicroLeakChannel);
        if (provider) {
            QVideoFrame frame = imageToVideoFrame(resultImage);
            if (frame.isValid()) {
                provider->onNewVideoContentReceived(frame);
            }
        }
    }
}

