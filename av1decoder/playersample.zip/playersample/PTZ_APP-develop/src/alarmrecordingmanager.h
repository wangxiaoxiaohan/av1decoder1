#ifndef ALARMRECORDINGMANAGER_H
#define ALARMRECORDINGMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QVariantList>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QDir>
#include <QStandardPaths>
#include <QJsonObject>
#include <QJsonArray>
#include <QTimer>
#include <QMap>

// Forward declarations
class HikvisionRecorder;
class QTimer;

struct AlarmRecordingEntry {
    int id;                     // 数据库ID
    QString device_code;        // 设备编号
    QString device_name;        // 设备名称
    QString start_time;         // 开始时间
    QString end_time;           // 结束时间
    QString alarm_type;         // 报警类型 (气体报警)
    QString concentration;      // 气体浓度
    QString position;           // 位置信息
    int duration_seconds;       // 录制时长（秒）
    QString created_at;         // 创建时间
    
    QJsonObject toJson() const;
};

// 设备报警状态结构
struct DeviceAlarmState {
    bool isRecording;           // 是否正在录制
    QTimer* stopTimer;          // 停止定时器
    QString currentStartTime;   // 当前录制开始时间
    int extendCount;            // 延长次数
    
    DeviceAlarmState() : isRecording(false), stopTimer(nullptr), extendCount(0) {}
};

class AlarmRecordingManager : public QObject
{
    Q_OBJECT
public:
    static AlarmRecordingManager* instance();

    // QML可调用的接口
    Q_INVOKABLE void startAlarmRecording(const QString& deviceCode, const QString& deviceName, 
                                        const QString& concentration, const QString& position);
    Q_INVOKABLE void stopAlarmRecording(const QString& deviceCode);
    Q_INVOKABLE bool isRecording(const QString& deviceCode);
    
    // 查询接口
    Q_INVOKABLE QVariantList queryRecordings(const QString& deviceCode, 
                                           const QString& startDate = "", 
                                           const QString& endDate = "");
    Q_INVOKABLE QVariantList queryRecordingsForDate(const QString& deviceCode, const QDate& date);
    Q_INVOKABLE QVariantMap getRecordingStats(const QString& deviceCode);
    
    // 删除接口
    Q_INVOKABLE bool deleteRecording(int id);
    Q_INVOKABLE bool deleteAllRecordings(const QString& deviceCode = "");
    
    // 获取当前录制状态
    Q_INVOKABLE QVariantMap getCurrentRecording(const QString& deviceCode);

    // 处理气体报警 - 这是主要的接口
    Q_INVOKABLE void handleGasAlarm(const QString& deviceCode, const QString& deviceName,
                                   const QString& concentration, const QString& position);

signals:
    void recordingStarted(const QString& deviceCode, const QString& startTime, const QString& concentration);
    void recordingStopped(const QString& deviceCode, const QString& endTime, int duration);
    void recordingExtended(const QString& deviceCode, const QString& newEndTime);
    void recordingAdded();
    void recordingDeleted();

private slots:
    void onStopTimerTimeout(const QString& deviceCode);

private:
    explicit AlarmRecordingManager(QObject* parent = nullptr);
    static AlarmRecordingManager* m_instance;
    QSqlDatabase m_db;
    QMap<QString, DeviceAlarmState*> m_deviceStates;  // 设备状态映射
    HikvisionRecorder* m_hikvisionRecorder;  // 海康录像下载器

    void initDatabase();
    AlarmRecordingEntry fromQuery(const QSqlQuery& query);
    QString getCurrentRecordingStartTime(const QString& deviceCode);
    void extendRecording(const QString& deviceCode);
    void stopRecordingInternal(const QString& deviceCode);
    DeviceAlarmState* getDeviceState(const QString& deviceCode);
    void cleanupDeviceState(const QString& deviceCode);
    void downloadRecordingFromNvr(const QString& deviceCode, const QDateTime& startTime, const QDateTime& endTime, const QString& alarmName = "");
};

#endif // ALARMRECORDINGMANAGER_H