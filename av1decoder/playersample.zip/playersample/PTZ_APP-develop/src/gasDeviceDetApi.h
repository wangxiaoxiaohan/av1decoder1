#ifndef GAS_DEVICE_DET_API_H
#define GAS_DEVICE_DET_API_H
#if (_WIN32)
#ifdef GASDET_API_EXPORTS
#define GASDET_API __declspec(dllexport)
#else
#define GASDET_API __declspec(dllimport)
#endif
#else
#define GASDET_API __attribute__((visibility("default")))
#endif

/* 创建模型
    @param cfg_path: 模型配置文件路径
    @return: 模型句柄
*/
extern "C" GASDET_API void *gasDeviceDet_create(const char *cfg_path);
/* 销毁模型
    @param handle: 模型句柄
*/
extern "C" GASDET_API void gasDeviceDet_destroy(void **handle);
/* 检测气体
    @param handle: 模型句柄
    @param data: 图像数据, YUV420
    @param width: 图像宽度
    @param height: 图像高度
    @channel： 图像通道总数，yuv格式传1
    @tdlas_x：tdlas光标横坐标，调试时可直接输入图像中心坐标，在图像中的坐标，不是屏幕
    @tdlas_y：tdlas光标纵坐标
    @out_x：  输出横坐标
    @out_y：	 输出纵坐标
    @return: 0-执行成功，其他失败
*/
extern "C" GASDET_API int gasDeviceDet_detect(void *handle, unsigned char *data, int width, int height, int channel,
                                              int tdlas_x, int tdlas_y, int *out_x, int *out_y);

#endif // !GAS_DET_API_H
