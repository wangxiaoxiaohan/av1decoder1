#ifndef DEVICE_PROXY_H
#define DEVICE_PROXY_H

#include <QObject>
#include <QString>
#include <QList>
#include "ptz_device_manager.h"
#include "thermal_device_manager.h"
#include "thermal_ctl.h"

class DeviceProxy : public QObject
{
    Q_OBJECT

public:
    explicit DeviceProxy(QObject* parent = nullptr);
    
    // PTZ设备代理方法
    Q_INVOKABLE void mvTurnUp();
    Q_INVOKABLE void mvTurnDown();
    Q_INVOKABLE void mvTurnLeft();
    Q_INVOKABLE void mvTurnRight();
    Q_INVOKABLE void mvTurnStop();
    Q_INVOKABLE void mvDirectionTurnStop();
    Q_INVOKABLE void mvSetZoomIn(int val);
    Q_INVOKABLE void mvSetFocus(int val);
    Q_INVOKABLE void mvSetAperture(int val);
    Q_INVOKABLE void mvSetPreset(int id);
    Q_INVOKABLE void mvCallPreset(int id);
    Q_INVOKABLE void mvDeletePreset(int id);
    Q_INVOKABLE void mvSetCruiseScan(const QString &cruiseNumber, const QVariantList &presetPoints);
    Q_INVOKABLE void stopCruise();
    Q_INVOKABLE void mvSetLight(bool val);
    Q_INVOKABLE void mvSetWiper(bool val);
    Q_INVOKABLE void mvSetAssiFocus(bool val);
    Q_INVOKABLE void mvSetInfFlap(bool val);
    Q_INVOKABLE void mvTurnOnLaser();
    Q_INVOKABLE void mvTurnOffLaser();
    Q_INVOKABLE bool mvReboot();
    Q_INVOKABLE bool mvFactoryReset(bool retain_network);
    Q_INVOKABLE QList<int> getConcetList();
    Q_INVOKABLE void mvModifyImageSettings(int bright, int contrac, int saturation, int sharpness, int hlc, int blc, int nr2d, int nr3d, int tvsystem, int antificker);
    Q_INVOKABLE QVariantMap mvGetImageSettings();
    Q_INVOKABLE void mvModifyVideoSettings(QString encode_mode, QString resolution, QString framerate, QString govlength, QString bitrate, QString bitrate_control, int index);
    Q_INVOKABLE void mvModifyAudioSettings(bool enable_1, QString encode_type, QString samplerate, QString bitrate, QString input_volume, QString output_volume, QString amplify);
    Q_INVOKABLE QVariantMap mvGetVideoEncoderCapabilities(int streamIndex);
    Q_INVOKABLE QVariantMap mvGetAudioEncoderCapabilities();
    Q_INVOKABLE QVariantMap mvGetEventStorageConfig();
    Q_INVOKABLE void mvSetSpeed(int speed);
    Q_INVOKABLE QVariantMap mvGetMotionDetectConfig();
    Q_INVOKABLE void mvConfigUserOSD(int title_index, int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8);
    Q_INVOKABLE void mvConfigOSD(int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8);
    Q_INVOKABLE void mvConfigTimeOSD(int enable, int show_week, QString time_format, int title_pos_x, int title_pos_y);
    Q_INVOKABLE void mvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway, QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns, QString dns);
    Q_INVOKABLE void mvLoadNetworkConfig();
    Q_INVOKABLE void mvSetAlarmDetectionDuration(int durationMs);
    Q_INVOKABLE void mvSetCruiseIntervalDuration(int durationMs);

    // 热成像设备代理方法
    Q_INVOKABLE void setPseudoMode(int mode);
    Q_INVOKABLE void setFocusZoom(int channel, int digitalZoom, bool debug = false);
    Q_INVOKABLE void enhanceInfraRed(bool brightMutation = true, bool denoise2DEnable = true, int denoise2DLevel = 2,
                                    bool denoise3DEnable = true, int denoise3DLevel = 3, bool ddeEnable = true, int ddeLevel = 4,
                                    int flipMode = 4, bool regionalEnable = true, int regionalLevel = 4,
                                    int coordX = 4, int coordY = 4);
    Q_INVOKABLE void setThermalImageParams(int brightness, int contrast, int flipMode = 0);
    Q_INVOKABLE QJsonObject getThermalImageParams(bool defaultConfig = false);
    Q_INVOKABLE void rebootThermal();
    Q_INVOKABLE void factoryResetThermal();
    
    // 红外镜头PTZ操作
    Q_INVOKABLE void ptzOperation(int method);
    Q_INVOKABLE void ptzStopFocus();  // 红外镜头变倍聚焦停止
    
    // 获取当前设备的红外选中状态
    Q_INVOKABLE bool getCurrentDeviceInfraredSelected();
    
    // 设备管理方法
    Q_INVOKABLE void setCurrentDevice(const QString &deviceId);
    Q_INVOKABLE QString getCurrentDeviceId();
    Q_INVOKABLE bool isDeviceInitialized(const QString &deviceId);
    Q_INVOKABLE QStringList getInitializedDevices();
    
    // 扫描状态管理方法
    Q_INVOKABLE void setLineScanActive(bool active);
    Q_INVOKABLE void setTrajectoryScanActive(bool active);
    Q_INVOKABLE void currentScanModeChanged(int scanMode);
    Q_INVOKABLE void onRequestStopScanForGasAlarm();
    Q_INVOKABLE void onRequestResumeScanAfterGasAlarm(int scanMode);
    Q_INVOKABLE void onCurrentScanModeReceived(int scanMode);
    Q_INVOKABLE void onGasAlarmStateChanged(bool isActive);

signals:
    void networkConfigLoaded(const QVariantMap& config);
    void networkConfigLoadFailed(const QString& error);
    void networkPropertyModified(bool success, const QString& newIp);

private:
    PtzDeviceManager* m_ptzManager;
    ThermalDeviceManager* m_thermalManager;
};

#endif // DEVICE_PROXY_H
 