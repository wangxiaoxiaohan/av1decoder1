#ifndef DEVICE_PROXY_H
#define DEVICE_PROXY_H

#include <QObject>
#include <QString>
#include <QList>
#include "ptz_device_manager.h"
#include "thermal_device_manager.h"
#include "thermal_ctl.h"

class DeviceProxy : public QObject
{
    Q_OBJECT

public:
    explicit DeviceProxy(QObject* parent = nullptr);
    
    // PTZ设备代理方法
    Q_INVOKABLE void mvTurnUp();
    Q_INVOKABLE void mvTurnDown();
    Q_INVOKABLE void mvTurnLeft();
    Q_INVOKABLE void mvTurnRight();
    Q_INVOKABLE void mvTurnStop();
    Q_INVOKABLE void mvDirectionTurnStop();
    Q_INVOKABLE void mvSetZoomIn(int val);
    Q_INVOKABLE void mvSetFocus(int val);
    Q_INVOKABLE void mvSetAperture(int val);
    Q_INVOKABLE void mvSetPreset(int id);
    Q_INVOKABLE void mvCallPreset(int id);
    Q_INVOKABLE void mvDeletePreset(int id);
    Q_INVOKABLE void mvSetCruiseScan(const QString &cruiseNumber, const QVariantList &presetPoints);
    Q_INVOKABLE void mvSetLight(bool val);
    Q_INVOKABLE void mvSetWiper(bool val);
    Q_INVOKABLE void mvSetAssiFocus(bool val);
    Q_INVOKABLE void mvSetInfFlap(bool val);
    Q_INVOKABLE bool mvReboot();
    Q_INVOKABLE bool mvFactoryReset(bool retain_network);
    Q_INVOKABLE QList<int> getConcetList();
    Q_INVOKABLE void mvModifyImageSettings(int bright, int contrac, int saturation, int sharpness, int hlc, int blc, int nr2d, int nr3d, int tvsystem, int antificker);
    
    // 热成像设备代理方法
    Q_INVOKABLE void setPseudoMode(int mode);
    Q_INVOKABLE void setFocusZoom(int channel, int digitalZoom, bool debug = false);
    Q_INVOKABLE void enhanceInfraRed(bool brightMutation = true, bool denoise2DEnable = true, int denoise2DLevel = 2,
                                    bool denoise3DEnable = true, int denoise3DLevel = 3, bool ddeEnable = true, int ddeLevel = 4,
                                    int flipMode = 4, bool regionalEnable = true, int regionalLevel = 4,
                                    int coordX = 4, int coordY = 4);
    Q_INVOKABLE void setThermalImageParams(int brightness, int contrast, int flipMode = 0);
    Q_INVOKABLE void rebootThermal();
    Q_INVOKABLE void factoryResetThermal();
    
    // 红外镜头PTZ操作
    Q_INVOKABLE void ptzOperation(int method);
    Q_INVOKABLE void ptzStopFocus();  // 红外镜头变倍聚焦停止
    
    // 获取当前设备的红外选中状态
    Q_INVOKABLE bool getCurrentDeviceInfraredSelected();
    
    // 设备管理方法
    Q_INVOKABLE void setCurrentDevice(const QString &deviceId);
    Q_INVOKABLE QString getCurrentDeviceId();
    Q_INVOKABLE bool isDeviceInitialized(const QString &deviceId);
    Q_INVOKABLE QStringList getInitializedDevices();

private:
    PtzDeviceManager* m_ptzManager;
    ThermalDeviceManager* m_thermalManager;
};

#endif // DEVICE_PROXY_H 
 