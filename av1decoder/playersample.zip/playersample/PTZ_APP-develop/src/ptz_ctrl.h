//
// Created by Chian on 10/23/2024.
//

#ifndef QUICKGAS_PTZ_CTRL_H
#define QUICKGAS_PTZ_CTRL_H

#include <QObject>
#include "absl/container/flat_hash_map.h"
#include "ptz_device.h"

using namespace std;

class PtzCtrl : public QObject{
    Q_OBJECT
public:
    ~PtzCtrl();

    Q_INVOKABLE static PtzCtrl& moGetInstance();
    Q_INVOKABLE PtzDevice* moGetDiviceById(string device_id);
    Q_INVOKABLE PtzDevice* moGetCurrentDevice();
    Q_INVOKABLE int moGetCurrentDeviceTest();
    Q_INVOKABLE void mvSelectDevice(string device_id);
    Q_INVOKABLE void mvAddDevice(PtzDevice* obj);
    Q_INVOKABLE void mvSendTest();

    Q_INVOKABLE void mvSetRotation(int dr, int speed);
    Q_INVOKABLE void mvSetZoomIn(int val);
    Q_INVOKABLE void mvSetFocus(int val);
    Q_INVOKABLE void mvSetAperture(int val);

    Q_INVOKABLE void mvSetLight(int val);
    Q_INVOKABLE void mvSetWiper(int val);
    Q_INVOKABLE void mvSetAssiFocus(int val);
    Q_INVOKABLE void mvSetInfFlap(int val);
    Q_INVOKABLE void mvSetRestore();
    Q_INVOKABLE void mvSetInfImgSettings(QVariantMap mp);

    Q_INVOKABLE void mvSetImgSettings(QVariantMap mp);
    Q_INVOKABLE void mvModifyExposureSettings(int mode, int exp_time);
    Q_INVOKABLE void mvModifyWhideDynamicRange(int mode, int lev, bool suppress);
    Q_INVOKABLE void mvModifyDayNightSwitchSettings(int mode, QString start, QString end);
    Q_INVOKABLE void mvModifyWhiteBalanceSettings(int mode, int red_gain, int blue_gain);
    Q_INVOKABLE void mvModifyImageEnhancement(bool noise_enable, int noise_level, bool fog_enable, bool stabilization, int gray);
    Q_INVOKABLE void mvModifyVideoAdjustment(int mirro, int stab);

    Q_INVOKABLE void mvModifyChnTitle(bool enable, QString chn_name);
    Q_INVOKABLE void mvModifyTimeStyle(bool enable, bool week_enable, int time_style, int date_style);
    Q_INVOKABLE void mvModifyPtzInfo(bool preposition, bool zoom_ratio, bool cruisescan, bool trackingscan, bool linescan);
    Q_INVOKABLE void mvModifyOverlapString(bool enable_1, QString str_1, bool enable_2, QString str_2, bool enable_3, QString str_3, bool enable_4, QString str_4);
    Q_INVOKABLE void mvModifyFontProperty(int font_size, int font_color, int font_alig);

    Q_INVOKABLE void mvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway, QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns, QString dns);

    Q_INVOKABLE void mvApplyOsdSettings();
    Q_INVOKABLE void mvApplyNetWorkSettings();

    PtzCtrl(const PtzCtrl&) = delete;
    PtzCtrl& operator=(const PtzCtrl&) = delete;
private:
//    PtzCtrl();
    PtzCtrl(QObject* parent = nullptr);
    map<string, PtzDevice*> device_list_;
    PtzDevice* current_device_;
//    static PtzCtrl* instance_;
};
#endif //QUICKGAS_PTZ_CTRL_H
