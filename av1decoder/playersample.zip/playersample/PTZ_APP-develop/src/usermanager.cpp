#include "usermanager.h"
#include "filemanager.h"
#include "systemlog.h"
#include "model/devicemodel.h"
#include <QJsonDocument>
#include <QJsonArray>
#include <QStandardPaths>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <QApplication>

// UserPermissions 实现
QJsonObject UserPermissions::toJson() const {
    QJsonObject obj;
    obj["deviceManage"] = deviceManage;
    obj["systemConfig"] = systemConfig;
    obj["ptzControl"] = ptzControl;
    obj["video"] = video;
    obj["record"] = record;
    obj["snapshot"] = snapshot;
    obj["exitClient"] = exitClient;
    obj["voiceIntercom"] = voiceIntercom;
    obj["viewAlarmRecord"] = viewAlarmRecord;
    return obj;
}

void UserPermissions::fromJson(const QJsonObject& json) {
    deviceManage = json["deviceManage"].toBool(false);
    systemConfig = json["systemConfig"].toBool(false);
    ptzControl = json["ptzControl"].toBool(false);
    video = json["video"].toBool(false);
    record = json["record"].toBool(false);
    snapshot = json["snapshot"].toBool(false);
    exitClient = json["exitClient"].toBool(false);
    voiceIntercom = json["voiceIntercom"].toBool(false);
    viewAlarmRecord = json["viewAlarmRecord"].toBool(false);
}

// UserInfo 实现
QJsonObject UserInfo::toJson() const {
    QJsonObject obj;
    obj["username"] = username;
    obj["password"] = password;
    obj["userType"] = userType;
    obj["description"] = description;
    obj["canDelete"] = canDelete;
    obj["permissions"] = permissions.toJson();
    return obj;
}

void UserInfo::fromJson(const QJsonObject& json) {
    username = json["username"].toString();
    password = json["password"].toString();
    userType = json["userType"].toString();
    description = json["description"].toString();
    canDelete = json["canDelete"].toBool(true);
    if (json.contains("permissions")) {
        permissions.fromJson(json["permissions"].toObject());
    }
}

QVariantMap UserInfo::toVariantMap() const {
    QVariantMap map;
    map["username"] = username;
    map["password"] = password;
    map["userType"] = userType;
    map["description"] = description;
    map["canDelete"] = canDelete;
    
    QVariantMap permMap;
    permMap["deviceManage"] = permissions.deviceManage;
    permMap["systemConfig"] = permissions.systemConfig;
    permMap["ptzControl"] = permissions.ptzControl;
    permMap["video"] = permissions.video;
    permMap["record"] = permissions.record;
    permMap["snapshot"] = permissions.snapshot;
    permMap["exitClient"] = permissions.exitClient;
    permMap["voiceIntercom"] = permissions.voiceIntercom;
    permMap["viewAlarmRecord"] = permissions.viewAlarmRecord;
    map["permissions"] = permMap;
    
    return map;
}

// UserManager 实现
UserManager* UserManager::m_instance = nullptr;

UserManager* UserManager::instance() {
    if (!m_instance) {
        m_instance = new UserManager();
    }
    return m_instance;
}

UserManager::UserManager(QObject* parent) : QObject(parent) {
    loadUserList();
    if (m_userList.isEmpty()) {
        initDefaultUsers();
    }
    
    // 默认选中第一个用户
    if (!m_userList.isEmpty()) {
        m_currentUser = m_userList.first();
    }
}

void UserManager::setCurrentUser(const QString& username) {
    for (const auto& user : m_userList) {
        if (user.username == username) {
            m_currentUser = user;
            emit currentUserChanged();
            qDebug() << "当前用户已切换到:" << username;
            return;
        }
    }
    qWarning() << "用户不存在:" << username;
}

QString UserManager::getCurrentUsername() const {
    return m_currentUser.username;
}

QVariantMap UserManager::getCurrentUserInfo() const {
    return m_currentUser.toVariantMap();
}

bool UserManager::updateCurrentUser(const QVariantMap& userInfo) {
    if (m_currentUser.username.isEmpty()) {
        qWarning() << "没有选中的用户";
        return false;
    }
    
    // 更新当前用户信息
    QString oldUsername = m_currentUser.username;
    QString newUsername = userInfo["username"].toString();
    m_currentUser.username = newUsername;
    m_currentUser.userType = userInfo["userType"].toString();
    m_currentUser.description = userInfo["description"].toString();
    
    // 更新密码
    if (userInfo.contains("password")) {
        m_currentUser.password = userInfo["password"].toString();
    }
    
    // 更新权限
    if (userInfo.contains("permissions")) {
        QVariantMap permMap = userInfo["permissions"].toMap();
        m_currentUser.permissions.deviceManage = permMap["deviceManage"].toBool();
        m_currentUser.permissions.systemConfig = permMap["systemConfig"].toBool();
        m_currentUser.permissions.ptzControl = permMap["ptzControl"].toBool();
        m_currentUser.permissions.video = permMap["video"].toBool();
        m_currentUser.permissions.record = permMap["record"].toBool();
        m_currentUser.permissions.snapshot = permMap["snapshot"].toBool();
        m_currentUser.permissions.exitClient = permMap["exitClient"].toBool();
        m_currentUser.permissions.voiceIntercom = permMap["voiceIntercom"].toBool();
        m_currentUser.permissions.viewAlarmRecord = permMap["viewAlarmRecord"].toBool();
    }
    
    // 更新用户列表中的对应项
    for (int i = 0; i < m_userList.size(); ++i) {
        if (m_userList[i].username == oldUsername) {
            m_userList[i] = m_currentUser;
            break;
        }
    }
    
    emit currentUserChanged();
    emit userUpdated(m_currentUser.username);
    qDebug() << "用户信息已在内存中更新:" << m_currentUser.username;
    
    return true;
}

bool UserManager::updateCurrentUserAndSave(const QVariantMap& userInfo)
{
    // 记录原用户名，用于删除旧文件
    QString oldUsername = m_currentUser.username;
    
    if (!updateCurrentUser(userInfo)) {
        return false;
    }
    
    // 如果用户名发生变化，删除旧的用户文件
    if (oldUsername != m_currentUser.username) {
        QString appDir = QApplication::applicationDirPath();
        QString oldConfigPath = appDir + "/config/user/" + oldUsername + ".json";
        QFile oldFile(oldConfigPath);
        if (oldFile.exists()) {
            if (oldFile.remove()) {
                qDebug() << "旧用户文件删除成功:" << oldConfigPath;
            } else {
                qWarning() << "旧用户文件删除失败:" << oldConfigPath;
            }
        }
    }
    
    // 保存到文件
    bool success = saveUserToFile(m_currentUser);
    if (success) {
        saveUserList();
        qDebug() << "用户信息更新成功:" << m_currentUser.username;
        
        // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        QString logDescription = QString("修改用户信息：%1").arg(m_currentUser.username);
        
        SystemLog::instance()->addLog(
            getCurrentUsername(),
            LOG_TYPE_OPERATION,
            ACTION_TYPE_MODIFY_ACCOUNT,
            currentTime,
            "127.0.0.1",
            RESULT_SUCCESS,
            logDescription
        );
    } else {
        qWarning() << "用户信息保存失败:" << m_currentUser.username;
        
        // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        QString logDescription = QString("修改用户信息失败：%1").arg(m_currentUser.username);
        
        SystemLog::instance()->addLog(
            getCurrentUsername(),
            LOG_TYPE_OPERATION,
            ACTION_TYPE_MODIFY_ACCOUNT,
            currentTime,
            "127.0.0.1",
            RESULT_FAILURE,
            logDescription
        );
    }
    
    return success;
}

QVariantList UserManager::getUserList() const {
    QVariantList list;
    for (const auto& user : m_userList) {
        QVariantMap userMap;
        userMap["username"] = user.username;
        userMap["description"] = user.description;
        userMap["userType"] = user.userType;
        userMap["canDelete"] = user.canDelete;
        list.append(userMap);
    }
    return list;
}

QVariantMap UserManager::getUserInfo(const QString& username) const {
    for (const auto& user : m_userList) {
        if (user.username == username) {
            return user.toVariantMap();
        }
    }
    return QVariantMap(); // 返回空的QVariantMap如果用户不存在
}

bool UserManager::addUser(const QVariantMap& userInfo)
{
    QString username = userInfo["username"].toString();
    if (userExists(username)) {
        qWarning() << "用户已存在:" << username;
        return false;
    }
    
    UserInfo newUser;
    newUser.username = username;
    newUser.password = userInfo["password"].toString();
    newUser.userType = userInfo["userType"].toString();
    newUser.canDelete = true;
    
    // 设置默认权限
    newUser.permissions.deviceManage = true;
    newUser.permissions.systemConfig = true;
    newUser.permissions.ptzControl = true;
    newUser.permissions.video = true;
    newUser.permissions.record = true;
    newUser.permissions.snapshot = true;
    newUser.permissions.exitClient = true;
    newUser.permissions.voiceIntercom = true;
    newUser.permissions.viewAlarmRecord = true;
    
    m_userList.append(newUser);
    
    emit userListChanged();
    emit userAdded(username);
    
    qDebug() << "新用户已添加到内存:" << username;
    
    return true;
}

bool UserManager::deleteUser(const QString& username) {
    if (username == "admin") {
        qWarning() << "不能删除admin用户";
        
        // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        QString operationIp = "127.0.0.1";
        QString selectedDeviceIp = DeviceModel::instance()->getSelectedDeviceVisibleLightIp();
        if (!selectedDeviceIp.isEmpty()) {
            operationIp = selectedDeviceIp;
        }
        SystemLog::instance()->addLog(
            getCurrentUsername(),                           // 操作账户
            LOG_TYPE_OPERATION,                            // 日志类型：操作日志
            ACTION_TYPE_DELETE_ACCOUNT,                    // 操作类型：删除账户
            currentTime,                                   // 操作时间
            operationIp,                                   // 操作IP
            RESULT_FAILURE,                                // 操作结果：失败
            QString("删除用户失败：不能删除admin用户")        // 操作描述
        );
        
        return false;
    }
    
    for (int i = 0; i < m_userList.size(); ++i) {
        if (m_userList[i].username == username) {
            if (!m_userList[i].canDelete) {
                qWarning() << "用户不能删除:" << username;
                
                // 记录系统日志
                QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
                QString operationIp = "127.0.0.1";
        QString selectedDeviceIp = DeviceModel::instance()->getSelectedDeviceVisibleLightIp();
        if (!selectedDeviceIp.isEmpty()) {
            operationIp = selectedDeviceIp;
        }
                SystemLog::instance()->addLog(
                    getCurrentUsername(),                           // 操作账户
                    LOG_TYPE_OPERATION,                            // 日志类型：操作日志
                    ACTION_TYPE_DELETE_ACCOUNT,                    // 操作类型：删除账户
                    currentTime,                                   // 操作时间
                    operationIp,                                   // 操作IP
                    RESULT_FAILURE,                                // 操作结果：失败
                    QString("删除用户失败：用户%1不能删除").arg(username)  // 操作描述
                );
                
                return false;
            }
            
            m_userList.removeAt(i);
            
            // 删除用户配置文件
            QString appDir = QApplication::applicationDirPath();
            QString configPath = appDir + "/config/user/" + username + ".json";
            QFile::remove(configPath);
            
            saveUserList();
            emit userListChanged();
            emit userDeleted(username);
            
            // 如果删除的是当前用户，切换到第一个用户
            if (m_currentUser.username == username && !m_userList.isEmpty()) {
                m_currentUser = m_userList.first();
                emit currentUserChanged();
            }
            
            qDebug() << "用户删除成功:" << username;
            
            // 记录系统日志
            QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
            QString operationIp = "127.0.0.1";
            QString selectedDeviceIp = DeviceModel::instance()->getSelectedDeviceVisibleLightIp();
            if (!selectedDeviceIp.isEmpty()) {
                operationIp = selectedDeviceIp;
            }
            SystemLog::instance()->addLog(
                getCurrentUsername(),                           // 操作账户
                LOG_TYPE_OPERATION,                            // 日志类型：操作日志
                ACTION_TYPE_DELETE_ACCOUNT,                    // 操作类型：删除账户
                currentTime,                                   // 操作时间
                operationIp,                                   // 操作IP
                RESULT_SUCCESS,                                // 操作结果：成功
                QString("删除用户：%1").arg(username)            // 操作描述
            );
            
            return true;
        }
    }
    
    qWarning() << "用户不存在:" << username;
    
    // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        QString operationIp = "127.0.0.1";
        QString selectedDeviceIp = DeviceModel::instance()->getSelectedDeviceVisibleLightIp();
        if (!selectedDeviceIp.isEmpty()) {
            operationIp = selectedDeviceIp;
        }
        SystemLog::instance()->addLog(
            getCurrentUsername(),                           // 操作账户
            LOG_TYPE_OPERATION,                            // 日志类型：操作日志
            ACTION_TYPE_DELETE_ACCOUNT,                    // 操作类型：删除账户
            currentTime,                                   // 操作时间
            operationIp,                                   // 操作IP
            RESULT_FAILURE,                                // 操作结果：失败
            QString("删除用户失败：用户%1不存在").arg(username)   // 操作描述
        );
    
    return false;
}

bool UserManager::userExists(const QString& username) const {
    for (const auto& user : m_userList) {
        if (user.username == username) {
            return true;
        }
    }
    return false;
}

QVariantMap UserManager::getCurrentUserPermissions() const {
    QVariantMap permMap;
    permMap["deviceManage"] = m_currentUser.permissions.deviceManage;
    permMap["systemConfig"] = m_currentUser.permissions.systemConfig;
    permMap["ptzControl"] = m_currentUser.permissions.ptzControl;
    permMap["video"] = m_currentUser.permissions.video;
    permMap["record"] = m_currentUser.permissions.record;
    permMap["snapshot"] = m_currentUser.permissions.snapshot;
    permMap["exitClient"] = m_currentUser.permissions.exitClient;
    permMap["voiceIntercom"] = m_currentUser.permissions.voiceIntercom;
    permMap["viewAlarmRecord"] = m_currentUser.permissions.viewAlarmRecord;
    return permMap;
}

bool UserManager::updateCurrentUserPermissions(const QVariantMap& permissions) {
    m_currentUser.permissions.deviceManage = permissions["deviceManage"].toBool();
    m_currentUser.permissions.systemConfig = permissions["systemConfig"].toBool();
    m_currentUser.permissions.ptzControl = permissions["ptzControl"].toBool();
    m_currentUser.permissions.video = permissions["video"].toBool();
    m_currentUser.permissions.record = permissions["record"].toBool();
    m_currentUser.permissions.snapshot = permissions["snapshot"].toBool();
    m_currentUser.permissions.exitClient = permissions["exitClient"].toBool();
    m_currentUser.permissions.voiceIntercom = permissions["voiceIntercom"].toBool();
    m_currentUser.permissions.viewAlarmRecord = permissions["viewAlarmRecord"].toBool();
    
    // 更新用户列表中的对应项
    for (int i = 0; i < m_userList.size(); ++i) {
        if (m_userList[i].username == m_currentUser.username) {
            m_userList[i].permissions = m_currentUser.permissions;
            break;
        }
    }
    
    bool success = saveUserToFile(m_currentUser);
    if (success) {
        emit currentUserChanged();
        emit userUpdated(m_currentUser.username);
        qDebug() << "用户权限更新成功:" << m_currentUser.username;
    } else {
        qWarning() << "用户权限保存失败:" << m_currentUser.username;
    }
    
    return success;
}

bool UserManager::validatePassword(const QString& username, const QString& password) const {
    // 查找用户并验证密码
    for (const auto& user : m_userList) {
        if (user.username == username) {
            return user.password == password;
        }
    }
    return false;
}

bool UserManager::updateCurrentUserPassword(const QString& newPassword) {
    if (m_currentUser.username.isEmpty()) {
        qWarning() << "没有选中的用户";
        return false;
    }
    
    QString oldUsername = m_currentUser.username;
    m_currentUser.password = newPassword;
    
    // 更新用户列表中的对应项
    for (int i = 0; i < m_userList.size(); ++i) {
        if (m_userList[i].username == oldUsername) {
            m_userList[i] = m_currentUser;
            break;
        }
    }
    
    // 保存到文件
    bool success = saveUserToFile(m_currentUser);
    if (success) {
        saveUserList();
        emit userUpdated(m_currentUser.username);
        qDebug() << "密码更新成功:" << m_currentUser.username;
    } else {
        qWarning() << "密码保存失败:" << m_currentUser.username;
    }
    
    return success;
}

void UserManager::loadUserList() {
    m_userList.clear();
    
    QString appDir = QApplication::applicationDirPath();
    QString userListPath = appDir + "/config/user/userlist.json";
    QFile file(userListPath);
    
    if (!file.exists()) {
        qDebug() << "用户列表文件不存在，将创建默认用户";
        return;
    }
    
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "无法打开用户列表文件:" << userListPath;
        return;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);
    
    if (error.error != QJsonParseError::NoError) {
        qWarning() << "用户列表文件解析失败:" << error.errorString();
        return;
    }
    
    QJsonArray userArray = doc.array();
    for (const auto& value : userArray) {
        UserInfo user;
        user.fromJson(value.toObject());
        m_userList.append(user);
    }
    
    qDebug() << "加载用户列表成功，共" << m_userList.size() << "个用户";
}

void UserManager::saveUserList() {
    QString appDir = QApplication::applicationDirPath();
    QString userDir = appDir + "/config/user";
    QDir().mkpath(userDir);
    
    QString userListPath = userDir + "/userlist.json";
    QFile file(userListPath);
    
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "无法创建用户列表文件:" << userListPath;
        return;
    }
    
    QJsonArray userArray;
    for (const auto& user : m_userList) {
        userArray.append(user.toJson());
    }
    
    QJsonDocument doc(userArray);
    file.write(doc.toJson());
    file.close();
    
    qDebug() << "用户列表保存成功:" << userListPath;
}

UserInfo UserManager::loadUserFromFile(const QString& username) const {
    UserInfo user;
    
    QString appDir = QApplication::applicationDirPath();
    QString configPath = appDir + "/config/user/" + username + ".json";
    QFile file(configPath);
    
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "无法打开用户配置文件:" << configPath;
        return user;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);
    
    if (error.error != QJsonParseError::NoError) {
        qWarning() << "用户配置文件解析失败:" << error.errorString();
        return user;
    }
    
    user.fromJson(doc.object());
    return user;
}

bool UserManager::saveUserToFile(const UserInfo& user) const {
    QString appDir = QApplication::applicationDirPath();
    QString userDir = appDir + "/config/user";
    QDir().mkpath(userDir);
    
    QString configPath = userDir + "/" + user.username + ".json";
    QFile file(configPath);
    
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "无法创建用户配置文件:" << configPath;
        return false;
    }
    
    QJsonDocument doc(user.toJson());
    file.write(doc.toJson());
    file.close();
    
    qDebug() << "用户配置保存成功:" << configPath;
    return true;
}

void UserManager::initDefaultUsers() {
    // 创建默认admin用户
    UserInfo adminUser;
    adminUser.username = "admin";
    adminUser.password = "123456";
    adminUser.userType = "管理员";
    adminUser.description = "默认为超级用户，不能删除";
    adminUser.canDelete = false;
    
    // 管理员默认全部权限
    adminUser.permissions.deviceManage = true;
    adminUser.permissions.systemConfig = true;
    adminUser.permissions.ptzControl = true;
    adminUser.permissions.video = true;
    adminUser.permissions.record = true;
    adminUser.permissions.snapshot = true;
    adminUser.permissions.exitClient = true;
    adminUser.permissions.voiceIntercom = true;
    adminUser.permissions.viewAlarmRecord = true;
    
    m_userList.append(adminUser);
    
    saveUserToFile(adminUser);
    saveUserList();
    
    qDebug() << "默认用户初始化完成";
}