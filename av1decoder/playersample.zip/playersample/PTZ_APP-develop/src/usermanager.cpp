#include "usermanager.h"
#include "filemanager.h"
#include "systemlog.h"
#include "model/devicemodel.h"
#include <QJsonDocument>
#include <QJsonArray>
#include <QStandardPaths>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <QApplication>

// UserPermissions 实现
QJsonObject UserPermissions::toJson() const {
    QJsonObject obj;
    
    // 用户管理权限
    obj["userManage"] = userManage;
    obj["createNormalUser"] = createNormalUser;
    obj["editNormalUser"] = editNormalUser;
    obj["deleteNormalUser"] = deleteNormalUser;
    obj["changeNormalUserPwd"] = changeNormalUserPwd;
    obj["enableDisableNormalUser"] = enableDisableNormalUser;
    
    // 设备管理权限
    obj["deviceManage"] = deviceManage;
    obj["addDeleteDevice"] = addDeleteDevice;
    obj["editDeviceInfo"] = editDeviceInfo;
    obj["deviceGroupSetting"] = deviceGroupSetting;
    obj["configDeviceInspection"] = configDeviceInspection;
    obj["deviceRestartMaintenance"] = deviceRestartMaintenance;
    obj["deviceAVParams"] = deviceAVParams;
    obj["networkSetting"] = networkSetting;
    obj["transportProtocolSetting"] = transportProtocolSetting;
    obj["storageSetting"] = storageSetting;
    obj["deviceUpgrade"] = deviceUpgrade;
    
    // 数据访问权限
    obj["dataAccess"] = dataAccess;
    obj["realtimePreview"] = realtimePreview;
    obj["viewImage"] = viewImage;
    obj["executeInspectionTask"] = executeInspectionTask;
    obj["recordPlayback"] = recordPlayback;
    obj["imageDownload"] = imageDownload;
    obj["ptzControl"] = ptzControl;
    obj["recordDownload"] = recordDownload;
    obj["viewLog"] = viewLog;
    
    // 报警管理权限
    obj["alarmManage"] = alarmManage;
    obj["configAlarmRule"] = configAlarmRule;
    obj["viewAlarmRecord"] = viewAlarmRecord;
    obj["handleConfirmAlarm"] = handleConfirmAlarm;
    
    
    return obj;
}

void UserPermissions::fromJson(const QJsonObject& json) {
    // 用户管理权限
    userManage = json["userManage"].toBool(false);
    createNormalUser = json["createNormalUser"].toBool(false);
    editNormalUser = json["editNormalUser"].toBool(false);
    deleteNormalUser = json["deleteNormalUser"].toBool(false);
    changeNormalUserPwd = json["changeNormalUserPwd"].toBool(false);
    enableDisableNormalUser = json["enableDisableNormalUser"].toBool(false);
    
    // 设备管理权限
    deviceManage = json["deviceManage"].toBool(false);
    addDeleteDevice = json["addDeleteDevice"].toBool(false);
    editDeviceInfo = json["editDeviceInfo"].toBool(false);
    deviceGroupSetting = json["deviceGroupSetting"].toBool(false);
    configDeviceInspection = json["configDeviceInspection"].toBool(false);
    deviceRestartMaintenance = json["deviceRestartMaintenance"].toBool(false);
    deviceAVParams = json["deviceAVParams"].toBool(false);
    networkSetting = json["networkSetting"].toBool(false);
    transportProtocolSetting = json["transportProtocolSetting"].toBool(false);
    storageSetting = json["storageSetting"].toBool(false);
    deviceUpgrade = json["deviceUpgrade"].toBool(false);
    
    // 数据访问权限
    dataAccess = json["dataAccess"].toBool(false);
    realtimePreview = json["realtimePreview"].toBool(false);
    viewImage = json["viewImage"].toBool(false);
    executeInspectionTask = json["executeInspectionTask"].toBool(false);
    recordPlayback = json["recordPlayback"].toBool(false);
    imageDownload = json["imageDownload"].toBool(false);
    ptzControl = json["ptzControl"].toBool(false);
    recordDownload = json["recordDownload"].toBool(false);
    viewLog = json["viewLog"].toBool(false);
    
    // 报警管理权限
    alarmManage = json["alarmManage"].toBool(false);
    configAlarmRule = json["configAlarmRule"].toBool(false);
    viewAlarmRecord = json["viewAlarmRecord"].toBool(false);
    handleConfirmAlarm = json["handleConfirmAlarm"].toBool(false);
    
}

// UserInfo 实现
QJsonObject UserInfo::toJson() const {
    QJsonObject obj;
    obj["username"] = username;
    obj["password"] = password;
    obj["userType"] = userType;
    obj["description"] = description;
    obj["canDelete"] = canDelete;
    obj["creationTime"] = creationTime;
    obj["lastLoginTime"] = lastLoginTime;
    obj["permissions"] = permissions.toJson();
    return obj;
}

void UserInfo::fromJson(const QJsonObject& json) {
    username = json["username"].toString();
    password = json["password"].toString();
    userType = json["userType"].toString();
    description = json["description"].toString();
    canDelete = json["canDelete"].toBool(true);
    creationTime = json["creationTime"].toString();
    lastLoginTime = json["lastLoginTime"].toString();
    if (json.contains("permissions")) {
        permissions.fromJson(json["permissions"].toObject());
    }
}

QVariantMap UserInfo::toVariantMap() const {
    QVariantMap map;
    map["username"] = username;
    map["password"] = password;
    map["userType"] = userType;
    map["description"] = description;
    map["canDelete"] = canDelete;
    map["creationTime"] = creationTime;
    map["lastLoginTime"] = lastLoginTime;
    
    QVariantMap permMap;
    
    // 用户管理权限
    permMap["userManage"] = permissions.userManage;
    permMap["createNormalUser"] = permissions.createNormalUser;
    permMap["editNormalUser"] = permissions.editNormalUser;
    permMap["deleteNormalUser"] = permissions.deleteNormalUser;
    permMap["changeNormalUserPwd"] = permissions.changeNormalUserPwd;
    permMap["enableDisableNormalUser"] = permissions.enableDisableNormalUser;
    
    // 设备管理权限
    permMap["deviceManage"] = permissions.deviceManage;
    permMap["addDeleteDevice"] = permissions.addDeleteDevice;
    permMap["editDeviceInfo"] = permissions.editDeviceInfo;
    permMap["deviceGroupSetting"] = permissions.deviceGroupSetting;
    permMap["configDeviceInspection"] = permissions.configDeviceInspection;
    permMap["deviceRestartMaintenance"] = permissions.deviceRestartMaintenance;
    permMap["deviceAVParams"] = permissions.deviceAVParams;
    permMap["networkSetting"] = permissions.networkSetting;
    permMap["transportProtocolSetting"] = permissions.transportProtocolSetting;
    permMap["storageSetting"] = permissions.storageSetting;
    permMap["deviceUpgrade"] = permissions.deviceUpgrade;
    
    // 数据访问权限
    permMap["dataAccess"] = permissions.dataAccess;
    permMap["realtimePreview"] = permissions.realtimePreview;
    permMap["viewImage"] = permissions.viewImage;
    permMap["executeInspectionTask"] = permissions.executeInspectionTask;
    permMap["recordPlayback"] = permissions.recordPlayback;
    permMap["imageDownload"] = permissions.imageDownload;
    permMap["ptzControl"] = permissions.ptzControl;
    permMap["recordDownload"] = permissions.recordDownload;
    permMap["viewLog"] = permissions.viewLog;
    
    // 报警管理权限
    permMap["alarmManage"] = permissions.alarmManage;
    permMap["configAlarmRule"] = permissions.configAlarmRule;
    permMap["viewAlarmRecord"] = permissions.viewAlarmRecord;
    permMap["handleConfirmAlarm"] = permissions.handleConfirmAlarm;
    
    map["permissions"] = permMap;
    
    return map;
}

// UserManager 实现
UserManager* UserManager::m_instance = nullptr;

UserManager* UserManager::instance() {
    if (!m_instance) {
        m_instance = new UserManager();
    }
    return m_instance;
}

UserManager::UserManager(QObject* parent) : QObject(parent) {
    loadUserList();
    if (m_userList.isEmpty()) {
        initDefaultUsers();
    }
    
    // 默认选中第一个用户
    if (!m_userList.isEmpty()) {
        m_currentUser = m_userList.first();
    }
}

void UserManager::setCurrentUser(const QString& username) {
    for (auto& user : m_userList) {
        if (user.username == username) {
            m_currentUser = user;
            
            // 更新最后登录时间
            QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
            m_currentUser.lastLoginTime = currentTime;
            user.lastLoginTime = currentTime; // 同时更新用户列表中的时间
            
            // 保存到文件
            saveUserToFile(m_currentUser);
            saveUserList();
            
            emit currentUserChanged();
            qDebug() << "当前用户已切换到:" << username << "，最后登录时间已更新:" << currentTime;
            return;
        }
    }
    qWarning() << "用户不存在:" << username;
}

QString UserManager::getCurrentUsername() const {
    qDebug() << "!!!!!!!!!!!!!!!!!!!!!!!!当前用户:" << m_currentUser.username;
    return m_currentUser.username;
}

QVariantMap UserManager::getCurrentUserInfo() const {
    return m_currentUser.toVariantMap();
}

bool UserManager::updateCurrentUser(const QVariantMap& userInfo)
{
    if (m_currentUser.username.isEmpty()) {
        qWarning() << "没有选中的用户";
        return false;
    }
    
    // 记录原用户名，用于更新用户列表
    QString oldUsername = m_currentUser.username;
    
    // 更新基本信息
    if (userInfo.contains("username")) {
        m_currentUser.username = userInfo["username"].toString();
    }
    if (userInfo.contains("userType")) {
        m_currentUser.userType = userInfo["userType"].toString();
    }
    if (userInfo.contains("description")) {
        m_currentUser.description = userInfo["description"].toString();
    }
    if (userInfo.contains("password")) {
        m_currentUser.password = userInfo["password"].toString();
    }
    
    // 更新权限
    if (userInfo.contains("permissions")) {
        QVariantMap permMap = userInfo["permissions"].toMap();
        
        qDebug() << "接收到权限数据:" << permMap;
        qDebug() << "editNormalUser 原始值:" << permMap["editNormalUser"];
        qDebug() << "deleteNormalUser 原始值:" << permMap["deleteNormalUser"];
        qDebug() << "changeNormalUserPwd 原始值:" << permMap["changeNormalUserPwd"];
        qDebug() << "enableDisableNormalUser 原始值:" << permMap["enableDisableNormalUser"];
        qDebug() << "editDeviceInfo 原始值:" << permMap["editDeviceInfo"];
        
        // 用户管理权限
        m_currentUser.permissions.userManage = permMap["userManage"].toBool();
        m_currentUser.permissions.createNormalUser = permMap["createNormalUser"].toBool();
        m_currentUser.permissions.editNormalUser = permMap["editNormalUser"].toBool();
        m_currentUser.permissions.deleteNormalUser = permMap["deleteNormalUser"].toBool();
        m_currentUser.permissions.changeNormalUserPwd = permMap["changeNormalUserPwd"].toBool();
        m_currentUser.permissions.enableDisableNormalUser = permMap["enableDisableNormalUser"].toBool();
        
        // 设备管理权限
        m_currentUser.permissions.deviceManage = permMap["deviceManage"].toBool();
        m_currentUser.permissions.addDeleteDevice = permMap["addDeleteDevice"].toBool();
        m_currentUser.permissions.editDeviceInfo = permMap["editDeviceInfo"].toBool();
        m_currentUser.permissions.deviceGroupSetting = permMap["deviceGroupSetting"].toBool();
        m_currentUser.permissions.configDeviceInspection = permMap["configDeviceInspection"].toBool();
        m_currentUser.permissions.deviceRestartMaintenance = permMap["deviceRestartMaintenance"].toBool();
        m_currentUser.permissions.deviceAVParams = permMap["deviceAVParams"].toBool();
        m_currentUser.permissions.networkSetting = permMap["networkSetting"].toBool();
        m_currentUser.permissions.transportProtocolSetting = permMap["transportProtocolSetting"].toBool();
        m_currentUser.permissions.storageSetting = permMap["storageSetting"].toBool();
        m_currentUser.permissions.deviceUpgrade = permMap["deviceUpgrade"].toBool();
        
        // 数据访问权限
        m_currentUser.permissions.dataAccess = permMap["dataAccess"].toBool();
        m_currentUser.permissions.realtimePreview = permMap["realtimePreview"].toBool();
        m_currentUser.permissions.viewImage = permMap["viewImage"].toBool();
        m_currentUser.permissions.executeInspectionTask = permMap["executeInspectionTask"].toBool();
        m_currentUser.permissions.recordPlayback = permMap["recordPlayback"].toBool();
        m_currentUser.permissions.imageDownload = permMap["imageDownload"].toBool();
        m_currentUser.permissions.ptzControl = permMap["ptzControl"].toBool();
        m_currentUser.permissions.recordDownload = permMap["recordDownload"].toBool();
        m_currentUser.permissions.viewLog = permMap["viewLog"].toBool();
        
        // 报警管理权限
        m_currentUser.permissions.alarmManage = permMap["alarmManage"].toBool();
        m_currentUser.permissions.configAlarmRule = permMap["configAlarmRule"].toBool();
        m_currentUser.permissions.viewAlarmRecord = permMap["viewAlarmRecord"].toBool();
        m_currentUser.permissions.handleConfirmAlarm = permMap["handleConfirmAlarm"].toBool();
    }
    
    // 更新用户列表中的对应项
    for (int i = 0; i < m_userList.size(); ++i) {
        if (m_userList[i].username == oldUsername) {
            m_userList[i] = m_currentUser;
            break;
        }
    }
    
    emit currentUserChanged();
    emit userUpdated(m_currentUser.username);
    qDebug() << "用户信息已在内存中更新:" << m_currentUser.username;
    
    return true;
}

bool UserManager::updateCurrentUserAndSave(const QVariantMap& userInfo)
{
    // 记录原用户名，用于删除旧文件
    QString oldUsername = m_currentUser.username;
    
    if (!updateCurrentUser(userInfo)) {
        return false;
    }
    
    // 如果用户名发生变化，删除旧的用户文件
    if (oldUsername != m_currentUser.username) {
        QString appDir = QApplication::applicationDirPath();
        QString oldConfigPath = appDir + "/config/user/" + oldUsername + ".json";
        QFile oldFile(oldConfigPath);
        if (oldFile.exists()) {
            if (oldFile.remove()) {
                qDebug() << "旧用户文件删除成功:" << oldConfigPath;
            } else {
                qWarning() << "旧用户文件删除失败:" << oldConfigPath;
            }
        }
    }
    
    // 保存到文件
    qDebug() << "保存前权限值:";
    qDebug() << "editNormalUser:" << m_currentUser.permissions.editNormalUser;
    qDebug() << "deleteNormalUser:" << m_currentUser.permissions.deleteNormalUser;
    qDebug() << "changeNormalUserPwd:" << m_currentUser.permissions.changeNormalUserPwd;
    qDebug() << "enableDisableNormalUser:" << m_currentUser.permissions.enableDisableNormalUser;
    qDebug() << "editDeviceInfo:" << m_currentUser.permissions.editDeviceInfo;
    
    bool success = saveUserToFile(m_currentUser);
    if (success) {
        saveUserList();
        qDebug() << "用户信息更新成功:" << m_currentUser.username;
        qDebug() << "用户权限:" << m_currentUser.permissions.enableDisableNormalUser;
        
        // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        QString logDescription = QString("修改用户信息：%1").arg(m_currentUser.username);
        
        SystemLog::instance()->addLog(
            getCurrentUsername(),
            LOG_TYPE_OPERATION,
            ACTION_TYPE_MODIFY_ACCOUNT,
            currentTime,
            "127.0.0.1",
            RESULT_SUCCESS,
            logDescription
        );
    } else {
        qWarning() << "用户信息保存失败:" << m_currentUser.username;
        
        // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        QString logDescription = QString("修改用户信息失败：%1").arg(m_currentUser.username);
        
        SystemLog::instance()->addLog(
            getCurrentUsername(),
            LOG_TYPE_OPERATION,
            ACTION_TYPE_MODIFY_ACCOUNT,
            currentTime,
            "127.0.0.1",
            RESULT_FAILURE,
            logDescription
        );
    }
    
    return success;
}

QVariantList UserManager::getUserList() const {
    QVariantList list;
    for (const auto& user : m_userList) {
        QVariantMap userMap;
        userMap["username"] = user.username;
        userMap["description"] = user.description;
        userMap["userType"] = user.userType;
        userMap["canDelete"] = user.canDelete;
        userMap["creationTime"] = user.creationTime;
        userMap["lastLoginTime"] = user.lastLoginTime;
        list.append(userMap);
    }
    return list;
}

QVariantMap UserManager::getUserInfo(const QString& username) const {
    for (const auto& user : m_userList) {
        if (user.username == username) {
            return user.toVariantMap();
        }
    }
    return QVariantMap(); // 返回空的QVariantMap如果用户不存在
}

bool UserManager::addUser(const QVariantMap& userInfo)
{
    QString username = userInfo["username"].toString();
    if (userExists(username)) {
        qWarning() << "用户已存在:" << username;
        return false;
    }
    
    UserInfo newUser;
    newUser.username = username;
    newUser.password = userInfo["password"].toString();
    newUser.userType = userInfo["userType"].toString();
    newUser.canDelete = true;
    newUser.creationTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    newUser.lastLoginTime = ""; // 新用户还没有登录过
    
    // 使用从QML传递过来的权限设置，而不是硬编码为false
    if (userInfo.contains("permissions")) {
        QVariantMap permMap = userInfo["permissions"].toMap();
        
        // 用户管理权限
        newUser.permissions.userManage = permMap["userManage"].toBool();
        newUser.permissions.createNormalUser = permMap["createNormalUser"].toBool();
        newUser.permissions.editNormalUser = permMap["editNormalUser"].toBool();
        newUser.permissions.deleteNormalUser = permMap["deleteNormalUser"].toBool();
        newUser.permissions.changeNormalUserPwd = permMap["changeNormalUserPwd"].toBool();
        newUser.permissions.enableDisableNormalUser = permMap["enableDisableNormalUser"].toBool();
        
        // 设备管理权限
        newUser.permissions.deviceManage = permMap["deviceManage"].toBool();
        newUser.permissions.addDeleteDevice = permMap["addDeleteDevice"].toBool();
        newUser.permissions.editDeviceInfo = permMap["editDeviceInfo"].toBool();
        newUser.permissions.deviceGroupSetting = permMap["deviceGroupSetting"].toBool();
        newUser.permissions.configDeviceInspection = permMap["configDeviceInspection"].toBool();
        newUser.permissions.deviceRestartMaintenance = permMap["deviceRestartMaintenance"].toBool();
        newUser.permissions.deviceAVParams = permMap["deviceAVParams"].toBool();
        newUser.permissions.networkSetting = permMap["networkSetting"].toBool();
        newUser.permissions.transportProtocolSetting = permMap["transportProtocolSetting"].toBool();
        newUser.permissions.storageSetting = permMap["storageSetting"].toBool();
        newUser.permissions.deviceUpgrade = permMap["deviceUpgrade"].toBool();
        
        // 数据访问权限
        newUser.permissions.dataAccess = permMap["dataAccess"].toBool();
        newUser.permissions.realtimePreview = permMap["realtimePreview"].toBool();
        newUser.permissions.viewImage = permMap["viewImage"].toBool();
        newUser.permissions.executeInspectionTask = permMap["executeInspectionTask"].toBool();
        newUser.permissions.recordPlayback = permMap["recordPlayback"].toBool();
        newUser.permissions.imageDownload = permMap["imageDownload"].toBool();
        newUser.permissions.ptzControl = permMap["ptzControl"].toBool();
        newUser.permissions.recordDownload = permMap["recordDownload"].toBool();
        newUser.permissions.viewLog = permMap["viewLog"].toBool();
        
        // 报警管理权限
        newUser.permissions.alarmManage = permMap["alarmManage"].toBool();
        newUser.permissions.configAlarmRule = permMap["configAlarmRule"].toBool();
        newUser.permissions.viewAlarmRecord = permMap["viewAlarmRecord"].toBool();
        newUser.permissions.handleConfirmAlarm = permMap["handleConfirmAlarm"].toBool();
    } else {
        // 如果没有传递权限信息，使用默认权限（全部为false）
        // 用户管理权限 - 设置为false（普通用户没有用户管理权限）
        newUser.permissions.userManage = false;
        newUser.permissions.createNormalUser = false;
        newUser.permissions.editNormalUser = false;
        newUser.permissions.deleteNormalUser = false;
        newUser.permissions.changeNormalUserPwd = false;
        newUser.permissions.enableDisableNormalUser = false;
        
        // 设备管理权限 - 设置为false（普通用户没有设备管理权限）
        newUser.permissions.deviceManage = false;
        newUser.permissions.addDeleteDevice = false;
        newUser.permissions.editDeviceInfo = false;
        newUser.permissions.deviceGroupSetting = false;
        newUser.permissions.configDeviceInspection = false;
        newUser.permissions.deviceRestartMaintenance = false;
        newUser.permissions.deviceAVParams = false;
        newUser.permissions.networkSetting = false;
        newUser.permissions.transportProtocolSetting = false;
        newUser.permissions.storageSetting = false;
        newUser.permissions.deviceUpgrade = false;
        
        // 数据访问权限 - 设置为false（普通用户没有数据访问权限）
        newUser.permissions.dataAccess = false;
        newUser.permissions.realtimePreview = false;
        newUser.permissions.viewImage = false;
        newUser.permissions.executeInspectionTask = false;
        newUser.permissions.recordPlayback = false;
        newUser.permissions.imageDownload = false;
        newUser.permissions.ptzControl = false;
        newUser.permissions.recordDownload = false;
        newUser.permissions.viewLog = false;
        
        // 报警管理权限 - 设置为false（普通用户没有报警管理权限）
        newUser.permissions.alarmManage = false;
        newUser.permissions.configAlarmRule = false;
        newUser.permissions.viewAlarmRecord = false;
        newUser.permissions.handleConfirmAlarm = false;
    }
    
    m_userList.append(newUser);

    // 立即落盘：先写单个用户文件，再写总列表
    bool ok = saveUserToFile(newUser);
    if (!ok) {
        // 保存失败，回滚内存列表
        m_userList.removeLast();
        qWarning() << "新用户文件保存失败，已回滚:" << username;
        return false;
    }
    saveUserList();   // 更新 users.json 索引

    emit userListChanged();
    emit userAdded(username);

    qDebug() << "新用户已添加到内存并落盘:" << username;
    return true;
}

bool UserManager::deleteUser(const QString& username) {
    if (username == "admin") {
        qWarning() << "不能删除admin用户";
        
        // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        QString operationIp = "127.0.0.1";
        QString selectedDeviceIp = DeviceModel::instance()->getSelectedDeviceVisibleLightIp();
        if (!selectedDeviceIp.isEmpty()) {
            operationIp = selectedDeviceIp;
        }
        SystemLog::instance()->addLog(
            getCurrentUsername(),                           // 操作账户
            LOG_TYPE_OPERATION,                            // 日志类型：操作日志
            ACTION_TYPE_DELETE_ACCOUNT,                    // 操作类型：删除账户
            currentTime,                                   // 操作时间
            operationIp,                                   // 操作IP
            RESULT_FAILURE,                                // 操作结果：失败
            QString("删除用户失败：不能删除admin用户")        // 操作描述
        );
        
        return false;
    }
    
    for (int i = 0; i < m_userList.size(); ++i) {
        if (m_userList[i].username == username) {
            if (!m_userList[i].canDelete) {
                qWarning() << "用户不能删除:" << username;
                
                // 记录系统日志
                QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
                QString operationIp = "127.0.0.1";
        QString selectedDeviceIp = DeviceModel::instance()->getSelectedDeviceVisibleLightIp();
        if (!selectedDeviceIp.isEmpty()) {
            operationIp = selectedDeviceIp;
        }
                SystemLog::instance()->addLog(
                    getCurrentUsername(),                           // 操作账户
                    LOG_TYPE_OPERATION,                            // 日志类型：操作日志
                    ACTION_TYPE_DELETE_ACCOUNT,                    // 操作类型：删除账户
                    currentTime,                                   // 操作时间
                    operationIp,                                   // 操作IP
                    RESULT_FAILURE,                                // 操作结果：失败
                    QString("删除用户失败：用户%1不能删除").arg(username)  // 操作描述
                );
                
                return false;
            }
            
            m_userList.removeAt(i);
            
            // 删除用户配置文件
            QString appDir = QApplication::applicationDirPath();
            QString configPath = appDir + "/config/user/" + username + ".json";
            QFile::remove(configPath);
            
            saveUserList();
            emit userListChanged();
            emit userDeleted(username);
            
            // 如果删除的是当前用户，切换到第一个用户
            if (m_currentUser.username == username && !m_userList.isEmpty()) {
                m_currentUser = m_userList.first();
                emit currentUserChanged();
            }
            
            qDebug() << "用户删除成功:" << username;
            
            // 记录系统日志
            QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
            QString operationIp = "127.0.0.1";
            QString selectedDeviceIp = DeviceModel::instance()->getSelectedDeviceVisibleLightIp();
            if (!selectedDeviceIp.isEmpty()) {
                operationIp = selectedDeviceIp;
            }
            SystemLog::instance()->addLog(
                getCurrentUsername(),                           // 操作账户
                LOG_TYPE_OPERATION,                            // 日志类型：操作日志
                ACTION_TYPE_DELETE_ACCOUNT,                    // 操作类型：删除账户
                currentTime,                                   // 操作时间
                operationIp,                                   // 操作IP
                RESULT_SUCCESS,                                // 操作结果：成功
                QString("删除用户：%1").arg(username)            // 操作描述
            );
            
            return true;
        }
    }
    
    qWarning() << "用户不存在:" << username;
    
    // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        QString operationIp = "127.0.0.1";
        QString selectedDeviceIp = DeviceModel::instance()->getSelectedDeviceVisibleLightIp();
        if (!selectedDeviceIp.isEmpty()) {
            operationIp = selectedDeviceIp;
        }
        SystemLog::instance()->addLog(
            getCurrentUsername(),                           // 操作账户
            LOG_TYPE_OPERATION,                            // 日志类型：操作日志
            ACTION_TYPE_DELETE_ACCOUNT,                    // 操作类型：删除账户
            currentTime,                                   // 操作时间
            operationIp,                                   // 操作IP
            RESULT_FAILURE,                                // 操作结果：失败
            QString("删除用户失败：用户%1不存在").arg(username)   // 操作描述
        );
    
    return false;
}

bool UserManager::userExists(const QString& username) const {
    for (const auto& user : m_userList) {
        if (user.username == username) {
            return true;
        }
    }
    return false;
}

QVariantMap UserManager::getCurrentUserPermissions() const {
    QVariantMap permMap;
    permMap["deviceManage"] = m_currentUser.permissions.deviceManage;
    permMap["ptzControl"] = m_currentUser.permissions.ptzControl;
    permMap["viewAlarmRecord"] = m_currentUser.permissions.viewAlarmRecord;
    
    // 添加新权限结构的字段
    permMap["userManage"] = m_currentUser.permissions.userManage;
    permMap["createNormalUser"] = m_currentUser.permissions.createNormalUser;
    permMap["editNormalUser"] = m_currentUser.permissions.editNormalUser;
    permMap["deleteNormalUser"] = m_currentUser.permissions.deleteNormalUser;
    permMap["changeNormalUserPwd"] = m_currentUser.permissions.changeNormalUserPwd;
    permMap["enableDisableNormalUser"] = m_currentUser.permissions.enableDisableNormalUser;
    
    permMap["addDeleteDevice"] = m_currentUser.permissions.addDeleteDevice;
    permMap["editDeviceInfo"] = m_currentUser.permissions.editDeviceInfo;
    permMap["deviceGroupSetting"] = m_currentUser.permissions.deviceGroupSetting;
    permMap["configDeviceInspection"] = m_currentUser.permissions.configDeviceInspection;
    permMap["deviceRestartMaintenance"] = m_currentUser.permissions.deviceRestartMaintenance;
    permMap["deviceAVParams"] = m_currentUser.permissions.deviceAVParams;
    permMap["networkSetting"] = m_currentUser.permissions.networkSetting;
    permMap["transportProtocolSetting"] = m_currentUser.permissions.transportProtocolSetting;
    permMap["storageSetting"] = m_currentUser.permissions.storageSetting;
    permMap["deviceUpgrade"] = m_currentUser.permissions.deviceUpgrade;
    
    permMap["dataAccess"] = m_currentUser.permissions.dataAccess;
    permMap["realtimePreview"] = m_currentUser.permissions.realtimePreview;
    permMap["viewImage"] = m_currentUser.permissions.viewImage;
    permMap["executeInspectionTask"] = m_currentUser.permissions.executeInspectionTask;
    permMap["recordPlayback"] = m_currentUser.permissions.recordPlayback;
    permMap["imageDownload"] = m_currentUser.permissions.imageDownload;
    permMap["recordDownload"] = m_currentUser.permissions.recordDownload;
    permMap["viewLog"] = m_currentUser.permissions.viewLog;
    
    permMap["alarmManage"] = m_currentUser.permissions.alarmManage;
    permMap["configAlarmRule"] = m_currentUser.permissions.configAlarmRule;
    permMap["handleConfirmAlarm"] = m_currentUser.permissions.handleConfirmAlarm;
    
    return permMap;
}

bool UserManager::updateCurrentUserPermissions(const QVariantMap& permissions) {
    m_currentUser.permissions.deviceManage = permissions["deviceManage"].toBool();
    m_currentUser.permissions.ptzControl = permissions["ptzControl"].toBool();
    m_currentUser.permissions.viewAlarmRecord = permissions["viewAlarmRecord"].toBool();
    
    // 添加新权限结构的字段
    m_currentUser.permissions.userManage = permissions["userManage"].toBool();
    m_currentUser.permissions.createNormalUser = permissions["createNormalUser"].toBool();
    m_currentUser.permissions.editNormalUser = permissions["editNormalUser"].toBool();
    m_currentUser.permissions.deleteNormalUser = permissions["deleteNormalUser"].toBool();
    m_currentUser.permissions.changeNormalUserPwd = permissions["changeNormalUserPwd"].toBool();
    m_currentUser.permissions.enableDisableNormalUser = permissions["enableDisableNormalUser"].toBool();
    
    m_currentUser.permissions.addDeleteDevice = permissions["addDeleteDevice"].toBool();
    m_currentUser.permissions.editDeviceInfo = permissions["editDeviceInfo"].toBool();
    m_currentUser.permissions.deviceGroupSetting = permissions["deviceGroupSetting"].toBool();
    m_currentUser.permissions.configDeviceInspection = permissions["configDeviceInspection"].toBool();
    m_currentUser.permissions.deviceRestartMaintenance = permissions["deviceRestartMaintenance"].toBool();
    m_currentUser.permissions.deviceAVParams = permissions["deviceAVParams"].toBool();
    m_currentUser.permissions.networkSetting = permissions["networkSetting"].toBool();
    m_currentUser.permissions.transportProtocolSetting = permissions["transportProtocolSetting"].toBool();
    m_currentUser.permissions.storageSetting = permissions["storageSetting"].toBool();
    m_currentUser.permissions.deviceUpgrade = permissions["deviceUpgrade"].toBool();
    
    m_currentUser.permissions.dataAccess = permissions["dataAccess"].toBool();
    m_currentUser.permissions.realtimePreview = permissions["realtimePreview"].toBool();
    m_currentUser.permissions.viewImage = permissions["viewImage"].toBool();
    m_currentUser.permissions.executeInspectionTask = permissions["executeInspectionTask"].toBool();
    m_currentUser.permissions.recordPlayback = permissions["recordPlayback"].toBool();
    m_currentUser.permissions.imageDownload = permissions["imageDownload"].toBool();
    m_currentUser.permissions.recordDownload = permissions["recordDownload"].toBool();
    m_currentUser.permissions.viewLog = permissions["viewLog"].toBool();
    
    m_currentUser.permissions.alarmManage = permissions["alarmManage"].toBool();
    m_currentUser.permissions.configAlarmRule = permissions["configAlarmRule"].toBool();
    m_currentUser.permissions.handleConfirmAlarm = permissions["handleConfirmAlarm"].toBool();
    
    // 更新用户列表中的对应项
    for (int i = 0; i < m_userList.size(); ++i) {
        if (m_userList[i].username == m_currentUser.username) {
            m_userList[i].permissions = m_currentUser.permissions;
            break;
        }
    }
    
    bool success = saveUserToFile(m_currentUser);
    if (success) {
        emit currentUserChanged();
        emit userUpdated(m_currentUser.username);
        qDebug() << "用户权限更新成功:" << m_currentUser.username;
    } else {
        qWarning() << "用户权限保存失败:" << m_currentUser.username;
    }
    
    return success;
}

bool UserManager::validatePassword(const QString& username, const QString& password) const {
    // 查找用户并验证密码
    for (const auto& user : m_userList) {
        if (user.username == username) {
            return user.password == password;
        }
    }
    return false;
}

bool UserManager::updateCurrentUserPassword(const QString& newPassword) {
    if (m_currentUser.username.isEmpty()) {
        qWarning() << "没有选中的用户";
        return false;
    }
    
    QString oldUsername = m_currentUser.username;
    m_currentUser.password = newPassword;
    
    // 更新用户列表中的对应项
    for (int i = 0; i < m_userList.size(); ++i) {
        if (m_userList[i].username == oldUsername) {
            m_userList[i] = m_currentUser;
            break;
        }
    }
    
    // 保存到文件
    bool success = saveUserToFile(m_currentUser);
    if (success) {
        saveUserList();
        emit userUpdated(m_currentUser.username);
        qDebug() << "密码更新成功:" << m_currentUser.username;
    } else {
        qWarning() << "密码保存失败:" << m_currentUser.username;
    }
    
    return success;
}

void UserManager::updateUserLastLoginTime(const QString& username) {
    // 查找用户
    for (int i = 0; i < m_userList.size(); ++i) {
        if (m_userList[i].username == username) {
            // 更新最后登录时间
            m_userList[i].lastLoginTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
            
            // 如果当前用户就是该用户，也更新当前用户信息
            if (m_currentUser.username == username) {
                m_currentUser.lastLoginTime = m_userList[i].lastLoginTime;
            }
            
            // 保存到文件
            bool success = saveUserToFile(m_userList[i]);
            if (success) {
                saveUserList();
                emit userUpdated(username);
                qDebug() << "用户最后登录时间更新成功:" << username;
            } else {
                qWarning() << "用户最后登录时间保存失败:" << username;
            }
            return;
        }
    }
    
    qWarning() << "未找到用户:" << username;
}

bool UserManager::login(const QString& username, const QString& password) {
    // 验证密码
    bool passwordValid = validatePassword(username, password);
    
    if (passwordValid) {
        // 如果密码正确，更新最后登录时间
        updateUserLastLoginTime(username);
        qDebug() << "用户登录成功:" << username;
    } else {
        qWarning() << "用户登录失败，用户名或密码错误:" << username;
    }
    
    return passwordValid;
}

void UserManager::loadUserList() {
    m_userList.clear();
    
    QString appDir = QApplication::applicationDirPath();
    QString userListPath = appDir + "/config/user/userlist.json";
    QFile file(userListPath);
    
    if (!file.exists()) {
        qDebug() << "用户列表文件不存在，将创建默认用户";
        return;
    }
    
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "无法打开用户列表文件:" << userListPath;
        return;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);
    
    if (error.error != QJsonParseError::NoError) {
        qWarning() << "用户列表文件解析失败:" << error.errorString();
        return;
    }
    
    QJsonArray userArray = doc.array();
    for (const auto& value : userArray) {
        UserInfo user;
        user.fromJson(value.toObject());
        m_userList.append(user);
    }
    
    qDebug() << "加载用户列表成功，共" << m_userList.size() << "个用户";
}

void UserManager::saveUserList() {
    QString appDir = QApplication::applicationDirPath();
    QString userDir = appDir + "/config/user";
    QDir().mkpath(userDir);
    
    QString userListPath = userDir + "/userlist.json";
    QFile file(userListPath);
    
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "无法创建用户列表文件:" << userListPath;
        return;
    }
    
    QJsonArray userArray;
    for (const auto& user : m_userList) {
        userArray.append(user.toJson());
    }
    
    QJsonDocument doc(userArray);
    file.write(doc.toJson());
    file.close();
    
    qDebug() << "用户列表保存成功:" << userListPath;
}

UserInfo UserManager::loadUserFromFile(const QString& username) const {
    UserInfo user;
    
    QString appDir = QApplication::applicationDirPath();
    QString configPath = appDir + "/config/user/" + username + ".json";
    QFile file(configPath);
    
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "无法打开用户配置文件:" << configPath;
        return user;
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    QJsonParseError error;
    QJsonDocument doc = QJsonDocument::fromJson(data, &error);
    
    if (error.error != QJsonParseError::NoError) {
        qWarning() << "用户配置文件解析失败:" << error.errorString();
        return user;
    }
    
    user.fromJson(doc.object());
    return user;
}

bool UserManager::saveUserToFile(const UserInfo& user) const {
    QString appDir = QApplication::applicationDirPath();
    QString userDir = appDir + "/config/user";
    QDir().mkpath(userDir);
    
    QString configPath = userDir + "/" + user.username + ".json";
    QFile file(configPath);
    
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "无法创建用户配置文件:" << configPath;
        return false;
    }
    
    QJsonObject userJson = user.toJson();
    qDebug() << "保存的用户JSON数据:" << userJson;
    qDebug() << "权限部分:" << userJson["permissions"].toObject();
    
    QJsonDocument doc(userJson);
    file.write(doc.toJson());
    file.close();
    
    qDebug() << "用户配置保存成功:" << configPath;
    return true;
}

void UserManager::initDefaultUsers() {
    // 创建默认admin用户
    UserInfo adminUser;
    adminUser.username = "admin";
    adminUser.password = "123456";
    adminUser.userType = "superadmin";
    adminUser.description = "默认为超级用户，不能删除";
    adminUser.canDelete = false;
    adminUser.creationTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    adminUser.lastLoginTime = ""; // 默认用户还没有登录过
    
    // 管理员默认全部权限 - 使用新的权限结构
    adminUser.permissions.userManage = true;                    // 用户管理总开关
    adminUser.permissions.createNormalUser = true;             // 创建普通用户
    adminUser.permissions.editNormalUser = true;               // 修改普通用户信息
    adminUser.permissions.deleteNormalUser = true;             // 删除普通用户
    adminUser.permissions.changeNormalUserPwd = true;        // 修改普通用户密码
    adminUser.permissions.enableDisableNormalUser = true;    // 启用禁用普通用户
    
    adminUser.permissions.deviceManage = true;                 // 设备管理总开关
    adminUser.permissions.addDeleteDevice = true;             // 添加/删除设备
    adminUser.permissions.editDeviceInfo = true;              // 修改设备信息
    adminUser.permissions.deviceGroupSetting = true;          // 设备分组设置
    adminUser.permissions.configDeviceInspection = true;      // 配置设备巡检
    adminUser.permissions.deviceRestartMaintenance = true;      // 设备重启/维护
    adminUser.permissions.deviceAVParams = true;               // 设备音视频参数
    adminUser.permissions.networkSetting = true;               // 网络设置
    adminUser.permissions.transportProtocolSetting = true;     // 传输协议设置
    adminUser.permissions.storageSetting = true;               // 存储设置
    adminUser.permissions.deviceUpgrade = true;               // 设备升级
    
    adminUser.permissions.dataAccess = true;                   // 数据访问总开关
    adminUser.permissions.realtimePreview = true;            // 实时预览
    adminUser.permissions.viewImage = true;                    // 查看图片
    adminUser.permissions.executeInspectionTask = true;       // 执行巡检任务
    adminUser.permissions.recordPlayback = true;              // 录像回放
    adminUser.permissions.imageDownload = true;                // 图片下载
    adminUser.permissions.ptzControl = true;                   // 云台控制
    adminUser.permissions.recordDownload = true;               // 录像下载
    adminUser.permissions.viewLog = true;                      // 查看日志
    
    adminUser.permissions.alarmManage = true;                  // 报警管理总开关
    adminUser.permissions.configAlarmRule = true;             // 配置报警规则
    adminUser.permissions.viewAlarmRecord = true;              // 查看报警记录
    adminUser.permissions.handleConfirmAlarm = true;          // 处理/确认报警
    
    m_userList.append(adminUser);
    
    saveUserToFile(adminUser);
    saveUserList();
    
    qDebug() << "默认用户初始化完成";
}

bool UserManager::hasRecordPlaybackPermission() const
{
    return m_currentUser.permissions.recordPlayback;
}

bool UserManager::hasViewLogPermission() const
{
    return m_currentUser.permissions.viewLog;
}

bool UserManager::hasExecuteInspectionTaskPermission() const
{
    return m_currentUser.permissions.executeInspectionTask;
}

bool UserManager::hasPtzControlPermission() const
{
    return m_currentUser.permissions.ptzControl;
}

bool UserManager::hasViewAlarmRecordPermission() const
{
    return m_currentUser.permissions.viewAlarmRecord;
}

bool UserManager::hasHandleConfirmAlarmPermission() const
{
    return m_currentUser.permissions.handleConfirmAlarm;
}