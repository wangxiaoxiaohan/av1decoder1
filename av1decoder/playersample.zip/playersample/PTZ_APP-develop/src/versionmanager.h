#ifndef VERSIONMANAGER_H
#define VERSIONMANAGER_H

#include <QObject>
#include <QString>

class VersionManager : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString version READ version CONSTANT)
    Q_PROPERTY(QString buildDate READ buildDate CONSTANT)
    Q_PROPERTY(QString buildTime READ buildTime CONSTANT)
    Q_PROPERTY(QString fullVersion READ fullVersion CONSTANT)

public:
    static VersionManager* instance();
    
    QString version() const;
    QString buildDate() const;
    QString buildTime() const;
    QString fullVersion() const;

private:
    explicit VersionManager(QObject *parent = nullptr);
    ~VersionManager() = default;

    QString m_version;
    QString m_buildDate;
    QString m_buildTime;
};

#endif // VERSIONMANAGER_H
