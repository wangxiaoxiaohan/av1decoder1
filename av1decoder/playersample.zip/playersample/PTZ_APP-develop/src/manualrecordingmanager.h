#ifndef MANUALRECORDINGMANAGER_H
#define MANUALRECORDINGMANAGER_H

#include <QObject>
#include <QSqlDatabase>
#include <QVariantList>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QDir>
#include <QStandardPaths>
#include <QJsonObject>
#include <QJsonArray>

struct ManualRecordingEntry {
    int id;                     // 数据库ID
    QString device_code;        // 设备编号
    QString device_name;        // 设备名称
    QString start_time;         // 开始时间
    QString end_time;           // 结束时间
    QString channel_type;       // 通道类型 (visible/infrared)
    int duration_seconds;       // 录制时长（秒）
    QString created_at;         // 创建时间
    
    QJsonObject toJson() const;
};

class ManualRecordingManager : public QObject
{
    Q_OBJECT
public:
    static ManualRecordingManager* instance();

    // QML可调用的接口
    Q_INVOKABLE void startRecording(const QString& deviceCode, const QString& deviceName, const QString& channelType);
    Q_INVOKABLE void stopRecording(const QString& deviceCode, const QString& channelType);
    Q_INVOKABLE bool isRecording(const QString& deviceCode, const QString& channelType);
    
    // 查询接口
    Q_INVOKABLE QVariantList queryRecordings(const QString& deviceCode, 
                                           const QString& startDate = "", 
                                           const QString& endDate = "");
    Q_INVOKABLE QVariantList queryRecordingsForDate(const QString& deviceCode, const QDate& date);
    Q_INVOKABLE QVariantMap getRecordingStats(const QString& deviceCode);
    
    // 删除接口
    Q_INVOKABLE bool deleteRecording(int id);
    Q_INVOKABLE bool deleteAllRecordings(const QString& deviceCode = "");
    
    // 获取当前录制状态
    Q_INVOKABLE QVariantMap getCurrentRecording(const QString& deviceCode, const QString& channelType);

signals:
    void recordingStarted(const QString& deviceCode, const QString& channelType, const QString& startTime);
    void recordingStopped(const QString& deviceCode, const QString& channelType, const QString& endTime, int duration);
    void recordingAdded();
    void recordingDeleted();

private:
    explicit ManualRecordingManager(QObject* parent = nullptr);
    static ManualRecordingManager* m_instance;
    QSqlDatabase m_db;

    void initDatabase();
    ManualRecordingEntry fromQuery(const QSqlQuery& query);
    QString getCurrentRecordingStartTime(const QString& deviceCode, const QString& channelType);
};

#endif // MANUALRECORDINGMANAGER_H