#ifndef YUV_OVERLAY_H
#define YUV_OVERLAY_H

#include "gaussian_plume.h" // 包含gaussian_plume.h以获取GAUSSIANPLUME_API宏

/**
 * @brief 位置模式枚举，表示覆盖图像的参考点位置
 */
enum PositionMode
{
    // POSITION_TOP_LEFT,    // 左上角（默认）
    // POSITION_TOP_RIGHT,   // 右上角
    POSITION_BOTTOM_LEFT,  // 左下角
    POSITION_BOTTOM_RIGHT, // 右下角
    // POSITION_LEFT_CENTER, // 左中心
    // POSITION_RIGHT_CENTER, // 右中心
};

/**
 * @brief 将YUV420SP格式的源图像覆盖到目标图像上，只覆盖有效区域（非黑色区域）
 *
 * @param src_yuv 源图像YUV420SP数据指针
 * @param src_width 源图像宽度
 * @param src_height 源图像高度
 * @param dst_yuv 目标图像YUV420SP数据指针
 * @param dst_width 目标图像宽度
 * @param dst_height 目标图像高度
 * @param offset_x 覆盖位置的x坐标（根据position_mode确定参考点）
 * @param offset_y 覆盖位置的y坐标（根据position_mode确定参考点）
 * @param position_mode 位置模式，默认为左上角
 * @return 0表示成功，非0表示失败
 */
int overlay(const unsigned char *src_yuv, int src_width, int src_height,
                              unsigned char *dst_yuv, int dst_width, int dst_height,
                              int offset_x, int offset_y, int tdlas_x, int tdlas_y,
                              PositionMode position_mode = POSITION_BOTTOM_LEFT);

#endif // YUV_OVERLAY_H