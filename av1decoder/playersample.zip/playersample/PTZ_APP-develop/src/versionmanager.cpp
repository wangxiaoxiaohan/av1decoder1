#include "versionmanager.h"

VersionManager* VersionManager::instance()
{
    static VersionManager instance;
    return &instance;
}

VersionManager::VersionManager(QObject *parent)
    : QObject(parent)
{
    // Manual version management for now
    // In a more advanced setup, this could come from CMake definitions
    m_version = "1.0.0"; 
    m_buildDate = __DATE__;
    m_buildTime = __TIME__;
}

QString VersionManager::version() const
{
    return m_version;
}

QString VersionManager::buildDate() const
{
    return m_buildDate;
}

QString VersionManager::buildTime() const
{
    return m_buildTime;
}

QString VersionManager::fullVersion() const
{
    return QString("v%1 built on %2 %3").arg(m_version, m_buildDate, m_buildTime);
}
