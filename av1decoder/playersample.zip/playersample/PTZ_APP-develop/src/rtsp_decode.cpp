#include "rtsp_decode.h"
#include <iostream>
#include <stdio.h>
//#include <unistd.h>
#include <gst/gstelement.h>

#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <QImage>
#include <QDir>
#include <QDateTime>
#include <QDebug>
#include "src/video_queue.h"


extern "C" {
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libswscale/swscale.h>
#include <libavutil/imgutils.h>
#include <libavutil/opt.h>
}

#include <thread>
using namespace std;

GstFlowReturn CaptureGstBGRBuffer(GstAppSink* sink, gpointer user_data){
    GstSample* sample = gst_app_sink_pull_sample(sink);

    auto piple = GST_ELEMENT(gst_element_get_parent(sink));

    GstElement* source = gst_bin_get_by_name(GST_BIN(piple), "Rtspsrc");

    if(source == NULL || sample == NULL){
        g_print("Source not found in the pipeline.\n");
        return GST_FLOW_ERROR;
    }
    gchar* uri;
    g_object_get(source, "location", &uri, NULL);

    GstBuffer* buffer = gst_sample_get_buffer(sample);
    GstMapInfo map_info;
    if(!gst_buffer_map((buffer), &map_info, GST_MAP_READ)){
        gst_buffer_unmap((buffer), &map_info);
        gst_sample_unref(sample);
        return GST_FLOW_ERROR;
    }
    GstCaps* caps = gst_sample_get_caps(sample);
    gint width, height;
    GstStructure* structure = gst_caps_get_structure(caps, 0);
    gst_structure_get_int(structure, "width", &width);
    gst_structure_get_int(structure, "height", &height);
    QImage image(map_info.data, width, height, QImage::Format_RGBA8888);

    VideoQueue::moGetInstance()->mvPushVideo2Queue(uri, image);
//    VideoQueue::moGetInstance()->mvPushVideo2Queue(uri, image.rgbSwapped());

    gst_buffer_unmap((buffer), &map_info);
    gst_sample_unref(sample);
    return GST_FLOW_OK;
}

static void RtspSrcPadAdded(GstElement* element, GstPad* pad, gpointer data){
    gchar* name;
    GstCaps* p_caps;
    gchar* description;
    GstElement* p_rtph264depay;

    name = gst_pad_get_name(pad);
    g_print("A new pad %s was created\n", name);

    // here, you would setup a new pad link for the newly created pad
    // sooo, now find that rtph264depay is needed and link them?
    p_caps = gst_pad_get_pad_template_caps(pad);

    description = gst_caps_to_string(p_caps);
    printf("%s \n", description);
    g_free(description);

    p_rtph264depay = GST_ELEMENT(data);

    // try to link the pads then ...
    if(!gst_element_link_pads(element, name, p_rtph264depay, "sink")){
        printf("Failed to link elements 3\n");
    }

    g_free(name);
}

RrspDecode::~RrspDecode(){
    if(pipeline_){
        gst_element_set_state(pipeline_, GST_STATE_NULL);
        gst_object_unref(pipeline_);
        pipeline_ = nullptr;
    }
}

int RrspDecode::inits(int width, int height, std::string url){
    decode_thread_ = new thread(&RrspDecode::init, this, url);
//    init(url);

//    width_ = width;
//    height_ = height;
//    url_ = url;
//
//    pipeline_ = gst_pipeline_new("pipeline");
//    rtspsrc_ = gst_element_factory_make("rtspsrc", "Rtspsrc");
//    rtph264depay_ = gst_element_factory_make("rtph264depay", "Rtph264depay");
//    h264parse_ = gst_element_factory_make("h264parse", "H264parse");
//    omxh264dec_ = gst_element_factory_make("d3d11h264dec", "d3d11h264dec");
//    videoconvert_ = gst_element_factory_make("videoconvert", "Videoconvert");
//    capsfilter_ = gst_element_factory_make("capsfilter", "Capsfilter");
//    appsink_ = gst_element_factory_make("appsink", "Appsink");
//
//    if(!pipeline_ || !rtspsrc_ || !rtph264depay_ || !h264parse_ || !omxh264dec_ || !videoconvert_ || !capsfilter_ || !appsink_){
//        std::cerr << "Not all elements could be created" << std::endl;
//        return -1;
//    }
//
//
//    g_object_set(G_OBJECT(rtspsrc_), "location", url_.c_str(), "latency", 1000, NULL);
//    GstCaps* caps = gst_caps_new_simple("video/x-raw", "format", G_TYPE_STRING, "RGBA", NULL);
//    g_object_set(G_OBJECT(capsfilter_), "caps", caps, NULL);
//    //    g_object_set(G_OBJECT(capsfilter_), "caps", gst_caps_new_simple("video/x-raw", "format", G_TYPE_STRING, "BGRx", "width", G_TYPE_INT, width_, "height", G_TYPE_INT, height_, nullptr), NULL);
//
//    g_object_set(G_OBJECT(appsink_), "emit-signals", TRUE, NULL);
//    g_object_set(G_OBJECT(appsink_), "sync", FALSE, NULL);
//    g_object_set(G_OBJECT(appsink_), "drop", TRUE, NULL);
//
//    g_signal_connect(appsink_, "new-sample", G_CALLBACK(CaptureGstBGRBuffer), reinterpret_cast<void*>(this));
//    g_signal_connect(rtspsrc_, "pad-added", G_CALLBACK(RtspSrcPadAdded), rtph264depay_);
//
//    gst_bin_add_many(GST_BIN(pipeline_), rtspsrc_, rtph264depay_, h264parse_, omxh264dec_, videoconvert_, capsfilter_, appsink_, nullptr);
//
//    if(gst_element_link_many(rtph264depay_, h264parse_, omxh264dec_, videoconvert_, capsfilter_, appsink_, nullptr) !=
//       TRUE){
//        std::cerr
//                << "rtspsrc_, rtph264depay_, h264parse_, omxh264dec_, capsfilter_,videoconvert_,appSink_ could not be linked"
//                << std::endl;
//        return -1;
//    }
//
//    auto ret = gst_element_set_state(pipeline_, GST_STATE_PLAYING);
//    if(ret == GST_STATE_CHANGE_FAILURE){
//        std::cerr << "Unable to set the pipeline to the playing state" << std::endl;
//        return -1;
//    }
    return 0;
}

bool RrspDecode::init(std::string uri){
    const char* rtsp_url = uri.c_str();

    AVDictionary* options = nullptr;
    av_dict_set(&options, "buffer_size", "42598400", 0);

    AVFormatContext* format_ctx = nullptr;
    if(avformat_open_input(&format_ctx, rtsp_url, nullptr, &options) != 0){
        std::cerr << "Could not open input file " << rtsp_url << "\n";
        return false;
    }

    if(avformat_find_stream_info(format_ctx, nullptr) < 0){
        std::cerr << "Could not find stream information\n";
        return false;
    }

    int video_stream_index = -1;
    AVCodecParameters* codec_params = nullptr;
    for(unsigned int i = 0; i < format_ctx->nb_streams; i++){
        if(format_ctx->streams[i]->codecpar->codec_type == AVMEDIA_TYPE_VIDEO){
            video_stream_index = i;
            codec_params = format_ctx->streams[i]->codecpar;
            break;
        }
    }

    if(video_stream_index == -1){
        std::cerr << "Could not find video stream\n";
        return false;
    }

    const AVCodec* codec = avcodec_find_decoder(codec_params->codec_id);
    if(!codec){
        std::cerr << "Unsupported codec\n";
        return false;
    }

    AVCodecContext* codec_ctx = avcodec_alloc_context3(codec);
    if(!codec_ctx){
        std::cerr << "Could not allocate video codec context\n";
        return false;
    }

    if(avcodec_parameters_to_context(codec_ctx, codec_params) < 0){
        std::cerr << "Could not copy codec parameters to codec context\n";
        return false;
    }

    if(avcodec_open2(codec_ctx, codec, nullptr) < 0){
        std::cerr << "Could not open codec\n";
        return false;
    }

    AVFrame* frame = av_frame_alloc();
    AVPacket* packet = av_packet_alloc();
    int response;

    av_opt_set(codec_ctx->priv_data, "rtsp_transport", "udp", 0);
//    av_dict_set(&opts_v, "buffer_size", "425984", 0)；
//    av_opt_set_int(codec_ctx->priv_data, "analyzeduration", 50000, 0);
    av_opt_set_int(codec_ctx->priv_data, "probesize", 60480, 0);
    av_opt_set_int(codec_ctx->priv_data, "fflags", AVFMT_FLAG_NOBUFFER, 0);
    av_opt_set_int(codec_ctx->priv_data, "max_delay", 50000, 0);

    while(av_read_frame(format_ctx, packet) >= 0){
        if(packet->stream_index == video_stream_index){
//            if (packet->pts > (int64_t)AV_NOPTS_VALUE && packet->pts < av_gettime_relative() / 1000000 - ) {
//                // 丢弃过时的帧
//                av_packet_unref(packet);
//                continue;
//            }
            response = avcodec_send_packet(codec_ctx, packet);
            if(response >= 0){
                response = avcodec_receive_frame(codec_ctx, frame);
                if(response >= 0){
                    SwsContext* sws_ctx = sws_getContext(frame->width, frame->height, codec_ctx->pix_fmt, frame->width,
                                                         frame->height, AV_PIX_FMT_RGB24, SWS_BILINEAR, nullptr,
                                                         nullptr, nullptr);
                    AVFrame* rgb_frame = av_frame_alloc();
                    int num_bytes = av_image_get_buffer_size(AV_PIX_FMT_RGB24, frame->width, frame->height, 1);
                    uint8_t* buffer = (uint8_t*) av_malloc(num_bytes * sizeof(uint8_t));
                    av_image_fill_arrays(rgb_frame->data, rgb_frame->linesize, buffer, AV_PIX_FMT_RGB24, frame->width,
                                         frame->height, 1);

                    sws_scale(sws_ctx, frame->data, frame->linesize, 0, frame->height, rgb_frame->data,
                              rgb_frame->linesize);

                    QImage img(rgb_frame->data[0], frame->width, frame->height,rgb_frame->linesize[0], QImage::Format_RGB888);

                    VideoQueue::moGetInstance()->mvPushVideo2Queue(rtsp_url, img);

                    av_free(buffer);
                    av_frame_free(&rgb_frame);
                    sws_freeContext(sws_ctx);
//                    break;
                }
            }
        }
        av_packet_unref(packet);
    }

    av_frame_free(&frame);
    av_packet_free(&packet);
    avcodec_free_context(&codec_ctx);
    avformat_close_input(&format_ctx);

    return false;
}
