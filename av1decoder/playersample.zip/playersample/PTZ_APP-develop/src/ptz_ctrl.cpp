//
// Created by Chian on 10/23/2024.
//

#include "ptz_ctrl.h"

//PtzCtrl* PtzCtrl::instance_ = nullptr;

PtzCtrl::PtzCtrl(QObject* parent)
        : QObject(parent)
          , device_list_()
          , current_device_(nullptr){
}

PtzCtrl::~PtzCtrl(){

}

PtzDevice* PtzCtrl::moGetDiviceById(string device_id){
    if(device_list_.find(device_id) == device_list_.end()){
        return nullptr;
    }

    return device_list_[device_id];
}

PtzDevice* PtzCtrl::moGetCurrentDevice(){
    return current_device_;
}

void PtzCtrl::mvSelectDevice(string device_id){
    if(device_list_.find(device_id) == device_list_.end()){
        return;
    }

    current_device_ = device_list_[device_id];
}

void PtzCtrl::mvAddDevice(PtzDevice* obj){
    device_list_.emplace(obj->msGetDeviceId(), obj);
}

int PtzCtrl::moGetCurrentDeviceTest(){
    return 1111;
}

PtzCtrl& PtzCtrl::moGetInstance(){
    static PtzCtrl instance_;  // 局部静态变量，线程安全
    return instance_;
}

void PtzCtrl::mvSendTest(){
    NetWorkCtrl::moGetInstance()->mbSendCmdTest();
}

void PtzCtrl::mvSetRotation(int dr, int speed){
    current_device_->mvSetRotation(dr, speed);
}

void PtzCtrl::mvSetZoomIn(int val){
    current_device_->mvSetZoomIn(val);
}

void PtzCtrl::mvSetFocus(int val){
    current_device_->mvSetFocus(val);
}

void PtzCtrl::mvSetAperture(int val){
    current_device_->mvSetAperture(val);
}

void PtzCtrl::mvSetLight(int val){
    current_device_->mvSetLight(val);
}

void PtzCtrl::mvSetWiper(int val){
    current_device_->mvSetWiper(val);
}

void PtzCtrl::mvSetAssiFocus(int val){
    current_device_->mvSetAssiFocus(val);
}

void PtzCtrl::mvSetInfFlap(int val){
    current_device_->mvSetInfFlap(val);
}

void PtzCtrl::mvSetRestore(){

}

void PtzCtrl::mvSetInfImgSettings(QVariantMap mp){
    if(mp.isEmpty()) return;

    current_device_->mvModifyInfraredImageSettings(mp["brightness"].toInt()
                                                   , mp["contrast"].toInt()
                                                   , mp["denoise"].toInt()
                                                   , mp["intensity"].toInt()
                                                   , mp["detail_enhancement"].toBool()
                                                   , mp["edge_enhancement"].toBool()
                                                   , mp["stripe_filter"].toBool());
}

void PtzCtrl::mvSetImgSettings(QVariantMap mp){
    if(mp.isEmpty()) return;

    current_device_->mvModifyImageSettings(mp["brightness"].toInt()
                                           , mp["contrast"].toInt()
                                           , mp["saturation"].toInt()
                                           , mp["sharpness"].toInt()
                                           , static_cast<ImageSettings::CaptureType>(mp["capture_type"].toInt())
                                           , static_cast<Resolution>(mp["image_size"].toInt())
                                           , static_cast<ImageSettings::ImageQuality>(mp["image_quality"].toInt()));
}

void PtzCtrl::mvModifyExposureSettings(int mode, int exp_time){
    current_device_->mvModifyExposureSettings(static_cast<ExposureSettings::ExposureMode>(mode), exp_time);
}

void PtzCtrl::mvModifyDayNightSwitchSettings(int mode, QString start, QString end){
    current_device_->mvModifyDayNightSwitchSettings(static_cast<DayNightSwitchSettings::Mode>(mode), start.toStdString(), end.toStdString());
}

void PtzCtrl::mvModifyWhiteBalanceSettings(int mode, int red_gain, int blue_gain){
    current_device_->mvModifyWhiteBalanceSettings(static_cast<WhiteBalanceSettings::WhiteBalanceMode>(mode), red_gain, blue_gain);
}

void PtzCtrl::mvModifyImageEnhancement(bool noise_enable, int noise_level, bool fog_enable, bool stabilization, int gray){
    current_device_->mvModifyImageEnhancement(noise_enable, noise_level, fog_enable, stabilization, gray);
}

void PtzCtrl::mvModifyVideoAdjustment(int mirro, int stab){
    current_device_->mvModifyVideoAdjustment(static_cast<VideoAdjustment::MirrorSetting>(mirro), static_cast<VideoAdjustment::StabilizationSetting>(stab));
}

void PtzCtrl::mvModifyWhideDynamicRange(int mode, int lev, bool suppress){
    current_device_->mvModifyWhideDynamicRange(static_cast<WideDynamicRange::WideDynamicMode>(mode), lev, suppress);
}

void PtzCtrl::mvModifyChnTitle(bool enable, QString chn_name){
    current_device_->mvModifyChnTitle(enable, chn_name);
}

void PtzCtrl::mvModifyTimeStyle(bool enable, bool week_enable, int time_style, int date_style){
    current_device_->mvModifyTimeStyle(enable, week_enable, static_cast<OSDSettings::TimeFormat>(time_style), static_cast<OSDSettings::DateFormat>(date_style));
}

void PtzCtrl::mvModifyOverlapString(bool enable_1, QString str_1, bool enable_2, QString str_2, bool enable_3, QString str_3,
                               bool enable_4, QString str_4){
    current_device_->mvModifyOverlapString(enable_1, str_1, enable_2, str_2, enable_3, str_3, enable_4, str_4);
}

void PtzCtrl::mvModifyPtzInfo(bool preposition, bool zoom_ratio, bool cruisescan, bool trackingscan, bool linescan){
    current_device_->mvModifyPtzInfo(preposition, zoom_ratio, cruisescan, trackingscan, linescan);
}

void PtzCtrl::mvModifyFontProperty(int font_size, int font_color, int font_alig){
    current_device_->mvModifyFontProperty(static_cast<OSDSettings::Size>(font_size),static_cast<OSDSettings::Color>(font_color), static_cast<OSDSettings::Alignment>(font_alig));
}

void PtzCtrl::mvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway,
                                           QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns,
                                           QString dns){
    current_device_->mvModifyLocalNetworkProperty(static_ip, ip4_ip, ip4_mask, ip4_gateway, ip6_ip, ip6_prefix, ip6_gateway, pre_dns, dns);
}

void PtzCtrl::mvApplyOsdSettings(){
    current_device_->mvApplyOsdSettings();
}

void PtzCtrl::mvApplyNetWorkSettings(){
    current_device_->mvApplyNetWorkSettings();
}
