#ifndef CRUISE_RECORD_MANAGER_H
#define CRUISE_RECORD_MANAGER_H

#include <QObject>
#include <QString>
#include <QDateTime>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QFile>
#include <QDir>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QThread>
#include <QMutex>

// 巡航记录数据结构
struct CruiseRecordData {
    int id = -1;                // 数据库ID
    QString timestamp;          // 时间戳 (yyyy-MM-dd HH:mm:ss)
    QString deviceId;           // 设备ID
    int presetId;               // 预置位ID
    double concentration;       // 浓度值
    double threshold = 0.0;     // 当时的报警浓度阈值
    QString status;             // 状态（保留但界面不使用）
    
    QJsonObject toJson() const;
    static CruiseRecordData fromJson(const QJsonObject& json);
};

class CruiseRecordManager : public QObject
{
    Q_OBJECT

public:
    static CruiseRecordManager* instance();
    
    // 保存巡航记录
    Q_INVOKABLE bool saveCruiseRecord(const QString& deviceId, int presetId, double concentration, double threshold, const QString& status);

    // 查询巡航记录
    Q_INVOKABLE QVariantList queryCruiseRecords(const QString& startTime = "",
                                               const QString& endTime = "",
                                               const QString& deviceId = "");

    // 查询巡航记录（分页）
    Q_INVOKABLE QVariantList queryCruiseRecordsPaginated(const QString& startTime = "",
                                                        const QString& endTime = "",
                                                        int limit = 100,
                                                        int offset = 0,
                                                        const QString& deviceId = "");

    // 删除记录
    Q_INVOKABLE bool deleteRecords(const QString& startTime = "",
                                  const QString& endTime = "",
                                  const QString& deviceId = "");

    Q_INVOKABLE bool deleteAllRecords();

private:
    CruiseRecordManager(QObject *parent = nullptr);
    ~CruiseRecordManager();
    
    static CruiseRecordManager* m_instance;
    
    QSqlDatabase m_db;
    QMutex m_dbMutex;  // 互斥锁确保线程安全
    
    void initDatabase();
    QString getCurrentDate();
};

#endif // CRUISE_RECORD_MANAGER_H
