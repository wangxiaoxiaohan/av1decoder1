#ifndef PTZ_DEVICE_MANAGER_H
#define PTZ_DEVICE_MANAGER_H

#include <QObject>
#include <QMap>
#include <QRecursiveMutex>
#include <QThread>
#include "ptz_device_cgi.h"
#include "model/devicemodel.h"

class PtzDeviceManager : public QObject
{
    Q_OBJECT
    
    // 添加气体浓度报警状态属性
    Q_PROPERTY(bool gasConcentrationAlarm READ gasConcentrationAlarm NOTIFY gasConcentrationAlarmChanged)

public:
    static PtzDeviceManager* instance();
    
    // 设备管理
    Q_INVOKABLE void initializeDevice(const QString &deviceId, const QString &username, const QString &password, const QString &ip, const QString &tdlasIp = QString(), int tdlasPort = 0, const QString &modbusIp = QString(), int modbusPort = 0, const QString &tofIp = QString(), int tofPort = 0);
    Q_INVOKABLE void removeDevice(const QString &deviceId);
    Q_INVOKABLE PtzDeviceCgi* getDevice(const QString &deviceId);
    Q_INVOKABLE QString getCurrentDeviceId();
    Q_INVOKABLE void setCurrentDevice(const QString &deviceId);
    
    // 批量操作
    Q_INVOKABLE void initializeAllDevices();
    Q_INVOKABLE void removeAllDevices();
    
    // 设备状态
    Q_INVOKABLE bool isDeviceInitialized(const QString &deviceId);
    Q_INVOKABLE QStringList getInitializedDevices();
    
    // 设置FrameProvider
    Q_INVOKABLE void setFrameProviders(FrameProvider* visibleLight, FrameProvider* infrared);
    Q_INVOKABLE void setDeviceFrameProviders(const QString &deviceId, FrameProvider* visibleLight, FrameProvider* infrared);

    // 添加气体浓度报警状态读取方法
    Q_INVOKABLE bool gasConcentrationAlarm() const;
    
    // 获取当前设备的报警浓度值
    Q_INVOKABLE int getCurrentDeviceAlarmConcentration() const;
    
    // 设置当前设备的报警浓度值
    Q_INVOKABLE void setCurrentDeviceAlarmConcentration(int concentration);
    
    // 获取当前报警设备的通道号
    Q_INVOKABLE int getCurrentAlarmDeviceChannel() const;
    
    // Modbus设备管理方法
    Q_INVOKABLE void initializeModbusDevice(const QString &deviceId, const QString &modbusIp, int modbusPort);
    Q_INVOKABLE void sendModbusVoltage(const QString &deviceId, float voltage);
    Q_INVOKABLE void sendModbusData(const QString &deviceId, const QVariantList &data);

    // TOF设备管理方法
    Q_INVOKABLE void initializeTofDevice(const QString &deviceId, const QString &tofIp, int tofPort);
    Q_INVOKABLE void sendTofSingleRangingCmd(const QString &deviceId);
    Q_INVOKABLE void sendTofContinuousRangingCmd(const QString &deviceId);
    Q_INVOKABLE void sendTofStopRangingCmd(const QString &deviceId);

signals:
    void deviceInitialized(const QString &deviceId);
    void deviceRemoved(const QString &deviceId);
    void currentDeviceChanged(const QString &deviceId);
    void allDevicesInitialized();
    void gasConcentrationAlarmChanged(bool alarm);
    void modbusDeviceInitialized(const QString &deviceId);
    void modbusDataSent(const QString &deviceId, bool success);
    void tofDeviceInitialized(const QString &deviceId);
    void tofDistanceUpdated(const QString &deviceId, int channelIndex, float distance);
    void tofRangingError(const QString &deviceId, QString errorMessage);

private:
    explicit PtzDeviceManager(QObject* parent = nullptr);
    ~PtzDeviceManager();
    
    static PtzDeviceManager* m_instance;
    
    QMap<QString, PtzDeviceCgi*> m_devices;
    QMap<QString, QThread*> m_deviceThreads;
    QString m_currentDeviceId;
    mutable QRecursiveMutex m_mutex;
    
    FrameProvider* m_defaultVisibleLightProvider;
    FrameProvider* m_defaultInfraredProvider;
    

};

#endif // PTZ_DEVICE_MANAGER_H