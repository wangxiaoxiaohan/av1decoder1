#include "systemlog.h"
#include <QStandardPaths>
#include <QDir>
#include <QDateTime>
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>

QJsonObject SystemLogEntry::toJson() const {
    QJsonObject obj;
    obj["id"] = id;
    obj["operator_name"] = operator_name;
    obj["log_type"] = static_cast<int>(log_type);
    obj["action_type"] = static_cast<int>(action_type);
    obj["operation_time"] = operation_time;
    obj["operation_ip"] = operation_ip;
    obj["result"] = static_cast<int>(result);
    obj["description"] = description;
    return obj;
}

SystemLog* SystemLog::m_instance = nullptr;

SystemLog* SystemLog::instance()
{
    if (!m_instance)
        m_instance = new SystemLog();
    return m_instance;
}

SystemLog::SystemLog(QObject* parent)
    : QObject(parent)
{
    // 使用程序运行目录创建config/systemlog目录
    QString appDir = QCoreApplication::applicationDirPath();
    QDir dir(appDir + "/config/systemlog");
    if (!dir.exists()) {
        dir.mkpath(appDir + "/config/systemlog");
    }
    QString dbPath = appDir + "/config/systemlog/systemlog.db";
    qDebug() << "***********SystemLog db path:" << dbPath;

    m_db = QSqlDatabase::addDatabase("QSQLITE", "systemlog_connection");
    m_db.setDatabaseName(dbPath);
    if (!m_db.open()) {
        qWarning() << "Failed to open SystemLog database:" << m_db.lastError().text();
    }

    initDatabase();
}

void SystemLog::initDatabase()
{
    qDebug() << "********** 初始化系统日志数据表 ***************";
    QSqlQuery query(m_db);
    
    // 创建系统日志表
    query.exec("CREATE TABLE IF NOT EXISTS SystemLog ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT,"
               "operator_name TEXT NOT NULL,"
               "log_type INTEGER NOT NULL,"
               "action_type INTEGER NOT NULL,"
               "operation_time DATETIME DEFAULT CURRENT_TIMESTAMP,"
               "operation_ip TEXT,"
               "result INTEGER DEFAULT 0,"
               "description TEXT"
               ")");

    // 创建索引以优化查询速度
    query.exec("CREATE INDEX IF NOT EXISTS idx_operator_name ON SystemLog(operator_name)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_log_type ON SystemLog(log_type)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_action_type ON SystemLog(action_type)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_operation_time ON SystemLog(operation_time)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_operation_ip ON SystemLog(operation_ip)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_result ON SystemLog(result)");

    // 创建触发器，自动清理6个月前的日志
    query.exec("CREATE TRIGGER IF NOT EXISTS trg_clean_old_systemlog "
               "AFTER INSERT ON SystemLog "
               "BEGIN "
               "  DELETE FROM SystemLog "
               "  WHERE operation_time < datetime('now', '-6 months'); "
               "END;");
}

void SystemLog::addLog(const SystemLogEntry& entry)
{
    QSqlQuery query(m_db);
    query.prepare("INSERT INTO SystemLog (operator_name, log_type, action_type, operation_time, "
                  "operation_ip, result, description) "
                  "VALUES (:operator_name, :log_type, :action_type, :operation_time, "
                  ":operation_ip, :result, :description)");
    query.bindValue(":operator_name", entry.operator_name);
    query.bindValue(":log_type", entry.log_type);
    query.bindValue(":action_type", entry.action_type);
    query.bindValue(":operation_time", entry.operation_time);
    query.bindValue(":operation_ip", entry.operation_ip);
    query.bindValue(":result", entry.result);
    query.bindValue(":description", entry.description);

    if (!query.exec()) {
        qWarning() << "Failed to insert system log:" << query.lastError().text();
        qWarning() << "Error details - operator:" << entry.operator_name 
                   << " log_type:" << entry.log_type 
                   << " action_type:" << entry.action_type
                   << " ip:" << entry.operation_ip;
    } else {
        qDebug() << "Successfully inserted system log";
        emit logAdded();
    }
}

void SystemLog::addLog(const QString& operatorName, int logType, int actionType,
                       const QString& operationTime, const QString& operationIp,
                       int result, const QString& description)
{
    SystemLogEntry entry;
    entry.operator_name = operatorName;
    entry.log_type = static_cast<LOG_TYPE_T>(logType);
    entry.action_type = static_cast<ACTION_TYPE_T>(actionType);
    entry.operation_time = operationTime.isEmpty() ? QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss") : operationTime;
    entry.operation_ip = operationIp;
    entry.result = static_cast<OPERATION_RESULT_T>(result);
    entry.description = description;

    addLog(entry);
}

QVariantMap SystemLog::queryLogs(const QString& operatorName,
                                 int logType,
                                 int actionType,
                                 const QString& startTime,
                                 const QString& endTime,
                                 int page,
                                 int pageSize)
{
    QVariantMap resultMap;
    QVariantList logsList;
    QSqlQuery query(m_db);

    qDebug() << "SystemLog query - operator:" << operatorName << "logType:" << logType 
             << "actionType:" << actionType << "start:" << startTime << "end:" << endTime 
             << "page:" << page;

    // 动态构建 WHERE 条件
    QStringList conditions;
    if (!operatorName.isEmpty() && operatorName != "全部") {
        conditions << "operator_name = :operator_name";
    }
    if (logType >= 0) {
        conditions << "log_type = :log_type";
    }
    if (actionType >= 0) {
        conditions << "action_type = :action_type";
    }
    if (!startTime.isEmpty()) {
        conditions << "operation_time >= :start_time";
    }
    if (!endTime.isEmpty()) {
        conditions << "operation_time <= :end_time";
    }

    QString whereClause = conditions.isEmpty() ? "" : " WHERE " + conditions.join(" AND ");

    // ------- 1. 查询总数 -------
    QString countSql = "SELECT COUNT(*) FROM SystemLog" + whereClause;
    query.prepare(countSql);

    if (!operatorName.isEmpty() && operatorName != "全部") {
        query.bindValue(":operator_name", operatorName);
    }
    if (logType >= 0) {
        query.bindValue(":log_type", logType);
    }
    if (actionType >= 0) {
        query.bindValue(":action_type", actionType);
    }
    if (!startTime.isEmpty()) {
        query.bindValue(":start_time", startTime);
    }
    if (!endTime.isEmpty()) {
        query.bindValue(":end_time", endTime);
    }

    int totalCount = 0;
    if (query.exec() && query.next())
        totalCount = query.value(0).toInt();
    else
        qWarning() << "Failed to query system log count:" << query.lastError().text();

    // ------- 2. 查询分页数据 -------
    QString dataSql = "SELECT * FROM SystemLog" + whereClause +
                      " ORDER BY operation_time DESC LIMIT :limit OFFSET :offset";
    query.prepare(dataSql);

    if (!operatorName.isEmpty() && operatorName != "全部") {
        query.bindValue(":operator_name", operatorName);
    }
    if (logType >= 0) {
        query.bindValue(":log_type", logType);
    }
    if (actionType >= 0) {
        query.bindValue(":action_type", actionType);
    }
    if (!startTime.isEmpty()) {
        query.bindValue(":start_time", startTime);
    }
    if (!endTime.isEmpty()) {
        query.bindValue(":end_time", endTime);
    }
    query.bindValue(":limit", pageSize);
    query.bindValue(":offset", page * pageSize);

    if (!query.exec()) {
        qWarning() << "Failed to query system logs:" << query.lastError().text();
    } else {
        while (query.next()) {
            SystemLogEntry entry = fromQuery(query);
            QVariantMap map;
            map["id"] = entry.id;
            map["operator_name"] = entry.operator_name;
            map["log_type"] = entry.log_type;
            map["action_type"] = entry.action_type;
            map["operation_time"] = entry.operation_time;
            map["operation_ip"] = entry.operation_ip;
            map["result"] = entry.result;
            map["description"] = entry.description;

            logsList.append(map);
        }
    }

    // ------- 3. 返回结构 -------
    qDebug() << "Total matched system logs:" << totalCount;
    qDebug() << "Returned system logs in this page:" << logsList.size();

    resultMap["total"] = totalCount;
    resultMap["page"] = page;
    resultMap["logs"] = logsList;
    return resultMap;
}

SystemLogEntry SystemLog::fromQuery(const QSqlQuery& query)
{
    SystemLogEntry entry;
    entry.id = query.value("id").toInt();
    entry.operator_name = query.value("operator_name").toString();
    entry.log_type = static_cast<LOG_TYPE_T>(query.value("log_type").toInt());
    entry.action_type = static_cast<ACTION_TYPE_T>(query.value("action_type").toInt());
    entry.operation_time = query.value("operation_time").toString();
    entry.operation_ip = query.value("operation_ip").toString();
    entry.result = static_cast<OPERATION_RESULT_T>(query.value("result").toInt());
    entry.description = query.value("description").toString();
    return entry;
}

bool SystemLog::deleteLog(int id)
{
    QSqlQuery query(m_db);
    query.prepare("DELETE FROM SystemLog WHERE id = :id");
    query.bindValue(":id", id);
    if (!query.exec()) {
        qWarning() << "Failed to delete system log:" << query.lastError().text();
        return false;
    }
    return true;
}

bool SystemLog::deleteAll()
{
    QSqlQuery query(m_db);
    if (!query.exec("DELETE FROM SystemLog")) {
        qWarning() << "Failed to delete all system logs:" << query.lastError().text();
        return false;
    }
    return true;
}

bool SystemLog::exportLogsToCsv(const QString& operatorName,
                                int logType,
                                int actionType,
                                const QString& startTime,
                                const QString& endTime)
{
    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMddHHmmss");
    QString fileName = QString("systemlog_%1.csv").arg(timestamp);

    // 保存到桌面目录
    QString dir = QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);
    QString filePath = dir + "/" + fileName;

    qDebug() << "export system log filePath:" << filePath;

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qWarning() << "Cannot open file for writing:" << file.errorString();
        return false;
    }

    QTextStream out(&file);
    out.setCodec("UTF-8");
    out << QChar(0xFEFF);  // 写入 UTF-8 BOM 以防止 Excel 乱码

    // 写入表头
    auto csvSafe = [](const QString& val) -> QString {
        QString safeVal = val;
        return "\"" + safeVal.replace("\"", "\"\"") + "\"";
    };

    out << csvSafe("ID") << "," << csvSafe("操作人员") << "," << csvSafe("日志类型") << ","
        << csvSafe("操作类型") << "," << csvSafe("操作时间") << "," << csvSafe("操作IP") << ","
        << csvSafe("操作结果") << "," << csvSafe("操作描述") << "\n";

    QVariantMap result = queryLogs(operatorName, logType, actionType, startTime, endTime, 0, 100000);
    if (result["logs"].isNull()) return false;

    QVariantList logs = result["logs"].toList();
    if (logs.length() == 0) return false;

    for (const QVariant& logVar : logs) {
        QVariantMap log = logVar.toMap();
        out << log["id"].toString() << ","
            << csvSafe(log["operator_name"].toString()) << ","
            << csvSafe(getLogTypeString(log["log_type"].toInt())) << ","
            << csvSafe(getActionTypeString(log["action_type"].toInt())) << ","
            << csvSafe(log["operation_time"].toString()) << ","
            << csvSafe(log["operation_ip"].toString()) << ","
            << csvSafe(getResultString(log["result"].toInt())) << ","
            << csvSafe(log["description"].toString()) << "\n";
    }

    file.close();
    return true;
}

QString SystemLog::getLogTypeString(int logType)
{
    switch (logType) {
    case LOG_TYPE_QUERY:
        return "查询日志";
    case LOG_TYPE_OPERATION:
        return "操作日志";
    default:
        return "未知类型";
    }
}

QString SystemLog::getActionTypeString(int actionType)
{
    switch (actionType) {
    case ACTION_TYPE_VIDEO_PLAYBACK:
        return "视频回放";
    case ACTION_TYPE_MODIFY_ACCOUNT:
        return "修改账户";
    case ACTION_TYPE_DELETE_ACCOUNT:
        return "删除账户";
    case ACTION_TYPE_ADD_ACCOUNT:
        return "新增账户";
    case ACTION_TYPE_MODIFY_DEVICE:
        return "修改设备";
    case ACTION_TYPE_DELETE_DEVICE:
        return "删除设备";
    case ACTION_TYPE_ADD_DEVICE:
        return "添加设备";
    case ACTION_TYPE_QUERY_ALARM:
        return "查询报警记录";
    default:
        return "未知操作";
    }
}

QString SystemLog::getResultString(int result)
{
    switch (result) {
    case RESULT_SUCCESS:
        return "成功";
    case RESULT_FAILURE:
        return "失败";
    default:
        return "未知";
    }
}