#include "systemlog.h"
#include <QStandardPaths>
#include <QDir>
#include <QDateTime>
#include <QFile>
#include <QTextStream>
#include <QCoreApplication>

QJsonObject SystemLogEntry::toJson() const {
    QJsonObject obj;
    obj["id"] = id;
    obj["operator_name"] = operator_name;
    obj["log_type"] = static_cast<int>(log_type);
    obj["action_type"] = static_cast<int>(action_type);
    obj["operation_time"] = operation_time;
    obj["operation_ip"] = operation_ip;
    obj["result"] = static_cast<int>(result);
    obj["description"] = description;
    return obj;
}

SystemLog* SystemLog::m_instance = nullptr;

SystemLog* SystemLog::instance()
{
    if (!m_instance)
        m_instance = new SystemLog();
    return m_instance;
}

SystemLog::SystemLog(QObject* parent)
    : QObject(parent)
{
    // 获取应用程序所在目录的绝对路径
    QString appDir = QCoreApplication::applicationDirPath();
    QString configDir = QDir(appDir).absoluteFilePath("config/systemlog");
    
    QDir dir(configDir);
    if (!dir.exists()) {
        if (!dir.mkpath(configDir)) {
            qWarning() << "Failed to create directory:" << configDir;
        } else {
            qDebug() << "Created directory:" << configDir;
        }
    } else {
        qDebug() << "Directory exists:" << configDir;
    }
    
    QString dbPath = QDir(configDir).absoluteFilePath("systemlog.db");
    qDebug() << "***********SystemLog db path:" << dbPath;
    qDebug() << "Database file exists:" << QFile::exists(dbPath);

    m_db = QSqlDatabase::addDatabase("QSQLITE", "systemlog_connection");
    m_db.setDatabaseName(dbPath);
    if (!m_db.open()) {
        qWarning() << "Failed to open SystemLog database:" << m_db.lastError().text();
        
        // 尝试使用备用路径
        QString fallbackPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
        QDir fallbackDir(fallbackPath);
        if (!fallbackDir.exists()) {
            fallbackDir.mkpath(fallbackPath);
        }
        
        QString fallbackDbPath = QDir(fallbackPath).absoluteFilePath("systemlog.db");
        qDebug() << "Trying fallback path:" << fallbackDbPath;
        
        m_db.setDatabaseName(fallbackDbPath);
        if (!m_db.open()) {
            qWarning() << "Failed to open SystemLog database with fallback path:" << m_db.lastError().text();
        } else {
            qDebug() << "Successfully opened SystemLog database with fallback path";
        }
    } else {
        qDebug() << "Successfully opened SystemLog database";
    }

    initDatabase();
}

void SystemLog::initDatabase()
{
    qDebug() << "********** 初始化系统日志数据表 ***************";
    QSqlQuery query(m_db);
    
    // 创建系统日志表
    query.exec("CREATE TABLE IF NOT EXISTS SystemLog ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT,"
               "operator_name TEXT NOT NULL,"
               "log_type INTEGER NOT NULL,"
               "action_type INTEGER NOT NULL,"
               "operation_time DATETIME DEFAULT CURRENT_TIMESTAMP,"
               "operation_ip TEXT,"
               "result INTEGER DEFAULT 0,"
               "description TEXT"
               ")");

    // 创建单列索引以优化基本查询速度
    query.exec("CREATE INDEX IF NOT EXISTS idx_operator_name ON SystemLog(operator_name)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_log_type ON SystemLog(log_type)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_action_type ON SystemLog(action_type)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_operation_time ON SystemLog(operation_time)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_operation_ip ON SystemLog(operation_ip)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_result ON SystemLog(result)");

    // 创建复合索引以优化常见查询组合
    // 操作员 + 操作时间组合查询（最常见）
    query.exec("CREATE INDEX IF NOT EXISTS idx_operator_time ON SystemLog(operator_name, operation_time DESC)");
    
    // 日志类型 + 操作时间组合查询
    query.exec("CREATE INDEX IF NOT EXISTS idx_logtype_time ON SystemLog(log_type, operation_time DESC)");
    
    // 操作类型 + 操作时间组合查询
    query.exec("CREATE INDEX IF NOT EXISTS idx_action_time ON SystemLog(action_type, operation_time DESC)");
    
    // 操作员 + 日志类型 + 操作时间组合查询
    query.exec("CREATE INDEX IF NOT EXISTS idx_operator_logtype_time ON SystemLog(operator_name, log_type, operation_time DESC)");
    
    // 操作员 + 操作类型 + 操作时间组合查询
    query.exec("CREATE INDEX IF NOT EXISTS idx_operator_action_time ON SystemLog(operator_name, action_type, operation_time DESC)");
    
    // 日志类型 + 操作类型 + 操作时间组合查询
    query.exec("CREATE INDEX IF NOT EXISTS idx_logtype_action_time ON SystemLog(log_type, action_type, operation_time DESC)");
    
    // 操作员 + 日志类型 + 操作类型 + 操作时间组合查询（最复杂的查询）
    query.exec("CREATE INDEX IF NOT EXISTS idx_operator_logtype_action_time ON SystemLog(operator_name, log_type, action_type, operation_time DESC)");

    // 创建触发器，自动清理6个月前的日志
    query.exec("CREATE TRIGGER IF NOT EXISTS trg_clean_old_systemlog "
               "AFTER INSERT ON SystemLog "
               "BEGIN "
               "  DELETE FROM SystemLog "
               "  WHERE operation_time < datetime('now', '-6 months'); "
               "END;");
}

void SystemLog::addLog(const SystemLogEntry& entry)
{
    // 开始事务
    if (!m_db.transaction()) {
        qWarning() << "Failed to start transaction for system log insertion:" << m_db.lastError().text();
    }
    
    QSqlQuery query(m_db);
    query.prepare("INSERT INTO SystemLog (operator_name, log_type, action_type, operation_time, "
                  "operation_ip, result, description) "
                  "VALUES (:operator_name, :log_type, :action_type, :operation_time, "
                  ":operation_ip, :result, :description)");
    query.bindValue(":operator_name", entry.operator_name);
    query.bindValue(":log_type", entry.log_type);
    query.bindValue(":action_type", entry.action_type);
    query.bindValue(":operation_time", entry.operation_time);
    query.bindValue(":operation_ip", entry.operation_ip);
    query.bindValue(":result", entry.result);
    query.bindValue(":description", entry.description);

    bool success = query.exec();
    if (!success) {
        qWarning() << "Failed to insert system log:" << query.lastError().text();
        qWarning() << "Error details - operator:" << entry.operator_name 
                   << " log_type:" << entry.log_type 
                   << " action_type:" << entry.action_type
                   << " ip:" << entry.operation_ip;
        
        // 回滚事务
        if (!m_db.rollback()) {
            qWarning() << "Failed to rollback transaction:" << m_db.lastError().text();
        }
    } else {
        // 提交事务
        if (!m_db.commit()) {
            qWarning() << "Failed to commit transaction:" << m_db.lastError().text();
        } else {
            qDebug() << "Successfully inserted system log";
            emit logAdded();
        }
    }
}

void SystemLog::addLog(const QString& operatorName, int logType, int actionType,
                       const QString& operationTime, const QString& operationIp,
                       int result, const QString& description)
{
    SystemLogEntry entry;
    entry.operator_name = operatorName;
    entry.log_type = static_cast<LOG_TYPE_T>(logType);
    entry.action_type = static_cast<ACTION_TYPE_T>(actionType);
    entry.operation_time = operationTime.isEmpty() ? QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss") : operationTime;
    entry.operation_ip = operationIp;
    entry.result = static_cast<OPERATION_RESULT_T>(result);
    entry.description = description;

    addLog(entry);
}

QVariantMap SystemLog::queryLogs(const QString& operatorName,
                                 int logType,
                                 int actionType,
                                 const QString& startTime,
                                 const QString& endTime,
                                 int page,
                                 int pageSize)
{
    QVariantMap resultMap;
    QVariantList logsList;
    QSqlQuery query(m_db);

    qDebug() << "SystemLog query - operator:" << operatorName << "logType:" << logType 
             << "actionType:" << actionType << "start:" << startTime << "end:" << endTime 
             << "page:" << page;

    // 动态构建 WHERE 条件
    QStringList conditions;
    if (!operatorName.isEmpty() && operatorName != "全部") {
        conditions << "operator_name = :operator_name";
    }
    if (logType >= 0) {
        conditions << "log_type = :log_type";
    }
    if (actionType >= 0) {
        conditions << "action_type = :action_type";
    }
    if (!startTime.isEmpty()) {
        conditions << "operation_time >= :start_time";
    }
    if (!endTime.isEmpty()) {
        conditions << "operation_time <= :end_time";
    }

    QString whereClause = conditions.isEmpty() ? "" : " WHERE " + conditions.join(" AND ");

    // 使用优化的单次查询 + 子查询获取总数
    QString optimizedSql = "SELECT "
        "  (SELECT COUNT(*) FROM SystemLog" + whereClause + ") as total_count, "
        "  id, operator_name, log_type, action_type, operation_time, "
        "  operation_ip, result, description "
        "FROM SystemLog" + whereClause + 
        " ORDER BY operation_time DESC LIMIT :limit OFFSET :offset";

    query.prepare(optimizedSql);

    if (!operatorName.isEmpty() && operatorName != "全部") {
        query.bindValue(":operator_name", operatorName);
    }
    if (logType >= 0) {
        query.bindValue(":log_type", logType);
    }
    if (actionType >= 0) {
        query.bindValue(":action_type", actionType);
    }
    if (!startTime.isEmpty()) {
        query.bindValue(":start_time", startTime);
    }
    if (!endTime.isEmpty()) {
        query.bindValue(":end_time", endTime);
    }
    query.bindValue(":limit", pageSize);
    query.bindValue(":offset", page * pageSize);

    qDebug() << "Optimized query SQL:" << optimizedSql;

    int totalCount = 0;
    qDebug() << "system log query start time:" << QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
    if (!query.exec()) {
        qWarning() << "Failed to query system logs:" << query.lastError().text();
    } else {
        // 预分配内存以提高性能
        logsList.reserve(querySizeHint(pageSize));
        
        bool firstRow = true;
        while (query.next()) {
            if (firstRow) {
                totalCount = query.value(0).toInt();
                firstRow = false;
                qDebug() << "Total matched system logs:" << totalCount;
            }
            
            QVariantMap map;
            map["id"] = query.value("id").toInt();
            map["operator_name"] = query.value("operator_name").toString();
            map["log_type"] = query.value("log_type").toInt();
            map["action_type"] = query.value("action_type").toInt();
            map["operation_time"] = query.value("operation_time").toString();
            map["operation_ip"] = query.value("operation_ip").toString();
            map["result"] = query.value("result").toInt();
            map["description"] = query.value("description").toString();

            logsList.append(map);
        }
    }
    qDebug() << "system log query end time:" << QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
    // ------- 3. 返回结构 -------
    qDebug() << "Total matched system logs:" << totalCount;
    qDebug() << "Returned system logs in this page:" << logsList.size();

    resultMap["total"] = totalCount;
    resultMap["page"] = page;
    resultMap["logs"] = logsList;
    return resultMap;
}

SystemLogEntry SystemLog::fromQuery(const QSqlQuery& query)
{
    SystemLogEntry entry;
    entry.id = query.value("id").toInt();
    entry.operator_name = query.value("operator_name").toString();
    entry.log_type = static_cast<LOG_TYPE_T>(query.value("log_type").toInt());
    entry.action_type = static_cast<ACTION_TYPE_T>(query.value("action_type").toInt());
    entry.operation_time = query.value("operation_time").toString();
    entry.operation_ip = query.value("operation_ip").toString();
    entry.result = static_cast<OPERATION_RESULT_T>(query.value("result").toInt());
    entry.description = query.value("description").toString();
    return entry;
}

bool SystemLog::deleteLog(int id)
{
    // 开始事务
    if (!m_db.transaction()) {
        qWarning() << "Failed to start transaction for system log deletion:" << m_db.lastError().text();
    }
    
    QSqlQuery query(m_db);
    query.prepare("DELETE FROM SystemLog WHERE id = :id");
    query.bindValue(":id", id);
    
    bool success = query.exec();
    if (!success) {
        qWarning() << "Failed to delete system log:" << query.lastError().text();
        
        // 回滚事务
        if (!m_db.rollback()) {
            qWarning() << "Failed to rollback transaction:" << m_db.lastError().text();
        }
        return false;
    } else {
        // 提交事务
        if (!m_db.commit()) {
            qWarning() << "Failed to commit transaction:" << m_db.lastError().text();
            return false;
        }
        qDebug() << "Successfully deleted system log with id:" << id;
        return true;
    }
}

bool SystemLog::deleteAll()
{
    // 开始事务
    if (!m_db.transaction()) {
        qWarning() << "Failed to start transaction for deleting all system logs:" << m_db.lastError().text();
    }
    
    QSqlQuery query(m_db);
    bool success = query.exec("DELETE FROM SystemLog");
    if (!success) {
        qWarning() << "Failed to delete all system logs:" << query.lastError().text();
        
        // 回滚事务
        if (!m_db.rollback()) {
            qWarning() << "Failed to rollback transaction:" << m_db.lastError().text();
        }
        return false;
    } else {
        // 提交事务
        if (!m_db.commit()) {
            qWarning() << "Failed to commit transaction:" << m_db.lastError().text();
            return false;
        }
        qDebug() << "Successfully deleted all system logs";
        return true;
    }
}

bool SystemLog::exportLogsToCsvWithPath(const QString& filePath,
                                        const QString& operatorName,
                                        int logType,
                                        int actionType,
                                        const QString& startTime,
                                        const QString& endTime)
{
    qDebug() << "export system log filePath:" << filePath;

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qWarning() << "Cannot open file for writing:" << file.errorString();
        return false;
    }

    QTextStream out(&file);
    out.setCodec("UTF-8");
    out << QChar(0xFEFF);  // 写入 UTF-8 BOM 以防止 Excel 乱码

    // 写入表头
    auto csvSafe = [](const QString& val) -> QString {
        QString safeVal = val;
        return "\"" + safeVal.replace("\"", "\"\"") + "\"";
    };

    out << csvSafe("ID") << "," << csvSafe("操作人员") << "," << csvSafe("日志类型") << ","
        << csvSafe("操作类型") << "," << csvSafe("操作时间") << "," << csvSafe("操作IP") << ","
        << csvSafe("操作结果") << "," << csvSafe("操作描述") << "\n";

    QVariantMap result = queryLogs(operatorName, logType, actionType, startTime, endTime, 0, 100000);
    if (result["logs"].isNull()) return false;

    QVariantList logs = result["logs"].toList();
    if (logs.length() == 0) return false;

    for (const QVariant& logVar : logs) {
        QVariantMap log = logVar.toMap();
        out << log["id"].toString() << ","
            << csvSafe(log["operator_name"].toString()) << ","
            << csvSafe(getLogTypeString(log["log_type"].toInt())) << ","
            << csvSafe(getActionTypeString(log["action_type"].toInt())) << ","
            << csvSafe(log["operation_time"].toString()) << ","
            << csvSafe(log["operation_ip"].toString()) << ","
            << csvSafe(getResultString(log["result"].toInt())) << ","
            << csvSafe(log["description"].toString()) << "\n";
    }

    file.close();
    return true;
}

bool SystemLog::exportLogsToCsv(const QString& operatorName,
                                int logType,
                                int actionType,
                                const QString& startTime,
                                const QString& endTime)
{
    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMddHHmmss");
    QString fileName = QString("systemlog_%1.csv").arg(timestamp);

    // 保存到桌面目录
    QString dir = QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);
    QString filePath = dir + "/" + fileName;

    // 调用新的导出方法
    return exportLogsToCsvWithPath(filePath, operatorName, logType, actionType, startTime, endTime);
}

int SystemLog::querySizeHint(int pageSize) const
{
    // 返回一个合理的预分配大小，避免频繁重新分配内存
    return pageSize > 0 ? pageSize : 50;  // 默认预分配50条记录的空间
}

QString SystemLog::getLogTypeString(int logType)
{
    switch (logType) {
    case LOG_TYPE_QUERY:
        return "查询日志";
    case LOG_TYPE_OPERATION:
        return "操作日志";
    default:
        return "未知类型";
    }
}

QString SystemLog::getActionTypeString(int actionType)
{
    switch (actionType) {
    case ACTION_TYPE_VIDEO_PLAYBACK:
        return "视频回放";
    case ACTION_TYPE_MODIFY_ACCOUNT:
        return "修改账户";
    case ACTION_TYPE_DELETE_ACCOUNT:
        return "删除账户";
    case ACTION_TYPE_ADD_ACCOUNT:
        return "新增账户";
    case ACTION_TYPE_MODIFY_DEVICE:
        return "修改设备";
    case ACTION_TYPE_DELETE_DEVICE:
        return "删除设备";
    case ACTION_TYPE_ADD_DEVICE:
        return "添加设备";
    case ACTION_TYPE_QUERY_ALARM:
        return "查询报警记录";
    default:
        return "未知操作";
    }
}

QString SystemLog::getResultString(int result)
{
    switch (result) {
    case RESULT_SUCCESS:
        return "成功";
    case RESULT_FAILURE:
        return "失败";
    default:
        return "未知";
    }
}