#include "alarmrecordingmanager.h"
#include "hikvision_recorder.h"
#include "model/devicemodel.h"
#include "hikvision_ctrl.h"
#include <QDateTime>
#include <QJsonDocument>
#include <QCoreApplication>
#include <QDir>
#include <QStandardPaths>
#include <QTimer>

AlarmRecordingManager* AlarmRecordingManager::m_instance = nullptr;

QJsonObject AlarmRecordingEntry::toJson() const {
    QJsonObject obj;
    obj["id"] = id;
    obj["device_code"] = device_code;
    obj["device_name"] = device_name;
    obj["start_time"] = start_time;
    obj["end_time"] = end_time;
    obj["alarm_type"] = alarm_type;
    obj["concentration"] = concentration;
    obj["position"] = position;
    obj["duration_seconds"] = duration_seconds;
    obj["created_at"] = created_at;
    return obj;
}

AlarmRecordingManager* AlarmRecordingManager::instance()
{
    if (!m_instance) {
        m_instance = new AlarmRecordingManager();
    }
    return m_instance;
}

AlarmRecordingManager::AlarmRecordingManager(QObject* parent) : QObject(parent)
{
    initDatabase();
    
    // 初始化海康录像下载器
    m_hikvisionRecorder = new HikvisionRecorder(this);
    if (!m_hikvisionRecorder->initializeSDK()) {
        qWarning() << "海康SDK初始化失败";
    }
}

void AlarmRecordingManager::initDatabase()
{
    // 使用与手动录像相同的路径策略 - 相对路径

    QString appPath = QCoreApplication::applicationDirPath();
    QString dbPath = QDir(appPath).absoluteFilePath("config/recordvideo/alarm_recordings.db");

    //QString dbPath = QDir::currentPath() + "/config/recordvideo/alarm_recordings.db";
    QDir dbDir(QFileInfo(dbPath).absolutePath());
    if (!dbDir.exists()) {
        dbDir.mkpath(".");
    }

    m_db = QSqlDatabase::addDatabase("QSQLITE", "alarm_recording_connection");
    m_db.setDatabaseName(dbPath);

    if (!m_db.open()) {
        qDebug() << "无法打开报警录像数据库:" << m_db.lastError().text();
        return;
    }

    QSqlQuery query(m_db);
    QString createTable = R"(
        CREATE TABLE IF NOT EXISTS alarm_recordings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_code TEXT NOT NULL,
            device_name TEXT,
            start_time TEXT NOT NULL,
            end_time TEXT,
            alarm_type TEXT NOT NULL DEFAULT '气体报警',
            concentration TEXT,
            position TEXT,
            duration_seconds INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    )";

    if (!query.exec(createTable)) {
        qDebug() << "创建报警录像表失败:" << query.lastError().text();
        return;
    }
    
    // 创建索引
    QString createIndex = "CREATE INDEX IF NOT EXISTS idx_device_code ON alarm_recordings(device_code)";
    if (!query.exec(createIndex)) {
        qDebug() << "创建设备索引失败:" << query.lastError().text();
    }
    
    createIndex = "CREATE INDEX IF NOT EXISTS idx_start_time ON alarm_recordings(start_time)";
    if (!query.exec(createIndex)) {
        qDebug() << "创建时间索引失败:" << query.lastError().text();
    }
}

void AlarmRecordingManager::handleGasAlarm(const QString& deviceCode, const QString& deviceName,
                                           const QString& concentration, const QString& position)
{
    DeviceAlarmState* state = getDeviceState(deviceCode);
    
    if (state->isRecording) {
        // 如果正在录制，延长录制时间
        extendRecording(deviceCode);
        qDebug() << "设备" << deviceCode << "气体报警，延长录制时间，浓度:" << concentration;
    } else {
        // 如果未录制，开始新的录制
        startAlarmRecording(deviceCode, deviceName, concentration, position);
        qDebug() << "设备" << deviceCode << "开始报警录制，浓度:" << concentration;
    }
}

void AlarmRecordingManager::startAlarmRecording(const QString& deviceCode, const QString& deviceName,
                                              const QString& concentration, const QString& position)
{
    DeviceAlarmState* state = getDeviceState(deviceCode);
    
    if (state->isRecording) {
        // 如果已经在录制，先停止当前的
        stopRecordingInternal(deviceCode);
    }
    
    QString startTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    state->currentStartTime = startTime;
    state->isRecording = true;
    state->extendCount = 0;
    
    // 创建15秒后的停止定时器
    if (!state->stopTimer) {
        state->stopTimer = new QTimer(this);
        connect(state->stopTimer, &QTimer::timeout, [this, deviceCode]() {
            onStopTimerTimeout(deviceCode);
        });
    }
    
    state->stopTimer->start(15000); // 15秒
    
    emit recordingStarted(deviceCode, startTime, concentration);
    qDebug() << "设备" << deviceCode << "开始报警录制，开始时间:" << startTime;
}

void AlarmRecordingManager::extendRecording(const QString& deviceCode)
{
    DeviceAlarmState* state = getDeviceState(deviceCode);
    
    if (!state->isRecording || !state->stopTimer) {
        return;
    }
    
    // 重置定时器，再延长15秒
    state->stopTimer->stop();
    state->stopTimer->start(15000);
    state->extendCount++;
    
    emit recordingExtended(deviceCode, QDateTime::currentDateTime().addSecs(15).toString("yyyy-MM-dd hh:mm:ss"));
    qDebug() << "设备" << deviceCode << "延长录制时间，延长次数:" << state->extendCount;
}

void AlarmRecordingManager::onStopTimerTimeout(const QString& deviceCode)
{
    stopRecordingInternal(deviceCode);
}

void AlarmRecordingManager::stopRecordingInternal(const QString& deviceCode)
{
    DeviceAlarmState* state = getDeviceState(deviceCode);
    
    if (!state->isRecording) {
        return;
    }
    
    QString endTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    
    // 计算录制时长
    QDateTime startDateTime = QDateTime::fromString(state->currentStartTime, "yyyy-MM-dd hh:mm:ss");
    QDateTime endDateTime = QDateTime::fromString(endTime, "yyyy-MM-dd hh:mm:ss");
    int duration = startDateTime.secsTo(endDateTime);
    
    // 查询设备名称和最后一次报警信息
    QString deviceName = "";
    QString concentration = "";
    QString position = "";
    
    // 这里可以查询设备信息，暂时使用默认值
    deviceName = deviceCode; // 简化处理
    
    // 保存到数据库
    QSqlQuery query(m_db);
    query.prepare(R"(
        INSERT INTO alarm_recordings 
        (device_code, device_name, start_time, end_time, alarm_type, concentration, position, duration_seconds)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    )");
    
    query.addBindValue(deviceCode);
    query.addBindValue(deviceName);
    query.addBindValue(state->currentStartTime);
    query.addBindValue(endTime);
    query.addBindValue("气体报警");
    query.addBindValue(concentration);
    query.addBindValue(position);
    query.addBindValue(duration);
    
    if (query.exec()) {
        emit recordingStopped(deviceCode, endTime, duration);
        emit recordingAdded();
        qDebug() << "设备" << deviceCode << "报警录制结束，时长:" << duration << "秒";
        
        // 延迟20分钟后从NVR下载录像
        QTimer::singleShot(3 * 60 * 1000, this, [this, deviceCode, startDateTime, endDateTime, deviceName]() {
            qInfo() << "开始延迟下载NVR录像，设备:" << deviceCode << "时间段:" << startDateTime.toString() << "-" << endDateTime.toString();
            downloadRecordingFromNvr(deviceCode, startDateTime, endDateTime, deviceName);
        });
        
    } else {
        qDebug() << "保存报警录制记录失败:" << query.lastError().text();
    }
    
    // 重置状态
    state->isRecording = false;
    state->currentStartTime = "";
    state->extendCount = 0;
    
    if (state->stopTimer) {
        state->stopTimer->stop();
    }
}

void AlarmRecordingManager::stopAlarmRecording(const QString& deviceCode)
{
    stopRecordingInternal(deviceCode);
}

void AlarmRecordingManager::downloadRecordingFromNvr(const QString& deviceCode, const QDateTime& startTime, const QDateTime& endTime, const QString& alarmName)
{
    // 获取设备信息
    DeviceModel* deviceModel = DeviceModel::instance();
    if (!deviceModel) {
        qWarning() << "DeviceModel未初始化";
        return;
    }
    
    QString hikvisionIp = deviceModel->getHikvisionIp(deviceCode);
    int hikvisionPort = deviceModel->getHikvisionPort(deviceCode);
    QString hikvisionUsername = deviceModel->getHikvisionUsername(deviceCode);
    QString hikvisionPassword = deviceModel->getHikvisionPassword(deviceCode);
    
    if (hikvisionIp.isEmpty() || hikvisionPort == 0 || hikvisionUsername.isEmpty() || hikvisionPassword.isEmpty()) {
        qWarning() << "设备" << deviceCode << "的NVR连接参数不完整";
        return;
    }
    
    // 获取报警视频保存路径
    QString alarmVideoPath = deviceModel->getVideoSettings("alarmVideoPath");
    if (alarmVideoPath.isEmpty()) {
        alarmVideoPath = "D:/ZG_Client/Alarm_video"; // 默认路径
    }
    
    // 设置下载路径
    QString downloadPath = alarmVideoPath + "/" + deviceCode;
    QDir dir(downloadPath);
    if (!dir.exists()) {
        dir.mkpath(downloadPath);
    }
    
    // 生成文件名
    QString fileName = QString("%1_%2_%3.mp4")
        .arg(alarmName.isEmpty() ? "alarm" : alarmName)
        .arg(startTime.toString("yyyyMMdd_HHmmss"))
        .arg(endTime.toString("yyyyMMdd_HHmmss"));
    
    QString fullPath = downloadPath + "/" + fileName;
    
    // 获取通道号 - 参考StorageManagement.qml的实现
    int selectedChannel = 1; // 默认通道
    QString channelType = "红外"; // 默认类型
    QString ipcIp = "";
    
    // 默认使用红外通道，因为没有UI选择，优先使用红外
    channelType = "红外";
    ipcIp = deviceModel->getInfraredIp(deviceCode);
    
    qInfo() << "设备" << deviceCode << "通道类型:" << channelType << "IPC IP:" << ipcIp;
    
    // 创建HikvisionCtrl实例来查找通道号
    HikvisionCtrl* hikvisionCtrl = new HikvisionCtrl(this);
    if (hikvisionCtrl && !ipcIp.isEmpty()) {
        qInfo() << "使用HikvisionCtrl查找通道号...";
        
        selectedChannel = hikvisionCtrl->findChannelByIP(
            hikvisionIp, 
            hikvisionPort, 
            hikvisionUsername, 
            hikvisionPassword,
            ipcIp
        );
        
        qInfo() << "HikvisionCtrl查找结果:" << selectedChannel;
        
        if (selectedChannel <= 0) {
            qInfo() << "HikvisionCtrl查找失败，回退到静态配置";
            // 回退到静态配置 - 使用红外下载通道
            selectedChannel = deviceModel->getSelectedDeviceInfraredDownloadChannel();
            qInfo() << "使用静态红外下载通道:" << selectedChannel;
        } else {
            qInfo() << "成功通过HikvisionCtrl获取通道号:" << selectedChannel;
        }
        
        // 清理HikvisionCtrl实例
        hikvisionCtrl->deleteLater();
    } else {
        qInfo() << "HikvisionCtrl不可用或IPC IP为空，使用静态配置";
        // 使用静态配置作为回退方案 - 使用红外下载通道
        selectedChannel = deviceModel->getSelectedDeviceInfraredDownloadChannel();
        qInfo() << "使用静态红外下载通道:" << selectedChannel;
        
        // 清理HikvisionCtrl实例
        if (hikvisionCtrl) {
            hikvisionCtrl->deleteLater();
        }
    }
    
    qInfo() << "开始下载NVR录像:" << deviceCode << "时间段:" << startTime.toString() << "-" << endTime.toString();
    qInfo() << "下载路径:" << fullPath;
    qInfo() << "使用通道号:" << selectedChannel;
    
    // 调用海康录像下载，使用动态获取的通道号
    QString taskId = m_hikvisionRecorder->downloadRecordByTime(
        hikvisionIp, 
        hikvisionPort, 
        hikvisionUsername, 
        hikvisionPassword,
        selectedChannel,  // 使用动态获取的通道号
        startTime,
        endTime,
        fullPath
    );
    
    if (!taskId.isEmpty()) {
        qInfo() << "NVR录像下载任务创建成功，任务ID:" << taskId << "文件:" << fullPath;
    } else {
        qWarning() << "NVR录像下载任务创建失败";
    }
}

bool AlarmRecordingManager::isRecording(const QString& deviceCode)
{
    DeviceAlarmState* state = getDeviceState(deviceCode);
    return state->isRecording;
}

QVariantMap AlarmRecordingManager::getCurrentRecording(const QString& deviceCode)
{
    QVariantMap result;
    DeviceAlarmState* state = getDeviceState(deviceCode);
    
    if (state->isRecording) {
        result["isRecording"] = true;
        result["startTime"] = state->currentStartTime;
        result["extendCount"] = state->extendCount;
        result["remainingTime"] = state->stopTimer ? state->stopTimer->remainingTime() / 1000 : 0;
    } else {
        result["isRecording"] = false;
    }
    
    return result;
}

QVariantList AlarmRecordingManager::queryRecordings(const QString& deviceCode, 
                                                  const QString& startDate, 
                                                  const QString& endDate)
{
    QVariantList result;
    QSqlQuery query(m_db);
    
    QString sql = "SELECT * FROM alarm_recordings WHERE 1=1";
    if (!deviceCode.isEmpty()) {
        sql += " AND device_code = '" + deviceCode + "'";
    }
    if (!startDate.isEmpty()) {
        sql += " AND start_time >= '" + startDate + "'";
    }
    if (!endDate.isEmpty()) {
        sql += " AND start_time <= '" + endDate + " 23:59:59'";
    }
    sql += " ORDER BY start_time DESC";
    
    if (query.exec(sql)) {
        while (query.next()) {
            AlarmRecordingEntry entry = fromQuery(query);
            result.append(entry.toJson());
        }
    } else {
        qDebug() << "查询报警录制记录失败:" << query.lastError().text();
    }
    
    return result;
}

QVariantList AlarmRecordingManager::queryRecordingsForDate(const QString& deviceCode, const QDate& date)
{
    QString startDate = date.toString("yyyy-MM-dd");
    QString endDate = date.toString("yyyy-MM-dd");
    return queryRecordings(deviceCode, startDate, endDate);
}

QVariantMap AlarmRecordingManager::getRecordingStats(const QString& deviceCode)
{
    QVariantMap result;
    QSqlQuery query(m_db);
    
    QString sql = "SELECT COUNT(*), SUM(duration_seconds) FROM alarm_recordings WHERE 1=1";
    if (!deviceCode.isEmpty()) {
        sql += " AND device_code = '" + deviceCode + "'";
    }
    
    if (query.exec(sql) && query.next()) {
        result["totalCount"] = query.value(0).toInt();
        result["totalDuration"] = query.value(1).toInt();
    }
    
    return result;
}

bool AlarmRecordingManager::deleteRecording(int id)
{
    QSqlQuery query(m_db);
    query.prepare("DELETE FROM alarm_recordings WHERE id = ?");
    query.addBindValue(id);
    
    bool success = query.exec();
    if (success) {
        emit recordingDeleted();
    }
    
    return success;
}

bool AlarmRecordingManager::deleteAllRecordings(const QString& deviceCode)
{
    QSqlQuery query(m_db);
    QString sql = "DELETE FROM alarm_recordings WHERE 1=1";
    
    if (!deviceCode.isEmpty()) {
        sql += " AND device_code = '" + deviceCode + "'";
    }
    
    bool success = query.exec(sql);
    if (success) {
        emit recordingDeleted();
    }
    
    return success;
}

AlarmRecordingEntry AlarmRecordingManager::fromQuery(const QSqlQuery& query)
{
    AlarmRecordingEntry entry;
    entry.id = query.value("id").toInt();
    entry.device_code = query.value("device_code").toString();
    entry.device_name = query.value("device_name").toString();
    entry.start_time = query.value("start_time").toString();
    entry.end_time = query.value("end_time").toString();
    entry.alarm_type = query.value("alarm_type").toString();
    entry.concentration = query.value("concentration").toString();
    entry.position = query.value("position").toString();
    entry.duration_seconds = query.value("duration_seconds").toInt();
    entry.created_at = query.value("created_at").toString();
    return entry;
}

DeviceAlarmState* AlarmRecordingManager::getDeviceState(const QString& deviceCode)
{
    if (!m_deviceStates.contains(deviceCode)) {
        m_deviceStates[deviceCode] = new DeviceAlarmState();
    }
    return m_deviceStates[deviceCode];
}

void AlarmRecordingManager::cleanupDeviceState(const QString& deviceCode)
{
    if (m_deviceStates.contains(deviceCode)) {
        DeviceAlarmState* state = m_deviceStates[deviceCode];
        if (state->stopTimer) {
            state->stopTimer->stop();
            state->stopTimer->deleteLater();
        }
        delete state;
        m_deviceStates.remove(deviceCode);
    }
}