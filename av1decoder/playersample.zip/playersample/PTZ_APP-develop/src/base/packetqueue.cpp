#include "src/base/packetqueue.h"
#include <QDebug>

extern "C" {
#include <libavutil/avutil.h>
}

packetqueue::packetqueue()
    :list_size(0)
{
    packet_queue.size = 0;
    packet_queue.first = NULL;
    packet_queue.last = NULL;
}
//packetqueue still exist memory lack

void packetqueue::get(AVPacket *pkt){
    mutex.lock();
    while(packet_queue.size == 0) {
        qDebug() << "Packet queue is empty, waiting...";
        condition.wait(&mutex);
        qDebug() << "Packet queue wait finished.";
    }

    Packet_Node *node = packet_queue.first;
    
    // Move reference, this is safer and more efficient than a simple copy.
    av_packet_move_ref(pkt, &node->packt);
    
    packet_queue.first = node->next;
    if (!packet_queue.first) {
        packet_queue.last = NULL;
    }
    
    av_free(node);
    packet_queue.size -= 1;

    mutex.unlock();
}

void packetqueue::put(AVPacket *pkt){
    mutex.lock();

    AVPacket *cloned_pkt = av_packet_clone(pkt);
    if (!cloned_pkt) {
        mutex.unlock();
        qWarning("Failed to clone AVPacket");
        return;
    }

    Packet_Node *node;
    node = (Packet_Node *)av_malloc(sizeof(Packet_Node));
    if (!node) {
        av_packet_free(&cloned_pkt);
        mutex.unlock();
        qWarning("Failed to allocate Packet_Node");
        return;
    }

    node->next = NULL;
    node->packt = *cloned_pkt;
    av_free(cloned_pkt); // The struct is now copied into node->packt

    if(NULL == packet_queue.last){
        packet_queue.first = node;
    }else{
        packet_queue.last->next = node;
    }
    packet_queue.last = node;
    packet_queue.size += 1;
    condition.wakeOne();
    mutex.unlock();
}

int packetqueue::size(){
    return packet_queue.size;
}
void packetqueue::clear(){
    mutex.lock();
    Packet_Node *node, *nextNode;
    for(node = packet_queue.first; node != NULL; node = nextNode) {
        nextNode = node->next;
        av_packet_unref(&node->packt);
        av_free(node);
    }
    packet_queue.size = 0;
    packet_queue.first = NULL;
    packet_queue.last = NULL;
    mutex.unlock();
}
