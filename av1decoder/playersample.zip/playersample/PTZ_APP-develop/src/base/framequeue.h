#ifndef FRAMEQUEUE_H
#define FRAMEQUEUE_H
#include <QObject>
#include <QMutex>
#include <QWaitCondition>
#include <QVector>
#include <QDebug>
#include <QQueue>
#include <QSet>
extern "C" {
#include <libavutil/frame.h>
}
// class AVFramePool : public QObject
// {
//     Q_OBJECT

// public:
//     explicit AVFramePool(int bufferSize = 32, QObject *parent = nullptr)
//         : QObject(parent), m_bufferSize(bufferSize), m_readIndex(0), m_writeIndex(0), m_size(0)
//     {
//         for (int i = 0; i < m_bufferSize; ++i) {
//             AVFrame* frame = av_frame_alloc();
//             if (!frame) {
//                 qWarning() << "Failed to allocate AVFrame at index" << i;
//                 continue;
//             }
//             m_frames.append(frame);
//         }
//     }

//     ~AVFramePool()
//     {
//         clear();
//     }

//     // 获取一个空闲帧用于填充
//     AVFrame* getFreeFrame()
//     {
//         QMutexLocker locker(&m_mutex);

//         while (isFull()) {
//             m_condition.wait(&m_mutex);
//         }

//         int index = m_writeIndex % m_bufferSize;
//         qDebug() << "getFreeFrame" << index <<"m_writeIndex" << m_writeIndex <<  "m_size" << m_size;
//         return m_frames[index];
//     }

//     // 提交一个已填充的帧
//     void signalFrameFilled()
//     {
//         QMutexLocker locker(&m_mutex);
        
//         m_writeIndex++;
//         m_size++;
//         m_condition.wakeOne(); // 唤醒等待的消费者
//     }

//     // 获取一个已填充的帧用于显示（FIFO 顺序）
//     AVFrame* getFilledFrame()
//     {
//         QMutexLocker locker(&m_mutex);

//         while (isEmpty()) {
//             m_condition.wait(&m_mutex);
//         }

//         int index = m_readIndex % m_bufferSize;
//         m_readIndex++;
//         m_size--;
//         m_condition.wakeOne(); // 唤醒等待的生产者
//         qDebug() << "getFilledFrame" << index <<"m_readIndex" << m_readIndex <<  "m_size" << m_size;
//         return m_frames[index];
//     }

//     // 清理所有资源
//     void clear()
//     {
//         QMutexLocker locker(&m_mutex);

//         for (AVFrame* frame : m_frames) {
//             av_frame_free(&frame);
//         }
//         m_frames.clear();
//         m_readIndex = 0;
//         m_writeIndex = 0;
//         m_size = 0;
//     }

// private:
//     QVector<AVFrame*> m_frames;
//     QMutex m_mutex;
//     QWaitCondition m_condition;
//     int m_bufferSize;
//     int m_readIndex;
//     int m_writeIndex;
//     int m_size; // 已填充的缓冲区数量

//     bool isEmpty() const
//     {
//         return m_size == 0;
//     }

//     bool isFull() const
//     {
//         return m_size >= m_bufferSize;
//     }
// };
// #endif


class AVFramePool : public QObject {
    Q_OBJECT

public:
    explicit AVFramePool(int bufferSize = 10, QObject* parent = nullptr)
        : QObject(parent), m_isValid(false) {
        if (bufferSize <= 0) {
            qCritical() << "Invalid buffer size:" << bufferSize;
            return;
        }
        
        for (int i = 0; i < bufferSize; ++i) {
            AVFrame* frame = av_frame_alloc();
            if (frame) {
                m_freeFrames.enqueue(frame);
                m_totalFrames.insert(frame); // 跟踪所有分配的帧
            } else {
                qCritical() << "Failed to allocate AVFrame at index" << i;
                break; // 分配失败时停止
            }
        }
        
        if (m_freeFrames.isEmpty()) {
            qCritical() << "No frames allocated! Pool is invalid.";
            return;
        }
        
        m_isValid = true;

    }

    ~AVFramePool() { clear(); }

    // 检查缓冲池是否有效
    bool isValid() const {
        QMutexLocker locker(&m_mutex);
        return m_isValid;
    }

    // 带超时的获取空闲帧
    AVFrame* getFreeFrame(int timeoutMs = 5000) {
        QMutexLocker locker(&m_mutex);
        if (!m_isValid) {

            return nullptr;
        }
        
        
        if (m_freeFrames.isEmpty()) {
            if (!m_freeCondition.wait(&m_mutex, timeoutMs)) {
                return nullptr;
            }

        }
        
        if (m_freeFrames.isEmpty()) {
            return nullptr;
        }
        
        return m_freeFrames.dequeue();
    }

    void commitFrame(AVFrame* frame) {
        if (!frame) {
            qWarning() << "Attempting to commit null frame";
            return;
        }
        
        QMutexLocker locker(&m_mutex);
        if (!m_isValid) {
            qWarning() << "Attempting to use invalid frame pool";
            return;
        }
        
        // 验证帧是否来自此缓冲池
        if (!m_totalFrames.contains(frame)) {
            qWarning() << "Attempting to commit frame not from this pool";
            return;
        }
        
        m_filledFrames.enqueue(frame);
        m_filledCondition.wakeOne();
    }

    // 带超时的获取填充帧
    AVFrame* getFilledFrame(int timeoutMs = 5000) {
        QMutexLocker locker(&m_mutex);
        if (!m_isValid) {
            qWarning() << "Attempting to use invalid frame pool";
            return nullptr;
        }
        
        if (m_filledFrames.isEmpty()) {
            if (!m_filledCondition.wait(&m_mutex, timeoutMs)) {
                qWarning() << "getFilledFrame timeout after" << timeoutMs << "ms";
                return nullptr;
            }
        }
        
        if (m_filledFrames.isEmpty()) {
            qWarning() << "No filled frames available after timeout";
            return nullptr;
        }
        
        return m_filledFrames.dequeue();
    }

    AVFrame* peek() {
        QMutexLocker locker(&m_mutex);
        if (!m_isValid || m_filledFrames.isEmpty()) {
            return nullptr;
        }
        return m_filledFrames.head();
    }

    AVFrame* peekNext() {
        QMutexLocker locker(&m_mutex);
        if (!m_isValid || m_filledFrames.size() < 2) {
            return nullptr;
        }
        return m_filledFrames.at(1);
    }

    void releaseFrame(AVFrame* frame) {
        if (!frame) {
            qWarning() << "Attempting to release null frame";
            return;
        }
        
        QMutexLocker locker(&m_mutex);
        if (!m_isValid) {
            qWarning() << "Attempting to use invalid frame pool";
            return;
        }
        
        // 验证帧是否来自此缓冲池
        if (!m_totalFrames.contains(frame)) {
            qWarning() << "Attempting to release frame not from this pool";
            return;
        }
        
        av_frame_unref(frame);
        m_freeFrames.enqueue(frame);
        m_freeCondition.wakeOne();
    }

    // 获取状态信息
    int getFreeCount() const {
        QMutexLocker locker(&m_mutex);
        return m_freeFrames.size();
    }
    
    int getFilledCount() const {
        QMutexLocker locker(&m_mutex);
        return m_filledFrames.size();
    }
    
    int getTotalCount() const {
        QMutexLocker locker(&m_mutex);
        return m_totalFrames.size();
    }

    void clear() {
        QMutexLocker locker(&m_mutex);
        
        // 标记为无效，防止新的操作
        m_isValid = false;
        
        // 唤醒所有等待的线程
        m_freeCondition.wakeAll();
        m_filledCondition.wakeAll();
        
        auto cleanup = [](QQueue<AVFrame*>& queue) {
            while (!queue.isEmpty()) {
                AVFrame* frame = queue.dequeue();
                av_frame_free(&frame);
            }
        };
        
        cleanup(m_freeFrames);
        cleanup(m_filledFrames);
        m_totalFrames.clear();
        
    }

    // 添加重新初始化方法
    void reinitialize(int bufferSize = 10) {
        QMutexLocker locker(&m_mutex);
        
        // 先清理现有资源
        if (m_isValid) {
            auto cleanup = [](QQueue<AVFrame*>& queue) {
                while (!queue.isEmpty()) {
                    AVFrame* frame = queue.dequeue();
                    av_frame_free(&frame);
                }
            };
            cleanup(m_freeFrames);
            cleanup(m_filledFrames);
            m_totalFrames.clear();
        }
        
        m_isValid = false;
        
        if (bufferSize <= 0) {
            qCritical() << "Invalid buffer size:" << bufferSize;
            return;
        }
        
        // 重新分配帧
        for (int i = 0; i < bufferSize; ++i) {
            AVFrame* frame = av_frame_alloc();
            if (frame) {
                m_freeFrames.enqueue(frame);
                m_totalFrames.insert(frame);
            } else {
                qCritical() << "Failed to allocate AVFrame at index" << i;
                return; // 分配失败
            }
        }
        
        if (!m_freeFrames.isEmpty()) {
            m_isValid = true;
            qDebug() << "AVFramePool reinitialized with" << m_freeFrames.size() << "frames";
        }
    }

private:
    mutable QMutex m_mutex;
    QWaitCondition m_freeCondition;
    QWaitCondition m_filledCondition;
    QQueue<AVFrame*> m_freeFrames;
    QQueue<AVFrame*> m_filledFrames;
    QSet<AVFrame*> m_totalFrames; // 跟踪所有分配的帧
    bool m_isValid; // 缓冲池是否有效
};
#endif