#include "panorama_manager.h"
#include "panoramaStitch.h"
#include <QDebug>
#include <QFileInfo>
#include <QDir>
#include <QCoreApplication>
#include <opencv2/opencv.hpp>

// Worker Implementation
PanoramaWorker::PanoramaWorker(QObject *parent) : QObject(parent) {}

void PanoramaWorker::processStitching(const QStringList &imagePaths, const QString &outputPath)
{
    qDebug() << "Starting stitching process with" << imagePaths.size() << "images path" << outputPath;
    
    if (imagePaths.size() < 2) {
        emit stitchingFinished(false, "Need at least 2 images to stitch", "");
        return;
    }

    std::vector<cv::Mat> vecImgs;
    for (const QString &path : imagePaths) {
        // Remove file:/// prefix if present
        QString localPath = path;
        if (localPath.startsWith("file:///")) {
            localPath = localPath.mid(8);
        }
        
        // Handle Windows paths properly
        localPath = QDir::toNativeSeparators(localPath);
        
        // Ensure string is valid for OpenCV
        std::string stdPath = localPath.toLocal8Bit().constData();
        
        cv::Mat img = cv::imread(stdPath);
        if (img.empty()) {
            qWarning() << "Failed to load image:" << localPath;
            continue;
        }
        vecImgs.push_back(img);
    }

    if (vecImgs.size() < 2) {
        emit stitchingFinished(false, "Failed to load enough valid images", "");
        return;
    }

    cv::Mat resImg;
    
    qDebug() << "Calling wPanoramaStitch...";
    int result = wPanoramaStitch(vecImgs, resImg);
    qDebug() << "wPanoramaStitch returned:" << result;

    if (result == 0 && !resImg.empty()) {
        // Remove file:/// prefix from outputPath if present for saving
        QString localOutputPath = outputPath;
        if (localOutputPath.startsWith("file:///")) {
            localOutputPath = localOutputPath.mid(8);
        }
        
        // Check if path is relative and make it absolute relative to application directory if needed
        QFileInfo checkInfo(localOutputPath);
        if (checkInfo.isRelative()) {
             localOutputPath = QCoreApplication::applicationDirPath() + "/" + localOutputPath;
        }

        localOutputPath = QDir::toNativeSeparators(localOutputPath);
        
        // Ensure directory exists
        QFileInfo fileInfo(localOutputPath);
        QDir dir = fileInfo.absoluteDir();
        if (!dir.exists()) {
            if (!dir.mkpath(".")) {
                 qWarning() << "Failed to create directory:" << dir.absolutePath();
                 emit stitchingFinished(false, "Failed to create output directory", "");
                 return;
            }
        }

        std::string stdOutputPath = localOutputPath.toLocal8Bit().constData();
        if (cv::imwrite(stdOutputPath, resImg)) {
            qDebug() << "Stitching successful, saved to:" << localOutputPath;
            // Return the absolute path so QML can load it easily with file:///
            // Convert to forward slashes for QML URL compatibility
            QString qmlPath = QDir::fromNativeSeparators(localOutputPath);
            emit stitchingFinished(true, "Stitching successful", qmlPath);
        } else {
            qWarning() << "Failed to save stitched image to:" << localOutputPath;
            emit stitchingFinished(false, "Failed to save result image", "");
        }
    } else {
        qWarning() << "Stitching failed with error code:" << result;
        emit stitchingFinished(false, QString("Stitching process failed with code: %1").arg(result), "");
    }
}

void PanoramaWorker::processImageMatching(const QString &panoramaPath, const QString &targetPath)
{
    QString localPanoramaPath = panoramaPath;
    if (localPanoramaPath.startsWith("file:///")) {
        localPanoramaPath = localPanoramaPath.mid(8);
    }
    localPanoramaPath = QDir::toNativeSeparators(localPanoramaPath);
    
    QString localTargetPath = targetPath;
    if (localTargetPath.startsWith("file:///")) {
        localTargetPath = localTargetPath.mid(8);
    }
    localTargetPath = QDir::toNativeSeparators(localTargetPath);
    
    std::string stdPanoramaPath = localPanoramaPath.toLocal8Bit().constData();
    std::string stdTargetPath = localTargetPath.toLocal8Bit().constData();
    
    int x = 0, y = 0; int w = 0, h = 0;
    int result = wMatchImage(stdPanoramaPath, stdTargetPath, x, y, w, h);
    
    if (result == 0) {
        qDebug() << "Image matching successful at:" << x << y << " size:" << w << h;
        emit imageMatchingFinished(true, x, y, w, h);
    } else {
        qWarning() << "Image matching failed with code:" << result;
        emit imageMatchingFinished(false, 0, 0, 0, 0);
    }
}

// Manager Implementation
PanoramaManager* PanoramaManager::m_instance = nullptr;

PanoramaManager* PanoramaManager::instance()
{
    if (!m_instance) {
        m_instance = new PanoramaManager();
    }
    return m_instance;
}

PanoramaManager::PanoramaManager(QObject *parent) : QObject(parent)
{
    m_workerThread = new QThread(this);
    m_worker = new PanoramaWorker();
    m_worker->moveToThread(m_workerThread);
    
    connect(m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    connect(m_workerThread, &QThread::started, [this](){ qDebug() << "Panorama worker thread started"; });
    
    // Forward signals from worker to manager
    connect(m_worker, &PanoramaWorker::stitchingFinished, this, &PanoramaManager::stitchingFinished);
    connect(m_worker, &PanoramaWorker::imageMatchingFinished, this, &PanoramaManager::imageMatchingFinished);
    
    m_workerThread->start();
}

PanoramaManager::~PanoramaManager()
{
    m_workerThread->quit();
    m_workerThread->wait();
}

void PanoramaManager::stitchImages(const QStringList &imagePaths, const QString &outputPath)
{
    emit stitchingStarted();
    
    // Use QMetaObject::invokeMethod to call slot in the worker thread
    QMetaObject::invokeMethod(m_worker, "processStitching", 
                              Qt::QueuedConnection,
                              Q_ARG(QStringList, imagePaths),
                              Q_ARG(QString, outputPath));
}

void PanoramaManager::requestImageMatching(const QString &panoramaPath, const QString &targetPath)
{
    QMetaObject::invokeMethod(m_worker, "processImageMatching", 
                              Qt::QueuedConnection,
                              Q_ARG(QString, panoramaPath),
                              Q_ARG(QString, targetPath));
}
