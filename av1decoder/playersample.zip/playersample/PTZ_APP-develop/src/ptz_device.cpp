#include "rtsp_decode.h"
#include "ptz_device.h"

#include <QDebug>

PtzDevice::PtzDevice(QObject* parent) : QObject(parent), device_id_("666666"){
}

PtzDevice::~PtzDevice(){

}

bool PtzDevice::mbInitVideo(){
    if(inf_video_url_.empty() || white_video_url_.empty()){
        qDebug() << "video url is empty";
        return false;
    }

    int res_w = white_video_decode_.inits(640, 480,white_video_url_);
    int res_i = inf_video_decode_.inits(640, 480,inf_video_url_);

    if(res_w == -1 || !res_i == -1){
        return false;
    }

    return true;
}

Q_INVOKABLE void PtzDevice::mvSetRotation(int dr, int speed){
    Rotation rt;
    switch(dr){
        case 0:{
            rt.set_direction(Direction::UP);
        }
            break;
        case 1:{
            rt.set_direction(Direction::DOWN);
        }
            break;
        case 2:{
            rt.set_direction(Direction::LEFT);
        }
            break;
        case 3:{
            rt.set_direction(Direction::RIGHT);
        }
            break;
        default:{
            qDebug() << "direction is error";
        }
    }

    rt.set_speed(speed_);

    PTZControlProtol ptz;
    ptz.set_type(SET_Rotation);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_rotation() = rt;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);

    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
    //    NetWorkCtrl::moGetInstance()->mbSendCmdTest();
}

void PtzDevice::mvSetZoomIn(int val){
    auto lc = mobGenLenControl(val, LEN_CONTROL_ZOOM);
    mvSendCmd(lc);

}

void PtzDevice::mvSetFocus(int val){
    auto lc = mobGenLenControl(val, LEN_CONTROL_FOCUS);
    mvSendCmd(lc);
}

void PtzDevice::mvSetAperture(int val){
    auto lc = mobGenLenControl(val, LEN_CONTROL_APERTURE);
    mvSendCmd(lc);
}

LensControl PtzDevice::mobGenLenControl(float val, LenControlEtype type){
    LensControl lc;
    lc.set_zoom_level(zoom_level_);
    lc.set_aperture(aperture_);
    lc.set_focus(focus_);

    switch(type){
        case LEN_CONTROL_ZOOM:{
            lc.set_zoom_level(val);
        }
            break;
        case LEN_CONTROL_FOCUS:{
            lc.set_focus(val);
        }
            break;
        case LEN_CONTROL_APERTURE:{
            lc.set_aperture(val);
        }
            break;
    }

    return lc;
}

void PtzDevice::mvSendCmd(LensControl lencmd){
    PTZControlProtol ptz;

    ptz.set_type(SET_LensControl);

    ptz.set_timestamp(time(NULL));

    ptz.set_device_id(device_id_);

    *ptz.mutable_lens_control() = lencmd;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);

    NetWorkCtrl* instance = NetWorkCtrl::moGetInstance();

    instance->mbSendCmdByTopic("top1", ttp);

}

void PtzDevice::mvSendCmd(AccessoryControl lencmd){
    PTZControlProtol ptz;
    ptz.set_type(SET_AccessoryControl);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_accessory_control() = lencmd;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);

    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
}

void PtzDevice::mvSetLight(bool val){
    auto ac = mobGenAccessoryControl(val, ACCESSORYCONTROL_LIGHT);
    mvSendCmd(ac);
}

AccessoryControl PtzDevice::mobGenAccessoryControl(bool val, AccessoryControlEtype type){
    AccessoryControl ac;
    ac.set_light(light_);
    ac.set_wiper(wiper_);
    ac.set_assifocus(assifocus_);
    ac.set_inf_flap(inf_flap_);

    switch(type){
        case ACCESSORYCONTROL_LIGHT:{
            ac.set_light(val);
        }
            break;
        case ACCESSORYCONTROL_WIPER:{
            ac.set_wiper(val);
        }
            break;
        case ACCESSORYCONTROL_ASSIFOCUS:{
            ac.set_assifocus(val);
        }
            break;
        case ACCESSORYCONTROL_INF_FLAP:{
            ac.set_inf_flap(val);
        }
            break;
    }

    return ac;
}

void PtzDevice::mvSetWiper(bool val){
    auto ac = mobGenAccessoryControl(val, ACCESSORYCONTROL_WIPER);
    mvSendCmd(ac);
}

void PtzDevice::mvSetAssiFocus(bool val){
    auto ac = mobGenAccessoryControl(val, ACCESSORYCONTROL_ASSIFOCUS);
    mvSendCmd(ac);
}

void PtzDevice::mvSetInfFlap(bool val){
    auto ac = mobGenAccessoryControl(val, ACCESSORYCONTROL_INF_FLAP);
    mvSendCmd(ac);
}

MediaSettings PtzDevice::mobGenMediaSettings(){
    media_settings_.set_stream_type(StreamType::MAIN);
    media_settings_.set_video_stream_type(VideoStreamType::VIDEO);
    media_settings_.set_resolution(Resolution::RESOLUTION_1280x720);
    media_settings_.set_bitrate_type(BitrateType::CONSTANT);
    media_settings_.set_bitrate(FrameRate::FPS_10);
    media_settings_.set_encoding_mode(VideoCodec::H264);
    media_settings_.set_iframe_interval(8);

    media_settings_.set_auxiliary_stream_enabled(false);
    media_settings_.set_audio_input(AudioSource::LineIn);
    media_settings_.set_sampling_rate(44100);
    media_settings_.set_noise_reduction_enabled(false);
    media_settings_.set_microphone_volume(50);
    media_settings_.set_speaker_volume(50);
    return MediaSettings();
}

void PtzDevice::mvSendCmd(MediaSettings media_para){
    PTZControlProtol ptz;
    ptz.set_type(SET_MediaSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_media_settings() = media_para;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
}

void
PtzDevice::mvModifyInfraredImageSettings(int bright, int contrac, int denoise, int intens, bool detail_e, bool edg_e,
                                         bool strip_filer){
    infrared_img_settings_.set_brightness(bright);
    infrared_img_settings_.set_contrast(contrac);
    infrared_img_settings_.set_denoise(denoise);
    infrared_img_settings_.set_intensity(intens);
    infrared_img_settings_.set_detail_enhancement(detail_e);
    infrared_img_settings_.set_edge_enhancement(edg_e);
    infrared_img_settings_.set_stripe_filter(strip_filer);

    mvSendCmd(infrared_img_settings_);
}

void PtzDevice::mvSendCmd(InfraredImageSettings inf_para){
    PTZControlProtol ptz;
    ptz.set_type(SET_InfraredImageSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_infrared_image_settings() = inf_para;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
}

void PtzDevice::mvModifyImageSettings(int bright, int contrac, int saturation, int sharpness,
                                      ImageSettings::CaptureType type, Resolution image_size,
                                      ImageSettings::ImageQuality img_quality){
    img_adj_.set_brightness(bright);
    img_adj_.set_contrast(contrac);
    img_adj_.set_saturation(saturation);
    img_adj_.set_sharpness(sharpness);
    img_adj_.set_capture_type(type);
    img_adj_.set_image_size(image_size);
    img_adj_.set_image_quality(img_quality);

    PTZControlProtol ptz;
    ptz.set_type(SET_ImageSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_image_settings() = img_adj_;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
}

void PtzDevice::mvModifyExposureSettings(ExposureSettings::ExposureMode exp_mode, int exp_time){
    exposure_setting_.set_exposure_mode(exp_mode);
    exposure_setting_.set_exposure_time(exp_time);

    PTZControlProtol ptz;
    ptz.set_type(SET_ExposureSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_exposure_settings() = exposure_setting_;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
}

void PtzDevice::mvModifyDayNightSwitchSettings(DayNightSwitchSettings::Mode mode, string start, string end){
    day_night_swhitch_setting_.set_mode(mode);
    day_night_swhitch_setting_.set_start_time(start);
    day_night_swhitch_setting_.set_end_time(end);

    PTZControlProtol ptz;
    ptz.set_type(SET_DayNightSwitchSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_day_night_switch_settings() = day_night_swhitch_setting_;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
}

void PtzDevice::mvModifyWhiteBalanceSettings(WhiteBalanceSettings::WhiteBalanceMode mode, int red_gain, int blue_gain){
    WhiteBalanceSettings::ManualWhiteBalance manual;
    manual.set_red_gain(red_gain);
    manual.set_blue_gain(blue_gain);

    white_balance_setting_.set_white_balance_mode(mode);
    *white_balance_setting_.mutable_manual_white_balance() = manual;

    PTZControlProtol ptz;
    ptz.set_type(SET_WhiteBalanceSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_white_balance_settings() = white_balance_setting_;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);

}

void
PtzDevice::mvModifyImageEnhancement(bool noise_enable, int noise_level, bool fog_enable, bool stabilization, int gray){
    NoiseReduction noise_reduction;
    noise_reduction.set_enabled(noise_enable);
    noise_reduction.set_level(noise_level);
    img_enhance_.mutable_noise_reduction()->CopyFrom(noise_reduction);

    img_enhance_.set_fog_enhancement(fog_enable);
    img_enhance_.set_stabilization(stabilization);
    img_enhance_.set_gray_range(gray);

    PTZControlProtol ptz;
    ptz.set_type(SET_ImageSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_image_enhancement() = img_enhance_;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);

}

void
PtzDevice::mvModifyVideoAdjustment(VideoAdjustment::MirrorSetting mirro, VideoAdjustment::StabilizationSetting stab){
    video_adj_.set_mirror_setting(mirro);
    video_adj_.set_stabilization_setting(stab);

    PTZControlProtol ptz;
    ptz.set_type(SET_VideoAdjustment);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_video_adjustment() = video_adj_;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);

}

void PtzDevice::mvModifyWhideDynamicRange(WideDynamicRange::WideDynamicMode mode, int lv, bool suppress){
    wide_dynamic_range_.set_mode(mode);
    wide_dynamic_range_.set_level(lv);
    wide_dynamic_range_.set_highlight_suppression(suppress);

    PTZControlProtol ptz;
    ptz.set_type(SET_WhiteBalanceSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_wide_dynamic_range() = wide_dynamic_range_;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
}

void PtzDevice::mvModifyChnTitle(bool enable, QString chn_name){
    osd_settings_.set_enabled(enable);
    osd_settings_.set_name(chn_name.toStdString());
}

void PtzDevice::mvModifyTimeStyle(bool enable, bool week_enable, OSDSettings::TimeFormat time_style,
                                  OSDSettings::DateFormat date_style){
    osd_settings_.set_time_enabled(enable);
    osd_settings_.set_show_weekday(week_enable);
    osd_settings_.set_time_format(time_style);
    osd_settings_.set_date_format(date_style);
}

void PtzDevice::mvModifyPtzInfo(bool preposition, bool zoom_ratio, bool cruisescan, bool trackingscan, bool linescan){
    osd_settings_.set_preset_enabled(preposition);
    osd_settings_.set_zoom_enabled(zoom_ratio);
    osd_settings_.set_cruise_enabled(cruisescan);
    osd_settings_.set_tracking_enabled(trackingscan);
    osd_settings_.set_scan_enabled(linescan);
}

void PtzDevice::mvModifyOverlapString(bool enable_1, QString str_1, bool enable_2, QString str_2, bool enable_3,
                                      QString str_3, bool enable_4, QString str_4){
    osd_settings_.set_first_enable(enable_1);
    osd_settings_.set_first_str(str_1.toStdString());

    osd_settings_.set_second_enable(enable_2);
    osd_settings_.set_second_str(str_2.toStdString());

    osd_settings_.set_third_enable(enable_3);
    osd_settings_.set_third_str(str_3.toStdString());

    osd_settings_.set_four_enable(enable_4);
    osd_settings_.set_fourth_str(str_4.toStdString());
}

void PtzDevice::mvModifyFontProperty(OSDSettings::Size font_size, OSDSettings::Color font_color,
                                     OSDSettings::Alignment font_alig){
    osd_settings_.set_size(font_size);
    osd_settings_.set_color(font_color);
    osd_settings_.set_alignment(font_alig);
}

void PtzDevice::mvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway,
                                             QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns,
                                             QString dns){
    ip_settings_.set_is_static_ip(static_ip);

    IPSettings_IPv4Config ip4;
    ip4.set_ip_address(ip4_ip.toStdString());
    ip4.set_subnet_mask(ip4_mask.toStdString());
    ip4.set_default_gateway(ip4_gateway.toStdString());
    ip4.set_primary_dns(pre_dns.toStdString());
    ip4.set_secondary_dns(dns.toStdString());
    *ip_settings_.mutable_ipv4() = ip4;

    IPSettings_IPv6Config ip6;
    ip6.set_ip_address(ip6_ip.toStdString());
    ip6.set_subnet_prefix(ip6_prefix.toStdString());
    ip6.set_default_gateway(ip6_gateway.toStdString());
    *ip_settings_.mutable_ipv6() = ip6;
}

void PtzDevice::mvApplyNetWorkSettings(){
    PTZControlProtol ptz;
    ptz.set_type(SET_IPSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_ip_settings() = ip_settings_;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
}

void PtzDevice::mvApplyOsdSettings(){
    PTZControlProtol ptz;
    ptz.set_type(SET_OSDSettings);
    ptz.set_timestamp(time(NULL));
    ptz.set_device_id(device_id_);

    *ptz.mutable_osd_settings() = osd_settings_;

    string ttp;
    google::protobuf::util::MessageToJsonString(ptz, &ttp);
    NetWorkCtrl::moGetInstance()->mbSendCmdByTopic("top1", ttp);
}
