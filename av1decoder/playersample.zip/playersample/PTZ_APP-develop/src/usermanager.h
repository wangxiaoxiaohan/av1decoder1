#ifndef USERMANAGER_H
#define USERMANAGER_H

#include <QObject>
#include <QVariantMap>
#include <QVariantList>
#include <QJsonObject>
#include <QString>
#include <QDebug>

// 用户权限结构
struct UserPermissions {
    bool deviceManage = false;      // 设备管理
    bool systemConfig = false;      // 系统配置
    bool ptzControl = false;        // 云台控制
    bool video = false;             // 视频
    bool record = false;            // 录像
    bool snapshot = false;          // 抓拍
    bool exitClient = false;        // 退出客户端
    bool voiceIntercom = false;     // 语音对讲
    bool viewAlarmRecord = false;    // 查看报警记录
    
    QJsonObject toJson() const;
    void fromJson(const QJsonObject& json);
};

// 用户信息结构
struct UserInfo {
    QString username;               // 用户名
    QString userType;               // 用户类型：管理员、普通用户
    QString description;            // 描述
    bool canDelete = true;          // 是否可删除
    UserPermissions permissions;    // 用户权限
    
    QJsonObject toJson() const;
    void fromJson(const QJsonObject& json);
    QVariantMap toVariantMap() const;
};

class UserManager : public QObject
{
    Q_OBJECT
    
    // 当前选中用户的属性
    Q_PROPERTY(QString currentUsername READ currentUsername NOTIFY currentUserChanged)
    Q_PROPERTY(QString currentUserType READ currentUserType NOTIFY currentUserChanged)
    Q_PROPERTY(QString currentDescription READ currentDescription NOTIFY currentUserChanged)
    Q_PROPERTY(bool currentCanDelete READ currentCanDelete NOTIFY currentUserChanged)
    
public:
    static UserManager* instance();
    
    // 当前用户管理
    Q_INVOKABLE void setCurrentUser(const QString& username);
    Q_INVOKABLE QString getCurrentUsername() const;
    Q_INVOKABLE QVariantMap getCurrentUserInfo() const;
    Q_INVOKABLE bool updateCurrentUser(const QVariantMap& userInfo);
    
    // 用户列表管理
    Q_INVOKABLE QVariantList getUserList() const;
    Q_INVOKABLE QVariantMap getUserInfo(const QString& username) const;
    Q_INVOKABLE bool addUser(const QString& username, const QString& userType = "普通用户");
    Q_INVOKABLE bool deleteUser(const QString& username);
    Q_INVOKABLE bool userExists(const QString& username) const;
    
    // 用户权限管理
    Q_INVOKABLE QVariantMap getCurrentUserPermissions() const;
    Q_INVOKABLE bool updateCurrentUserPermissions(const QVariantMap& permissions);
    
    // 密码管理
    Q_INVOKABLE bool validatePassword(const QString& username, const QString& password) const;
    Q_INVOKABLE bool updateCurrentUserPassword(const QString& newPassword);
    
    // 属性访问器
    QString currentUsername() const { return m_currentUser.username; }
    QString currentUserType() const { return m_currentUser.userType; }
    QString currentDescription() const { return m_currentUser.description; }
    bool currentCanDelete() const { return m_currentUser.canDelete; }
    
signals:
    void currentUserChanged();
    void userListChanged();
    void userAdded(const QString& username);
    void userDeleted(const QString& username);
    void userUpdated(const QString& username);
    
private:
    explicit UserManager(QObject* parent = nullptr);
    static UserManager* m_instance;
    
    UserInfo m_currentUser;         // 当前选中的用户
    QList<UserInfo> m_userList;     // 用户列表
    
    void loadUserList();            // 从文件加载用户列表
    void saveUserList();            // 保存用户列表到文件
    UserInfo loadUserFromFile(const QString& username) const;  // 从文件加载单个用户
    bool saveUserToFile(const UserInfo& user) const;           // 保存单个用户到文件
    void initDefaultUsers();        // 初始化默认用户
};

#endif // USERMANAGER_H