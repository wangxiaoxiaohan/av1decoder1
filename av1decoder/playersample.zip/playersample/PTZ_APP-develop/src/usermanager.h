#ifndef USERMANAGER_H
#define USERMANAGER_H

#include <QObject>
#include <QVariantMap>
#include <QVariantList>
#include <QJsonObject>
#include <QString>
#include <QDebug>

// 用户权限结构
struct UserPermissions {
    // 用户管理权限
    bool userManage = false;           // 用户管理（总开关）
    bool createNormalUser = false;     // 创建普通用户
    bool editNormalUser = false;       // 修改普通用户信息
    bool deleteNormalUser = false;     // 删除普通用户
    bool changeNormalUserPwd = false;  // 修改普通用户密码
    bool enableDisableNormalUser = false; // 启用禁用普通用户
    
    // 设备管理权限
    bool deviceManage = false;         // 设备管理（总开关）
    bool addDeleteDevice = false;      // 添加/删除设备
    bool editDeviceInfo = false;       // 修改设备信息
    bool deviceGroupSetting = false;   // 设备分组设置
    bool configDeviceInspection = false; // 配置设备巡检
    bool deviceRestartMaintenance = false; // 设备重启/维护
    bool deviceAVParams = false;       // 设备音视频参数
    bool networkSetting = false;       // 网络设置
    bool transportProtocolSetting = false; // 传输协议设置
    bool storageSetting = false;       // 存储设置
    bool deviceUpgrade = false;        // 设备升级
    
    // 数据访问权限
    bool dataAccess = false;           // 数据访问（总开关）
    bool realtimePreview = false;      // 实时预览
    bool viewImage = false;            // 查看图片
    bool executeInspectionTask = false; // 执行巡检任务
    bool recordPlayback = false;       // 录像回放
    bool imageDownload = false;        // 图片下载
    bool ptzControl = false;           // 云台控制
    bool recordDownload = false;       // 录像下载
    bool viewLog = false;              // 查看日志
    
    // 报警管理权限
    bool alarmManage = false;          // 报警管理（总开关）
    bool configAlarmRule = false;      // 配置报警规则
    bool viewAlarmRecord = false;      // 查看报警记录
    bool handleConfirmAlarm = false;   // 处理/确认报警
    
    QJsonObject toJson() const;
    void fromJson(const QJsonObject& json);
};

// 用户信息结构
struct UserInfo {
    QString username;               // 用户名
    QString password;               // 密码
    QString userType;               // 用户类型：管理员、普通用户
    QString description;            // 描述
    bool canDelete = true;          // 是否可删除
    QString creationTime;           // 创建时间
    QString lastLoginTime;          // 上次登录时间
    UserPermissions permissions;    // 用户权限
    
    QJsonObject toJson() const;
    void fromJson(const QJsonObject& json);
    QVariantMap toVariantMap() const;
};

class UserManager : public QObject
{
    Q_OBJECT
    
    // 当前选中用户的属性
    Q_PROPERTY(QString currentUsername READ currentUsername NOTIFY currentUserChanged)
    Q_PROPERTY(QString currentUserType READ currentUserType NOTIFY currentUserChanged)
    Q_PROPERTY(QString currentDescription READ currentDescription NOTIFY currentUserChanged)
    Q_PROPERTY(bool currentCanDelete READ currentCanDelete NOTIFY currentUserChanged)
    
public:
    static UserManager* instance();
    
    // 当前用户管理
    Q_INVOKABLE void setCurrentUser(const QString& username);
    Q_INVOKABLE QString getCurrentUsername() const;
    Q_INVOKABLE QVariantMap getCurrentUserInfo() const;
    Q_INVOKABLE bool updateCurrentUser(const QVariantMap& userInfo);
    Q_INVOKABLE bool updateCurrentUserAndSave(const QVariantMap& userInfo);
    
    // 用户列表管理
    Q_INVOKABLE QVariantList getUserList() const;
    Q_INVOKABLE QVariantMap getUserInfo(const QString& username) const;
    Q_INVOKABLE bool addUser(const QVariantMap& userInfo);
    Q_INVOKABLE bool deleteUser(const QString& username);
    Q_INVOKABLE bool userExists(const QString& username) const;
    
    // 用户权限管理
    Q_INVOKABLE QVariantMap getCurrentUserPermissions() const;
    Q_INVOKABLE bool updateCurrentUserPermissions(const QVariantMap& permissions);
    Q_INVOKABLE bool hasRecordPlaybackPermission() const;
    Q_INVOKABLE bool hasViewLogPermission() const;
    Q_INVOKABLE bool hasExecuteInspectionTaskPermission() const;
    Q_INVOKABLE bool hasPtzControlPermission() const;
    Q_INVOKABLE bool hasViewAlarmRecordPermission() const;
    Q_INVOKABLE bool hasHandleConfirmAlarmPermission() const;
    
    // 密码管理
    Q_INVOKABLE bool validatePassword(const QString& username, const QString& password) const;
    Q_INVOKABLE bool updateCurrentUserPassword(const QString& newPassword);
    
    // 登录时间管理
    Q_INVOKABLE void updateUserLastLoginTime(const QString& username);
    Q_INVOKABLE bool login(const QString& username, const QString& password);
    
    // 属性访问器
    QString currentUsername() const { return m_currentUser.username; }
    QString currentUserType() const { return m_currentUser.userType; }
    QString currentDescription() const { return m_currentUser.description; }
    bool currentCanDelete() const { return m_currentUser.canDelete; }
    
signals:
    void currentUserChanged();
    void userListChanged();
    void userAdded(const QString& username);
    void userDeleted(const QString& username);
    void userUpdated(const QString& username);
    
private:
    explicit UserManager(QObject* parent = nullptr);
    static UserManager* m_instance;
    
    UserInfo m_currentUser;         // 当前选中的用户
    QList<UserInfo> m_userList;     // 用户列表
    
    void loadUserList();            // 从文件加载用户列表
    void saveUserList();            // 保存用户列表到文件
    UserInfo loadUserFromFile(const QString& username) const;  // 从文件加载单个用户
    bool saveUserToFile(const UserInfo& user) const;           // 保存单个用户到文件
    void initDefaultUsers();        // 初始化默认用户
};

#endif // USERMANAGER_H