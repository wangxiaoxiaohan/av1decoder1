#ifndef HIKVISION_RECORDER_H
#define HIKVISION_RECORDER_H

#include <QObject>
#include <QString>
#include <QDateTime>
#include <QThread>
#include <QMutex>
#include <QTimer>
#include <QDebug>
#include <QDir>
#include <QFileInfo>
#include <QJsonObject>
#include <QJsonArray>
#include <QQueue>
#include <QWaitCondition>
#include <atomic>
#include <QRandomGenerator>
#include <QDataStream>

#include "HCNetSDK.h"

// 前向声明
class DownloadWorker;

// 下载任务结构
struct DownloadTask {
    QString deviceIp;
    int port;
    QString username;
    QString password;
    int channel;
    QDateTime startTime;
    QDateTime endTime;
    QString savePath;
    QString taskId;  // 唯一任务ID
    
    DownloadTask() : port(8000), channel(1) {}
    
    DownloadTask(const QString& ip, int p, const QString& user, const QString& pwd,
                 int ch, const QDateTime& start, const QDateTime& end, const QString& path)
        : deviceIp(ip), port(p), username(user), password(pwd), channel(ch),
          startTime(start), endTime(end), savePath(path) {
        // 生成唯一任务ID
        taskId = QString("task_%1_%2").arg(QDateTime::currentMSecsSinceEpoch()).arg(QRandomGenerator::global()->bounded(1000, 9999));
    }
    
    // 添加序列化支持
    friend QDataStream& operator<<(QDataStream& out, const DownloadTask& task) {
        out << task.deviceIp << task.port << task.username << task.password 
            << task.channel << task.startTime << task.endTime << task.savePath << task.taskId;
        return out;
    }
    
    friend QDataStream& operator>>(QDataStream& in, DownloadTask& task) {
        in >> task.deviceIp >> task.port >> task.username >> task.password 
           >> task.channel >> task.startTime >> task.endTime >> task.savePath >> task.taskId;
        return in;
    }
};

// 批量下载任务结构
struct BatchDownloadTask {
    QString deviceIp;
    int port;
    QString username;
    QString password;
    QList<QPair<QDateTime, QDateTime>> timeRanges;
    int channel;
    QString saveDir;
    QString taskId;
    
    BatchDownloadTask() : port(8000), channel(1) {}
    
    BatchDownloadTask(const QString& ip, int p, const QString& user, const QString& pwd,
                      const QList<QPair<QDateTime, QDateTime>>& ranges, int ch, const QString& dir)
        : deviceIp(ip), port(p), username(user), password(pwd), timeRanges(ranges), channel(ch), saveDir(dir) {
        taskId = QString("batch_%1_%2").arg(QDateTime::currentMSecsSinceEpoch()).arg(QRandomGenerator::global()->bounded(1000, 9999));
    }
    
    // 添加序列化支持
    friend QDataStream& operator<<(QDataStream& out, const BatchDownloadTask& task) {
        out << task.deviceIp << task.port << task.username << task.password 
            << task.timeRanges << task.channel << task.saveDir << task.taskId;
        return out;
    }
    
    friend QDataStream& operator>>(QDataStream& in, BatchDownloadTask& task) {
        in >> task.deviceIp >> task.port >> task.username >> task.password 
           >> task.timeRanges >> task.channel >> task.saveDir >> task.taskId;
        return in;
    }
};

// 下载状态枚举
enum class DownloadStatus {
    Pending,    // 等待中
    Running,    // 下载中
    Completed,  // 完成
    Failed,     // 失败
    Cancelled   // 已取消
};

// 下载进度信息
struct DownloadProgress {
    QString taskId;
    QString fileName;
    int progress;  // 0-100
    DownloadStatus status;
    QString errorMessage;
    
    DownloadProgress() : progress(0), status(DownloadStatus::Pending) {}
};

class HikvisionRecorder : public QObject
{
    Q_OBJECT

public:
    explicit HikvisionRecorder(QObject* parent = nullptr);
    ~HikvisionRecorder();

    // 初始化SDK
    bool initializeSDK();
    
    // 登录设备
    bool loginDevice(const QString& deviceIp, int port, 
                    const QString& username, const QString& password);
    
    // 登录设备（不需要互斥锁，供内部使用）
    bool loginDeviceWithoutLock(const QString& deviceIp, int port, 
                               const QString& username, const QString& password);
    
    // 异步下载接口
    Q_INVOKABLE QString downloadRecordByTime(const QString& deviceIp, int port,
                                            const QString& username, const QString& password,
                                            int channel, const QDateTime& startTime, 
                                            const QDateTime& endTime, const QString& savePath);
    
    // 异步批量下载接口
    Q_INVOKABLE QString downloadRecordsByTime(const QString& deviceIp, int port,
                                             const QString& username, const QString& password,
                                             const QList<QPair<QDateTime, QDateTime>>& timeRanges,
                                             int channel, const QString& saveDir);
    
    // 取消下载任务
    Q_INVOKABLE bool cancelDownload(const QString& taskId);
    
    // 获取下载状态
    Q_INVOKABLE int getDownloadStatus(const QString& taskId);
    
    // 获取下载进度
    Q_INVOKABLE int getDownloadProgress(const QString& taskId);
    
    // 获取所有活动任务
    Q_INVOKABLE QStringList getActiveTaskIds();

signals:
    // 下载进度信号
    void downloadProgressUpdated(const QString& taskId, const QString& fileName, int progress);
    
    // 单个任务完成信号
    void downloadCompleted(const QString& taskId, const QString& fileName, bool success, const QString& errorMsg);
    
    // 批量下载完成信号
    void downloadAllCompleted(const QString& taskId, int successCount, int totalCount);
    
    // 任务状态变化信号
    void taskStatusChanged(const QString& taskId, DownloadStatus status);
    
    // 错误信号
    void errorOccurred(const QString& errorMessage);

private slots:
    // 工作线程相关槽函数
    void onWorkerTaskCompleted(const QString& taskId, const QString& fileName, bool success, const QString& errorMsg);
    void onWorkerProgressUpdated(const QString& taskId, const QString& fileName, int progress);
    void onWorkerBatchCompleted(const QString& taskId, int successCount, int totalCount);
    void onWorkerError(const QString& errorMessage);

private:
    // 辅助函数
    bool saveRecordByTime(int userId, int channel, 
                         const QDateTime& startTime, const QDateTime& endTime,
                         const QString& destFile);
    void convertTimeToDownloadCondition(const QDateTime& dateTime, 
                                       DWORD& year, DWORD& month, DWORD& day, 
                                       DWORD& hour, DWORD& minute, DWORD& second);
    QString generateFileName(const QDateTime& startTime, const QDateTime& endTime, int channel);
    QString getLastErrorMessage();
    
    // 任务管理
    void addTask(const QString& taskId, const DownloadTask& task);
    void addBatchTask(const QString& taskId, const BatchDownloadTask& task);
    void removeTask(const QString& taskId);
    void updateTaskStatus(const QString& taskId, DownloadStatus status);
    void updateTaskProgress(const QString& taskId, const QString& fileName, int progress);
    
    // 成员变量
    bool m_sdkInitialized;
    int m_userId;
    QMutex m_mutex;
    
    // 异步工作线程
    QThread* m_workerThread;
    DownloadWorker* m_worker;
    
    // 任务管理
    QMap<QString, DownloadTask> m_singleTasks;
    QMap<QString, BatchDownloadTask> m_batchTasks;
    QMap<QString, DownloadProgress> m_taskProgress;
    QMutex m_taskMutex;
    
    // 当前设备信息
    QString m_currentDeviceIp;
    int m_currentPort;
    QString m_currentUsername;
    QString m_currentPassword;
};

// 下载工作线程类
class DownloadWorker : public QObject
{
    Q_OBJECT

public:
    explicit DownloadWorker(QObject* parent = nullptr);
    ~DownloadWorker();

public slots:
    // 处理单个下载任务
    void processDownloadTask(const QString& taskId, const QString& deviceIp, int port,
                           const QString& username, const QString& password, int channel,
                           const QDateTime& startTime, const QDateTime& endTime, const QString& savePath);
    
    // 处理批量下载任务 - 暂时注释掉，避免复杂的参数传递
    // void processBatchDownloadTask(const QString& taskId, const BatchDownloadTask& task);
    
    // 取消任务
    void cancelTask(const QString& taskId);

signals:
    // 进度信号
    void progressUpdated(const QString& taskId, const QString& fileName, int progress);
    
    // 完成信号
    void taskCompleted(const QString& taskId, const QString& fileName, bool success, const QString& errorMsg);
    
    // 批量完成信号
    void batchCompleted(const QString& taskId, int successCount, int totalCount);
    
    // 错误信号
    void errorOccurred(const QString& errorMessage);

private:
    // 实际下载实现
    bool doDownloadRecordByTime(const DownloadTask& task);
    bool doDownloadRecordsByTime(const BatchDownloadTask& task);
    bool saveRecordByTime(int userId, int channel, 
                         const QDateTime& startTime, const QDateTime& endTime,
                         const QString& destFile, const QString& taskId = "");
    void convertTimeToDownloadCondition(const QDateTime& dateTime, 
                                       DWORD& year, DWORD& month, DWORD& day, 
                                       DWORD& hour, DWORD& minute, DWORD& second);
    QString generateFileName(const QDateTime& startTime, const QDateTime& endTime, int channel);
    
    // 设备登录
    bool loginDevice(const QString& deviceIp, int port, 
                    const QString& username, const QString& password);
    bool initializeSDK();
    QString getLastErrorMessage();
    
    // 成员变量
    bool m_sdkInitialized;
    int m_userId;
    QMutex m_mutex;
    std::atomic<bool> m_cancelled;
    QString m_currentTaskId;  // 当前任务ID
    
    // 当前设备信息
    QString m_currentDeviceIp;
    int m_currentPort;
    QString m_currentUsername;
    QString m_currentPassword;
};

#endif // HIKVISION_RECORDER_H 