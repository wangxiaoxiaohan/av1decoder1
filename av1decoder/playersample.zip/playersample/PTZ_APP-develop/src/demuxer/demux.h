#ifndef DEMUX_H
#define DEMUX_H
#include <QSharedPointer>
#include <QThread>
#include <QQueue>
#include <QMutex>
extern "C"{
#include <libavformat/avformat.h>
}
#include "src/base/packetqueue.h"
class demux;
class demuxWorker:public QObject
{
    Q_OBJECT
public:
    demuxWorker(demux *demuxer);
    ~demuxWorker();

public slots:
    void work_thread();
    void quit_threag_flag();
private:
    demux *mDemuxer;
    bool quit_flag;
};
class demux : public QObject
{
    Q_OBJECT
public:
    demux();
    ~demux();
    int start(QString file);
    int stop();
    int openFile(QString path);
    int seek(double timeStamp);
    int switchUrl(QString path);
    bool isSwitching() const; // 添加检查切换状态的方法
private:
    int findStreamInfo();
    QThread* demuxThread;
    demuxWorker *worker;
    QString url;
    bool seek_flag;
    double seek_timeStamp;
    QString new_url;
    bool switch_flag;
public slots:

signals:
    void quitDemuxThread();
public:

    int audio_steam_index;
    int video_steam_index;
    packetqueue *video_packq;
    packetqueue *audio_packq;
    packetqueue *subtitle_packq;
    AVFormatContext *fmtCtx;
    QMutex *mutex;

signals:
    void finished();
    void error(QString err);
friend class demuxWorker;
};

#endif // DEMUX_H
