#ifndef DEMUX_H
#define DEMUX_H
#include <QSharedPointer>
#include <QThread>
#include <QQueue>
#include <QMutex>
#include <atomic>
extern "C"{
#include <libavformat/avformat.h>
}
#include "src/base/packetqueue.h"
class demux;
class demuxWorker:public QObject
{
    Q_OBJECT
public:
    demuxWorker(demux *demuxer);
    ~demuxWorker();

public slots:
    void work_thread();
    void quit_threag_flag();
private:
    demux *mDemuxer;
    bool quit_flag;
};
class demux : public QObject
{
    Q_OBJECT
public:
    demux();
    ~demux();
    int start(QString file);
    int stop();
    int openFile(QString path);
    int seek(double timeStamp);
    int switchUrl(QString path);
    bool isSwitching() const; // 添加检查切换状态的方法
    QString getUrl();
    // New: allow external force to abort IO to break out of blocking read
    inline void forceAbortIO() { abort_io.store(true, std::memory_order_release); }
private:
    int findStreamInfo();
    QThread* demuxThread;
    demuxWorker *worker;
    QString url;
    QString m_url;
    bool seek_flag;
    double seek_timeStamp;
    QString new_url;
    std::atomic<bool> switch_flag;
    std::atomic<bool> abort_io; // 用于ffmpeg中断回调的独立标志
    // IO phase: 0=IDLE, 1=OPENING, 2=READING
    std::atomic<int> io_phase;
    std::chrono::steady_clock::time_point last_read_time; // 用于超时检查的时间戳
public slots:

signals:
    void quitDemuxThread();
public:

    int audio_steam_index;
    int video_steam_index;
    packetqueue *video_packq;
    packetqueue *audio_packq;
    packetqueue *subtitle_packq;
    AVFormatContext *fmtCtx;
    QMutex *mutex;

signals:
    void finished();
    void error(QString err);
friend class demuxWorker;
};

#endif // DEMUX_H
