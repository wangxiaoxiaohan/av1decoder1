#ifndef DEMUX_H
#define DEMUX_H
#include <QSharedPointer>
#include <QThread>
#include <QQueue>
#include <QMutex>
#include <atomic>
extern "C"{
#include <libavformat/avformat.h>
}
#include "src/base/packetqueue.h"
class demux;
class demuxWorker:public QObject
{
    Q_OBJECT
public:
    demuxWorker(demux *demuxer);
    ~demuxWorker();

public slots:
    void work_thread();
    void quit_threag_flag();
private:
    demux *mDemuxer;
    bool quit_flag;
};
class demux : public QObject
{
    Q_OBJECT
public:
    demux();
    ~demux();
    int start(QString file);
    int stop();
    int openFile(QString path);
    int seek(double timeStamp);
    int switchUrl(QString path);
    bool isSwitching() const; // 添加检查切换状态的方法
    QString getUrl();
    
    // 录像相关方法

    int startRecording(QString filePath, QString format = "ts");
    int stopRecording();
    bool isRecording() const;
    // New: allow external force to abort IO to break out of blocking read
    inline void forceAbortIO() { abort_io.store(true, std::memory_order_release); }
private:
    int findStreamInfo();
    QThread* demuxThread;
    demuxWorker *worker;
    QString url;
    QString m_url;
    bool seek_flag;
    double seek_timeStamp;
    QString new_url;
    std::atomic<bool> switch_flag;
    std::atomic<bool> abort_io; // 用于ffmpeg中断回调的独立标志
    // IO phase: 0=IDLE, 1=OPENING, 2=READING
    std::atomic<int> io_phase;
    std::chrono::steady_clock::time_point last_read_time; // 用于超时检查的时间戳
    
    // 录像相关成员变量
    std::atomic<bool> recording_flag; // 录像状态标志
    AVFormatContext *recordingFmtCtx; // 录像输出格式上下文
    QString recordingFilePath; // 录像文件路径
    QString recordingFormat; // 录像格式
    int recording_video_stream_index; // 录像视频流索引
    int recording_audio_stream_index; // 录像音频流索引
    QMutex *recording_mutex; // 录像操作互斥锁
    bool recording_idr_frame_written; // 是否已写入IDR帧标志
public slots:

signals:
    void quitDemuxThread();
public:

    int audio_steam_index;
    int video_steam_index;
    packetqueue *video_packq;
    packetqueue *audio_packq;
    packetqueue *subtitle_packq;
    AVFormatContext *fmtCtx;
    QMutex *mutex;

signals:
    void finished();
    void error(QString err);
friend class demuxWorker;
};

#endif // DEMUX_H
