#include "src/demuxer/demux.h"
#include <QtDebug>
#include <QCoreApplication>
#include <QDateTime>
#include <iostream>
demuxWorker::demuxWorker(demux *demuxer)
    :mDemuxer(demuxer),
    quit_flag(false)
{

}
demuxWorker::~demuxWorker(){
    qDebug() << "demuxWorker destruct!!";
}
void demuxWorker::quit_threag_flag(){
    qDebug() << "demux receive quit signal";
    quit_flag = true;
}
void demuxWorker::work_thread(){
    //mDemuxer->read_thread();
    int ret;
    AVPacket pkt;
    //qDebug() << "in demux work_thread";
    qDebug() << "in demux work_thread" ;
    long long loop_count = 0;
    while(!quit_flag){
        //qDebug() << "timeStamp demux work_thread reading" <<QDateTime::currentDateTime().toString("hh:mm:ss.zzz ");
        if(mDemuxer->fmtCtx){
            while(mDemuxer->audio_packq->size() > 200 || mDemuxer->video_packq->size() > 100){
                if(mDemuxer->seek_flag){
                    break;
                }
                QThread::usleep(100);
                //QCoreApplication::processEvents(QEventLoop::AllEvents,100);
                //qDebug() << "packet full!!!";
            }
            if(mDemuxer->seek_flag){
                //std::cout << "timeStamp mDemuxer seek start" << QDateTime::currentDateTime().toString("hh:mm:ss.zzz ");
                mDemuxer->audio_packq->clear();
                mDemuxer->video_packq->clear();

                int ret = avformat_seek_file(mDemuxer->fmtCtx, -1, INT64_MIN, mDemuxer->seek_timeStamp, INT64_MAX, 0);

                //std::cout << "timeStamp mDemuxer seek end" << QDateTime::currentDateTime().toString("hh:mm:ss.zzz ");
                qDebug() << "demux seek file ret " << ret;

                mDemuxer->seek_flag = false;
            }
            if(mDemuxer->switch_flag){
                qDebug() << "=== DEMUX: URL switching detected ===";
                qDebug() << "DEMUX: Current fmtCtx address:" << mDemuxer->fmtCtx;
                qDebug() << "DEMUX: Current video_steam_index:" << mDemuxer->video_steam_index;
                qDebug() << "DEMUX: Current audio_steam_index:" << mDemuxer->audio_steam_index;
                
                qDebug() << "DEMUX: Closing current format context...";
                if(mDemuxer->fmtCtx){
                    avformat_close_input(&mDemuxer->fmtCtx);
                    qDebug() << "DEMUX: Format context closed";
                }
                qDebug() << "DEMUX: Clearing packet queues...";
                mDemuxer->audio_packq->clear();
                mDemuxer->video_packq->clear();
                mDemuxer->subtitle_packq->clear();
                qDebug() << "DEMUX: Packet queues cleared";
                
                // 重置stream indices
                mDemuxer->video_steam_index = -1;
                mDemuxer->audio_steam_index = -1;
                qDebug() << "DEMUX: Stream indices reset";
                
                // 复制URL，并在打开前清除switch_flag，避免中断回调打断 open_input
                QString targetUrl = mDemuxer->new_url;
                mDemuxer->switch_flag = false;
                
                qDebug() << "DEMUX: Opening new URL:" << targetUrl;
                int ret = mDemuxer->openFile(targetUrl);
                if(ret < 0){
                    qCritical() << "DEMUX: Failed to open new URL:" << targetUrl;
                    qCritical() << "DEMUX: fmtCtx after failed open:" << mDemuxer->fmtCtx;
                } else {
                    qDebug() << "DEMUX: Successfully opened new URL";
                    qDebug() << "DEMUX: New fmtCtx address:" << mDemuxer->fmtCtx;
                    qDebug() << "DEMUX: New fmtCtx->nb_streams:" << (mDemuxer->fmtCtx ? mDemuxer->fmtCtx->nb_streams : -1);
                    qDebug() << "DEMUX: New video stream index:" << mDemuxer->video_steam_index;
                    qDebug() << "DEMUX: New audio stream index:" << mDemuxer->audio_steam_index;
                    
                    // 验证stream indices的有效性
                    if (mDemuxer->fmtCtx && mDemuxer->fmtCtx->streams) {
                        if (mDemuxer->video_steam_index >= 0 && mDemuxer->video_steam_index < mDemuxer->fmtCtx->nb_streams) {
                            qDebug() << "DEMUX: Video stream validation OK";
                        } else {
                            qWarning() << "DEMUX: Invalid video stream index:" << mDemuxer->video_steam_index;
                        }
                        
                        if (mDemuxer->audio_steam_index >= 0 && mDemuxer->audio_steam_index < mDemuxer->fmtCtx->nb_streams) {
                            qDebug() << "DEMUX: Audio stream validation OK";
                        } else {
                            qWarning() << "DEMUX: Invalid audio stream index:" << mDemuxer->audio_steam_index;
                        }
                    } else {
                        qWarning() << "DEMUX: fmtCtx or streams is null after openFile";
                    }
                }
                qDebug() << "=== DEMUX: URL switching completed ===";
            }

            // 如果因为切换失败或其它原因导致 fmtCtx 为空，避免调用 av_read_frame 造成崩溃
            if (!mDemuxer->fmtCtx) {
                qWarning() << "DEMUX: fmtCtx is null, skip read and wait";
                QThread::msleep(50);
                continue;
            }
            int ret = av_read_frame(mDemuxer->fmtCtx,&pkt);
            if(ret < 0){
                //qDebug()<< "demuxing av_read_frame ret < 0" ;

                continue;
            }

            if(pkt.stream_index == mDemuxer->audio_steam_index){
                mDemuxer->audio_packq->put(&pkt);

                //qDebug() << "demuxing audio pkt pts" << pkt.pts ;
            }else if(pkt.stream_index == mDemuxer->video_steam_index){
                mDemuxer->video_packq->put(&pkt);

                //qDebug() << "demuxing VIDEO pkt pts" << pkt.pts ;
            }else{
              // subtitle_packq->put(&pkt);
            }
            av_packet_unref(&pkt);
        }


    }
    qDebug() << "demuxing real quit  threading" ;
    avformat_close_input(&mDemuxer->fmtCtx);
    mDemuxer->video_packq->clear();
    mDemuxer->audio_packq->clear();
}
demux::demux()
{
    //fmtCtx = avformat_alloc_context();
    qDebug() << "demux constructor";
    video_packq = new packetqueue();
    audio_packq = new packetqueue();
    subtitle_packq = new packetqueue();
    mutex = new QMutex();
    seek_timeStamp = 0;
    switch_flag = false;
}
demux::~demux()
{
    delete video_packq;
    delete audio_packq;
    delete subtitle_packq;
    delete mutex;
}
int demux::openFile(QString path){
    qDebug() << "openFile" << path;

    std::string path_std = path.toStdString();
    const char* file_path = path_std.c_str();
    qDebug() << "openFile file_path" << file_path;
    AVDictionary *options = NULL;

    // 判断是否是回放(带starttime/endtime参数)，大小写不敏感
   // bool isReplay = path.contains("starttime", Qt::CaseInsensitive) || path.contains("endtime", Qt::CaseInsensitive);
   bool isReplay = false;
    qDebug() << (isReplay ? "is replay" : "is not replay");

    // 分配格式上下文并设置中断回调，防止阻塞在 av_read_frame/avformat_open_input
    fmtCtx = avformat_alloc_context();
    if (!fmtCtx) {
        qCritical() << "Failed to alloc AVFormatContext";
        return -1;
    }
    fmtCtx->interrupt_callback.callback = [](void *ctx) -> int {
        demux *demuxer = static_cast<demux*>(ctx);
        // 当切换URL或停止时，立刻中断阻塞调用
        if (demuxer && demuxer->switch_flag) {
            return 1;
        }
        return 0;
    };
    fmtCtx->interrupt_callback.opaque = this;

    // 根据实时/回放分别设置参数
    if (!isReplay) {
        // 实时流：尽量降低延时
        av_dict_set(&options, "buffer_size", "32768", 0);
        av_dict_set(&options, "max_delay", "50000", 0);        // 50ms
        av_dict_set(&options, "stimeout", "5000000", 0);       // 5s
        av_dict_set(&options, "fflags", "nobuffer", 0);
        av_dict_set(&options, "flags", "zerolatency", 0);
        av_dict_set(&options, "rtsp_transport", "tcp", 0);
        av_dict_set(&options, "tune", "zerolatency", 0);
        av_dict_set(&options, "probesize", "50000", 0);
        av_dict_set(&options, "analyzeduration", "0.1", 0);
    } else {
        // 回放：稳定优先，避免过激进的低延迟参数导致打开失败
        av_dict_set(&options, "rtsp_transport", "tcp", 0);
        av_dict_set(&options, "stimeout", "5000000", 0);       // 5s socket 超时
        // 不设置 nobuffer/zerolatency/probesize/analyzeduration
    }

    qDebug() << "open input done asd";
    int ret = avformat_open_input(&fmtCtx, file_path, NULL, &options);
    av_dict_free(&options);
    if(ret < 0){
        qCritical() << "demux open file error!!!!!!!!!!!!!!!!!!! ret=" << ret;
        // 确保 fmtCtx 置空以避免后续误用
        avformat_close_input(&fmtCtx);
        fmtCtx = nullptr;
        return -1;
    }
    qDebug() << "open input done";

    findStreamInfo();

    // if (avformat_find_stream_info(fmtCtx, NULL) < 0) {
    //     qDebug() << "Could not find stream information";
    //     exit(1);
    // }

    // int audio_idx = av_find_best_stream(fmtCtx, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
    // audio_steam_index = (audio_idx < 0) ? -1 : audio_idx;

    // int video_idx = av_find_best_stream(fmtCtx, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    // video_steam_index = (video_idx < 0) ? -1 : video_idx;


    if(audio_steam_index < 0 && video_steam_index < 0)
        return -1;

    qDebug()<< "fmt duration"<< fmtCtx->duration  << " video_steam_index " << video_steam_index << " audio_steam_index " << audio_steam_index;
    return 1;
}

int demux::findStreamInfo(){
    int ret;
    qDebug() << "open input done" ;

    // Manually configure stream info to skip avformat_find_stream_info
    if (fmtCtx->nb_streams == 0) {
        qDebug() << "No streams found in context, manually creating one.";
        AVStream *video_stream = avformat_new_stream(fmtCtx, NULL);
        if (!video_stream) {
            qDebug() << "Failed to create new video stream";
            return -1;
        }

        AVCodecParameters *codecpar = video_stream->codecpar;
        codecpar->codec_type = AVMEDIA_TYPE_VIDEO;
        codecpar->codec_id = AV_CODEC_ID_HEVC;
        codecpar->width = 640;
        codecpar->height = 360;
        codecpar->format = AV_PIX_FMT_YUV420P;
        
        video_stream->time_base = (AVRational){1, 90000};
        video_stream->avg_frame_rate = (AVRational){25, 1};
    }
    
    qDebug() << "Skipping avformat_find_stream_info by manually setting stream info.";

    int audio_idx = av_find_best_stream(fmtCtx, AVMEDIA_TYPE_AUDIO, -1, -1, NULL, 0);
    audio_steam_index = (audio_idx < 0) ? -1 : audio_idx;

    int video_idx = av_find_best_stream(fmtCtx, AVMEDIA_TYPE_VIDEO, -1, -1, NULL, 0);
    video_steam_index = (video_idx < 0) ? -1 : video_idx;

    qDebug() << "Finished finding streams at:" << QDateTime::currentDateTime().toString("hh:mm:ss.zzz");

     if(audio_steam_index < 0 && video_steam_index < 0)
         return -1;

     qDebug()<< "fmt duration"<< fmtCtx->duration  << " video_steam_index " << video_steam_index << " audio_steam_index " << audio_steam_index;
    return 1;
}

int demux::start(QString file){
    url = file;
    seek_flag = false;
    video_packq->clear();
    audio_packq->clear();

    worker = new demuxWorker(this);
    demuxThread = new QThread;
 
    worker->moveToThread(demuxThread);


    connect(demuxThread, SIGNAL(started()), worker, SLOT(work_thread()));
    connect(this, SIGNAL(quitDemuxThread()), worker, SLOT(quit_threag_flag()));
    connect(demuxThread, SIGNAL(finished()), worker, SLOT(deleteLater()));
    connect(demuxThread, SIGNAL(finished()), demuxThread, SLOT(deleteLater()));
    //emit quitDemuxThread(false);


    demuxThread->start();

    QThread::msleep(1000);
    return  0;
}
int demux::stop(){

    std::cout << "receive demux quit " << std::endl  << std::flush;
    emit quitDemuxThread();
    
    // 等待demux线程完全结束
    if(demuxThread) {
        demuxThread->wait(3000);  // 等待最多3秒
        qDebug() << "Demux thread terminated";
    }
    
    // 清理packet queue
    video_packq->clear();
    audio_packq->clear();
    
    return  0;

}
int demux::seek(double timeStamp){
    //std::cout << "timeStamp receive seek signal" <<QDateTime::currentDateTime().toString("hh:mm:ss.zzz ");
    qDebug() << "demux seek timeStamp" << timeStamp;
    seek_flag = true;
    seek_timeStamp = timeStamp;
    return  0;
}

int demux::switchUrl(QString path){
    qDebug() << "DEMUX: switchUrl called with:" << path;
    qDebug() << "DEMUX: Current switch_flag:" << switch_flag;
    qDebug() << "DEMUX: Current fmtCtx:" << fmtCtx;
    
    mutex->lock();
    
    // 检查是否已经在切换中
    if (switch_flag) {
        qWarning() << "DEMUX: URL switch already in progress, ignoring new request";
        mutex->unlock();
        return 0;
    }
    
    new_url = path;
    switch_flag = true;
    qDebug() << "DEMUX: Switch flag set to true";
    qDebug() << "DEMUX: New URL set to:" << new_url;
    
    mutex->unlock();
    return 0;
}

bool demux::isSwitching() const {
    return switch_flag;
}
