#ifndef PLAYERMANAGER_H
#define PLAYERMANAGER_H

#include <QObject>
#include <QMap>
#include <QThread>
#include <QMutex>
#include "player.h"
#include "frame_provider.h"

class PlayerManager : public QObject
{
    Q_OBJECT
    
public:
    static PlayerManager* instance();
    
    // 播放器类型枚举
    enum PlayerType {
        VisibleLightLive,      // 可见光实时
        InfraredLive,          // 红外实时
        VisibleLightRecord,    // 可见光录像
        InfraredRecord,        // 红外录像
        DualFusion            // 双光融合
    };
    Q_ENUM(PlayerType)
    
    // 播放器管理
    Q_INVOKABLE splayer* getPlayer(int channelIndex, PlayerType playerType);
    Q_INVOKABLE splayer* getPlayer(int channelIndex, bool isVisibleLight = true); // 向后兼容
    Q_INVOKABLE void switchDeviceToChannel(const QString &deviceId, int channelIndex);
    Q_INVOKABLE void updatePlayerUrls();
    Q_INVOKABLE void initializePlayers(int maxChannels = 9);
    
    // 播放器状态管理
    Q_INVOKABLE void startAllPlayers();
    Q_INVOKABLE void stopAllPlayers();
    Q_INVOKABLE void pauseAllPlayers();
    Q_INVOKABLE void resumeAllPlayers();
    
    // 播放器配置
    Q_INVOKABLE void setPlayerUrls(int channelIndex, const QString &visibleLightUrl, const QString &infraredUrl);
    Q_INVOKABLE void setPlayerUrl(int channelIndex, PlayerType playerType, const QString &url);
    Q_INVOKABLE void fastSwitchPlayerUrl(int channelIndex, bool isVisibleLight, const QString &newUrl);
    Q_INVOKABLE void fastSwitchPlayerUrl(int channelIndex, PlayerType playerType, const QString &newUrl);
    Q_INVOKABLE QString getVisibleLightUrl(int channelIndex);
    Q_INVOKABLE QString getInfraredUrl(int channelIndex);
    Q_INVOKABLE QString getPlayerUrl(int channelIndex, PlayerType playerType);
    
    // FrameProvider管理
    Q_INVOKABLE void setFrameProviders(FrameProvider* visibleLightProvider, FrameProvider* infraredProvider);
    Q_INVOKABLE void setChannelFrameProvider(int channelIndex, bool isVisibleLight, FrameProvider* provider);
    Q_INVOKABLE void setChannelFrameProvider(int channelIndex, PlayerType playerType, FrameProvider* provider);
    
    // 播放器状态查询
    Q_INVOKABLE bool isPlayerPlaying(int channelIndex, bool isVisibleLight = true);
    Q_INVOKABLE bool isPlayerPlaying(int channelIndex, PlayerType playerType);
    Q_INVOKABLE int getPlayerStatus(int channelIndex, bool isVisibleLight = true);
    Q_INVOKABLE int getPlayerStatus(int channelIndex, PlayerType playerType);
    
    // 清理资源
    void cleanup();
    
signals:
    void playerUrlChanged(int channelIndex, bool isVisibleLight, const QString &url);
    void playerUrlChanged(int channelIndex, PlayerType playerType, const QString &url);
    void playerStatusChanged(int channelIndex, bool isVisibleLight, int status);
    void playerStatusChanged(int channelIndex, PlayerType playerType, int status);
    void playerInitialized(int channelIndex);
    void allPlayersInitialized();
    void dualFusionModeChanged(int channelIndex, bool enabled);  // 双光融合模式变化信号
    void gasCloudModeChanged(int channelIndex, bool enabled);  // 气云成像模式变化信号
    
private:
    explicit PlayerManager(QObject *parent = nullptr);
    ~PlayerManager();
    
    static PlayerManager* m_instance;
    QMap<int, QMap<PlayerType, splayer*>> m_players;  // 每个通道的四个播放器
    QMap<int, QMap<PlayerType, QThread*>> m_playerThreads;  // 每个播放器的线程
    QMap<int, QMap<PlayerType, QString>> m_playerUrls;  // 每个播放器的URL缓存
    QMutex m_mutex;
    int m_maxChannels;
    bool m_initialized;
    
    // FrameProvider映射
    QMap<int, QMap<PlayerType, FrameProvider*>> m_frameProviders;  // 每个播放器的FrameProvider
    
    // 用于算法处理但不显示的FrameProvider（解决双光融合闪烁问题）
    QMap<int, FrameProvider*> m_algorithmVisibleProviders;  // 每个通道可见光算法处理FrameProvider
    QMap<int, FrameProvider*> m_algorithmInfraredProviders; // 每个通道红外光算法处理FrameProvider
    
    // 双光融合相关
    QMap<int, FrameProvider*> m_dualFusionProviders;  // 每个通道的双光融合FrameProvider
    QMap<int, bool> m_dualFusionMode;  // 每个通道是否处于双光融合模式
    int m_currentFusionChannel;
    
    // 气云成像相关
    QMap<int, FrameProvider*> m_gasCloudVisibleProviders;  // 每个通道的气云可见光FrameProvider
    QMap<int, FrameProvider*> m_gasCloudInfraredProviders;  // 每个通道的气云红外FrameProvider
    QMap<int, bool> m_gasCloudMode;  // 每个通道是否处于气云成像模式
    int m_currentGasCloudChannel;  // 当前正在融合的通道
    
    // TOF距离相关
    QMap<int, float> m_tofDistances;  // 每个通道的TOF距离（毫米）
    
    void createPlayer(int channelIndex);
    void destroyPlayer(int channelIndex);
    void connectPlayerSignals(splayer* player, int channelIndex, PlayerType playerType);
    void triggerDualFusion(int channelIndex, PlayerType sourceType, const QVideoFrame& frame);
    void triggerGasCloud(int channelIndex, PlayerType sourceType, const QVideoFrame& frame);
    QVideoFrame imageToVideoFrame(const QImage& image);
    
    // 直接从QVideoFrame提取YUV数据
    QByteArray extractYUVData(const QVideoFrame& frame, int& width, int& height) const;
    // YUV420P转NV12格式转换
    QByteArray convertYUV420PToNV12(const QByteArray& yuv420pData, int width, int height) const;

private slots:
    // 处理双光融合完成
    void onDualFusionCompleted(const QVideoFrame& fusedFrame, bool success, const QString& errorMessage);
    
    // 处理气云成像完成
    void onGasCloudCompleted(const QVideoFrame& fusionFrame, const QVideoFrame& irHeatmapFrame, bool success, const QString& errorMessage);

public slots:
    // 双光融合相关方法
    void setDualFusionMode(int channelIndex, bool enabled);
    bool isDualFusionMode(int channelIndex) const;
    FrameProvider* getDualFusionProvider(int channelIndex);
    void setDualFusionProvider(int channelIndex, FrameProvider* provider);
    
    // 气云成像相关方法
    void setGasCloudMode(int channelIndex, bool enabled);
    bool isGasCloudMode(int channelIndex) const;
    FrameProvider* getGasCloudVisibleProvider(int channelIndex);
    FrameProvider* getGasCloudInfraredProvider(int channelIndex);
    void setGasCloudVisibleProvider(int channelIndex, FrameProvider* provider);
    void setGasCloudInfraredProvider(int channelIndex, FrameProvider* provider);
    
    // TOF距离相关方法
    Q_INVOKABLE void setTofDistance(int channelIndex, float distance);
    Q_INVOKABLE float getTofDistance(int channelIndex);
};

#endif // PLAYERMANAGER_H