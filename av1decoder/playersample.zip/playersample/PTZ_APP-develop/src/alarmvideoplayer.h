#ifndef ALARMVIDEOPLAYER_H
#define ALARMVIDEOPLAYER_H

#include <QObject>
#include <QQmlEngine>
#include <QDateTime>
#include <QString>
#include <QThread>
#include <QMutex>
#include <QPointer>
#include <QTimer>
#include "player.h"
#include "frame_provider.h"

// 前向声明
class HikvisionCtrl;

class AlarmVideoPlayer : public QObject
{
    Q_OBJECT
    QML_ELEMENT
    QML_SINGLETON

public:
    static AlarmVideoPlayer* instance();
    explicit AlarmVideoPlayer(QObject *parent = nullptr);
    ~AlarmVideoPlayer();

    // QML可调用的方法
    Q_INVOKABLE void playAlarmVideo(const QString& deviceCode, const QString& alarmTime, bool isInfraredVideo);
    Q_INVOKABLE void stopAlarmVideo();
    Q_INVOKABLE bool isPlaying() const;
    Q_INVOKABLE FrameProvider* getFrameProvider() const;
    
    // 设置HikvisionCtrl实例
    void setHikvisionCtrl(HikvisionCtrl* hikvisionCtrl);

    // 新增：暂停/恢复/快速切换
    Q_INVOKABLE void pauseAlarmVideo();
    Q_INVOKABLE void resumeAlarmVideo();
    Q_INVOKABLE void fastSwitchAlarmVideo(const QString& deviceCode, const QString& alarmTime, bool isInfraredVideo);

signals:
    void playbackStarted();
    void playbackStopped();
    void playbackError(const QString& errorMessage);

private slots:
    void onPlayerNewFrame(const QVideoFrame& frame);
    void handlePlayerError();

private:
    void initializePlayer();
    void cleanupPlayer();
    QString buildAlarmVideoUrl(const QString& deviceCode, const QString& alarmTime, bool isInfraredVideo);
    QString formatAlarmTime(const QString& alarmTime);
    void setupPlayerConnections();
    void disconnectPlayerConnections();

    static AlarmVideoPlayer* s_instance;
    
    QPointer<splayer> m_player;
    QPointer<QThread> m_playerThread;
    QPointer<FrameProvider> m_frameProvider;
    
    bool m_isPlaying;
    bool m_playerReady;
    mutable QMutex m_mutex;
    
    // 当前播放参数（用于错误恢复）
    QString m_currentDeviceCode;
    QString m_currentAlarmTime;
    bool m_currentIsInfrared;
    
    // HikvisionCtrl实例
    QPointer<HikvisionCtrl> m_hikvisionCtrl;
};

#endif // ALARMVIDEOPLAYER_H 