#ifndef SYSTEMLOG_H
#define SYSTEMLOG_H

#include <QObject>
#include <QSqlDatabase>
#include <QVariantList>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QJsonObject>

typedef enum {
    LOG_TYPE_QUERY = 0,     // 查询日志
    LOG_TYPE_OPERATION,     // 操作日志
    LOG_TYPE_NONE = 99
} LOG_TYPE_T;

typedef enum {
    ACTION_TYPE_VIDEO_PLAYBACK = 0,  // 视频回放
    ACTION_TYPE_MODIFY_ACCOUNT,      // 修改账户
    ACTION_TYPE_DELETE_ACCOUNT,      // 删除账户
    ACTION_TYPE_ADD_ACCOUNT,         // 新增账户
    ACTION_TYPE_MODIFY_DEVICE,       // 修改设备
    ACTION_TYPE_DELETE_DEVICE,       // 删除设备
    ACTION_TYPE_ADD_DEVICE,          // 添加设备
    ACTION_TYPE_QUERY_ALARM,         // 查询报警记录
    
    ACTION_TYPE_NONE = 99
} ACTION_TYPE_T;

typedef enum {
    RESULT_SUCCESS = 0,     // 成功
    RESULT_FAILURE = 1      // 失败
} OPERATION_RESULT_T;

struct SystemLogEntry {
    int id;                         // 数据库ID，新增时不需要赋值
    QString operator_name;          // 操作人员
    LOG_TYPE_T log_type;           // 日志类型
    ACTION_TYPE_T action_type;     // 操作类型
    QString operation_time;         // 操作时间
    QString operation_ip;           // 操作IP
    OPERATION_RESULT_T result;      // 操作结果（成功或失败）
    QString description;            // 操作描述（可选）
    
    QJsonObject toJson() const;
};

class SystemLog : public QObject
{
    Q_OBJECT
public:
    static SystemLog* instance();

    // 系统日志记录接口
    // C++ 调用
    void addLog(const SystemLogEntry& entry);

    // QML 调用
    Q_INVOKABLE void addLog(const QString& operatorName, int logType, int actionType,
                            const QString& operationTime, const QString& operationIp,
                            int result, const QString& description = "");

    Q_INVOKABLE QVariantMap queryLogs(const QString& operatorName = "",
                                      int logType = -1,
                                      int actionType = -1,
                                      const QString& startTime = "",
                                      const QString& endTime = "",
                                      int page = 0,
                                      int pageSize = 10);

    Q_INVOKABLE bool deleteLog(int id);
    Q_INVOKABLE bool deleteAll();

    // 导出到指定路径
    Q_INVOKABLE bool exportLogsToCsvWithPath(const QString& filePath,
                                             const QString& operatorName = "",
                                             int logType = -1,
                                             int actionType = -1,
                                             const QString& startTime = "",
                                             const QString& endTime = "");
    
    // 导出到桌面（兼容旧版本）
    Q_INVOKABLE bool exportLogsToCsv(const QString& operatorName = "",
                                     int logType = -1,
                                     int actionType = -1,
                                     const QString& startTime = "",
                                     const QString& endTime = "");

    // 获取枚举值对应的字符串
    Q_INVOKABLE QString getLogTypeString(int logType);
    Q_INVOKABLE QString getActionTypeString(int actionType);
    Q_INVOKABLE QString getResultString(int result);

signals:
    void logAdded();

private:
    explicit SystemLog(QObject* parent = nullptr);
    static SystemLog* m_instance;
    QSqlDatabase m_db;

    void initDatabase();
    SystemLogEntry fromQuery(const QSqlQuery& query);
    int querySizeHint(int pageSize) const;
};

#endif // SYSTEMLOG_H