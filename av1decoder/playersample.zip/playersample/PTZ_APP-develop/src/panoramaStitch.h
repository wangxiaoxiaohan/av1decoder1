#pragma once
#include<opencv2/opencv.hpp>
#include<vector>

int wPanoramaStitch(std::vector<cv::Mat>& vecImgs, cv::Mat& resImg);
int wMatchImage(const std::string& panoramaPath, const std::string& targetPath, int& x, int& y, int& w, int& h);

