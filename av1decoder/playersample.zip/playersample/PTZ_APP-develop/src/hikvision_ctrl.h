#ifndef HIKVISION_CTRL_H
#define HIKVISION_CTRL_H

#include <QObject>
#include <QString>
#include <QJsonObject>
#include <QJsonArray>
#include <QTimer>
#include <QVariantMap>
#include <QHash>
#include <QDateTime>
#include <QDomDocument>
#include <QDomElement>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <curl/curl.h>

// 通道信息缓存结构
struct ChannelInfo {
    int channelNumber = -1;
    QString nvrIp;
    QString ipcIp;
    bool isValid = false;
    QDateTime lastUpdated;
    
    ChannelInfo() = default;
    ChannelInfo(int channel, const QString& nvr, const QString& ipc) 
        : channelNumber(channel), nvrIp(nvr), ipcIp(ipc), isValid(true), lastUpdated(QDateTime::currentDateTime()) {}
};

class HikvisionCtrl : public QObject
{
    Q_OBJECT

public:
    explicit HikvisionCtrl(QObject* parent = nullptr);
    ~HikvisionCtrl();

    // 公共接口 - 只发信号，不做耗时工作
    Q_INVOKABLE void searchRecording(const QString& searchId, int trackId, 
                                    const QString& startTime, const QString& endTime, 
                                    int maxResults = 100, int searchResultPosition = 0);
    
    
    // 从录像段信息中提取RTSP URL
    Q_INVOKABLE QString getRtspUrlFromSegment(const QJsonObject& segment);
    
    // 构建完整的RTSP URL（带认证参数）
    Q_INVOKABLE QString buildAuthenticatedRtspUrl(const QString& originalUrl);

    // 异步查找IPC摄像头在NVR中的通道号 - 新的异步接口
    Q_INVOKABLE void findChannelByIPAsync(const QString& deviceIp, int port,
                                         const QString& username, const QString& password,
                                         const QString& ipcIp);
    
    // 同步查找IPC摄像头在NVR中的通道号 - 保留兼容性，会先检查缓存
    Q_INVOKABLE int findChannelByIP(const QString& deviceIp, int port,
                                   const QString& username, const QString& password,
                                   const QString& ipcIp);
    
    // 强制更新指定IPC的通道信息（清除缓存并重新查询）
    Q_INVOKABLE void forceUpdateChannelInfo(const QString& deviceIp, int port,
                                           const QString& username, const QString& password,
                                           const QString& ipcIp);
    
    // 批量初始化通道信息
    Q_INVOKABLE void initializeChannelInfo(const QStringList& deviceIps, 
                                          const QStringList& usernames,
                                          const QStringList& passwords,
                                          const QStringList& ipcIps,
                                          int port = 8000);
    
    // 获取缓存的通道信息
    Q_INVOKABLE int getCachedChannelNumber(const QString& nvrIp, const QString& ipcIp);
    
    // 检查缓存是否有效
    Q_INVOKABLE bool isChannelCacheValid(const QString& nvrIp, const QString& ipcIp);
    
    // 清除所有缓存
    Q_INVOKABLE void clearChannelCache();
    
    // 设置当前设备的认证信息（用于移动侦测等接口）
    Q_INVOKABLE void setCurrentDeviceCredentials(const QString& serverIp, const QString& username, const QString& password);
    
    // 获取当前设备的认证信息
    Q_INVOKABLE QString getCurrentServerIp() const { return m_serverIp; }
    Q_INVOKABLE QString getCurrentUsername() const { return m_username; }

    // ========== 移动侦测相关接口 ==========
    // 1. 获取系统能力（检查是否支持移动侦测）
    Q_INVOKABLE void getSystemCapabilities();
    
    // 2. 获取通道事件能力（检查通道是否支持VMD）
    Q_INVOKABLE void getChannelEventCapabilities(int channelId = -1);
    
    // 3. 获取指定通道移动侦测能力
    Q_INVOKABLE void getMotionDetectionCapabilities(int channelId);
    
    // 4. 获取移动侦测区域配置能力
    Q_INVOKABLE void getMotionDetectionLayoutCapabilities(int channelId);
    
    // 5. 获取移动侦测配置
    Q_INVOKABLE void getMotionDetectionConfig(int channelId);
    
    // 6. 设置移动侦测配置
    Q_INVOKABLE void setMotionDetectionConfig(int channelId, const QJsonObject& config);
    
    // 7. 获取移动侦测区域配置
    Q_INVOKABLE void getMotionDetectionLayout(int channelId, const QString& regionType = "grid");
    
    // 8. 设置移动侦测区域配置
    Q_INVOKABLE void setMotionDetectionLayout(int channelId, const QJsonObject& layout, const QString& regionType = "grid");
    
    // 9. 获取移动侦测联动规则
    Q_INVOKABLE void getMotionDetectionTrigger(int channelId);
    
    // 10. 设置移动侦测联动规则
    Q_INVOKABLE void setMotionDetectionTrigger(int channelId, const QJsonObject& trigger);
    
    // 11. 删除移动侦测联动规则
    Q_INVOKABLE void deleteMotionDetectionTrigger(int channelId);
    
    // 12. 获取移动侦测布防时间
    Q_INVOKABLE void getMotionDetectionSchedule(int channelId);
    
    // 13. 设置移动侦测布防时间
    Q_INVOKABLE void setMotionDetectionSchedule(int channelId, const QJsonObject& schedule);
    
    // 14. 诊断移动侦测支持能力（尝试所有可能的端点）
    Q_INVOKABLE void diagnoseMotionDetectionSupport(int channelId);



signals:
    // 请求信号
    void searchRecordingRequested(const QString& searchId, int trackId, 
                                const QString& startTime, const QString& endTime, 
                                int maxResults, int searchResultPosition);

    // 通道查找请求信号
    void channelLookupRequested(const QString& deviceIp, int port,
                               const QString& username, const QString& password,
                               const QString& ipcIp, bool forceUpdate);

    // 结果信号
    void recordingSearchCompleted(const QJsonObject& result);
    
    // 通道查找完成信号
    void channelLookupCompleted(const QString& nvrIp, const QString& ipcIp, int channelNumber);
    
    // 通道查找失败信号
    void channelLookupFailed(const QString& nvrIp, const QString& ipcIp, const QString& errorMessage);
    
    // 批量初始化完成信号
    void channelInitializationCompleted();
    
    // ========== 移动侦测相关信号 ==========
    // 系统能力查询完成
    void systemCapabilitiesReceived(const QJsonObject& capabilities);
    
    // 通道事件能力查询完成
    void channelEventCapabilitiesReceived(int channelId, const QJsonObject& capabilities);
    
    // 移动侦测能力查询完成
    void motionDetectionCapabilitiesReceived(int channelId, const QJsonObject& capabilities);
    
    // 移动侦测区域配置能力查询完成
    void motionDetectionLayoutCapabilitiesReceived(int channelId, const QJsonObject& capabilities);
    
    // 移动侦测配置获取完成
    void motionDetectionConfigReceived(int channelId, const QJsonObject& config);
    
    // 移动侦测配置设置完成
    void motionDetectionConfigSet(int channelId, bool success, const QString& message);
    
    // 移动侦测区域配置获取完成
    void motionDetectionLayoutReceived(int channelId, const QJsonObject& layout);
    
    // 移动侦测区域配置设置完成
    void motionDetectionLayoutSet(int channelId, bool success, const QString& message);
    
    // 移动侦测联动规则获取完成
    void motionDetectionTriggerReceived(int channelId, const QJsonObject& trigger);
    
    // 移动侦测联动规则设置完成
    void motionDetectionTriggerSet(int channelId, bool success, const QString& message);
    
    // 移动侦测联动规则删除完成
    void motionDetectionTriggerDeleted(int channelId, bool success, const QString& message);
    
    // 移动侦测布防时间获取完成
    void motionDetectionScheduleReceived(int channelId, const QJsonObject& schedule);
    
    // 移动侦测布防时间设置完成
    void motionDetectionScheduleSet(int channelId, bool success, const QString& message);
    
    // 移动侦测操作错误
    void motionDetectionError(const QString& operation, const QString& errorMessage);
    
    // 移动侦测支持诊断结果
    void motionDetectionDiagnosisCompleted(int channelId, const QJsonObject& supportInfo);

private slots:
    // 实际处理函数
    void doSearchRecording(const QString& searchId, int trackId, 
                          const QString& startTime, const QString& endTime, 
                          int maxResults, int searchResultPosition);
    
    // 异步通道查找处理函数
    void doChannelLookup(const QString& deviceIp, int port,
                        const QString& username, const QString& password,
                        const QString& ipcIp, bool forceUpdate);

private:
    // 辅助函数
    QString createSearchXml(const QString& searchId, int trackId, 
                          const QString& startTime, const QString& endTime, 
                          int maxResults, int searchResultPosition);
    QJsonObject parseSearchResult(const QString& xmlResponse);
    bool sendHttpRequest(const QString& url, const QString& method, 
                        const QString& data = QString(), 
                        QString* response = nullptr);
    
    // 新增：获取Cookie认证
    bool authenticateAndGetCookie();

    // 解析通道信息XML响应，查找匹配IP的通道号
    int parseChannelInfoForIP(const QString& xmlResponse, const QString& ipcIp);
    
    // 缓存管理
    QString generateCacheKey(const QString& nvrIp, const QString& ipcIp);
    void updateChannelCache(const QString& nvrIp, const QString& ipcIp, int channelNumber);
    ChannelInfo getChannelFromCache(const QString& nvrIp, const QString& ipcIp);
    
    // ========== XML解析和生成辅助函数 ==========
    // 将JSON对象转换为XML格式
    QByteArray convertJsonToXml(const QJsonObject& jsonObj, const QString& rootElement);
    
    // 递归将JSON对象转换为XML元素
    void convertJsonObjectToXmlElement(const QJsonObject& jsonObj, QDomElement& xmlElement, QDomDocument& doc);
    
    // 增强的XML到JSON转换函数（专门用于移动侦测）
    QJsonObject parseMotionDetectionXml(const QByteArray& xmlData);
    
    // 专门用于解析移动侦测布局XML的函数
    QJsonObject parseMotionDetectionLayoutXml(const QByteArray& xmlData);
    
    // 将JSON对象转换为移动侦测布局XML
    QByteArray convertJsonToMotionDetectionLayoutXml(const QJsonObject& jsonObj);
    
    // 解析移动侦测布防时间XML
    QJsonObject parseMotionDetectionScheduleXml(const QByteArray& xmlData);
    
    // 将JSON对象转换为移动侦测布防时间XML
    QByteArray convertJsonToMotionDetectionScheduleXml(const QJsonObject& jsonObj);
    
    // 递归将XML元素转换为JSON对象
    QJsonObject convertXmlElementToJsonObject(const QDomElement& xmlElement);

    // 成员变量
    QString m_serverIp;
    QString m_username;
    QString m_password;
    QString m_cookie;        // 新增：存储Cookie
    QString m_sessionId;     // 新增：存储会话ID
    
    // 通道信息缓存
    QHash<QString, ChannelInfo> m_channelCache;  // key: "nvrIp|ipcIp"
    
    // CURL 相关
    CURL* m_curl;
    struct curl_slist* m_headers;
    
    // 网络管理器（用于移动侦测接口）
    QNetworkAccessManager* m_networkManager;
};

#endif // HIKVISION_CTRL_H