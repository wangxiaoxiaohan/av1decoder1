#ifndef HIKVISION_CTRL_H
#define HIKVISION_CTRL_H

#include <QObject>
#include <QString>
#include <QJsonObject>
#include <QJsonArray>
#include <QTimer>
#include <QVariantMap>
#include <QHash>
#include <QDateTime>
#include <QDomDocument>
#include <QDomElement>
#include <QXmlStreamWriter>
#include <QXmlStreamReader>
#include <QNetworkAccessManager>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QThread>
#include <curl/curl.h>
#include <atomic>

// 通道信息缓存结构
struct ChannelInfo {
    int channelNumber = -1;
    QString nvrIp;
    QString ipcIp;
    bool isValid = false;
    QDateTime lastUpdated;
    
    ChannelInfo() = default;
    ChannelInfo(int channel, const QString& nvr, const QString& ipc) 
        : channelNumber(channel), nvrIp(nvr), ipcIp(ipc), isValid(true), lastUpdated(QDateTime::currentDateTime()) {}
};

// 前向声明
class HikvisionWorker;
//todo ,还有一部分函数没有移动到HikvisionWorker中
class HikvisionCtrl : public QObject
{
    Q_OBJECT

public:
    explicit HikvisionCtrl(QObject* parent = nullptr);
    ~HikvisionCtrl();

    // 公共接口 - 只发信号，不做耗时工作
    Q_INVOKABLE void searchRecording(const QString& searchId, int trackId, 
                                    const QString& startTime, const QString& endTime, 
                                    int maxResults = 100, int searchResultPosition = 0);
    
    
    // 从录像段信息中提取RTSP URL
    Q_INVOKABLE QString getRtspUrlFromSegment(const QJsonObject& segment);
    
    // 构建完整的RTSP URL（带认证参数）
    Q_INVOKABLE QString buildAuthenticatedRtspUrl(const QString& originalUrl);

    
    // 同步查找IPC摄像头在NVR中的通道号 - 保留兼容性，会先检查缓存
    Q_INVOKABLE int findChannelByIP(const QString& deviceIp, int port,
                                   const QString& username, const QString& password,
                                   const QString& ipcIp);
    
    
    // 设置当前设备的认证信息（用于移动侦测等接口）
    Q_INVOKABLE void setCurrentDeviceCredentials(const QString& serverIp, const QString& username, const QString& password);
    
    // 获取当前设备的认证信息
    Q_INVOKABLE QString getCurrentServerIp() const { return m_serverIp; }
    Q_INVOKABLE QString getCurrentUsername() const { return m_username; }

    // ========== 移动侦测相关接口 ==========
    // 1. 获取系统能力（检查是否支持移动侦测）
    Q_INVOKABLE void getSystemCapabilities();
    
    // 2. 获取通道事件能力（检查通道是否支持VMD）
    Q_INVOKABLE void getChannelEventCapabilities(int channelId = -1);
    
    // 3. 获取指定通道移动侦测能力
    Q_INVOKABLE void getMotionDetectionCapabilities(int channelId);
    
    // 4. 获取移动侦测区域配置能力
    Q_INVOKABLE void getMotionDetectionLayoutCapabilities(int channelId);
    
    // 5. 获取移动侦测配置
    Q_INVOKABLE void getMotionDetectionConfig(int channelId);
    
    // 6. 设置移动侦测配置
    Q_INVOKABLE void setMotionDetectionConfig(int channelId, const QJsonObject& config);
    
    // 7. 获取移动侦测区域配置
    Q_INVOKABLE void getMotionDetectionLayout(int channelId, const QString& regionType = "grid");
    
    // 8. 设置移动侦测区域配置
    Q_INVOKABLE void setMotionDetectionLayout(int channelId, const QJsonObject& layout, const QString& regionType = "grid");
    
    // 9. 获取移动侦测联动规则
    Q_INVOKABLE void getMotionDetectionTrigger(int channelId);
    
    // 10. 设置移动侦测联动规则
    Q_INVOKABLE void setMotionDetectionTrigger(int channelId, const QJsonObject& trigger);
    
    // 11. 删除移动侦测联动规则
    Q_INVOKABLE void deleteMotionDetectionTrigger(int channelId);
    
    // 12. 获取移动侦测布防时间
    Q_INVOKABLE void getMotionDetectionSchedule(int channelId);
    
    // 13. 设置移动侦测布防时间
    Q_INVOKABLE void setMotionDetectionSchedule(int channelId, const QJsonObject& schedule);
    
    // 14. 诊断移动侦测支持能力（尝试所有可能的端点）
    Q_INVOKABLE void diagnoseMotionDetectionSupport(int channelId);
    
    // ========== 录像计划相关接口 ==========
    // 1. 获取指定通道的录像计划
    Q_INVOKABLE void getRecordingSchedule(int channelId, int trackId = -1);
    
    // 2. 设置指定通道的录像计划
    Q_INVOKABLE void setRecordingSchedule(int channelId, const QJsonObject& scheduleConfig, int trackId = -1);



signals:
    // 录像搜索请求信号已删除 - 直接调用方法替代

    // 通道查找请求信号已删除 - 直接调用方法替代

    // 结果信号
    void recordingSearchCompleted(const QJsonObject& result);
    
    // 通道查找完成信号
    void channelLookupCompleted(const QString& nvrIp, const QString& ipcIp, int channelNumber);
    
    // 通道查找失败信号
    void channelLookupFailed(const QString& nvrIp, const QString& ipcIp, const QString& errorMessage);
    
    
    // ========== 移动侦测相关信号 ==========
    // 系统能力查询完成
    void systemCapabilitiesReceived(const QJsonObject& capabilities);
    
    // 通道事件能力查询完成
    void channelEventCapabilitiesReceived(int channelId, const QJsonObject& capabilities);
    
    // 移动侦测能力查询完成
    void motionDetectionCapabilitiesReceived(int channelId, const QJsonObject& capabilities);
    
    // 移动侦测区域配置能力查询完成
    void motionDetectionLayoutCapabilitiesReceived(int channelId, const QJsonObject& capabilities);
    
    // 移动侦测配置获取完成
    void motionDetectionConfigReceived(int channelId, const QJsonObject& config);
    
    // 移动侦测配置设置完成
    void motionDetectionConfigSet(int channelId, bool success, const QString& message);
    
    // 移动侦测区域配置获取完成
    void motionDetectionLayoutReceived(int channelId, const QJsonObject& layout);
    
    // 移动侦测区域配置设置完成
    void motionDetectionLayoutSet(int channelId, bool success, const QString& message);
    
    // 移动侦测联动规则获取完成
    void motionDetectionTriggerReceived(int channelId, const QJsonObject& trigger);
    
    // 移动侦测联动规则设置完成
    void motionDetectionTriggerSet(int channelId, bool success, const QString& message);
    
    // 移动侦测联动规则删除完成
    void motionDetectionTriggerDeleted(int channelId, bool success, const QString& message);
    
    // 移动侦测布防时间获取完成
    void motionDetectionScheduleReceived(int channelId, const QJsonObject& schedule);
    
    // 移动侦测布防时间设置完成
    void motionDetectionScheduleSet(int channelId, bool success, const QString& message);
    
    // 移动侦测操作错误
    void motionDetectionError(const QString& operation, const QString& errorMessage);
    
    // 移动侦测支持诊断结果
    void motionDetectionDiagnosisCompleted(int channelId, const QJsonObject& supportInfo);
    
    // ========== 录像计划相关信号 ==========
    // 录像计划获取完成
    void recordingScheduleReceived(int channelId, int trackId, const QJsonObject& schedule);
    
    // 录像计划设置完成
    void recordingScheduleSet(int channelId, int trackId, bool success, const QString& message);
    
    // 录像计划操作错误
    void recordingScheduleError(const QString& operation, const QString& errorMessage);

private slots:


private:
    // 辅助函数
    QString createSearchXml(const QString& searchId, int trackId, 
                          const QString& startTime, const QString& endTime, 
                          int maxResults, int searchResultPosition);
    QJsonObject parseSearchResult(const QString& xmlResponse);
    bool sendHttpRequest(const QString& url, const QString& method, 
                        const QString& data = QString(), 
                        QString* response = nullptr);
    int parseChannelInfoForIP(const QString& xmlResponse, const QString& ipcIp);
    // 新增：获取Cookie认证
    bool authenticateAndGetCookie();
    
    // 缓存管理
    QString generateCacheKey(const QString& nvrIp, const QString& ipcIp);
    void updateChannelCache(const QString& nvrIp, const QString& ipcIp, int channelNumber);
    ChannelInfo getChannelFromCache(const QString& nvrIp, const QString& ipcIp);
    
    // ========== XML解析和生成辅助函数 ==========
    // 将JSON对象转换为XML格式
    QByteArray convertJsonToXml(const QJsonObject& jsonObj, const QString& rootElement);
    
    // 递归将JSON对象转换为XML元素
    void convertJsonObjectToXmlElement(const QJsonObject& jsonObj, QDomElement& xmlElement, QDomDocument& doc);
    
    // 增强的XML到JSON转换函数（专门用于移动侦测）
    QJsonObject parseMotionDetectionXml(const QByteArray& xmlData);
    
    // 专门用于解析移动侦测布局XML的函数
    QJsonObject parseMotionDetectionLayoutXml(const QByteArray& xmlData);
    QString convertJsonToXml(const QJsonObject& json);
    
    // 将JSON对象转换为移动侦测布局XML
    QByteArray convertJsonToMotionDetectionLayoutXml(const QJsonObject& jsonObj);
    
    // 递归将XML元素转换为JSON对象
    QJsonObject convertXmlElementToJsonObject(const QDomElement& xmlElement);

    // 成员变量
    QString m_serverIp;
    QString m_username;
    QString m_password;
    QString m_cookie;        // 新增：存储Cookie
    QString m_sessionId;     // 新增：存储会话ID
    
    // 通道信息缓存
    QHash<QString, ChannelInfo> m_channelCache;  // key: "nvrIp|ipcIp"
    
    // CURL 相关
    CURL* m_curl;
    struct curl_slist* m_headers;
    
    // 网络管理器（用于移动侦测接口）
    QNetworkAccessManager* m_networkManager;
    
    // 工作线程
    QThread* m_workerThread;
    HikvisionWorker* m_worker;
};

// HikvisionWorker类定义
class HikvisionWorker : public QObject
{
    Q_OBJECT

public slots:
    void process();
    void stop();
    void doSearchRecording(const QString& searchId, int trackId, 
                          const QString& startTime, const QString& endTime, 
                          int maxResults, int searchResultPosition);
    int findChannelByIP(const QString& deviceIp, int port,
                       const QString& username, const QString& password,
                       const QString& ipcIp);
    void setCurrentDeviceCredentials(const QString& serverIp, const QString& username, const QString& password);
    void getSystemCapabilities();
    void getChannelEventCapabilities(int channelId);
    void getMotionDetectionCapabilities(int channelId);
    void getMotionDetectionLayoutCapabilities(int channelId);
    void getMotionDetectionConfig(int channelId);
    void setMotionDetectionConfig(int channelId, const QJsonObject& config);
    
    // 新增：获取和设置移动侦测布局
    void getMotionDetectionLayout(int channelId, const QString& regionType = QString());
    void setMotionDetectionLayout(int channelId, const QJsonObject& layout, const QString& regionType = QString());
    
    // 新增：移动侦测触发器相关方法
    void getMotionDetectionTrigger(int channelId);
    void setMotionDetectionTrigger(int channelId, const QJsonObject& trigger);
    void deleteMotionDetectionTrigger(int channelId);
    
    // 新增：移动侦测布防时间相关方法
    void getMotionDetectionSchedule(int channelId);
    void setMotionDetectionSchedule(int channelId, const QJsonObject& schedule);
    
    // 新增：录像计划相关方法
    void getRecordingSchedule(int channelId, int trackId = -1);
    void setRecordingSchedule(int channelId, const QJsonObject& scheduleConfig, int trackId = -1);


public:
    explicit HikvisionWorker(QObject* parent = nullptr);
    ~HikvisionWorker();
    
    // 设置认证信息
    void setServerIp(const QString& ip) { m_serverIp = ip; }
    void setUsername(const QString& username) { m_username = username; }
    void setPassword(const QString& password) { m_password = password; }

signals:
    void recordingSearchCompleted(const QJsonObject& result);
    void channelLookupCompleted(const QString& nvrIp, const QString& ipcIp, int channelNumber);
    void systemCapabilitiesReceived(const QJsonObject& capabilities);
    void channelEventCapabilitiesReceived(int channelId, const QJsonObject& capabilities);
    void motionDetectionCapabilitiesReceived(int channelId, const QJsonObject& capabilities);
    void motionDetectionLayoutCapabilitiesReceived(int channelId, const QJsonObject& capabilities);
    void motionDetectionConfigReceived(int channelId, const QJsonObject& config);
    void motionDetectionConfigSet(int channelId, bool success, const QString& message);
    
    void motionDetectionLayoutReceived(int channelId, const QJsonObject& layout);
    void motionDetectionLayoutSet(int channelId, bool success, const QString& message);
    
    // 移动侦测触发器相关信号
    void motionDetectionTriggerReceived(int channelId, const QJsonObject& trigger);
    void motionDetectionTriggerSet(int channelId, bool success, const QString& message);
    void motionDetectionTriggerDeleted(int channelId, bool success, const QString& message);
    
    // 移动侦测布防时间相关信号
    void motionDetectionScheduleReceived(int channelId, const QJsonObject& schedule);
    void motionDetectionScheduleSet(int channelId, bool success, const QString& message);
    
    // 录像计划相关信号
    void recordingScheduleReceived(int channelId, int trackId, const QJsonObject& schedule);
    void recordingScheduleSet(int channelId, int trackId, bool success, const QString& message);
    void recordingScheduleError(const QString& operation, const QString& errorMessage);
    
    void motionDetectionError(const QString& operation, const QString& errorMessage);
    void finished();

private:
    // 辅助函数
    QString createSearchXml(const QString& searchId, int trackId, 
                          const QString& startTime, const QString& endTime, 
                          int maxResults, int searchResultPosition);
    QJsonObject parseSearchResult(const QString& xmlResponse);
    bool sendHttpRequest(const QString& url, const QString& method, 
                        const QString& data = QString(), 
                        QString* response = nullptr);
    int parseChannelInfoForIP(const QString& xmlResponse, const QString& ipcIp);
    QJsonObject parseMotionDetectionLayoutXml(const QByteArray& xmlData);
    
    // XML解析和生成辅助函数
    QByteArray convertJsonToXml(const QJsonObject& jsonObj, const QString& rootElement);
    void convertJsonObjectToXmlElement(const QJsonObject& jsonObj, QDomElement& xmlElement, QDomDocument& doc);
    QJsonObject parseMotionDetectionXml(const QByteArray& xmlData);
    QJsonObject convertXmlElementToJsonObject(const QDomElement& xmlElement);
    
    // 移动侦测布防时间XML解析和生成
    QJsonObject parseMotionDetectionScheduleXml(const QByteArray& xmlData);
    QByteArray convertJsonToMotionDetectionScheduleXml(const QJsonObject& jsonObj);
    QByteArray convertJsonToMotionDetectionLayoutXml(const QJsonObject& jsonObj);
    
    // 新增：录像计划相关方法
    QJsonObject parseRecordingScheduleXml(const QByteArray& xmlData);
    QByteArray convertJsonToRecordingScheduleXml(const QJsonObject& jsonObj);
    void writeCustomExtensionListElement(QXmlStreamWriter& writer, const QJsonObject& extensions);
    void writeScheduleActionElement(QXmlStreamWriter& writer, const QJsonObject& action);
    void writeScheduleBlockElement(QXmlStreamWriter& writer, const QJsonObject& block);
    void writeTrackScheduleElement(QXmlStreamWriter& writer, const QJsonObject& schedule);
    void writeTrackElement(QXmlStreamWriter& writer, const QJsonObject& track);
    QJsonObject parseTrackElement(QXmlStreamReader& reader);
    QJsonObject parseTrackScheduleElement(QXmlStreamReader& reader);
    QJsonObject parseScheduleBlockElement(QXmlStreamReader& reader);
    QJsonObject parseScheduleActionElement(QXmlStreamReader& reader);
    QJsonObject parseCustomExtensionListElement(QXmlStreamReader& reader);
    
    // 成员变量
    QString m_serverIp;
    QString m_username;
    QString m_password;
    QString m_cookie;
    QString m_sessionId;
    
    // CURL 相关
    CURL* m_curl;
    struct curl_slist* m_headers;
    
    // 停止标志
    std::atomic<bool> m_stopped;
};

#endif // HIKVISION_CTRL_H