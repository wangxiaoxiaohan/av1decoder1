#ifndef HIKVISION_CTRL_H
#define HIKVISION_CTRL_H

#include <QObject>
#include <QString>
#include <QJsonObject>
#include <QJsonArray>
#include <QTimer>
#include <QVariantMap>
#include <QHash>
#include <QDateTime>
#include <curl/curl.h>

// 通道信息缓存结构
struct ChannelInfo {
    int channelNumber = -1;
    QString nvrIp;
    QString ipcIp;
    bool isValid = false;
    QDateTime lastUpdated;
    
    ChannelInfo() = default;
    ChannelInfo(int channel, const QString& nvr, const QString& ipc) 
        : channelNumber(channel), nvrIp(nvr), ipcIp(ipc), isValid(true), lastUpdated(QDateTime::currentDateTime()) {}
};

class HikvisionCtrl : public QObject
{
    Q_OBJECT

public:
    explicit HikvisionCtrl(QObject* parent = nullptr);
    ~HikvisionCtrl();

    // 公共接口 - 只发信号，不做耗时工作
    Q_INVOKABLE void searchRecording(const QString& searchId, int trackId, 
                                    const QString& startTime, const QString& endTime, 
                                    int maxResults = 100, int searchResultPosition = 0);
    
    
    // 从录像段信息中提取RTSP URL
    Q_INVOKABLE QString getRtspUrlFromSegment(const QJsonObject& segment);
    
    // 构建完整的RTSP URL（带认证参数）
    Q_INVOKABLE QString buildAuthenticatedRtspUrl(const QString& originalUrl);

    // 异步查找IPC摄像头在NVR中的通道号 - 新的异步接口
    Q_INVOKABLE void findChannelByIPAsync(const QString& deviceIp, int port,
                                         const QString& username, const QString& password,
                                         const QString& ipcIp);
    
    // 同步查找IPC摄像头在NVR中的通道号 - 保留兼容性，会先检查缓存
    Q_INVOKABLE int findChannelByIP(const QString& deviceIp, int port,
                                   const QString& username, const QString& password,
                                   const QString& ipcIp);
    
    // 强制更新指定IPC的通道信息（清除缓存并重新查询）
    Q_INVOKABLE void forceUpdateChannelInfo(const QString& deviceIp, int port,
                                           const QString& username, const QString& password,
                                           const QString& ipcIp);
    
    // 批量初始化通道信息
    Q_INVOKABLE void initializeChannelInfo(const QStringList& deviceIps, 
                                          const QStringList& usernames,
                                          const QStringList& passwords,
                                          const QStringList& ipcIps,
                                          int port = 8000);
    
    // 获取缓存的通道信息
    Q_INVOKABLE int getCachedChannelNumber(const QString& nvrIp, const QString& ipcIp);
    
    // 检查缓存是否有效
    Q_INVOKABLE bool isChannelCacheValid(const QString& nvrIp, const QString& ipcIp);
    
    // 清除所有缓存
    Q_INVOKABLE void clearChannelCache();

signals:
    // 请求信号
    void searchRecordingRequested(const QString& searchId, int trackId, 
                                const QString& startTime, const QString& endTime, 
                                int maxResults, int searchResultPosition);

    // 通道查找请求信号
    void channelLookupRequested(const QString& deviceIp, int port,
                               const QString& username, const QString& password,
                               const QString& ipcIp, bool forceUpdate);

    // 结果信号
    void recordingSearchCompleted(const QJsonObject& result);
    
    // 通道查找完成信号
    void channelLookupCompleted(const QString& nvrIp, const QString& ipcIp, int channelNumber);
    
    // 通道查找失败信号
    void channelLookupFailed(const QString& nvrIp, const QString& ipcIp, const QString& errorMessage);
    
    // 批量初始化完成信号
    void channelInitializationCompleted();

private slots:
    // 实际处理函数
    void doSearchRecording(const QString& searchId, int trackId, 
                          const QString& startTime, const QString& endTime, 
                          int maxResults, int searchResultPosition);
    
    // 异步通道查找处理函数
    void doChannelLookup(const QString& deviceIp, int port,
                        const QString& username, const QString& password,
                        const QString& ipcIp, bool forceUpdate);

private:
    // 辅助函数
    QString createSearchXml(const QString& searchId, int trackId, 
                          const QString& startTime, const QString& endTime, 
                          int maxResults, int searchResultPosition);
    QJsonObject parseSearchResult(const QString& xmlResponse);
    bool sendHttpRequest(const QString& url, const QString& method, 
                        const QString& data = QString(), 
                        QString* response = nullptr);
    
    // 新增：获取Cookie认证
    bool authenticateAndGetCookie();

    // 解析通道信息XML响应，查找匹配IP的通道号
    int parseChannelInfoForIP(const QString& xmlResponse, const QString& ipcIp);
    
    // 缓存管理
    QString generateCacheKey(const QString& nvrIp, const QString& ipcIp);
    void updateChannelCache(const QString& nvrIp, const QString& ipcIp, int channelNumber);
    ChannelInfo getChannelFromCache(const QString& nvrIp, const QString& ipcIp);

    // 成员变量
    QString m_serverIp;
    QString m_username;
    QString m_password;
    QString m_cookie;        // 新增：存储Cookie
    QString m_sessionId;     // 新增：存储会话ID
    
    // 通道信息缓存
    QHash<QString, ChannelInfo> m_channelCache;  // key: "nvrIp|ipcIp"
    
    // CURL 相关
    CURL* m_curl;
    struct curl_slist* m_headers;
};

#endif // HIKVISION_CTRL_H