#ifndef IMAGE_FUSION_MANAGER_H
#define IMAGE_FUSION_MANAGER_H

#include <QObject>
#include <QString>
#include <QImage>
#include <QMutex>
#include <QThread>
#include <QVideoFrame>
#include <QByteArray>
//#include <nlohmann/json.hpp>
#include "wRegistration.h"

//using json = nlohmann::json;

// 前向声明
class ImageFusionWorker;

class ImageFusionManager : public QObject
{
    Q_OBJECT

public:
    static ImageFusionManager* instance();
    
    // 初始化融合管理器
    Q_INVOKABLE bool initializeFusion(const QString& calibrationConfigPath = "config/calibration_params.json");
    
    // 异步执行双光融合
    Q_INVOKABLE void performDualFusionWithYUVAsync(const QByteArray& visibleYUV, int visibleWidth, int visibleHeight,
                                                   const QByteArray& infraredYUV, int infraredWidth, int infraredHeight,
                                                   float depth = 2200.0f);
    
    // 检查融合功能是否可用
    Q_INVOKABLE bool isFusionAvailable() const;
    
    // 获取融合状态
    Q_INVOKABLE QString getFusionStatus() const;

signals:
    // 双光融合完成信号
    void dualFusionCompleted(const QVideoFrame& fusedFrame, bool success, const QString& errorMessage);
    
    // 错误信号
    void fusionError(const QString& errorMessage);

private:
    explicit ImageFusionManager(QObject* parent = nullptr);
    ~ImageFusionManager();
    
    // 单例实例
    static ImageFusionManager* m_instance;
    
    // 工作线程
    QThread* m_workerThread;
    
    // 工作对象
    ImageFusionWorker* m_worker;
    
    // 初始化状态
    bool m_initialized;
    
    // 互斥锁
    mutable QMutex m_mutex;
    
    // 默认图像尺寸
    int m_defaultVisibleWidth;
    int m_defaultVisibleHeight;
    int m_defaultInfraredWidth;
    int m_defaultInfraredHeight;
    
};

// 工作类，用于在线程中执行图像融合
class ImageFusionWorker : public QObject
{
    Q_OBJECT

public:
    explicit ImageFusionWorker(QObject* parent = nullptr);
    ~ImageFusionWorker();

public slots:
    // 初始化融合
    bool initialize(const QString& calibrationConfigPath);
    
    // 执行双光融合
    void performDualFusion(const QByteArray& visibleYUV, int visibleWidth, int visibleHeight,
                          const QByteArray& infraredYUV, int infraredWidth, int infraredHeight,
                          float depth);
    
    // 释放资源
    void release();

signals:
    // 处理完成信号
    void processingCompleted(const QVideoFrame& fusedFrame, bool success, const QString& errorMessage);

private:
    // 初始化状态
    bool m_initialized;
    
    // 算法句柄
    void* m_algHandle;
    
    // 标定参数
   // json m_calibrationParams;
    
    // 标定配置文件路径
    QString m_calibrationConfigPath;
    
    // 互斥锁
    mutable QMutex m_mutex;
    
    // 将YUV数据转换为QVideoFrame
    QVideoFrame yuvToVideoFrame(const QByteArray& yuvData, int width, int height) const;
    void saveNV12ToJPG(const QByteArray& nv12Data, int width, int height, const QString& filename) const;
};

#endif // IMAGE_FUSION_MANAGER_H 