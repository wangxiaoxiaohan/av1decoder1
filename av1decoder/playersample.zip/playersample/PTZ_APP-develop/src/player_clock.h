#ifndef PLAYER_CLOCK_H
#define PLAYER_CLOCK_H

#include <QMutex>

extern "C" {
#include "libavutil/time.h"
#include <libavutil/avutil.h>
}

class Clock {
public:
    Clock();
    double getClock();
    void setClockAt(double pts, double time);
    void setClock(double pts);
    void setSpeed(double speed);
    void pause(double time);
    void resume();
    double getLastUpdated();

private:
    double pts;
    double pts_drift;
    double last_updated;
    double speed;
    bool paused;
    QMutex mutex;
};

#endif // PLAYER_CLOCK_H 