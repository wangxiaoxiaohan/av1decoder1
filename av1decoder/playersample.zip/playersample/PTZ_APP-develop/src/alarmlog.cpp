#include "alarmlog.h"
#include <QStandardPaths>
#include <QDir>
#include <QDateTime>
#include <QFile>
#include <QTextStream>

QJsonObject HwAlarmLogEntry::toJson() const {
    QJsonObject obj;
    obj["alarm_time"] = alarm_time;
    obj["alarm_type"] = static_cast<int>(alarm_type);
    obj["alarm_type_code"] = alarm_type_code;
    obj["alarm_type_name"] = alarm_type_name;
    obj["alarm_part"] = alarm_part;
    obj["device_code"] = device_code;
    obj["device_name"] = device_name;
    obj["alarm_medium"] = alarm_medium;
    obj["alarm_value"] = alarm_value;
    obj["preset"] = preset;
    obj["area"] = area;
    obj["distance"] = distance;
    obj["ir_image_url"] = ir_image_url;
    obj["ir_video_url"] = ir_video_url;
    obj["vi_image_url"] = vi_image_url;
    obj["vi_video_url"] = vi_video_url;
    obj["handle_status"] = handle_status;
    return obj;
}

AlarmLog* AlarmLog::m_instance = nullptr;

AlarmLog* AlarmLog::instance()
{
    if (!m_instance)
        m_instance = new AlarmLog();
    return m_instance;
}

AlarmLog::AlarmLog(QObject* parent)
    : QObject(parent)
{
    //QString path = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    //QDir().mkpath(path);
    //QString dbPath = path + "/alarm_logs.db";
    QString dbPath = "ptz.db";
    qDebug() << "***********db path:" << dbPath;

    m_db = QSqlDatabase::addDatabase("QSQLITE");
    m_db.setDatabaseName(dbPath);
    if (!m_db.open()) {
        qWarning() << "Failed to open database:" << m_db.lastError().text();
    }

    initDatabase();
}

void AlarmLog::initDatabase()
{
    qDebug() << "********** 初始化数据表 ***************";
    QSqlQuery query;
    query.exec("CREATE TABLE IF NOT EXISTS HwAlarmLog ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT,"
               "alarm_time DATETIME DEFAULT CURRENT_TIMESTAMP,"
               "alarm_type INTEGER,"
               "alarm_type_code TEXT,"
               "alarm_type_name TEXT,"
               "alarm_part TEXT,"
               "device_code TEXT,"
               "device_name TEXT,"
               "alarm_medium TEXT,"
               "alarm_value TEXT,"
               "preset TEXT,"
               "area TEXT,"
               "distance TEXT," // ALTER TABLE HwAlarmLog ADD COLUMN distance TEXT; 新增距离字段SQL，在数据库工具里执行后保存
               "ir_image_url TEXT,"
               "ir_video_url TEXT,"
               "vi_image_url TEXT,"
               "vi_video_url TEXT,"
               "handle_status INTEGER DEFAULT 0"
               ")");

    query.exec("CREATE INDEX IF NOT EXISTS idx_device_code ON HwAlarmLog(device_code)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_alarm_type ON HwAlarmLog(alarm_type)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_handle_status ON HwAlarmLog(handle_status)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_alarm_time ON HwAlarmLog(alarm_time)");

    query.exec("CREATE TRIGGER IF NOT EXISTS trg_clean_old_hwalarmlog "
               "AFTER INSERT ON HwAlarmLog "
               "BEGIN "
               "  DELETE FROM HwAlarmLog "
               "  WHERE alarm_time < datetime('now', '-6 months'); "
               "END;");

    query.exec("CREATE TABLE IF NOT EXISTS HwAlarmActions ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT,"
               "alarm_log_id INTEGER,"
               "handler TEXT,"
               "handle_time DATETIME,"
               "handle_result TEXT"
               ")");

    query.exec("CREATE INDEX IF NOT EXISTS idx_alarm_log_id ON HwAlarmActions(alarm_log_id)");
}

void AlarmLog::addLog(const HwAlarmLogEntry& entry)
{
    QSqlQuery query;
    query.prepare("INSERT INTO HwAlarmLog (alarm_time, alarm_type, alarm_type_code, alarm_type_name, alarm_part, "
                  "device_code, device_name, alarm_medium, alarm_value, preset, area, distance, "
                  "ir_image_url, ir_video_url, vi_image_url, vi_video_url, handle_status) "
                  "VALUES (:alarm_time, :alarm_type, :alarm_type_code, :alarm_type_name, :alarm_part, "
                  ":device_code, :device_name, :alarm_medium, :alarm_value, :preset, :area, :distance, "
                  ":ir_image_url, :ir_video_url, :vi_image_url, :vi_video_url, :handle_status)");
    query.bindValue(":alarm_time", entry.alarm_time);
    query.bindValue(":alarm_type", entry.alarm_type);
    query.bindValue(":alarm_type_code", entry.alarm_type_code);
    query.bindValue(":alarm_type_name", entry.alarm_type_name);
    query.bindValue(":alarm_part", entry.alarm_part);
    query.bindValue(":device_code", entry.device_code);
    query.bindValue(":device_name", entry.device_name);
    query.bindValue(":alarm_medium", entry.alarm_medium);
    query.bindValue(":alarm_value", entry.alarm_value);
    query.bindValue(":preset", entry.preset);
    query.bindValue(":area", entry.area);
    query.bindValue(":distance", entry.distance);
    query.bindValue(":ir_image_url", entry.ir_image_url);
    query.bindValue(":ir_video_url", entry.ir_video_url);
    query.bindValue(":vi_image_url", entry.vi_image_url);
    query.bindValue(":vi_video_url", entry.vi_video_url);
    query.bindValue(":handle_status", entry.handle_status);

    if (!query.exec()) {
        qWarning() << "Failed to insert log:" << query.lastError().text();
        qWarning() << "Error details - alarm_type:" << entry.alarm_type 
                   << " device_code:" << entry.device_code 
                   << " alarm_value:" << entry.alarm_value
                   << " ir_image_url length:" << entry.ir_image_url.length()
                   << " vi_image_url length:" << entry.vi_image_url.length();
    } else {
        qDebug() << "successed insert log";
        emit logAdded();
    }
}

void AlarmLog::addLog(ALARM_T alarmType, const QString& alarmTypeCode,
                      const QString& alarmTypeName, const QString& alarmPart,
                      const QString& deviceCode, const QString& deviceName,
                      const QString& alarmMedium, const QString& alarmValue,
                      const QString& preset, const QString& area, const QString& distance,
                      const QString& irImageUrl, const QString& irVideoUrl,
                      const QString& viImageUrl, const QString& viVideoUrl,
                      int handleStatus)
{
    HwAlarmLogEntry entry;
    entry.alarm_time = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    entry.alarm_type = alarmType;
    entry.alarm_type_code = alarmTypeCode;
    entry.alarm_type_name = alarmTypeName;
    entry.alarm_part = alarmPart;
    entry.device_code = deviceCode;
    entry.device_name = deviceName;
    entry.alarm_medium = alarmMedium;
    entry.alarm_value = alarmValue;
    entry.preset = preset;
    entry.area = area;
    entry.distance = distance;
    entry.ir_image_url = irImageUrl;
    entry.ir_video_url = irVideoUrl;
    entry.vi_image_url = viImageUrl;
    entry.vi_video_url = viVideoUrl;
    entry.handle_status = handleStatus;

    addLog(entry);
}

QVariantMap AlarmLog::queryLogs(int type, int status,
                                const QString& devSn,
                                const QString& start,
                                const QString& end,
                                int page,
                                int pageSize)
{
    QVariantMap resultMap;
    QVariantList logsList;
    QSqlQuery query;

    qDebug() << "type:" << type << "devSn:" << devSn << "start:" << start << "end:" << end << "page:" << page;

    if (devSn.isEmpty() || start.isEmpty() || end.isEmpty()) {
        qWarning() << "devSn or start or end is null";
        return resultMap;
    }


    int alarm_type = -1;

    switch (type) {
    case 0: // 全部
        alarm_type = -1;
        break;
    case 1: // 移动侦测报警
    case 2: // 遮挡报警
    case 3: // 气体泄漏报警
    case 4: // 设备故障报警
        alarm_type = type - 1;
        break;
    default:
        return resultMap;
    }

    int alarm_status = -1;
    switch (status) {
    case 1: // 未处理
    case 2: // 已处理
        alarm_status = status - 1;
        break;
    default:
        break;
    }

    // 动态构建 WHERE 条件
    QStringList conditions;
    conditions << "device_code = :devsn";
    if (alarm_type >= 0) conditions << "alarm_type = :type";
    if (alarm_status >= 0) conditions << "handle_status = :status";
    conditions << "alarm_time >= :start";
    conditions << "alarm_time <= :end";

    QString whereClause = conditions.isEmpty() ? "" : " WHERE " + conditions.join(" AND ");

    // ------- 1. 查询总数 -------
    QString countSql = "SELECT COUNT(*) FROM HwAlarmLog" + whereClause;
    query.prepare(countSql);

    query.bindValue(":devsn", devSn);
    if (alarm_type >= 0) query.bindValue(":type", alarm_type);
    if (alarm_status >= 0) query.bindValue(":status", alarm_status);
    query.bindValue(":start", start);
    query.bindValue(":end", end);

    int totalCount = 0;
    if (query.exec() && query.next())
        totalCount = query.value(0).toInt();
    else
        qWarning() << "Failed to query count:" << query.lastError().text();

    // ------- 2. 查询分页数据 -------
    QString dataSql = "SELECT * FROM HwAlarmLog" + whereClause +
                      " ORDER BY alarm_time DESC LIMIT :limit OFFSET :offset";
    query.prepare(dataSql);

    query.bindValue(":devsn", devSn);
    if (alarm_type >= 0) query.bindValue(":type", alarm_type);
    if (alarm_status >= 0) query.bindValue(":status", alarm_status);
    query.bindValue(":start", start);
    query.bindValue(":end", end);
    query.bindValue(":limit", pageSize);
    query.bindValue(":offset", page * pageSize);

    if (!query.exec()) {
        qWarning() << "Failed to query logs:" << query.lastError().text();
    } else {
        while (query.next()) {
            HwAlarmLogEntry entry = fromQuery(query);
            QVariantMap map;
            map["id"] = entry.id;
            map["alarm_time"] = entry.alarm_time;
            map["alarm_type"] = entry.alarm_type;
            map["alarm_type_code"] = entry.alarm_type_code;
            map["alarm_type_name"] = entry.alarm_type_name;
            map["alarm_part"] = entry.alarm_part;
            map["device_code"] = entry.device_code;
            map["device_name"] = entry.device_name;
            map["alarm_medium"] = entry.alarm_medium;
            map["alarm_value"] = entry.alarm_value;
            map["preset"] = entry.preset;
            map["area"] = entry.area;
            map["distance"] = entry.distance;
            map["ir_image_url"] = entry.ir_image_url;
            map["ir_video_url"] = entry.ir_video_url;
            map["vi_image_url"] = entry.vi_image_url;
            map["vi_video_url"] = entry.vi_video_url;
            map["handle_status"] = entry.handle_status;

            // qDebug() << "Query Result Entry:"
            //          << "ID:" << entry.id
            //          << "Time:" << entry.alarm_time
            //          << "Type:" << entry.alarm_type
            //          << "Code:" << entry.alarm_type_code
            //          << "Part:" << entry.alarm_part
            //          << "Device:" << entry.device_code
            //          << "Handled:" << entry.handle_status;

            logsList.append(map);
        }
    }

    // ------- 3. 返回结构 -------
    qDebug() << "Total matched logs:" << totalCount;
    qDebug() << "Returned logs in this page:" << logsList.size();

    resultMap["total"] = totalCount;
    resultMap["page"] = page;
    resultMap["logs"] = logsList;
    return resultMap;
}

HwAlarmLogEntry AlarmLog::fromQuery(const QSqlQuery& query)
{
    HwAlarmLogEntry entry;
    entry.id = query.value("id").toInt();
    entry.alarm_time = query.value("alarm_time").toString();
    entry.alarm_type = (ALARM_T)query.value("alarm_type").toInt();
    entry.alarm_type_code = query.value("alarm_type_code").toString();
    entry.alarm_type_name = query.value("alarm_type_name").toString();
    entry.alarm_part = query.value("alarm_part").toString();
    entry.device_code = query.value("device_code").toString();
    entry.device_name = query.value("device_name").toString();
    entry.alarm_medium = query.value("alarm_medium").toString();
    entry.alarm_value = query.value("alarm_value").toString();
    entry.preset = query.value("preset").toString();
    entry.area = query.value("area").toString();
    entry.distance = query.value("distance").toString();
    entry.ir_image_url = query.value("ir_image_url").toString();
    entry.ir_video_url = query.value("ir_video_url").toString();
    entry.vi_image_url = query.value("vi_image_url").toString();
    entry.vi_video_url = query.value("vi_video_url").toString();
    entry.handle_status = query.value("handle_status").toInt();
    return entry;
}

bool AlarmLog::deleteLog(int id)
{
    QSqlQuery query;
    query.prepare("DELETE FROM HwAlarmLog WHERE id = :id");
    query.bindValue(":id", id);
    if (!query.exec()) {
        qWarning() << "Failed to delete log:" << query.lastError().text();
        return false;
    }
    return true;
}

bool AlarmLog::deleteAll()
{
    QSqlQuery query;
    if (!query.exec("DELETE FROM HwAlarmLog")) {
        qWarning() << "Failed to delete all logs:" << query.lastError().text();
        return false;
    }
    return true;
}

bool AlarmLog::alarmHandle(int id)
{
    QSqlQuery query(m_db);
    query.prepare("UPDATE HwAlarmLog SET handle_status = :status WHERE id = :id");
    query.bindValue(":status", 1);
    query.bindValue(":id", id);

    if (!query.exec()) {
        qWarning() << "Failed to update handle_status:" << query.lastError().text();
        return false;
    }

    if (query.numRowsAffected() == 0) {
        qWarning() << "No row updated for id:" << id;
        return false;
    }

    qDebug() << "Handle status updated for id:" << id;
    return true;
}

bool AlarmLog::exportLogsToCsv(int type, int status,
                               const QString& devSn,
                               const QString& start,
                               const QString& end)
{
    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMddHHmmss");
    QString fileName = QString("%1_%2.csv").arg(devSn.isEmpty() ? "export" : devSn).arg(timestamp);

    // 保存到桌面目录
    QString dir = QStandardPaths::writableLocation(QStandardPaths::DesktopLocation);
    QString filePath = dir + "/" + fileName;

    qDebug() << "export filePath:" << filePath;

    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qWarning() << "Cannot open file for writing:" << file.errorString();
        return false;
    }

    QTextStream out(&file);
    out.setCodec("UTF-8");
    out << QChar(0xFEFF);  // 写入 UTF-8 BOM 以防止 Excel 乱码

    // 写入表头
    auto csvSafe = [](const QString& val) -> QString {
        QString safeVal = val;
        return "\"" + safeVal.replace("\"", "\"\"") + "\"";
    };

    out << csvSafe("ID") << "," << csvSafe("报警时间") << "," << csvSafe("报警类型") << ","
        << csvSafe("异常类型编号") << "," << csvSafe("异常类型") << "," << csvSafe("异常部件") << ","
        << csvSafe("设备编号") << "," << csvSafe("设备名称") << "," << csvSafe("报警介质") << ","
        << csvSafe("报警值") << "," << csvSafe("预置位") << "," << csvSafe("测量距离") << "," << csvSafe("检测区域") << ","
        << csvSafe("红外图片") << "," << csvSafe("红外视频") << "," << csvSafe("可见光图片") << ","
        << csvSafe("可见光视频") << "," << csvSafe("处理状态") << "\n";

    QVariantMap result = queryLogs(type, status, devSn, start, end, 0, 100000);
    if (result["logs"].isNull()) return false;

    QVariantList logs = result["logs"].toList();
    if (logs.length() == 0) return false;

    for (const QVariant& logVar : logs) {
        QVariantMap log = logVar.toMap();
        QString alarm_t = "";
        int at = log["alarm_type"].toInt();
        switch (at) {
        case 0:
            alarm_t = csvSafe("移动侦测报警");
            break;
        case 1:
            alarm_t = csvSafe("遮挡报警");
            break;
        case 2:
            alarm_t = csvSafe("气体泄漏报警");
            break;
        case 3:
            alarm_t = csvSafe("设备故障报警");
            break;
        default:
            continue;
        }
        out << log["id"].toString() << ","
            << log["alarm_time"].toString() << ","
            << alarm_t << ","
            << log["alarm_type_code"].toString() << ","
            << log["alarm_type_name"].toString() << ","
            << log["alarm_part"].toString() << ","
            << log["device_code"].toString() << ","
            << log["device_name"].toString() << ","
            << log["alarm_medium"].toString() << ","
            << log["alarm_value"].toString() << ","
            << log["preset"].toString() << ","
            << log["distance"].toString() << ","
            << log["area"].toString() << ","
            << log["ir_image_url"].toString() << ","
            << log["ir_video_url"].toString() << ","
            << log["vi_image_url"].toString() << ","
            << log["vi_video_url"].toString() << ","
            << (log["handle_status"].toInt() == 1 ? csvSafe("已处理") : csvSafe("未处理"))
            << "\n";
    }

    file.close();
    return true;
}

// 报警处理记录相关
void AlarmLog::addAction(const HwAlarmActionEntry& entry)
{
    QSqlQuery query(m_db);
    query.prepare("INSERT INTO HwAlarmActions (alarm_log_id, handler, handle_time, handle_result) "
                  "VALUES (:alarm_log_id, :handler, :handle_time, :handle_result)");
    query.bindValue(":alarm_log_id", entry.alarm_log_id);
    query.bindValue(":handler", entry.handler);
    query.bindValue(":handle_time", entry.handle_time);
    query.bindValue(":handle_result", entry.handle_result);

    if (!query.exec()) {
        qWarning() << "Failed to insert alarm action:" << query.lastError().text();
    } else {
        emit actionAdded();
    }
}

void AlarmLog::addAction(int alarmLogId, const QString& handler, const QString& handleTime, const QString& handleResult)
{
    // 更新报警记录处理状态
    alarmHandle(alarmLogId);

    // 记录处理信息
    HwAlarmActionEntry entry;
    entry.alarm_log_id = alarmLogId;
    entry.handler = handler;
    entry.handle_time = handleTime;
    entry.handle_result = handleResult;
    addAction(entry);
}

QVariantList AlarmLog::queryActionsByAlarmId(int alarmLogId)
{
    QVariantList list;
    QSqlQuery query(m_db);
    query.prepare("SELECT id, alarm_log_id, handler, handle_time, handle_result FROM HwAlarmActions WHERE alarm_log_id = :alarm_log_id ORDER BY handle_time DESC");
    query.bindValue(":alarm_log_id", alarmLogId);

    if (!query.exec()) {
        qWarning() << "Failed to query alarm actions:" << query.lastError().text();
        return list;
    }

    while (query.next()) {
        QVariantMap map;
        map["id"] = query.value("id").toInt();
        map["alarm_log_id"] = query.value("alarm_log_id").toInt();
        map["handler"] = query.value("handler").toString();
        map["handle_time"] = query.value("handle_time").toString();
        map["handle_result"] = query.value("handle_result").toString();
        list.append(map);
    }

    return list;
}

bool AlarmLog::deleteAction(int id)
{
    QSqlQuery query;
    query.prepare("DELETE FROM HwAlarmActions WHERE id = :id");
    query.bindValue(":id", id);
    if (!query.exec()) {
        qWarning() << "Failed to delete log:" << query.lastError().text();
        return false;
    }
    return true;
}

bool AlarmLog::deleteAllActions()
{
    QSqlQuery query;
    if (!query.exec("DELETE FROM HwAlarmActions")) {
        qWarning() << "Failed to delete all logs:" << query.lastError().text();
        return false;
    }
    return true;
}
