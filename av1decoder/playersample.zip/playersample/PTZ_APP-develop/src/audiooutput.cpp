#include "audiooutput.h"
#include <QDebug>

audioOutput::audioOutput(QObject *parent) : QObject(parent), output(nullptr), device(nullptr)
{
    format.setSampleRate(48000);
    format.setSampleSize(16);
    format.setChannelCount(2);
    format.setCodec("audio/pcm");
    format.setByteOrder(QAudioFormat::LittleEndian);
    format.setSampleType(QAudioFormat::SignedInt);
}

audioOutput::~audioOutput()
{
    stop();
}

void audioOutput::setAudioFormat(QString codec,int sampleRate,int sampleSize,int channelCount,
                    QAudioFormat::SampleType sampleType,QAudioFormat::Endian byteOrder)
{
    format.setCodec(codec);
    format.setSampleRate(sampleRate);
    format.setSampleSize(sampleSize);
    format.setSampleType(sampleType);
    format.setChannelCount(channelCount);
    format.setByteOrder(byteOrder);
}

void audioOutput::start()
{
    if(output) {
        stop();
    }
    output = new QAudioOutput(format, this);
    device = output->start();
}

void audioOutput::stop()
{
    if (output) {
        output->stop();
        delete output;
        output = nullptr;
        device = nullptr;
    }
}

void audioOutput::suspend()
{
    if(output) output->suspend();
}

void audioOutput::resume()
{
    if(output) output->resume();
}

void audioOutput::playRawAudio(const QByteArray &data){
    if (device) {
        device->write(data.data(),data.length());
    }
}

void audioOutput::setVolume(qreal volume)
{
    if(output) output->setVolume(volume);
}

double audioOutput::getBufferStatus() const
{
    if (!output) return 0.0;
    
    qint64 bufferSize = output->bufferSize();
    if (bufferSize == 0) return 0.0;
    
    qint64 bytesFree = output->bytesFree();
    qint64 bytesUsed = bufferSize - bytesFree;
    
    return (double)bytesUsed / bufferSize;
}

double audioOutput::getLatency() const
{
    if(!output) return 0;
    int bytes_in_buffer = output->bufferSize() - output->bytesFree();
    double latency_sec = (double)bytes_in_buffer / (format.sampleRate() * format.channelCount() * (format.sampleSize() / 8));
    return latency_sec;
}
