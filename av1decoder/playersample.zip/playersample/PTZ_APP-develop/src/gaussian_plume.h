/**
 * @file gaussian_plume.h
 * @brief 高斯烟羽模型 (Gaussian Plume Model)
 * 用于计算和可视化大气污染物扩散
 */

#ifndef GAUSSIAN_PLUME_H
#define GAUSSIAN_PLUME_H

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

// // 导出宏定义
// #ifdef GAUSSIANPLUME_EXPORTS
// #define GAUSSIANPLUME_API __declspec(dllexport)
// #else
// #define GAUSSIANPLUME_API __declspec(dllimport)
// #endif

#include <tuple>
#include <string>
#include <vector>

namespace GaussianPlumeModel
{

    /**
     * @class GaussianPlume
     * @brief 高斯烟羽模型类
     */
    class GaussianPlume
    {
    public:
        /**
         * @brief 构造函数
         * @param source_strength 源强 (g/s 或 kg/s)
         * @param wind_speed 平均风速 (m/s)
         * @param stack_height 烟囱高度 (m)
         * @param effective_height 有效烟囱高度 (m)，如果<=0则等于stack_height
         */
        GaussianPlume(float source_strength = 1.0,
                      float wind_speed = 2.0,
                      float stack_height = 50.0,
                      float effective_height = -1.0);

        /**
         * @brief 计算指定位置的污染物浓度
         * @param x 下风向距离 (m)
         * @param y 横风向距离 (m)
         * @param z 垂直高度 (m)
         * @param stability_class 大气稳定性类别 (A-F)
         * @return 浓度值 (g/m³ 或 kg/m³)
         */
        float concentration(float x, float y = 0.0, float z = 0.0,
                            const std::string &stability_class = "D") const;

        /**
         * @brief 计算二维浓度场
         * @param x_range x方向范围 (x_min, x_max)
         * @param y_range y方向范围 (y_min, y_max)
         * @param z 垂直高度 (m)
         * @param nx x方向网格点数
         * @param ny y方向网格点数
         * @param stability_class 大气稳定性类别
         * @return tuple<X网格, Y网格, 浓度场>，其中每个网格是二维向量
         */
        std::tuple<std::vector<std::vector<float>>, std::vector<std::vector<float>>, std::vector<std::vector<float>>> concentrationField(
            const std::pair<float, float> &x_range,
            const std::pair<float, float> &y_range,
            float z = 0.0,
            int nx = 100,
            int ny = 100,
            const std::string &stability_class = "D") const;

        /**
         * @brief 计算地面浓度（z=0）
         */
        float groundLevelConcentration(float x, float y = 0.0,
                                       const std::string &stability_class = "D") const;

        /**
         * @brief 计算中心线浓度（y=0）
         */
        float centerlineConcentration(float x, float z = 0.0,
                                      const std::string &stability_class = "D") const;

        /**
         * @brief 计算最大地面浓度及其对应的下风向距离
         * @return pair<最大浓度距离, 最大浓度值>
         */
        std::pair<float, float> maxGroundConcentrationDistance(
            const std::string &stability_class = "D",
            float x_max = 5000.0) const;

    private:
        float Q_;  // 源强
        float u_;  // 风速
        float H_;  // 有效高度
        float hs_; // 烟囱高度

        /**
         * @brief 根据Pasquill-Gifford稳定性分类计算扩散参数
         * @return pair<sigma_y, sigma_z>
         */
        std::pair<float, float> pasquillGiffordSigma(
            float distance,
            const std::string &stability_class = "D") const;
    };

} // namespace GaussianPlumeModel

#endif // GAUSSIAN_PLUME_H