#include "frame_provider.h"
#include <QImage>
#include <QPainter>
#include <QDateTime>
#include <QRandomGenerator>
#include <QVideoFrame>
#include <QDebug>
#include <QVideoWidget>
#include <QFile>
#include <QStandardPaths>
#include <QDir>
#include <QMutexLocker>
#include <QUrl>

#include <QVideoSurfaceFormat>
#include <QAbstractVideoSurface>



FrameProvider::FrameProvider(QObject* parent) : nosignal_count_(6){
    nosignal_timer_.setInterval(1000);
    connect(&nosignal_timer_, &QTimer::timeout, this, &FrameProvider::OnNoSignalTimeout);
}

FrameProvider::~FrameProvider(){
    // Properly stop and clear all video surfaces
    for(const auto &surface : m_surfaces) {
        if(surface && surface->isActive()) {
            surface->stop();
        }
    }
    m_surfaces.clear();
}

QAbstractVideoSurface* FrameProvider::videoSurface() const{
    // Return first active surface or nullptr
    for(const auto &surface : m_surfaces) {
        if(surface && surface->isActive()) {
            return surface.data();
        }
    }
    return nullptr;
}

void FrameProvider::setVideoSurface(QAbstractVideoSurface* surface){
    if(surface && !m_surfaces.contains(QPointer<QAbstractVideoSurface>(surface))) {
        m_surfaces.append(QPointer<QAbstractVideoSurface>(surface));
        if(m_format.isValid()){
            QVideoSurfaceFormat fmt = surface->nearestFormat(m_format);
            surface->start(fmt);
        }
    }
}

void FrameProvider::removeVideoSurface(QAbstractVideoSurface *surface)
{
    if(surface){
        if(surface->isActive()){
            surface->stop();
        }
        // Remove all instances of this surface from our list
        QPointer<QAbstractVideoSurface> pointer(surface);
        m_surfaces.removeAll(pointer);
    }
}

void FrameProvider::setFormat(int width, int heigth, QVideoFrame::PixelFormat format){
    //qDebug() << "FrameProvider: setFormat called with" << width << "x" << heigth << "format:" << format;
    
    QSize size(width, heigth);
    QVideoSurfaceFormat vsformat(size, format);
    
    //qDebug() << "FrameProvider: Created format:" << vsformat.frameSize() << "pixelFormat:" << vsformat.pixelFormat();
    //qDebug() << "FrameProvider: Format valid:" << vsformat.isValid();
    
    m_format = vsformat;

    // Negotiate and start each surface with new format
    auto it = m_surfaces.begin();
    while (it != m_surfaces.end()) {
        QPointer<QAbstractVideoSurface> surface = *it;
        // QPointer automatically becomes null when object is destroyed
        if (!surface) {
            // Remove null pointer from list
            it = m_surfaces.erase(it);
            continue;
        }
        
        if(surface->isActive()) {
            //qDebug() << "FrameProvider: Stopping active surface";
            surface->stop();
        }
        QVideoSurfaceFormat fmt = surface->nearestFormat(m_format);
        //qDebug() << "FrameProvider: Nearest format:" << fmt.frameSize() << "pixelFormat:" << fmt.pixelFormat();
        //qDebug() << "FrameProvider: Nearest format valid:" << fmt.isValid();
        bool started = surface->start(fmt);
        //qDebug() << "FrameProvider: Surface start result:" << started;
        ++it;
    }
}

void FrameProvider::onNewVideoContentReceived(const QVideoFrame& frame){
    // qDebug() << "FrameProvider::onNewVideoContentReceived called with frame:" 
    //          << "width=" << frame.width() 
    //          << "height=" << frame.height() 
    //          << "valid=" << frame.isValid()
    //          << "surfaces count=" << m_surfaces.size();
    
    if (!frame.isValid()) {
        qWarning() << "FrameProvider: Received invalid frame";
        return;
    }
    
    
    {
        QMutexLocker locker(&m_frameMutex);
        m_currentFrame = frame; //因为m_currentFrame 持有了其内部的真正的videobuffer的引用，只要m_currentFrame 
                            //还存在，其内部的videobuffer就还存在，所以这里不需要copy，QVideoFrame通过引用计数管理其内部的
                            //videobuffer
    }
    
    // Update format if needed
    if(m_format.frameWidth() != frame.width() || m_format.frameHeight() != frame.height() || m_format.pixelFormat() != frame.pixelFormat()){
        qDebug() << "FrameProvider: Updating format from" << m_format.frameWidth() << "x" << m_format.frameHeight() 
                 << "to" << frame.width() << "x" << frame.height();
        setFormat(frame.width(), frame.height(), frame.pixelFormat());
    }

    // Present frame to all active surfaces
    int activeSurfaces = 0;
    int presentedFrames = 0;
    
    // Use an iterator to safely remove invalid surfaces during iteration
    auto it = m_surfaces.begin();
    while (it != m_surfaces.end()) {
        QPointer<QAbstractVideoSurface> surface = *it;
        // Check if surface is still valid (QPointer automatically becomes null when object is destroyed)
        if (!surface) {
            // Remove invalid surface and continue to next
            it = m_surfaces.erase(it);
            continue;
        }
        
        activeSurfaces++;
        // 如果表面不活跃，尝试重新激活
        if(!surface->isActive()) {
            qDebug() << "FrameProvider: Reactivating inactive surface";
            if(m_format.isValid()) {
                QVideoSurfaceFormat fmt = surface->nearestFormat(m_format);
                bool started = surface->start(fmt);
                qDebug() << "FrameProvider: Surface start result:" << started;
            }
        }
        
        // 现在尝试显示帧
        if(surface->isActive()) {
            bool presented = surface->present(frame);
            if (presented) {
                presentedFrames++;
            }
        } else {
            qWarning() << "FrameProvider: Surface is not active, cannot present frame";
        }
        
        ++it;
    }
}

QString FrameProvider::captureCurrentFrame(const QString& fileName) {
    QMutexLocker locker(&m_frameMutex);
    
    if (!m_currentFrame.isValid()) {
        qWarning() << "FrameProvider: No current frame available to capture";
        return QString();
    }
    
    qDebug() << "FrameProvider: Capturing frame on demand, frame size:" << m_currentFrame.width() << "x" << m_currentFrame.height();
    
    // 按需转换当前帧为QImage（只在需要时才转换，节省资源）
    QImage currentImage = videoFrameToImage(m_currentFrame);
    if (currentImage.isNull()) {
        qWarning() << "FrameProvider: Failed to convert frame to image";
        return QString();
    }
    
    qDebug() << "FrameProvider: Frame converted to image, size:" << currentImage.size();
    
    // 生成文件名
    QString finalFileName = fileName;
    if (finalFileName.isEmpty()) {
        QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss_zzz");
        finalFileName = QString("frame_%1.jpg").arg(timestamp);
    }
    
    // 创建保存目录 - 使用应用程序当前目录下的子目录
    QString dataDir = "captured_frames";
    
    QDir dir;
    if (!dir.exists(dataDir)) {
        if (!dir.mkpath(dataDir)) {
            qWarning() << "FrameProvider: Failed to create directory:" << dataDir;
            return QString();
        }
        qDebug() << "FrameProvider: Created directory:" << dataDir;
    }
    
    QString fullPath = QDir(dataDir).absoluteFilePath(finalFileName);
    QString absolutePath = QDir::current().absoluteFilePath(fullPath);
    qDebug() << "FrameProvider: Attempting to save frame to:" << absolutePath;
    
    // 保存图片，使用较高质量
    if (currentImage.save(absolutePath, "JPG", 95)) {
        qDebug() << "FrameProvider: Frame captured successfully:" << absolutePath;
        
        // 验证文件是否确实保存成功
        QFileInfo fileInfo(absolutePath);
        if (fileInfo.exists() && fileInfo.size() > 0) {
            qDebug() << "FrameProvider: File verified, size:" << fileInfo.size() << "bytes";
            
            // 返回file://URL格式，供QML使用
            QString fileUrl = QUrl::fromLocalFile(absolutePath).toString();
            qDebug() << "FrameProvider: Returning URL:" << fileUrl;
            return fileUrl;
        } else {
            qWarning() << "FrameProvider: File not found or empty after save";
            return QString();
        }
    } else {
        qWarning() << "FrameProvider: Failed to save frame to:" << absolutePath;
        return QString();
    }
}

QImage FrameProvider::getCurrentFrameAsImage() const {
    QMutexLocker locker(&m_frameMutex);
    
    if (!m_currentFrame.isValid()) {
        qWarning() << "FrameProvider: No current frame available";
        return QImage();
    }
    
    // 按需转换（只在调用时转换）
    return videoFrameToImage(m_currentFrame);
}

QImage FrameProvider::videoFrameToImage(const QVideoFrame& frame) const {
    if (!frame.isValid()) {
        return QImage();
    }
    
    QVideoFrame cloneFrame(frame);
    if (!cloneFrame.map(QAbstractVideoBuffer::ReadOnly)) {
        qWarning() << "Failed to map video frame";
        return QImage();
    }
    
    QImage image;
    
    // 根据不同的像素格式进行转换
    switch (cloneFrame.pixelFormat()) {
        case QVideoFrame::Format_YUV420P: {
            // YUV420P 转换为 RGB
            int width = cloneFrame.width();
            int height = cloneFrame.height();
            
            const uchar* yData = cloneFrame.bits(0);
            const uchar* uData = cloneFrame.bits(1);  
            const uchar* vData = cloneFrame.bits(2);
            
            if (!yData || !uData || !vData) {
                qWarning() << "Invalid YUV420P data pointers";
                break;
            }
            
            int yStride = cloneFrame.bytesPerLine(0);
            int uStride = cloneFrame.bytesPerLine(1);
            int vStride = cloneFrame.bytesPerLine(2);
            
            image = QImage(width, height, QImage::Format_RGB888);
            uchar* rgbData = image.bits();
            int rgbStride = image.bytesPerLine();
            
            // 优化的YUV到RGB转换
            for (int y = 0; y < height; ++y) {
                for (int x = 0; x < width; ++x) {
                    int yIndex = y * yStride + x;
                    int uvIndex = (y / 2) * uStride + (x / 2);
                    
                    int Y = yData[yIndex];
                    int U = uData[uvIndex] - 128;
                    int V = vData[uvIndex] - 128;
                    
                    // 改进的YUV到RGB转换公式
                    int R = qBound(0, Y + ((1436 * V) >> 10), 255);
                    int G = qBound(0, Y - ((354 * U + 732 * V) >> 10), 255);
                    int B = qBound(0, Y + ((1814 * U) >> 10), 255);
                    
                    int rgbIndex = y * rgbStride + x * 3;
                    rgbData[rgbIndex] = R;
                    rgbData[rgbIndex + 1] = G;
                    rgbData[rgbIndex + 2] = B;
                }
            }
            break;
        }
        case QVideoFrame::Format_RGB32:
        case QVideoFrame::Format_ARGB32: {
            image = QImage(cloneFrame.bits(), cloneFrame.width(), cloneFrame.height(), 
                          cloneFrame.bytesPerLine(), QImage::Format_RGB32);
            break;
        }
        case QVideoFrame::Format_RGB24: {
            image = QImage(cloneFrame.bits(), cloneFrame.width(), cloneFrame.height(), 
                          cloneFrame.bytesPerLine(), QImage::Format_RGB888);
            break;
        }
        default: {
            qWarning() << "Unsupported pixel format for frame conversion:" << cloneFrame.pixelFormat();
            // 尝试使用Qt的转换
            image = QImage(cloneFrame.bits(), cloneFrame.width(), cloneFrame.height(), 
                          cloneFrame.bytesPerLine(), QImage::Format_RGB888);
            break;
        }
    }
    
    cloneFrame.unmap();
    return image;
}

Q_INVOKABLE bool FrameProvider::mbIsNoSignal(){
    return nosignal_count_ == 0 ? true : false;
}

void FrameProvider::OnNoSignalTimeout(){
    nosignal_count_ > 0 ? nosignal_count_-- : nosignal_count_ = 0;
}

void FrameProvider::clearFrameData()
{
    qDebug() << "FrameProvider::clearFrameData called";
    
    // 清理当前帧数据
    {
        QMutexLocker locker(&m_frameMutex);
        m_currentFrame = QVideoFrame(); // 重置为空帧
    }
    
    // 停止所有视频表面
    for (auto it = m_surfaces.begin(); it != m_surfaces.end(); ++it) {
        QPointer<QAbstractVideoSurface> surface = *it;
        if (surface && surface->isActive()) {
            qDebug() << "FrameProvider: Stopping video surface";
            surface->stop();
        }
    }
    
    // 重置格式
    m_format = QVideoSurfaceFormat();
    
    // 重置无信号相关状态
    nosignal_count_ = 0;
    if (nosignal_timer_.isActive()) {
        nosignal_timer_.stop();
    }
    
    // 清理缓存图像
    first_buf_img_ = QImage();
    second_buf_img_ = QImage();
    
    qDebug() << "FrameProvider: Frame data cleared successfully";
}

void FrameProvider::disconnectAll()
{
    qDebug() << "FrameProvider::disconnectAll called";
    
    // 断开这个对象的所有信号和槽连接
    disconnect(this, nullptr, nullptr, nullptr);
    
    // 断开所有连接到这个对象的信号
    QObject::disconnect(nullptr, nullptr, this, nullptr);
    
    qDebug() << "FrameProvider: All connections disconnected";
}