#include "ptz_device_cgi.h"
//#include "libwhitecamera.h"
#include <QVariantMap>
#include <QJsonObject>
#include <QJsonDocument>
#include <thread>
#include <QList>
#include <QFileInfo>
#include <QThread>
#include <QDateTime>
#include <QTimer>
#include <cmath>
#include <curl/curl.h>
#include <tinyxml2.h>
#include "src/model/alarmmodel.h"
#include "src/thermal_device_manager.h"

// For TdlasWorker
#include <iostream>
#include <string>
#include <vector>
#include <chrono>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <winsock2.h>
#include <ws2tcpip.h>

#include "whitecamera.hpp"
#include "src/model/alarmmodel.h"
#include "src/frame_provider.h"
#include "src/alarm_audio_player.h"
#include "src/tdlas_data_manager.h"
#include "src/alarmrecordingmanager.h"
using namespace std;

// CURL写回调函数已在whitecamera.hpp中定义，这里不再重复定义





//fix me !! use DataModel fix me 
#define PRESET_GROUP_COUNT 4
#define PRESET_LINE_COUNT 4
// 移除宏定义，改为从设备配置中获取
// #define ALARM_TDLAS 300
#define MAX_ALARM_TDLAS 50000
#define TDLAS_INTERVAL 1000
PtzDeviceCgi::PtzDeviceCgi(QObject* parent)
: QObject(parent)
, turn_speed_(5)
, presetIdx(0)
, m_visibleLightProvider(nullptr)
, m_infraredProvider(nullptr)
, m_tdlasWorker(nullptr)
, m_tdlasThread(nullptr)
, m_modbusWorker(nullptr)
, m_modbusThread(nullptr)
, m_tofWorker(nullptr)
, m_tofThread(nullptr)
, device_id_("")
, m_gasConcentrationAlarm(false)
, m_currentTofDistance(0.0f)
{

    // 连接所有信号和槽，确保异步执行
    connect(this, &PtzDeviceCgi::mvKeepAliveRequested,
            this, &PtzDeviceCgi::doMvKeepAlive,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvModifyImageSettingsRequested,
            this, &PtzDeviceCgi::doMvModifyImageSettings,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvModifyVideoSettingsRequested,
            this, &PtzDeviceCgi::doMvModifyVideoSettings,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvModifyAudioSettingsRequested,
            this, &PtzDeviceCgi::doMvModifyAudioSettings,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvModifyLocalNetworkPropertyRequested,
            this, &PtzDeviceCgi::doMvModifyLocalNetworkProperty,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvRebootRequested,
            this, &PtzDeviceCgi::doMvReboot,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvFactoryResetRequested,
            this, &PtzDeviceCgi::doMvFactoryReset,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::ConfigMainOSDRequested,
            this, &PtzDeviceCgi::doConfigMainOSD,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvConfigOSDRequested,
            this, &PtzDeviceCgi::doMvConfigOSD,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvConfigTimeOSDRequested,
            this, &PtzDeviceCgi::doMvConfigTimeOSD,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvConfigUserOSDRequested,
            this, &PtzDeviceCgi::doMvConfigUserOSD,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvConfigMotionDetectRequested,
            this, &PtzDeviceCgi::doMvConfigMotionDetect,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvConfigEventStorageRequested,
            this, &PtzDeviceCgi::doMvConfigEventStorage,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvConfigServicePortsRequested,
            this, &PtzDeviceCgi::doMvConfigServicePorts,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetRtspPortRequested,
            this, &PtzDeviceCgi::doMvSetRtspPort,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetHttpPortRequested,
            this, &PtzDeviceCgi::doMvSetHttpPort,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvConfigScheduleStorageRequested,
            this, &PtzDeviceCgi::doMvConfigScheduleStorage,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSnapshotUploadRequested,
            this, &PtzDeviceCgi::doMvSnapshotUpload,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvInitRequested,
            this, &PtzDeviceCgi::doMvInit,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvGetVideoEncoderCapabilitiesRequested,
            this, &PtzDeviceCgi::doMvGetVideoEncoderCapabilities,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvGetAudioEncoderCapabilitiesRequested,
            this, &PtzDeviceCgi::doMvGetAudioEncoderCapabilities,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvGetMotionDetectConfigRequested,
            this, &PtzDeviceCgi::doMvGetMotionDetectConfig,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvGetEventStorageConfigRequested,
            this, &PtzDeviceCgi::doMvGetEventStorageConfig,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvGetRecordFilePathRequested,
            this, &PtzDeviceCgi::doMvGetRecordFilePath,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetLightRequested,
            this, &PtzDeviceCgi::doMvSetLight,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetWiperRequested,
            this, &PtzDeviceCgi::doMvSetWiper,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetAssiFocusRequested,
            this, &PtzDeviceCgi::doMvSetAssiFocus,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetInfFlapRequested,
            this, &PtzDeviceCgi::doMvSetInfFlap,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvTurnUpRequested,
            this, &PtzDeviceCgi::doMvTurnUp,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvTurnDownRequested,
            this, &PtzDeviceCgi::doMvTurnDown,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvTurnLeftRequested,
            this, &PtzDeviceCgi::doMvTurnLeft,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvTurnRightRequested,
            this, &PtzDeviceCgi::doMvTurnRight,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvTurnStopRequested,
            this, &PtzDeviceCgi::doMvTurnStop,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetZoomInRequested,
            this, &PtzDeviceCgi::doMvSetZoomIn,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetFocusRequested,
            this, &PtzDeviceCgi::doMvSetFocus,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetApertureRequested,
            this, &PtzDeviceCgi::doMvSetAperture,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvSetPresetRequested,
            this, &PtzDeviceCgi::doMvSetPreset,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvCallPresetRequested,
            this, &PtzDeviceCgi::doMvCallPreset,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvDeletePresetRequested,
            this, &PtzDeviceCgi::doMvDeletePreset,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvLoadNetworkConfigRequested,
            this, &PtzDeviceCgi::doMvLoadNetworkConfig,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvGetCurrentImageBrightnessRequested,
            this, &PtzDeviceCgi::doMvGetCurrentImageBrightness,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvGetCurrentInfraredBrightnessRequested,
            this, &PtzDeviceCgi::doMvGetCurrentInfraredBrightness,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvTurnOnLaserRequested,
            this, &PtzDeviceCgi::doMvTurnOnLaser,
            Qt::QueuedConnection);
    connect(this, &PtzDeviceCgi::mvTurnOffLaserRequested,
            this, &PtzDeviceCgi::doMvTurnOffLaser,
            Qt::QueuedConnection);
    
    // 气体报警相关信号连接
    // connect(this, &PtzDeviceCgi::requestStopScanForGasAlarm,
    //         this, &PtzDeviceCgi::onRequestStopScanForGasAlarm,
    //         Qt::DirectConnection);
    connect(this, &PtzDeviceCgi::requestResumeScanAfterGasAlarm,
            this, &PtzDeviceCgi::onRequestResumeScanAfterGasAlarm,
            Qt::DirectConnection);

    tdls_ip_ = "192.168.1.200";
    tdls_port_ = 2000;
    modbus_ip_ = "192.168.2.25";
    modbus_port_ = 1000;
    scanTimer = new QTimer(this);
    
    // 初始化气体报警相关成员变量
    m_previousScanMode = 0; // 初始无扫描
    m_scanPausedDueToAlarm = false;
    m_alarmDetectionTimer = new QTimer(this);
    m_alarmDetectionTimer->setSingleShot(true); // 单次触发
    connect(m_alarmDetectionTimer, &QTimer::timeout, this, &PtzDeviceCgi::onAlarmDetectionTimerExpired);


    timerwar = new QTimer(this);
    timerwar->setInterval(3000);
    connect(timerwar, &QTimer::timeout, this, &PtzDeviceCgi::mvFreshTdlasWarning);
    timerwar->start();
    
    
    timer_alive = new QTimer(this);
    timer_alive->setInterval(5000);
    connect(timer_alive, &QTimer::timeout, this, &PtzDeviceCgi::mvKeepAlive);
    timer_alive->start();

    for(int i = 0 ; i < PRESET_GROUP_COUNT; i++){
        QVector<int> vec;
        presetGroups.push_back(vec);
    }
    for(int i = 0 ; i < PRESET_LINE_COUNT; i++){
        QVector<int> vec;
        LinePresetGroups.push_back(vec);
    }

    // 连接新的内部信号和槽，确保 Worker 在 PtzDeviceCgi 的线程中创建
    connect(this, &PtzDeviceCgi::initializeTdlasWorkerInternalRequested,
            this, &PtzDeviceCgi::doInitializeTdlasWorkerInternal,
            Qt::QueuedConnection); // 关键：使用 QueuedConnection
    connect(this, &PtzDeviceCgi::initializeModbusWorkerInternalRequested,
            this, &PtzDeviceCgi::doInitializeModbusWorkerInternal,
            Qt::QueuedConnection); // 关键：使用 QueuedConnection
    connect(this, &PtzDeviceCgi::initializeTofWorkerInternalRequested,
            this, &PtzDeviceCgi::doInitializeTofWorkerInternal,
            Qt::QueuedConnection); // 关键：使用 QueuedConnection
}

PtzDeviceCgi::~PtzDeviceCgi(){
    qDebug() << "PtzDeviceCgi destructor started for device:" << QString::fromStdString(device_id_);
    
    // 先断开所有信号连接，避免在析构过程中触发信号
    disconnect();
    
    // 调用停止所有子线程的方法
    stopAllWorkerThreads();

    
    // Cleanup curl global environment
    curl_global_cleanup();
    
    qDebug() << "PtzDeviceCgi destructor completed for device:" << QString::fromStdString(device_id_);
}

Q_INVOKABLE void PtzDeviceCgi::mvInit(QString user, QString passwd, QString ip, QString deviceName, QString deviceId){
    // 只发信号，不做耗时工作
    emit mvInitRequested(user, passwd, ip, deviceName, deviceId);
}

void PtzDeviceCgi::doMvInit(QString user, QString passwd, QString ip, QString deviceName, QString deviceId){
    // 无论登录是否成功，都先设置设备信息，以便后续异常报警使用
    if (!deviceId.isEmpty()) {
        device_id_ = deviceId.toStdString();
    }
    if (!deviceName.isEmpty()) {
        deviceName_ = deviceName.toStdString();
    } else if (deviceName_.empty()) {
        deviceName_ = device_id_.empty() ? ip.toStdString() : device_id_;
    }
    
    user_ = user.toStdString();
    passwd_ = passwd.toStdString();
    ip_ = ip.toStdString();
    
    const char* login_result = Login(const_cast<char*>( user_.c_str()), const_cast<char*>(passwd_.c_str()), const_cast<char*>(ip_.c_str()));
    if (login_result != nullptr) {
        uid_ = login_result;
    } else {
        uid_.clear(); // 确保uid_是空字符串而不是未定义状态
    }
    
    // 检查登录是否成功
    if (uid_.empty()) {
        qWarning() << "PTZ device login failed for device:" << QString::fromStdString(device_id_) << "at" << ip;
        // 发送设备异常报警 - 网络异常
        addDeviceExceptionAlarm("001", "网络异常", "可见光机芯");
    }
}

void PtzDeviceCgi::setFrameProviders(FrameProvider* visibleLight, FrameProvider* infrared) {
    m_visibleLightProvider = visibleLight;
    m_infraredProvider = infrared;
    qDebug() << "Frame providers set successfully";
}

void PtzDeviceCgi::stopAllWorkerThreads() {
    qDebug() << "PtzDeviceCgi::stopAllWorkerThreads started for device:" << QString::fromStdString(device_id_);
    
    // 停止定时器
    if (scanTimer) {
        scanTimer->stop();
    }
    if (timerwar) {
        timerwar->stop();
    }
    if (timer_alive) {
        timer_alive->stop();
    }
    qDebug() << "PtzDeviceCgi::stopAllWorkerThreads 111" << QString::fromStdString(device_id_);
    // 停止TDLAS线程
    if (m_tdlasWorker) {
        m_tdlasWorker->disconnect();
        m_tdlasWorker->stop();
    }
    qDebug() << "PtzDeviceCgi::stopAllWorkerThreads 222" << QString::fromStdString(device_id_);
    if (m_tdlasThread) {
        if (m_tdlasThread->isRunning()) {
            m_tdlasThread->quit();
            if (!m_tdlasThread->wait(5000)) {
                qWarning() << "TDLAS thread failed to quit gracefully, terminating...";
                m_tdlasThread->terminate();
                m_tdlasThread->wait(1000);
            }
        }
        m_tdlasThread = nullptr;
    }
    qDebug() << "PtzDeviceCgi::stopAllWorkerThreads 333" << QString::fromStdString(device_id_);
    m_tdlasWorker = nullptr;
    
    // 停止Modbus线程
    if (m_modbusWorker) {
        m_modbusWorker->disconnect();
        m_modbusWorker->stop();
    }
    qDebug() << "PtzDeviceCgi::stopAllWorkerThreads 444" << QString::fromStdString(device_id_);
    if (m_modbusThread) {
        if (m_modbusThread->isRunning()) {
            m_modbusThread->quit();
            if (!m_modbusThread->wait(5000)) {
                qWarning() << "Modbus thread failed to quit gracefully, terminating...";
                m_modbusThread->terminate();
                qWarning() << "Modbus thread failed to quit gracefully, terminating done";
                m_modbusThread->wait(1000);
            }
        }
        m_modbusThread = nullptr;
    }
    qDebug() << "PtzDeviceCgi::stopAllWorkerThreads 555" << QString::fromStdString(device_id_);
    m_modbusWorker = nullptr;
    
    // 停止TOF线程
    if (m_tofWorker) {
        m_tofWorker->disconnect();
        m_tofWorker->stop();
    }
    qDebug() << "PtzDeviceCgi::stopAllWorkerThreads 66" << QString::fromStdString(device_id_);
    if (m_tofThread) {
        if (m_tofThread->isRunning()) {
            m_tofThread->quit();
            if (!m_tofThread->wait(5000)) {
                qWarning() << "TOF thread failed to quit gracefully, terminating...";
                m_tofThread->terminate();
                m_tofThread->wait(1000);
            }
        }
        m_tofThread = nullptr;
    }
    qDebug() << "PtzDeviceCgi::stopAllWorkerThreads 77" << QString::fromStdString(device_id_);
    m_tofWorker = nullptr;
    
    qDebug() << "PtzDeviceCgi::stopAllWorkerThreads completed for device:" << QString::fromStdString(device_id_);
}

// 修改 initializeTdlasWorker，使其只发出信号
void PtzDeviceCgi::initializeTdlasWorker(const QString& ip, int port) {
    emit initializeTdlasWorkerInternalRequested(ip, port);
}

// 实现新的 doInitializeTdlasWorkerInternal 槽函数
void PtzDeviceCgi::doInitializeTdlasWorkerInternal(const QString& ip, int port) {
    // 原始的初始化 TdlasWorker 的逻辑从这里开始
    // 如果已经存在 TdlasWorker，先清理
    if (m_tdlasWorker && m_tdlasThread) {
        m_tdlasWorker->stop();
        m_tdlasThread->quit();
        m_tdlasThread->wait(1000); // 等待线程退出
        // m_tdlasWorker 和 m_tdlasThread 会通过 deleteLater 销毁
        m_tdlasWorker = nullptr;
        m_tdlasThread = nullptr;
    }

    // 创建新的 TdlasWorker 线程，父对象设置为 PtzDeviceCgi (这个QThread的父对象可以设置为PtzDeviceCgi)
    m_tdlasThread = new QThread(this);

    // 创建新的 TdlasWorker，将父对象明确设置为 nullptr，避免跨线程创建子对象的错误
    m_tdlasWorker = new TdlasWorker(ip, port, nullptr); // <-- 关键修改: parent is nullptr

    // 将 Worker 移动到它自己的线程中
    m_tdlasWorker->moveToThread(m_tdlasThread);

    connect(m_tdlasThread, &QThread::started, m_tdlasWorker, &TdlasWorker::process);
    connect(m_tdlasWorker, &TdlasWorker::finished, m_tdlasThread, &QThread::quit);
    connect(m_tdlasWorker, &TdlasWorker::finished, m_tdlasWorker, &QObject::deleteLater);
    connect(m_tdlasThread, &QThread::finished, m_tdlasThread, &QObject::deleteLater); // 确保线程在结束时销毁

    connect(m_tdlasWorker, &TdlasWorker::concentrationUpdated, this, &PtzDeviceCgi::onConcentrationUpdated, Qt::QueuedConnection);
    connect(m_tdlasWorker, &TdlasWorker::rangingError, this, [this](QString errorMessage) {

        // 如果需要，可以在这里发出一个信号给 PtzDeviceManager 或其他上层模块
    });

    m_tdlasThread->start();
    qDebug() << "TdlasWorker initialized with IP:" << ip << "Port:" << port;
}

// 修改 initializeModbusWorker，使其只发出信号
void PtzDeviceCgi::initializeModbusWorker(const QString& ip, int port) {
    emit initializeModbusWorkerInternalRequested(ip, port);
}

// 实现新的 doInitializeModbusWorkerInternal 槽函数
void PtzDeviceCgi::doInitializeModbusWorkerInternal(const QString& ip, int intPort) {
    // 原始的初始化 ModbusWorker 的逻辑从这里开始
    if (m_modbusWorker && m_modbusThread) {
        m_modbusThread->quit();
        m_modbusThread->wait(1000);
        m_modbusWorker = nullptr;
        m_modbusThread = nullptr;
    }

    m_modbusThread = new QThread(this); // 父对象为 PtzDeviceCgi
    // 将 PtzDeviceCgi 的 this 指针作为 ptzCgiParent 传入，QObject 的父对象仍为 nullptr
    m_modbusWorker = new ModbusWorker(ip, intPort, this, nullptr); // <--- 关键修改

    m_modbusWorker->moveToThread(m_modbusThread);

    connect(m_modbusThread, &QThread::started, m_modbusWorker, &ModbusWorker::process);
    connect(m_modbusWorker, &ModbusWorker::finished, m_modbusThread, &QThread::quit);
    connect(m_modbusWorker, &ModbusWorker::finished, m_modbusWorker, &QObject::deleteLater);
    connect(m_modbusThread, &QThread::finished, m_modbusThread, &QObject::deleteLater);

    connect(m_modbusWorker, &ModbusWorker::voltageDataSent, this, [this](bool success) {
        // 这个 lambda 在 PtzDeviceCgi 的线程中执行
        if (!success) {
            qWarning() << "Modbus 电压数据发送失败。";
        }
    });

    m_modbusThread->start();
    qDebug() << "ModbusWorker initialized with IP:" << ip << "Port:" << intPort;
}

void PtzDeviceCgi::initializeModbusWorkerFromDevice(const QString& deviceId) {
    // 从DeviceModel获取Modbus配置
    QString modbusIp = DeviceModel::instance()->getModbusIp(deviceId);
    int modbusPort = DeviceModel::instance()->getDevice(deviceId).modbusPort;
    
    if (modbusIp.isEmpty()) {
        qWarning() << "Modbus IP not configured for device:" << deviceId;
        return;
    }
    
    // 使用设备配置初始化ModbusWorker
    initializeModbusWorker(modbusIp, modbusPort);
}

Q_INVOKABLE void PtzDeviceCgi::mvKeepAlive(){
    qDebug() << "PtzDeviceCgi::mvKeepAlive";
    // 只发信号，不做耗时工作
    emit mvKeepAliveRequested();
}

void PtzDeviceCgi::doMvKeepAlive(){
    bool success = KeepAlive(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()));
    
    // 如果keepalive失败，发送设备异常报警
    if (!success) {
        qWarning() << "PTZ device keepalive failed for device:" << QString::fromStdString(device_id_);
        // 发送设备异常报警 - 网络异常
        addDeviceExceptionAlarm("001", "网络异常", "可见光机芯");
    }
}



Q_INVOKABLE void
PtzDeviceCgi::mvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway,
                                           QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns,
                                           QString dns){
    // 只发信号，不做耗时工作
    emit mvModifyLocalNetworkPropertyRequested(static_ip, ip4_ip, ip4_mask, ip4_gateway, ip6_ip, ip6_prefix, ip6_gateway, pre_dns, dns);
}

void PtzDeviceCgi::doMvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway,
                                           QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns,
                                           QString dns){
    QVariantMap mp;
    mp["dhcp"] = static_ip;
    mp["ipaddr"] = ip4_ip;
    //    mp["ip4_mask"] = ip4_mask;
    mp["netmask"] = ip4_mask;
    mp["gateway"] = ip4_gateway;
    mp["dns1"] = pre_dns;
    mp["dns2"] = dns;
    //    mp["port"] = pre_dns;

    auto obj = QJsonObject::fromVariantMap(mp);
    QJsonDocument doc(obj);
    string str = doc.toJson().toStdString();

    bool success = ConfigNetWork(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()), const_cast<char*>(str.c_str()));
    
    // 发出网络配置修改结果信号
    emit networkPropertyModified(success, ip4_ip);
    
    // 如果修改成功，更新设备信息中的可见光IP
    if (success) {
        QString deviceId = QString::fromStdString(device_id_);
        DeviceInfo device = DeviceModel::instance()->getDevice(deviceId);
        if (!device.deviceId.isEmpty()) {
            device.visibleLightIp = ip4_ip;
            DeviceModel::instance()->updateDevice(device);
            qDebug() << "设备" << deviceId << "的可见光IP已更新为:" << ip4_ip;
        }
    }
}

Q_INVOKABLE void
PtzDeviceCgi::mvModifyImageSettings(int bright, int contrac, int saturation, int sharpness, int hlc, int blc, int nr2d,
                                    int nr3d, int tvsystem, int antificker){
    // 只发信号，不做耗时工作
    emit mvModifyImageSettingsRequested(bright, contrac, saturation, sharpness, hlc, blc, nr2d, nr3d, tvsystem, antificker);
}

void PtzDeviceCgi::doMvModifyImageSettings(int bright, int contrac, int saturation, int sharpness, int hlc, int blc, int nr2d,
                                    int nr3d, int tvsystem, int antificker){
    QVariantMap mp;

    mp["brightness"] = bright;
    mp["contrast"] = contrac;
    mp["saturation"] = saturation;
    mp["sharpness"] = sharpness;
    mp["hlc"] = hlc;
    mp["blc"] = blc;
    mp["nr2d"] = nr2d;
    mp["nr3d"] = nr3d;
    mp["tvsystem"] = tvsystem;
    mp["antificker"] = antificker;

    auto obj = QJsonObject::fromVariantMap(mp);
    QJsonDocument doc(obj);
    string str = doc.toJson().toStdString();

    ConfigImg(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()), const_cast<char*>(str.c_str()));
}

QVariantMap PtzDeviceCgi::mvGetImageSettings(){
    // 只发信号，不做耗时工作
    emit mvGetImageSettingsRequested();
    // 直接调用实际处理函数并返回结果
    return doMvGetImageSettings();
}

Q_INVOKABLE void PtzDeviceCgi::mvGetCurrentImageBrightness()
{
    emit mvGetCurrentImageBrightnessRequested();
}

void PtzDeviceCgi::mvGetCurrentInfraredBrightness()
{
    emit mvGetCurrentInfraredBrightnessRequested();
}

QVariantMap PtzDeviceCgi::doMvGetImageSettings(){
    QVariantMap result;
    
    // 构造获取图像参数的URL
    string url = "http://" + ip_ + "/cgi-bin/image?uid=" + uid_;
    
    CURL* curl;
    CURLcode res;
    string responseBody;

    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();
    if(!curl){
        curl_global_cleanup();
        return result;
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK){
        cerr << "CURL error: " << curl_easy_strerror(res) << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return result;
    }

    long http_code;
    curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &http_code);
    cout << "HTTP Status: " << http_code << endl;

    // 解析响应体中的XML数据
    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if(xmlErr != XML_SUCCESS){
        cerr << "Error parsing XML: " << doc.ErrorStr() << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return result;
    }

    XMLElement* rootElement = doc.RootElement();
    if(rootElement == nullptr || string(rootElement->Name()) != "image"){
        cerr << "Invalid XML format or no <image> tag found" << endl;
        curl_easy_cleanup(curl);
        curl_global_cleanup();
        return result;
    }

    // 提取图像参数
    for(const XMLAttribute* attr = rootElement->FirstAttribute(); attr != nullptr; attr = attr->Next()){
        result[QString(attr->Name())] = QString(attr->Value());
    }

    curl_easy_cleanup(curl);
    curl_global_cleanup();

    return result;
}

void PtzDeviceCgi::doMvGetCurrentImageBrightness(){
    // 获取当前图像设置
    QVariantMap imageSettings = doMvGetImageSettings();
    
    // 提取亮度值
    if (imageSettings.contains("brightness")) {
        bool ok;
        int brightness = imageSettings["brightness"].toInt(&ok);
        if (ok) {
            qDebug() << "Current visible brightness:" << brightness;
            // 保存原始亮度值
            if (m_originalVisibleBrightness == -1) {
                m_originalVisibleBrightness = brightness;
                qDebug() << "Saved original visible brightness:" << m_originalVisibleBrightness;
            }
        } else {
            qWarning() << "Failed to convert brightness to int";
        }
    } else {
        qWarning() << "No brightness found in image settings";
    }
}

void PtzDeviceCgi::doMvGetCurrentInfraredBrightness(){
    // 获取当前红外亮度参数并保存
    ThermalCtl* thermalDevice = ThermalDeviceManager::instance()->getDevice(QString::fromStdString(device_id_));
    if (thermalDevice) {
        QJsonObject thermalParams = thermalDevice->getThermalImageParams();
        if (thermalParams.contains("Luminance")) {
            int currentBrightness = thermalParams["Luminance"].toInt();
            qDebug() << "Current infrared brightness:" << currentBrightness;
            // 保存原始亮度值
            if (m_originalInfraredBrightness == -1) {
                m_originalInfraredBrightness = currentBrightness;
                qDebug() << "Saved original infrared brightness:" << m_originalInfraredBrightness;
            }
        } else {
            qWarning() << "No Luminance found in thermal image params";
        }
    } else {
        qWarning() << "Thermal device not found for device ID:" << QString::fromStdString(device_id_);
    }
}

Q_INVOKABLE void
PtzDeviceCgi::mvModifyVideoSettings(QString encode_mode, QString resolution, QString framerate, QString govlength,
                                    QString bitrate, QString bitrate_control, int index){
    // 只发信号，不做耗时工作
    emit mvModifyVideoSettingsRequested(encode_mode, resolution, framerate, govlength, bitrate, bitrate_control, index);
}

void PtzDeviceCgi::doMvModifyVideoSettings(QString encode_mode, QString resolution, QString framerate, QString govlength,
                                    QString bitrate, QString bitrate_control, int index){
    QVariantMap mp;

    mp["encode_mode"] = encode_mode;
    mp["resolution"] = resolution;
    mp["framerate"] = framerate;
    mp["govlength"] = govlength;
    mp["bitrate"] = bitrate;
    mp["bitrate_control"] = bitrate_control;

    auto obj = QJsonObject::fromVariantMap(mp);
    QJsonDocument doc(obj);
    string str = doc.toJson().toStdString();

    ConfigVideoEncoding(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()), index,
                        const_cast<char*>(str.c_str()));
}

Q_INVOKABLE void
PtzDeviceCgi::mvModifyAudioSettings(bool enable_1, QString encode_type, QString samplerate, QString bitrate,
                                    QString input_volume, QString output_volume, QString amplify){
    // 只发信号，不做耗时工作
    emit mvModifyAudioSettingsRequested(enable_1, encode_type, samplerate, bitrate, input_volume, output_volume, amplify);
}

void PtzDeviceCgi::doMvModifyAudioSettings(bool enable_1, QString encode_type, QString samplerate, QString bitrate,
                                    QString input_volume, QString output_volume, QString amplify){
    QVariantMap mp;

    mp["enable"] = enable_1;
    mp["encode_type"] = encode_type;
    mp["samplerate"] = samplerate;
    mp["bitrate"] = bitrate;
    mp["input_volume"] = input_volume;
    mp["output_volume"] = output_volume;
    mp["amplify"] = amplify;

    auto obj = QJsonObject::fromVariantMap(mp);
    QJsonDocument doc(obj);
    string str = doc.toJson().toStdString();

    ConfigAudioEncoding(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()),
                        const_cast<char*>(str.c_str()));
}

// 移除单例实现，改为普通实例化
// Q_INVOKABLE PtzDeviceCgi& PtzDeviceCgi::moGetInstance(){
//     static PtzDeviceCgi instance_;  // 局部静态变量，线程安全
//     return instance_;
// }

Q_INVOKABLE void
PtzDeviceCgi::mvModifyOverlapString(bool enable_1, QString str_1, bool enable_2, QString str_2, bool enable_3,
                                    QString str_3, bool enable_4, QString str_4){
}

Q_INVOKABLE void PtzDeviceCgi::ConfigMainOSD(QString enable, QString title){
    // 只发信号，不做耗时工作
    emit ConfigMainOSDRequested(enable, title);
}

void PtzDeviceCgi::doConfigMainOSD(QString enable, QString title){
    QVariantMap mp;

    mp["enable"] = enable;
    mp["title_utf8"] = title;

    auto obj = QJsonObject::fromVariantMap(mp);
    QJsonDocument doc(obj);
    string str = doc.toJson().toStdString();

    ConfigOSD(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()), const_cast<char*>(str.c_str()));
}

int PtzDeviceCgi::mvFreshTdlasWarning(){
    // 从设备模型获取当前设备的报警浓度值
    int alarmThreshold = DeviceModel::instance()->getAlarmConcentration(QString::fromStdString(device_id_));
    qDebug() << "alarmThreshold concet_ :" << concet_;
    if(m_gasConcentrationAlarm){
        // 抓取可见光和红外图像
        QString visibleImagePath = "";
        QString infraredImagePath = "";
        
        // 抓取可见光帧 - 不再传入硬编码的文件名，让FrameProvider根据设置生成
        if (m_visibleLightProvider) {
            visibleImagePath = m_visibleLightProvider->captureCurrentFrame("", true); // 报警抓拍
            if (!visibleImagePath.isEmpty()) {
                qDebug() << "Captured visible light frame (alarm):" << visibleImagePath;
            } else {
                qWarning() << "Failed to capture visible light frame";
                visibleImagePath = "1.png"; // 后备图片
            }
        } else {
            qWarning() << "Visible light frame provider not set";
            visibleImagePath = "1.png"; // 后备图片
        }
        
        // 抓取红外图像 - 不再传入硬编码的文件名，让FrameProvider根据设置生成
        if (m_infraredProvider) {
            infraredImagePath = m_infraredProvider->captureCurrentFrame("", true); // 报警抓拍
            if (!infraredImagePath.isEmpty()) {
                qDebug() << "Captured infrared frame:" << infraredImagePath;
            } else {
                qWarning() << "Failed to capture infrared frame";
                infraredImagePath = "1.png"; // 后备图片
            }
        } else {
            qWarning() << "Infrared frame provider not set";
            infraredImagePath = "1.png"; // 后备图片
        }

        AlarmData alarmData = {
            GAS_LEAK_ALARM,  // 报警模式：气体报警
            visibleImagePath,
            infraredImagePath,
            QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"),
            QString("%1").arg(concet_),  // 气体浓度
            QString("超过阈值 %1 ppm").arg(alarmThreshold),  // 压力信息
            QString::fromStdString(""),  // 位置信息
            QString("%1").arg(m_currentTofDistance, 0, 'f', 2),  // 当前TOF距离
            QString::fromStdString(device_id_),  // 设备编号
            QString::fromStdString(deviceName_),  // 设备名称
            "", "", "",  // 设备异常字段为空
            "0°",  // 水平角度
            "0°"   // 垂直角度
        };

        // Ensure thread-safe update to AlarmModel on the GUI thread
        
        QMetaObject::invokeMethod(AlarmModel::instance(), [alarmData]() {
            AlarmModel::instance()->addAlarm(alarmData);
        }, Qt::QueuedConnection);
        
        // 注意：报警音频播放现在在onConcentrationUpdated方法中统一管理
    }
    return concet_;
}
void PtzDeviceCgi::mvTurnUp(){
    // 只发信号，不做耗时工作
    emit mvTurnUpRequested();
}

void PtzDeviceCgi::doMvTurnUp(){
    SteeringWithSpeed(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()), STEERING_UP, turn_speed_);
}

void PtzDeviceCgi::mvTurnDown(){
    // 只发信号，不做耗时工作
    emit mvTurnDownRequested();
}

void PtzDeviceCgi::doMvTurnDown(){
    SteeringWithSpeed(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()), STEERING_DOWN, turn_speed_);
}

void PtzDeviceCgi::mvTurnLeft(){
    // 只发信号，不做耗时工作
    emit mvTurnLeftRequested();
}

void PtzDeviceCgi::doMvTurnLeft(){
    SteeringWithSpeed(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()), STEERING_LEFT, turn_speed_);
}

void PtzDeviceCgi::mvTurnRight(){
    // 只发信号，不做耗时工作
    emit mvTurnRightRequested();
}

void PtzDeviceCgi::doMvTurnRight(){
    SteeringWithSpeed(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()), STEERING_RIGHT, turn_speed_);
}

void PtzDeviceCgi::mvTurnStop(){
    // 只发信号，不做耗时工作
    emit mvTurnStopRequested();
}

void PtzDeviceCgi::doMvTurnStop(){
    TurnStop(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()));
}

void PtzDeviceCgi::mvSetTurnSpeed(int speed){
    turn_speed_ = speed;
}
void PtzDeviceCgi::mvSetZoomIn(int val){
    // 只发信号，不做耗时工作
    emit mvSetZoomInRequested(val);
}

void PtzDeviceCgi::doMvSetZoomIn(int val){
    setZoomIn(ip_, uid_,val);
}

void PtzDeviceCgi::mvSetFocus(int val){
    // 只发信号，不做耗时工作
    emit mvSetFocusRequested(val);
}

void PtzDeviceCgi::doMvSetFocus(int val){
    setFocus(ip_, uid_,val);
}

void PtzDeviceCgi::mvSetAperture(int val){
    // 只发信号，不做耗时工作
    emit mvSetApertureRequested(val);
}

void PtzDeviceCgi::doMvSetAperture(int val){
    setAperture(ip_, uid_,val);
}

void PtzDeviceCgi::mvSetPreset(int id){
    // 只发信号，不做耗时工作
    emit mvSetPresetRequested(id);
}

void PtzDeviceCgi::doMvSetPreset(int id){
    setPreset(ip_, uid_,id);
    // if(setPreset(ip_, uid_,id)){
    //     for(auto& presetGroup:presetGroups){
    //         presetGroup.push_back(id);
    //     }
    // }
}
void PtzDeviceCgi::mvSetLinePreset(int id){
    //setPreset(ip_, uid_,id);
    // if(setPreset(ip_, uid_,id)){
    //     for(int idx = 0; idx < LinePresetGroups.size() ; idx++ ){
    //         if(idx == groupInfo.line){
    //             LinePresetGroups[groupInfo.line].push_back(id);
    //             break;
    //         }
    //     }
    // }
}
void PtzDeviceCgi::mvCallPreset(int id){
    // 只发信号，不做耗时工作
    emit mvCallPresetRequested(id);
}

void PtzDeviceCgi::doMvCallPreset(int id){
    callPreset(ip_, uid_,id);
}

void PtzDeviceCgi::mvDeletePreset(int id){
    // 只发信号，不做耗时工作
    emit mvDeletePresetRequested(id);
}

void PtzDeviceCgi::doMvDeletePreset(int id){
    deletePreset(ip_, uid_,id);
    // for(auto& group:presetGroups){
    //     for (auto it = group.begin(); it != group.end();) {
    //         if (*it == id) {
    //             it = group.erase(it); 
    //         } else {
    //             ++it;
    //         }
    //     }
    // }
}



void PtzDeviceCgi::mvSetCruiseScan(const QString &cruiseNumber, const QVariantList &presetPoints){
    Q_UNUSED(cruiseNumber);

    QVector<int> points;
    for (const QVariant &point : presetPoints) {
        points.append(point.toInt());
    }
    if (points.isEmpty()) {
        return;
    }
    m_cruisePausedDueToAlarm = false;
    startCruiseWithPoints(points);
}

#define CRUISE_SCAN_INTERVAL ALARM_DETECTION_DURATION // 15秒
// 巡航控制辅助方法实现
void PtzDeviceCgi::startCruiseWithPoints(const QVector<int>& points)
{
    if (m_gasConcentrationAlarm) {
        // 当前处于报警，标记为因报警而暂停，不启动
        m_cruisePausedDueToAlarm = true;
        m_currentCruisePoints = points;
        return;
    }
    if (!scanTimer) {
        return;
    }
    scanTimer->stop();
    QObject::disconnect(scanTimer, nullptr, nullptr, nullptr);

    m_currentCruisePoints = points;
    if (m_currentCruisePoints.isEmpty()) {
        m_cruiseActive = false;
        return;
    }

    const int size = m_currentCruisePoints.size();
    if (presetIdx < 0 || presetIdx >= size) {
        presetIdx = 0;
    }

    // 立即调用当前预置位
    mvCallPreset(m_currentCruisePoints[presetIdx]);

    QObject::connect(scanTimer, &QTimer::timeout, this, [this, size]() {
        // 若报警在巡航过程中触发，立即停止
        if (m_gasConcentrationAlarm) {
            scanTimer->stop();
            m_cruiseActive = false;
            m_cruisePausedDueToAlarm = true;
            return;
        }
        presetIdx = (presetIdx + 1) % size;
        mvCallPreset(m_currentCruisePoints[presetIdx]);
        // 巡航将无限循环，不再停止
    });

    scanTimer->start(CRUISE_SCAN_INTERVAL);
    m_cruiseActive = true;
}

void PtzDeviceCgi::stopCruise()
{
    if (!scanTimer) {
        return;
    }
    if (scanTimer->isActive()) {
        scanTimer->stop();
    }
    QObject::disconnect(scanTimer, nullptr, nullptr, nullptr);
    m_cruiseActive = false;
}

void PtzDeviceCgi::resumeCruiseIfPaused()
{
    if (!m_cruisePausedDueToAlarm) {
        return;
    }
    m_cruisePausedDueToAlarm = false;
    if (m_currentCruisePoints.isEmpty()) {
        return;
    }
    const int size = m_currentCruisePoints.size();
    if (presetIdx < 0 || presetIdx >= size) {
        presetIdx = 0;
    }
    // 从当前索引继续
    startCruiseWithPoints(m_currentCruisePoints);
}

void PtzDeviceCgi::mvSetLight(bool val){
    // 只发信号，不做耗时工作
    emit mvSetLightRequested(val);
}

void PtzDeviceCgi::doMvSetLight(bool val){
    string url = "http://" + ip_ + "/cgi-bin/light?";
    url += "val=" + to_string(val ? 1 : 0);
    url += "&uid=" + uid_;
    
    cout << "Setting light: " << url << endl;
    sendCgiCommand(url);
}

void PtzDeviceCgi::mvSetWiper(bool val){
    // 只发信号，不做耗时工作
    emit mvSetWiperRequested(val);
}

void PtzDeviceCgi::doMvSetWiper(bool val){
    string url = "http://" + ip_ + "/cgi-bin/wiper?";
    url += "val=" + to_string(val ? 1 : 0);
    url += "&uid=" + uid_;
    
    cout << "Setting wiper: " << url << endl;
    sendCgiCommand(url);
}

void PtzDeviceCgi::mvSetAssiFocus(bool val){
    // 只发信号，不做耗时工作
    emit mvSetAssiFocusRequested(val);
}

void PtzDeviceCgi::doMvSetAssiFocus(bool val){
    string url = "http://" + ip_ + "/cgi-bin/assifocus?";
    url += "val=" + to_string(val ? 1 : 0);
    url += "&uid=" + uid_;
    
    cout << "Setting assi focus: " << url << endl;
    sendCgiCommand(url);
}

void PtzDeviceCgi::mvSetInfFlap(bool val){
    // 只发信号，不做耗时工作
    emit mvSetInfFlapRequested(val);
}

void PtzDeviceCgi::doMvSetInfFlap(bool val){
    string url = "http://" + ip_ + "/cgi-bin/infflap?";
    url += "val=" + to_string(val ? 1 : 0);
    url += "&uid=" + uid_;
    
    cout << "Setting inf flap: " << url << endl;
    sendCgiCommand(url);
}


Q_INVOKABLE bool PtzDeviceCgi::mvReboot() {
    // 只发信号，不做耗时工作
    emit mvRebootRequested();
    return true; // 立即返回，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvReboot() {
    string url = "http://" + ip_ + "/cgi-bin/reboot?uid=" + uid_;
    cout << "Reboot PTZ: " << url << endl;
    sendCgiCommand(url);
}


Q_INVOKABLE bool PtzDeviceCgi::mvFactoryReset(bool retain_network) {
    // 只发信号，不做耗时工作
    emit mvFactoryResetRequested(retain_network);
    return true; // 立即返回，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvFactoryReset(bool retain_network) {
    string url;
    
    if (retain_network) {
        url = "http://" + ip_ + "/cgi-bin/factory_reset?retain_network=1&uid=" + uid_;
    } else {
        url = "http://" + ip_ + "/cgi-bin/factory_reset?uid=" + uid_;
    }
    
    cout << "Factory Reset PTZ: " << url << endl;
    sendCgiCommand(url);
}


Q_INVOKABLE void PtzDeviceCgi::mvConfigOSD(int enable, int color, int fontsize, int title_pos_type, 
                                          int title_pos_x, int title_pos_y, QString title_utf8) {
    // 只发信号，不做耗时工作
    emit mvConfigOSDRequested(enable, color, fontsize, title_pos_type, title_pos_x, title_pos_y, title_utf8);
}

void PtzDeviceCgi::doMvConfigOSD(int enable, int color, int fontsize, int title_pos_type, 
                                          int title_pos_x, int title_pos_y, QString title_utf8) {


    QVariantMap mp;

    mp["enable"] = QString::number(enable);
    mp["color"] = QString::number(color);
    mp["fontsize"] = QString::number(fontsize);
    mp["title_pos_type"] = QString::number(title_pos_type);
    mp["title_pos_x"] = QString::number(title_pos_x);
    mp["title_pos_y"] = QString::number(title_pos_y);
    mp["title_utf8"] = title_utf8;

    auto obj = QJsonObject::fromVariantMap(mp);
    QJsonDocument doc(obj);
    string str = doc.toJson().toStdString();

    ConfigOSD(const_cast<char*>(ip_.c_str()), const_cast<char*>(uid_.c_str()), const_cast<char*>(str.c_str()));
}


Q_INVOKABLE void PtzDeviceCgi::mvConfigTimeOSD(int enable, int show_week, QString time_format, 
                                              int title_pos_x, int title_pos_y) {
    // 只发信号，不做耗时工作
    emit mvConfigTimeOSDRequested(enable, show_week, time_format, title_pos_x, title_pos_y);
}

void PtzDeviceCgi::doMvConfigTimeOSD(int enable, int show_week, QString time_format, 
                                              int title_pos_x, int title_pos_y) {

    
    QVariantMap mp;

    mp["enable"] = QString::number(enable);
    mp["show_week"] = QString::number(show_week);
    mp["time_format"] = time_format;
    mp["title_pos_x"] = QString::number(title_pos_x);
    mp["title_pos_y"] = QString::number(title_pos_y);

    auto obj = QJsonObject::fromVariantMap(mp);
    QJsonDocument doc(obj);
    string str = doc.toJson().toStdString();

    // 使用特定的cgi指令 /cgi-bin/osd?time
    string url = "http://" + ip_ + "/cgi-bin/osd?";
    for(const auto& key : mp.keys()) {
        url += key.toStdString() + "=" + mp[key].toString().toStdString() + "&";
    }
    url += "uid=" + uid_;
     cout << "mvConfigTimeOSD: " << url << endl;
    CURL* curl;
    CURLcode res;
    string responseBody;


    curl = curl_easy_init();
    if(curl) {
        // Set timeout options
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);        // 10秒总超时
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 5L);  // 5秒连接超时
        
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

        res = curl_easy_perform(curl);
        if(res != CURLE_OK) {
            cerr << "CURL error: " << curl_easy_strerror(res) << endl;
        }
        cout << "mvConfigTimeOSD: " << responseBody << endl;
        curl_easy_cleanup(curl);
    }
    
}


Q_INVOKABLE void PtzDeviceCgi::mvConfigUserOSD(int title_index, int enable, int color, int fontsize, 
                                              int title_pos_type, int title_pos_x, int title_pos_y, 
                                              QString title_utf8) {
    // 只发信号，不做耗时工作
    emit mvConfigUserOSDRequested(title_index, enable, color, fontsize, title_pos_type, title_pos_x, title_pos_y, title_utf8);
}

void PtzDeviceCgi::doMvConfigUserOSD(int title_index, int enable, int color, int fontsize, 
                                              int title_pos_type, int title_pos_x, int title_pos_y, 
                                              QString title_utf8) {

    
    QVariantMap mp;

    mp["title_index"] = QString::number(title_index);
    mp["enable"] = QString::number(enable);
    mp["color"] = QString::number(color);
    mp["fontsize"] = QString::number(fontsize);
    mp["title_pos_type"] = QString::number(title_pos_type);
    mp["title_pos_x"] = QString::number(title_pos_x);
    mp["title_pos_y"] = QString::number(title_pos_y);
    mp["title_utf8"] = title_utf8;

    auto obj = QJsonObject::fromVariantMap(mp);
    QJsonDocument doc(obj);
    string str = doc.toJson().toStdString();


    ConfigUserOSD(ip_, uid_, str);
}

Q_INVOKABLE QVariantMap PtzDeviceCgi::mvGetVideoEncoderCapabilities(int streamIndex) {
    QVariantMap result;
    QEventLoop loop;
    
    // 连接信号到槽，当结果准备好时退出事件循环
    QMetaObject::Connection connection = connect(this, &PtzDeviceCgi::videoEncoderCapabilitiesReady, 
                                                [&result, &loop](const QVariantMap& capabilities) {
        result = capabilities;
        loop.quit();
    });
    
    // 发出请求信号
    emit mvGetVideoEncoderCapabilitiesRequested(streamIndex);
    
    // 等待结果，设置超时时间为15秒
    QTimer::singleShot(15000, &loop, &QEventLoop::quit);
    loop.exec();
    
    // 断开连接
    disconnect(connection);
    
    return result;
}

void PtzDeviceCgi::doMvGetVideoEncoderCapabilities(int streamIndex) {
    QVariantMap result;
    
    // Create URL for video encoder capabilities request
    string url = "http://" + ip_ + "/cgi-bin/videoencoder/getcapabilities?uid=" + uid_;
    
    CURL* curl;
    CURLcode res;
    string responseBody;


    curl = curl_easy_init();
    if(!curl) {
        return;
    }

    // Set timeout options
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);        // 10秒总超时
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 5L);  // 5秒连接超时
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK) {
        curl_easy_cleanup(curl);
        
        return;
    }
    
    // Parse XML response
    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if(xmlErr == XML_SUCCESS) {
        XMLElement* rootElement = doc.RootElement();
        if(rootElement && string(rootElement->Name()) == "video_capabilities") {
            // Get the correct stream element based on index
            XMLElement* streamElement = nullptr;
            if(streamIndex == 0) {
                streamElement = rootElement->FirstChildElement("stream1");
            } else {
                streamElement = rootElement->FirstChildElement("stream2");
            }
            
            if(streamElement) {
                // Parse encode modes
                QStringList encodeModes;
                for(XMLElement* modeElement = streamElement->FirstChildElement("encode_mode"); 
                    modeElement; 
                    modeElement = modeElement->NextSiblingElement("encode_mode")) {
                    
                    const char* modeName = modeElement->Attribute("name");
                    if(modeName) {
                        encodeModes.append(QString(modeName));
                        
                        // For each mode, get supported resolutions, framerates, and bitrates
                        QVariantList resolutions;
                        QVariantList framerates;
                        QVariantList bitrates;
                        
                        for(XMLElement* resElement = modeElement->FirstChildElement("resolution");
                            resElement;
                            resElement = resElement->NextSiblingElement("resolution")) {
                            
                            const char* resName = resElement->Attribute("name");
                            if(resName) {
                                resolutions.append(QString(resName));
                                
                                // Get framerate range
                                XMLElement* framerateElement = resElement->FirstChildElement("framerate_range");
                                if(framerateElement) {
                                    const char* framerateText = framerateElement->GetText();
                                    if(framerateText) {
                                        framerates.append(QString(framerateText));
                                    }
                                }
                                
                                // Get bitrate range
                                XMLElement* bitrateElement = resElement->FirstChildElement("bitrate_range");
                                if(bitrateElement) {
                                    const char* bitrateText = bitrateElement->GetText();
                                    if(bitrateText) {
                                        bitrates.append(QString(bitrateText));
                                    }
                                }
                            }
                        }
                        
                        QString modeKey = QString(modeName);
                        result[modeKey + "_resolutions"] = resolutions;
                        result[modeKey + "_framerates"] = framerates;
                        result[modeKey + "_bitrates"] = bitrates;
                    }
                }
                
                result["encode_modes"] = encodeModes;
            }
        }
    }
    
    curl_easy_cleanup(curl);
    
    // 发出信号传递结果
    emit videoEncoderCapabilitiesReady(result);
}

Q_INVOKABLE QVariantMap PtzDeviceCgi::mvGetAudioEncoderCapabilities() {
    QVariantMap result;
    QEventLoop loop;
    
    // 连接信号到槽，当结果准备好时退出事件循环
    QMetaObject::Connection connection = connect(this, &PtzDeviceCgi::audioEncoderCapabilitiesReady, 
                                                [&result, &loop](const QVariantMap& capabilities) {
        result = capabilities;
        loop.quit();
    });
    
    // 发出请求信号
    emit mvGetAudioEncoderCapabilitiesRequested();
    
    // 等待结果，设置超时时间为15秒
    QTimer::singleShot(15000, &loop, &QEventLoop::quit);
    loop.exec();
    
    // 断开连接
    disconnect(connection);
    
    return result;
}

void PtzDeviceCgi::doMvGetAudioEncoderCapabilities() {
    QVariantMap result;
    
    // Create URL for audio encoder capabilities request
    string url = "http://" + ip_ + "/cgi-bin/audioencoder/getcapabilities?uid=" + uid_;
    
    CURL* curl;
    CURLcode res;
    string responseBody;


    curl = curl_easy_init();
    if(!curl) {
        return;
    }

    // Set timeout options
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L);        // 10秒总超时
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 5L);  // 5秒连接超时
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);

    res = curl_easy_perform(curl);
    if(res != CURLE_OK) {
        curl_easy_cleanup(curl);
        
        return;
    }
    
    // Parse XML response
    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if(xmlErr == XML_SUCCESS) {
        XMLElement* rootElement = doc.RootElement();
        if(rootElement && string(rootElement->Name()) == "audio_capabilities") {
            // Parse encode types
            QStringList encodeTypes;
            QVariantMap sampleRates;
            QVariantMap bitrates;
            
            for(XMLElement* typeElement = rootElement->FirstChildElement("encode_type"); 
                typeElement; 
                typeElement = typeElement->NextSiblingElement("encode_type")) {
                
                const char* typeName = typeElement->Attribute("name");
                if(typeName) {
                    encodeTypes.append(QString(typeName));
                    
                    // Get supported sample rates and bitrates for each encode type
                    QStringList typeRates;
                    QStringList typeBitrates;
                    
                    for(XMLElement* rateElement = typeElement->FirstChildElement("samplerate");
                        rateElement;
                        rateElement = rateElement->NextSiblingElement("samplerate")) {
                        
                        const char* rateName = rateElement->Attribute("name");
                        if(rateName) {
                            typeRates.append(QString(rateName));
                            
                            // Get bitrate for this sample rate
                            XMLElement* bitrateElement = rateElement->FirstChildElement("bitrate");
                            if(bitrateElement) {
                                const char* bitrateText = bitrateElement->GetText();
                                if(bitrateText) {
                                    typeBitrates.append(QString(bitrateText));
                                }
                            }
                        }
                    }
                    
                    sampleRates[QString(typeName)] = typeRates;
                    bitrates[QString(typeName)] = typeBitrates;
                }
            }
            
            result["encode_types"] = encodeTypes;
            result["samplerates"] = sampleRates;
            result["bitrates"] = bitrates;
        }
    }
    
    curl_easy_cleanup(curl);
    
    // 发出信号传递结果
    emit audioEncoderCapabilitiesReady(result);
}


Q_INVOKABLE bool PtzDeviceCgi::mvConfigMotionDetect(bool enable, int sensitivity, int alarmThreshold, 
                                                  bool enableNighttime, int nightSensitivity, 
                                                  int nightAlarmThreshold, QString blockCount, 
                                                  QString areaValue) {
    // 只发信号，不做耗时工作
    emit mvConfigMotionDetectRequested(enable, sensitivity, alarmThreshold, enableNighttime, nightSensitivity, nightAlarmThreshold, blockCount, areaValue);
    return true; // 立即返回，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvConfigMotionDetect(bool enable, int sensitivity, int alarmThreshold, 
                                                  bool enableNighttime, int nightSensitivity, 
                                                  int nightAlarmThreshold, QString blockCount, 
                                                  QString areaValue) {

    string url = "http://" + ip_ + "/cgi-bin/motion?";
    

    url += "enable=" + to_string(enable ? 1 : 0);
    
    if (enable) {
        url += "&sensitivity=" + to_string(sensitivity);
        url += "&alarmthreshold=" + to_string(alarmThreshold);
        url += "&enable_nighttime=" + to_string(enableNighttime ? 1 : 0);
        
        if (enableNighttime) {
            url += "&night_sensitivity=" + to_string(nightSensitivity);
            url += "&night_alarmthreshold=" + to_string(nightAlarmThreshold);
        }
        
        url += "&blockcount=" + blockCount.toStdString();
        
        if (!areaValue.isEmpty()) {
            url += "&areavalue=" + areaValue.toStdString();
        }
    }
    

    url += "&uid=" + uid_;
    
    cout << "Configuring motion detection: " << url << endl;
    

    CURL* curl;
    CURLcode res;
    string responseBody;
    long httpCode = 0;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    }
    
    curl_easy_cleanup(curl);
    
}

Q_INVOKABLE QVariantMap PtzDeviceCgi::mvGetMotionDetectConfig() {
    // 只发信号，不做耗时工作
    emit mvGetMotionDetectConfigRequested();
    return QVariantMap(); // 立即返回空结果，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvGetMotionDetectConfig() {
    QVariantMap result;
    

    string url = "http://" + ip_ + "/cgi-bin/motion?uid=" + uid_;
    

    CURL* curl;
    CURLcode res;
    string responseBody;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        curl_easy_cleanup(curl);
        
        return;
    }
    

    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if (xmlErr == XML_SUCCESS) {
        XMLElement* rootElement = doc.RootElement();
        if (rootElement && string(rootElement->Name()) == "motion") {

            const char* enable = rootElement->Attribute("enable");
            const char* sensitivity = rootElement->Attribute("sensitivity");
            const char* alarmthreshold = rootElement->Attribute("alarmthreshold");
            const char* enable_nighttime = rootElement->Attribute("enable_nighttime");
            const char* night_sensitivity = rootElement->Attribute("night_sensitivity");
            const char* night_alarmthreshold = rootElement->Attribute("night_alarmthreshold");
            const char* blockcount = rootElement->Attribute("blockcount");
            const char* areavalue = rootElement->Attribute("areavalue");
            

            if (enable) result["enable"] = QString(enable);
            if (sensitivity) result["sensitivity"] = QString(sensitivity);
            if (alarmthreshold) result["alarmthreshold"] = QString(alarmthreshold);
            if (enable_nighttime) result["enable_nighttime"] = QString(enable_nighttime);
            if (night_sensitivity) result["night_sensitivity"] = QString(night_sensitivity);
            if (night_alarmthreshold) result["night_alarmthreshold"] = QString(night_alarmthreshold);
            if (blockcount) result["blockcount"] = QString(blockcount);
            if (areavalue) result["areavalue"] = QString(areavalue);
        }
    }
    
    curl_easy_cleanup(curl);
    
    
    // 这里可以发送信号返回结果，但需要添加相应的信号
    // emit motionDetectConfigReceived(result);
}

Q_INVOKABLE bool PtzDeviceCgi::mvConfigEventStorage(bool trigger_recording, int stream, bool record_ftp_upload, 
                                                 bool record_email_upload, bool trigger_capture,
                                                 bool capture_ftp_upload, bool capture_email_upload,
                                                 bool capture_motionDetectAlarm) {
    // 只发信号，不做耗时工作
    emit mvConfigEventStorageRequested(trigger_recording, stream, record_ftp_upload, record_email_upload, trigger_capture, capture_ftp_upload, capture_email_upload, capture_motionDetectAlarm);
    return true; // 立即返回，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvConfigEventStorage(bool trigger_recording, int stream, bool record_ftp_upload, 
                                                 bool record_email_upload, bool trigger_capture,
                                                 bool capture_ftp_upload, bool capture_email_upload,
                                                 bool capture_motionDetectAlarm) {

    string url = "http://" + ip_ + "/cgi-bin/setEventStorage?";
    
    // Add parameters according to the EventStorage Configuration
    // trigger_recording: 0=Disable motion detection storage, 1=Turn on motion detection storage
    url += "trigger_recording=" + to_string(trigger_recording ? 1 : 0);
    
    // stream: 1=main stream, 2=substream
    url += "&stream=" + to_string(stream);
    
    // record_ftp_upload: 0=The video is not uploaded to FTP, 1=Upload video to FTP server
    url += "&record_ftp_upload=" + to_string(record_ftp_upload ? 1 : 0);
    
    // record_email_upload: 0=The video is not uploaded to Email, 1=Upload video to Email server
    url += "&record_email_upload=" + to_string(record_email_upload ? 1 : 0);
    
    // trigger_capture: 0=Disable motion detection screenshot, 1=Turn on motion detection screenshot
    url += "&trigger_capture=" + to_string(trigger_capture ? 1 : 0);
    
    // capture_ftp_upload: 0=Motion detection screenshots are not uploaded to FTP, 1=Upload motion detection screenshots to FTP server
    url += "&capture_ftp_upload=" + to_string(capture_ftp_upload ? 1 : 0);
    
    // capture_email_upload: 0=Motion detection screenshots are not uploaded to Email, 1=Upload motion detection screenshots to Email server
    url += "&capture_email_upload=" + to_string(capture_email_upload ? 1 : 0);
    
    // capture_motionDetectAlarm: 0=Disable motion detection alarm output, 1=Turn on motion detection alarm output
    url += "&capture_motionDetectAlarm=" + to_string(capture_motionDetectAlarm ? 1 : 0);
    
    // Add authentication information
    url += "&uid=" + uid_;
    
    cout << "Configuring event storage: " << url << endl;
    
    // Execute HTTP request
    CURL* curl;
    CURLcode res;
    string responseBody;
    long httpCode = 0;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
        
        // Status codes based on the screenshot:
        // 200: Request successful
        // 400: Parameter error (invalid trigger_recording, stream, etc.)
        if (httpCode == 200) {
            cout << "Event storage configuration successful" << endl;
        } else {
            cout << "Event storage configuration failed with code: " << httpCode << endl;
            cout << "Response body: " << responseBody << endl;
        }
    }
    
    curl_easy_cleanup(curl);
    
}

Q_INVOKABLE QVariantMap PtzDeviceCgi::mvGetEventStorageConfig() {
    // 只发信号，不做耗时工作
    emit mvGetEventStorageConfigRequested();
    return QVariantMap(); // 立即返回空结果，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvGetEventStorageConfig() {
    ///FIXME: getEventStorage IS NOT EXIST IN THE API
    QVariantMap result;
    
    // API endpoint to get event storage configuration
    string url = "http://" + ip_ + "/cgi-bin/getEventStorage?uid=" + uid_;
    
    cout << "Getting event storage configuration: " << url << endl;

    CURL* curl;
    CURLcode res;
    string responseBody;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        curl_easy_cleanup(curl);
        
        return;
    }
    
    // Parse XML response to extract configuration
    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if (xmlErr == XML_SUCCESS) {
        XMLElement* rootElement = doc.RootElement();
        if (rootElement && string(rootElement->Name()) == "RecordConfig") {
            // Extract all event storage parameters
            const char* trigger_recording = rootElement->Attribute("trigger_recording");
            const char* stream = rootElement->Attribute("stream");
            const char* record_ftp_upload = rootElement->Attribute("record_ftp_upload");
            const char* record_email_upload = rootElement->Attribute("record_email_upload");
            const char* trigger_capture = rootElement->Attribute("trigger_capture");
            const char* capture_ftp_upload = rootElement->Attribute("capture_ftp_upload");
            const char* capture_email_upload = rootElement->Attribute("capture_email_upload");
            const char* capture_motionDetectAlarm = rootElement->Attribute("capture_motionDetectAlarm");
            
            // Add all parameters to the result map
            if (trigger_recording) result["trigger_recording"] = QString(trigger_recording);
            if (stream) result["stream"] = QString(stream);
            if (record_ftp_upload) result["record_ftp_upload"] = QString(record_ftp_upload);
            if (record_email_upload) result["record_email_upload"] = QString(record_email_upload);
            if (trigger_capture) result["trigger_capture"] = QString(trigger_capture);
            if (capture_ftp_upload) result["capture_ftp_upload"] = QString(capture_ftp_upload);
            if (capture_email_upload) result["capture_email_upload"] = QString(capture_email_upload);
            if (capture_motionDetectAlarm) result["capture_motionDetectAlarm"] = QString(capture_motionDetectAlarm);
            
            cout << "Successfully retrieved event storage configuration" << endl;
        } else {
            cout << "Failed to find RecordConfig element in response" << endl;
        }
    } else {
        cout << "Failed to parse XML response: " << doc.ErrorStr() << endl;
    }
    
    curl_easy_cleanup(curl);
    
}

// Service port configuration implementation
Q_INVOKABLE bool PtzDeviceCgi::mvConfigServicePorts(bool enable_web, bool enable_control, bool enable_rtsp, bool enable_hik,
                                              int webport, int controlport, int rtspport, int hikport) {
    // 只发信号，不做耗时工作
    emit mvConfigServicePortsRequested(enable_web, enable_control, enable_rtsp, enable_hik, webport, controlport, rtspport, hikport);
    return true; // 立即返回，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvConfigServicePorts(bool enable_web, bool enable_control, bool enable_rtsp, bool enable_hik,
                                              int webport, int controlport, int rtspport, int hikport) {
    // Construct the API URL according to the screenshot
    string url = "http://" + ip_ + "/cgi-bin/set_service_port?";
    
    // Add parameters
    url += "enable_web=" + to_string(enable_web ? 1 : 0);
    url += "&enable_control=" + to_string(enable_control ? 1 : 0);
    url += "&enable_rtsp=" + to_string(enable_rtsp ? 1 : 0);
    url += "&enable_hik=" + to_string(enable_hik ? 1 : 0);
    
    // Add port numbers if corresponding services are enabled
    if (enable_web) {
        url += "&webport=" + to_string(webport);
    }
    
    if (enable_control) {
        url += "&controlport=" + to_string(controlport);
    }
    
    if (enable_rtsp) {
        url += "&rtspport=" + to_string(rtspport);
    }
    
    if (enable_hik) {
        url += "&hikport=" + to_string(hikport);
    }
    
    // Add authentication information
    url += "&uid=" + uid_;
    
    cout << "Configuring service ports: " << url << endl;
    
    // Execute HTTP request
    CURL* curl;
    CURLcode res;
    string responseBody;
    long httpCode = 0;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    }
    
    curl_easy_cleanup(curl);
    
}

// Set RTSP port only implementation
Q_INVOKABLE bool PtzDeviceCgi::mvSetRtspPort(int rtspport) {
    // 只发信号，不做耗时工作
    emit mvSetRtspPortRequested(rtspport);
    return true; // 立即返回，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvSetRtspPort(int rtspport) {
    // Construct the API URL based on the screenshot format for service port API
    string url = "http://" + ip_ + "/cgi-bin/set_service_port?enable_rtsp=1&rtspport=" + to_string(rtspport) + "&uid=" + uid_;
    
    cout << "Setting RTSP port: " << url << endl;
    
    // Execute HTTP request
    CURL* curl;
    CURLcode res;
    string responseBody;
    long httpCode = 0;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    }
    
    curl_easy_cleanup(curl);
    
}

// Set HTTP port only implementation
Q_INVOKABLE bool PtzDeviceCgi::mvSetHttpPort(int httpport) {
    // 只发信号，不做耗时工作
    emit mvSetHttpPortRequested(httpport);
    return true; // 立即返回，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvSetHttpPort(int httpport) {
    // Construct the API URL based on the screenshot format for network port
    // Using the same API endpoint with HTTP port parameter
    string url = "http://" + ip_ + "/cgi-bin/network?port=" + to_string(httpport) + "&uid=" + uid_;
    
    cout << "Setting HTTP port: " << url << endl;
    
    // Execute HTTP request
    CURL* curl;
    CURLcode res;
    string responseBody;
    long httpCode = 0;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
    }
    
    curl_easy_cleanup(curl);
    
}

Q_INVOKABLE bool PtzDeviceCgi::mvConfigScheduleStorage(bool localEnable, bool remoteEnable, 
                                                    int recordFileSize, QString remote_nfs_server,
                                                    QString nfs_server_path, int stream,
                                                    int jpeginterval, bool enable) {
    // 只发信号，不做耗时工作
    emit mvConfigScheduleStorageRequested(localEnable, remoteEnable, recordFileSize, remote_nfs_server, nfs_server_path, stream, jpeginterval, enable);
    return true; // 立即返回，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvConfigScheduleStorage(bool localEnable, bool remoteEnable, 
                                                    int recordFileSize, QString remote_nfs_server,
                                                    QString nfs_server_path, int stream,
                                                    int jpeginterval, bool enable) {
    // 构建API URL
    string url = "http://" + ip_ + "/cgi-bin/setScheduleStorage?";
    
    // 添加参数
    url += "localEnable=" + to_string(localEnable ? 1 : 0);
    url += "&remoteEnable=" + to_string(remoteEnable ? 1 : 0);
    url += "&recordFileSize=" + to_string(recordFileSize);
    
    // 只有当remoteEnable为true时，添加远程NFS服务器参数
    if (remoteEnable) {
        url += "&remote_nfs_server=" + remote_nfs_server.toStdString();
        url += "&nfs_server_path=" + nfs_server_path.toStdString();
    }
    
    // 添加流类型参数
    url += "&stream=" + to_string(stream);
    
    // 添加截图间隔参数
    url += "&jpeginterval=" + to_string(jpeginterval);
    
    // 添加是否启用计时录像参数
    url += "&enable=" + to_string(enable ? 1 : 0);
    
    // 添加认证信息
    url += "&uid=" + uid_;
    
    cout << "Configuring schedule storage: " << url << endl;
    
    // 执行HTTP请求
    CURL* curl;
    CURLcode res;
    string responseBody;
    long httpCode = 0;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
        
        if (httpCode == 200) {
            cout << "Schedule storage configuration successful" << endl;
        } else {
            cout << "Schedule storage configuration failed with code: " << httpCode << endl;
            cout << "Response body: " << responseBody << endl;
        }
    }
    
    curl_easy_cleanup(curl);
    
}

Q_INVOKABLE QString PtzDeviceCgi::mvGetRecordFilePath(int year, int month, int day, int start_hour, int start_min, int end_hour, int end_min) {
    // 只发信号，不做耗时工作
    emit mvGetRecordFilePathRequested(year, month, day, start_hour, start_min, end_hour, end_min);
    return QString(); // 立即返回空结果，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvGetRecordFilePath(int year, int month, int day, int start_hour, int start_min, int end_hour, int end_min) {
    // Create the URL for requesting recording file paths
    string url = "http://" + ip_ + "/cgi-bin/basic/record_search?mode=day_type";
    
    // Add date parameters
    url += "&year=" + to_string(year);
    url += "&month=" + to_string(month);
    url += "&day=" + to_string(day);
    
    // Add time range parameters
    url += "&start_hour=" + to_string(start_hour);
    url += "&start_min=" + to_string(start_min);
    url += "&end_hour=" + to_string(end_hour);
    url += "&end_min=" + to_string(end_min);
    
    // Add authentication
    url += "&uid=" + uid_;
    
    CURL* curl;
    CURLcode res;
    string responseBody;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    if (res != CURLE_OK) {
        curl_easy_cleanup(curl);
        
        return;
    }
    
    // Parse the response to extract file paths
    // Note: The exact parsing logic may need to be adjusted based on the actual response format
    QString result;
    
    // Here we're assuming the response has the file path(s)
    // This implementation might need refinement based on the actual response structure
    tinyxml2::XMLDocument doc;
    XMLError xmlErr = doc.Parse(responseBody.c_str());
    if (xmlErr == XML_SUCCESS) {
        XMLElement* rootElement = doc.RootElement();
        if (rootElement) {
            // Assuming the response contains a list of file elements
            for (XMLElement* fileElement = rootElement->FirstChildElement("file"); 
                 fileElement; 
                 fileElement = fileElement->NextSiblingElement("file")) {
                const char* path = fileElement->Attribute("path");
                if (path) {
                    // If multiple files are found, we concatenate them with semicolons
                    if (!result.isEmpty()) {
                        result += ";";
                    }
                    result += QString::fromStdString(path);
                }
            }
        }
    }
    
    curl_easy_cleanup(curl);
    
    
    // 这里可以发送信号返回结果，但需要添加相应的信号
    // emit recordFilePathReceived(result);
}

// Snapshot upload implementation
Q_INVOKABLE bool PtzDeviceCgi::mvSnapshotUpload(int stream, int upload_type) {
    // 只发信号，不做耗时工作
    emit mvSnapshotUploadRequested(stream, upload_type);
    return true; // 立即返回，实际结果在子线程中处理
}

void PtzDeviceCgi::doMvSnapshotUpload(int stream, int upload_type) {
    // Create URL for snapshot upload based on the documentation
    string url = "http://" + ip_ + "/cgi-bin/snapshot.cgi?";
    
    // Add stream parameter (0=sub stream, 1=main stream)
    url += "stream=" + to_string(stream);
    
    // Add upload parameter (0=SD card, 1=FTP, 2=Email, 3=NFS)
    url += "&upload=" + to_string(upload_type);
    
    // Add authentication
    url += "&username=" + user_ + "&password=" + passwd_;
    
    cout << "Snapshot upload request: " << url << endl;
    
    // Execute HTTP request
    CURL* curl;
    CURLcode res;
    string responseBody;
    long httpCode = 0;
    

    curl = curl_easy_init();
    if (!curl) {
        return;
    }
    
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBody);
    
    res = curl_easy_perform(curl);
    
    if (res == CURLE_OK) {
        curl_easy_getinfo(curl, CURLINFO_RESPONSE_CODE, &httpCode);
        
        // Check for success response (200 OK)
        if (httpCode == 200) {
            cout << "Snapshot upload successful" << endl;
        } else {
            cout << "Snapshot upload failed with code: " << httpCode << endl;
            cout << "Response body: " << responseBody << endl;
        }
    } else {
        cout << "CURL error: " << curl_easy_strerror(res) << endl;
        curl_easy_cleanup(curl);
        
        return;
    }
    
    curl_easy_cleanup(curl);
    
}

void PtzDeviceCgi::onConcentrationUpdated(int value)
{
    
    // 更新浓度值
    concet_ = value;
    
    // 维护浓度列表
    if(concet_list_.count() > 60){
        concet_list_.pop_front();
    }
    concet_list_.push_back(concet_);
    
    if(value > MAX_ALARM_TDLAS)
        return;
    // 保存TDLAS浓度数据
    TdlasDataManager::instance()->saveConcentrationData(value, 0.0, 0.0, m_currentTofDistance, QString::fromStdString(device_id_));
    
    // 使用QMetaObject::invokeMethod确保所有复杂操作在正确的线程中执行
    //qDebug() << "onConcentrationUpdated QMetaObject::invokeMethod";
    QMetaObject::invokeMethod(this, [this, value]() {
        // 从设备模型获取当前设备的报警浓度值
        int alarmThreshold = DeviceModel::instance()->getAlarmConcentration(QString::fromStdString(device_id_));
        bool previousAlarm = m_gasConcentrationAlarm;  // 使用缓存的状态
        bool currentAlarm = value > alarmThreshold;
        
        // 浓度值到电流值的映射 (0-50000 ppm -> 4-20 mA)
        float mappedCurrent = mapConcentrationToCurrent(value);
        //qDebug() << "onConcentrationUpdated mappedCurrent" << mappedCurrent;
        // 通过对应设备的Modbus接口发送电流值 - 使用QueuedConnection确保线程安全
        if (m_modbusWorker) {
            //qDebug() << "onConcentrationUpdated ModbusWorker::sendVoltageData";
            
            // 检查网络连接是否可用
            NetworkConnectionManager* connManager = NetworkConnectionManager::instance();
            if (connManager->canAcquireConnectionLock(m_modbusWorker->getIp(), m_modbusWorker->getPort(), "ModbusWorker")) {
                //qDebug() << "onConcentrationUpdated ModbusWorker::sendVoltageData: 连接可用";
                // 连接可用，立即发送
                QMetaObject::invokeMethod(m_modbusWorker, "sendVoltageData", Qt::QueuedConnection, Q_ARG(float, mappedCurrent));
            } else {
                // 连接被占用，延迟发送
                //qDebug() << "onConcentrationUpdated: Modbus连接被占用，延迟发送电流值";
                QTimer::singleShot(100, this, [this, mappedCurrent]() {
                    if (m_modbusWorker) {
                        QMetaObject::invokeMethod(m_modbusWorker, "sendVoltageData", Qt::QueuedConnection, Q_ARG(float, mappedCurrent));
                    }
                });
            }
        } else {
            //qWarning() << "ModbusWorker未初始化，无法发送电流值";
        }
        
        // 当报警状态发生变化时发出信号
        if (previousAlarm != currentAlarm) {
            // 更新缓存的状态
            m_gasConcentrationAlarm = currentAlarm;
            
            // 触发报警录像记录
            if (currentAlarm) {
                // 获取当前气体浓度和位置信息
                QString deviceCode = QString::fromStdString(device_id_);
                QString deviceName = deviceCode; // 可以扩展为从设备模型获取设备名称
                QString concentration = QString::number(value);
                QString position = ""; // 可以从设备模型获取位置信息
                
                // 调用报警录像管理器开始记录
                AlarmRecordingManager::instance()->handleGasAlarm(deviceCode, deviceName, concentration, position);
            }
            
            // 触发NOTIFY信号
            emit gasConcentrationAlarmChanged(currentAlarm, QString::fromStdString(device_id_));
            
            // 根据报警状态控制音乐播放和亮度调节
            if (currentAlarm) {
                // 报警开始，播放报警音频；停止所有扫描并保持在当前位置；调节亮度到最大
                QMetaObject::invokeMethod(AlarmAudioPlayer::instance(), "playAlarmAudio", Qt::QueuedConnection);
                
                // 停止所有扫描并保存当前扫描状态
                stopAllScansForAlarm();
                
                // 重置连续正常计数
                m_normalConcentrationCount = 0;
                
                // 保存当前亮度值（如果还没有保存）
                if (m_originalVisibleBrightness == -1) {
                    doMvGetCurrentImageBrightness();
                }
                
                // 保存当前红外亮度值（如果还没有保存）
                if (m_originalInfraredBrightness == -1) {
                    doMvGetCurrentInfraredBrightness();
                }
                
                // 如果报警检测计时器已经运行，则重置它；否则启动新的计时器
                if (m_alarmDetectionTimerActive) {
                    qDebug() << "Gas alarm still active, resetting 15-second detection timer";
                    startAlarmDetectionTimer(); // 重置计时器
                } else {
                    qDebug() << "Gas alarm detected, starting 15-second detection timer";
                    startAlarmDetectionTimer();
                }
                
                // 获取当前图像参数，只修改亮度到最大值，其他参数保持不变
                QVariantMap currentImageSettings = doMvGetImageSettings();
                if (!currentImageSettings.isEmpty()) {
                    // 获取当前各个参数值，如果某个参数不存在则使用默认值
                   
                    int currentBrightness = currentImageSettings.contains("brightness") ? currentImageSettings["brightness"].toInt() : 50;
                    int currentContrast = currentImageSettings.contains("contrast") ? currentImageSettings["contrast"].toInt() : 50;
                    int currentSaturation = currentImageSettings.contains("saturation") ? currentImageSettings["saturation"].toInt() : 50;
                    int currentSharpness = currentImageSettings.contains("sharpness") ? currentImageSettings["sharpness"].toInt() : 50;
                    int currentHlc = currentImageSettings.contains("hlc") ? currentImageSettings["hlc"].toInt() : 0;
                    int currentBlc = currentImageSettings.contains("blc") ? currentImageSettings["blc"].toInt() : 0;
                    int currentNr2d = currentImageSettings.contains("nr2d") ? currentImageSettings["nr2d"].toInt() : 0;
                    int currentNr3d = currentImageSettings.contains("nr3d") ? currentImageSettings["nr3d"].toInt() : 0;
                    int currentTvsystem = currentImageSettings.contains("tvsystem") ? currentImageSettings["tvsystem"].toInt() : 50;
                    int currentAntificker = currentImageSettings.contains("antificker") ? currentImageSettings["antificker"].toInt() : 0;
                    
                    qDebug() << "currentBrightness" << currentBrightness << "currentContrast" << currentContrast
                    << "currentSaturation" << currentSaturation << "currentSharpness" << currentSharpness
                    << "currentHlc" << currentHlc << "currentBlc" << currentBlc << "currentNr2d" << currentNr2d
                    << "currentNr3d" << currentNr3d << "currentTvsystem" << currentTvsystem << "currentAntificker" << currentAntificker;
                    
                    // 只有当当前亮度不是最大值时才发送修改指令
                    if (currentBrightness != MAX_VISIBLE_BRIGHTNESS) {
                        // 只修改亮度到最大值255，其他参数保持当前值
                        emit mvModifyImageSettingsRequested(MAX_VISIBLE_BRIGHTNESS, currentContrast, currentSaturation, currentSharpness, 
                                                        currentHlc, currentBlc, currentNr2d, currentNr3d, currentTvsystem, currentAntificker);
                        qDebug() << "Gas alarm: Set visible brightness to maximum (" << MAX_VISIBLE_BRIGHTNESS << "), kept other parameters unchanged";
                    } else {
                        qDebug() << "Visible brightness is already at maximum (" << MAX_VISIBLE_BRIGHTNESS << "), skipping adjustment";
                    }
                } else {
                    // 如果获取当前参数失败，则使用之前的默认逻辑
                    emit mvModifyImageSettingsRequested(MAX_VISIBLE_BRIGHTNESS, 50, 50, 50, 0, 0, 0, 0, 50, 0);
                    qDebug() << "Gas alarm: Failed to get current image settings, using default parameters";
                }
                
                // 获取当前红外参数，只修改亮度到最大值，其他参数保持不变
                ThermalCtl* thermalDevice = ThermalDeviceManager::instance()->getDevice(QString::fromStdString(device_id_));
                if (thermalDevice) {
                    QJsonObject currentThermalParams = thermalDevice->getThermalImageParams();
                    int currentLuminance = currentThermalParams.contains("Luminance") ? currentThermalParams["Luminance"].toInt() : 50;
                    int currentContrast = currentThermalParams.contains("Contrast") ? currentThermalParams["Contrast"].toInt() : 50;
                    int currentFlipMode = currentThermalParams.contains("FlipMode") ? currentThermalParams["FlipMode"].toInt() : 0;
                    
                    // 只有当当前红外亮度不是最大值时才发送修改指令
                    // if (currentLuminance != MAX_INFRARED_BRIGHTNESS) {
                    //     // 只将亮度调到最大值100，其他参数保持当前值
                    //     thermalDevice->setThermalImageParams(MAX_INFRARED_BRIGHTNESS, currentContrast, currentFlipMode);
                    //     qDebug() << "Gas alarm: Set infrared brightness to maximum (" << MAX_INFRARED_BRIGHTNESS << "), kept other parameters unchanged";
                    // } else {
                    //     qDebug() << "Infrared brightness is already at maximum (" << MAX_INFRARED_BRIGHTNESS << "), skipping adjustment";
                    // }
                }
            } else {
                // 报警停止，停止报警音频；如有需要恢复巡航
                QMetaObject::invokeMethod(AlarmAudioPlayer::instance(), "stopAlarmAudio", Qt::QueuedConnection);
                //resumeCruiseIfPaused();
                
                // 不再立即恢复亮度，而是开始计数连续正常状态
                qDebug() << "Gas alarm ended: Starting normal concentration count, current count:" << m_normalConcentrationCount;
            }
        } else if (!currentAlarm) {
            // 报警未发生且当前状态正常，增加正常计数
            m_normalConcentrationCount++;
            qDebug() << "Normal concentration count incremented to:" << m_normalConcentrationCount;
            
            // 如果报警检测计时器正在运行且连续正常计数达到阈值，则恢复扫描
            if (m_alarmDetectionTimerActive && m_normalConcentrationCount >= (ALARM_DETECTION_DURATION / TDLAS_INTERVAL)) {
                qDebug() << "Normal concentration maintained for" << m_normalConcentrationCount << "cycles, resuming scan operations";
                resumeScanAfterAlarm();
            }
            
            // 当连续正常计数达到10次时，恢复原始亮度
            if (m_normalConcentrationCount >= 5) {
                qDebug() << "10 consecutive normal concentrations reached, restoring original brightness";
                
                // 获取当前图像参数，只恢复亮度到原始值，其他参数保持不变
                QVariantMap currentImageSettings = doMvGetImageSettings();
                if (!currentImageSettings.isEmpty() && m_originalVisibleBrightness != -1) {
                    // 获取当前各个参数值，如果某个参数不存在则使用默认值
                    int currentContrast = currentImageSettings.contains("contrast") ? currentImageSettings["contrast"].toInt() : 50;
                    int currentSaturation = currentImageSettings.contains("saturation") ? currentImageSettings["saturation"].toInt() : 50;
                    int currentSharpness = currentImageSettings.contains("sharpness") ? currentImageSettings["sharpness"].toInt() : 50;
                    int currentHlc = currentImageSettings.contains("hlc") ? currentImageSettings["hlc"].toInt() : 0;
                    int currentBlc = currentImageSettings.contains("blc") ? currentImageSettings["blc"].toInt() : 0;
                    int currentNr2d = currentImageSettings.contains("nr2d") ? currentImageSettings["nr2d"].toInt() : 0;
                    int currentNr3d = currentImageSettings.contains("nr3d") ? currentImageSettings["nr3d"].toInt() : 0;
                    int currentTvsystem = currentImageSettings.contains("tvsystem") ? currentImageSettings["tvsystem"].toInt() : 50;
                    int currentAntificker = currentImageSettings.contains("antificker") ? currentImageSettings["antificker"].toInt() : 0;
                    
                    // 只有当当前亮度不是原始亮度时才发送修改指令
                    int currentBrightness = currentImageSettings.contains("brightness") ? currentImageSettings["brightness"].toInt() : 50;
                    if (currentBrightness != m_originalVisibleBrightness) {
                        // 只将亮度恢复到原始值，其他参数保持当前值
                        emit mvModifyImageSettingsRequested(m_originalVisibleBrightness, currentContrast, currentSaturation, currentSharpness, 
                                                        currentHlc, currentBlc, currentNr2d, currentNr3d, currentTvsystem, currentAntificker);
                        qDebug() << "Gas alarm ended: Restored visible brightness to" << m_originalVisibleBrightness << ", kept other parameters unchanged";
                    } else {
                        qDebug() << "Visible brightness is already at original value (" << m_originalVisibleBrightness << "), skipping adjustment";
                    }
                    m_originalVisibleBrightness = -1;  // 重置为未保存状态
                } else if (m_originalVisibleBrightness != -1) {
                    // 如果获取当前参数失败，则使用之前的默认逻辑
                    emit mvModifyImageSettingsRequested(m_originalVisibleBrightness, 50, 50, 50, 0, 0, 0, 0, 50, 0);
                    qDebug() << "Gas alarm ended: Failed to get current image settings, using default parameters";
                    m_originalVisibleBrightness = -1;  // 重置为未保存状态
                }
                
                // 获取当前红外参数，只恢复亮度到原始值，其他参数保持不变
                if (m_originalInfraredBrightness != -1) {
                    ThermalCtl* thermalDevice = ThermalDeviceManager::instance()->getDevice(QString::fromStdString(device_id_));
                    if (thermalDevice) {
                        QJsonObject currentThermalParams = thermalDevice->getThermalImageParams();
                        int currentLuminance = currentThermalParams.contains("Luminance") ? currentThermalParams["Luminance"].toInt() : 50;
                        int currentContrast = currentThermalParams.contains("Contrast") ? currentThermalParams["Contrast"].toInt() : 50;
                        int currentFlipMode = currentThermalParams.contains("FlipMode") ? currentThermalParams["FlipMode"].toInt() : 0;
                        
                        // 只有当当前红外亮度不是原始亮度时才发送修改指令
                        // if (currentLuminance != m_originalInfraredBrightness) {
                        //     // 只将亮度恢复到原始值，其他参数保持当前值
                        //     thermalDevice->setThermalImageParams(m_originalInfraredBrightness, currentContrast, currentFlipMode);
                        //     qDebug() << "Gas alarm ended: Restored infrared brightness to" << m_originalInfraredBrightness << 
                        //                ", kept other parameters unchanged";
                        // } else {
                        //     qDebug() << "Infrared brightness is already at original value (" << m_originalInfraredBrightness << "), skipping adjustment";
                        // }
                    }
                    m_originalInfraredBrightness = -1;  // 重置为未保存状态
                }
                
                // 重置计数器
                m_normalConcentrationCount = 0;
            }
        }
    }, Qt::QueuedConnection);
}

// 浓度值到电流值的映射函数实现
float PtzDeviceCgi::mapConcentrationToCurrent(int concentration)
{
    // TDLAS浓度值范围: 0-50000 ppm
    // Modbus电流值范围: 4-20 mA
    const int MIN_CONCENTRATION = 0;
    const int MAX_CONCENTRATION = 50000;
    const float MIN_CURRENT = 4.0f;
    const float MAX_CURRENT = 20.0f;
    
    // 限制浓度值在有效范围内
    if (concentration < MIN_CONCENTRATION) {
        concentration = MIN_CONCENTRATION;
    } else if (concentration > MAX_CONCENTRATION) {
        concentration = MAX_CONCENTRATION;
    }
    
    // 线性映射: (concentration - MIN_CONCENTRATION) / (MAX_CONCENTRATION - MIN_CONCENTRATION) * (MAX_CURRENT - MIN_CURRENT) + MIN_CURRENT
    float mappedCurrent = static_cast<float>(concentration - MIN_CONCENTRATION) / 
                         static_cast<float>(MAX_CONCENTRATION - MIN_CONCENTRATION) * 
                         (MAX_CURRENT - MIN_CURRENT) + MIN_CURRENT;
    
    // 保留两位小数
    return round(mappedCurrent * 100.0f) / 100.0f;
}


static const char* cmd_concentration = "01040000000131CA";
static const char* cmd_turnoffLaser = "010500000000CDCA";
static const char* cmd_turnonLaser = "01050000FF008C3A";
TdlasWorker::TdlasWorker(QString ip, int port, QObject* parent)
    : QObject(parent), m_ip(ip), m_port(port), m_stopped(false), m_sockfd(INVALID_SOCKET)
{

}

TdlasWorker::~TdlasWorker()
{
    if (m_sockfd != INVALID_SOCKET) {
        closesocket(m_sockfd);
        WSACleanup();
    }
}

void TdlasWorker::process()
{
    qDebug() << "TdlasWorker::process started on thread:" << QThread::currentThread();

    m_sockfd = connectToServe(m_ip.toStdString(), m_port);
    if (m_sockfd < 0) {
        qWarning() << "TdlasWorker: Failed to connect to server.";
        emit finished();
        return;
    }
    qDebug() << "TdlasWorker: Successfully connected to server, m_sockfd:" << m_sockfd;
    u_long mode = 1;
    ioctlsocket(m_sockfd, FIONBIO, &mode);
    // 设置 socket 接收超时
    // 由于循环中会发送数据并等待回复，将超时时间设置得短一些，以便更频繁地检查m_stopped
    int timeout_ms = 500; // 0.5 秒超时
    if (setsockopt(m_sockfd, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout_ms, sizeof(timeout_ms)) < 0) {
        qWarning() << "TdlasWorker: Error setting socket receive timeout:" << WSAGetLastError();
        closesocket(m_sockfd);
        m_sockfd = INVALID_SOCKET;
        WSACleanup();
        emit finished();
        return;
    }
    //turnonlaser(m_sockfd);
    //turnofflaser(m_sockfd);
    char buffer[8];
    while (!m_stopped) {
        // 在发送数据前再次检查停止标志，确保及时响应停止请求
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (m_stopped) {
                break; // 退出循环
            }
        }

        // 发送浓度查询命令
        if (!SendData(m_sockfd, cmd_concentration)) {
            qWarning() << "TdlasWorker: Failed to send concentration command. Stopping.";
            std::lock_guard<std::mutex> lock(m_mutex);
            m_stopped = true;
            break; // 退出循环
        }

        // 尝试接收数据
        memset(buffer, 0, sizeof(buffer));
        ssize_t bytesRead = recv(m_sockfd, buffer, sizeof(buffer), 0);

        if (bytesRead <= 0) {
            int lastError = WSAGetLastError();
            // 处理超时或非阻塞模式下的阻塞情况
            if (bytesRead < 0 && (lastError == WSAETIMEDOUT || lastError == WSAEWOULDBLOCK)) {
                // 接收超时，或非阻塞模式下无数据可读，继续循环
                qDebug() << "TdlasWorker: Receive timeout/no data, continuing. ip:" << m_ip;
                // 添加一个短暂的延时，避免CPU空转
                QThread::msleep(50);
                continue; 
            }
            // 真正的读取错误或连接关闭
            qWarning() << "TdlasWorker: Read error or connection closed. Error Code:" << lastError;
            std::lock_guard<std::mutex> lock(m_mutex);
            m_stopped = true; // 设置停止标志
            break; // 退出循环
        }
        
        // 处理接收到的数据
        unsigned char buf[8];
        memcpy(buf, buffer, bytesRead);

        // 确保数据足够解析
        if (bytesRead >= 5) { // 至少需要 buf[3] 和 buf[4] 来解析浓度
            auto res = (buf[3] << 8) | buf[4];
            int decimal_value = static_cast<int>(res);
            //qDebug() << "TdlasWorker::process: concentrationUpdated(" << decimal_value << ")";
            emit concentrationUpdated(decimal_value);
        } else {
            qWarning() << "TdlasWorker::process: Received less than 5 bytes, cannot parse concentration. Bytes received:" << bytesRead;
        }

        // 确保每次循环的间隔大约为1秒
        // 已经有timeout_ms的等待，这里补充剩余的等待时间
        QThread::msleep(TDLAS_INTERVAL - timeout_ms); 
    }

    qDebug() << "TdlasWorker::process finished loop. Cleaning up socket.";
    closesocket(m_sockfd);
    m_sockfd = INVALID_SOCKET;
    WSACleanup();

    emit finished();
}

void TdlasWorker::stop()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    m_stopped = true;
    qDebug() << "TdlasWorker: Stop requested.";
}

int TdlasWorker::connectToServe(const std::string& address, int port){
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        std::cerr << "Winsock initialization failed!" << std::endl;
        return -1;
    }

    SOCKET sockfd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (sockfd == INVALID_SOCKET) {
        std::cerr << "Error creating socket" << std::endl;
        WSACleanup();
        return -1;
    }

    // 如果已请求停止，则不要再尝试连接
    if (m_stopped) {
        std::cerr << "TdlasWorker: stop requested before connect" << std::endl;
        closesocket(sockfd);
        WSACleanup();
        return -1;
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(port);

    // 解析 IP 地址
    if (inet_pton(AF_INET, address.c_str(), &server_addr.sin_addr) != 1) {
        std::cerr << "TdlasWorker: invalid IP address" << std::endl;
        closesocket(sockfd);
        WSACleanup();
        return -1;
    }

    // 设置 SO_LINGER 为 0，加速关闭时释放资源
    struct linger sl; sl.l_onoff = 1; sl.l_linger = 0;
    setsockopt(sockfd, SOL_SOCKET, SO_LINGER, (const char*)&sl, sizeof(sl));

    // 使用非阻塞 connect 控制超时
    u_long nonBlocking = 1;
    if (ioctlsocket(sockfd, FIONBIO, &nonBlocking) != NO_ERROR) {
        std::cerr << "TdlasWorker: ioctlsocket(FIONBIO, 1) failed: " << WSAGetLastError() << std::endl;
        closesocket(sockfd);
        WSACleanup();
        return -1;
    }

    int ret = ::connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr));
    if (ret == SOCKET_ERROR) {
        int wsaErr = WSAGetLastError();
        if (wsaErr != WSAEWOULDBLOCK && wsaErr != WSAEINPROGRESS) {
            std::cerr << "TdlasWorker: connect immediate failure, error: " << wsaErr << std::endl;
            closesocket(sockfd);
            WSACleanup();
            return -1;
        }
        // 等待连接完成（最多 2 秒）
        fd_set writefds;
        FD_ZERO(&writefds);
        FD_SET(sockfd, &writefds);
        TIMEVAL tv; tv.tv_sec = 2; tv.tv_usec = 0;
        int sel = select(0, NULL, &writefds, NULL, &tv);
        if (sel == 0) {
            std::cerr << "TdlasWorker: connect timeout (2s)" << std::endl;
            closesocket(sockfd);
            WSACleanup();
            return -1;
        } else if (sel == SOCKET_ERROR) {
            std::cerr << "TdlasWorker: select failed while connecting, error: " << WSAGetLastError() << std::endl;
            closesocket(sockfd);
            WSACleanup();
            return -1;
        }
        // 检查连接是否成功
        int so_error = 0; int optLen = sizeof(so_error);
        if (getsockopt(sockfd, SOL_SOCKET, SO_ERROR, (char*)&so_error, &optLen) == SOCKET_ERROR || so_error != 0) {
            std::cerr << "TdlasWorker: connect failed, SO_ERROR: " << (so_error ? so_error : WSAGetLastError()) << std::endl;
            closesocket(sockfd);
            WSACleanup();
            return -1;
        }
    }

    // 还原为阻塞模式，后续 recv/send 使用既有超时配置
    u_long blocking = 0; ioctlsocket(sockfd, FIONBIO, &blocking);

    return sockfd;
}

std::vector<uint8_t> TdlasWorker::hexDecode(const std::string& hexString){
    std::vector<uint8_t> result;
    if (hexString.length() % 2 != 0) {
        throw std::invalid_argument("Invalid hex string length");
    }

    for (size_t i = 0; i < hexString.length(); i += 2) {
        std::string byteString = hexString.substr(i, 2);
        unsigned int byte;
        std::stringstream ss;
        ss << std::hex << byteString;
        ss >> byte;
        result.push_back(static_cast<uint8_t>(byte));
    }

    return result;
}

bool TdlasWorker::SendData(SOCKET sockfd, const std::string& hexString){
    std::vector<uint8_t> message;
    try {
        message = hexDecode(hexString);
    } catch (const std::exception& e) {
        std::cerr << "Error decoding hex string: " << e.what() << std::endl;
        return false;
    }

    if (sockfd == INVALID_SOCKET) {
        std::cerr << "Error: Invalid socket file descriptor" << std::endl;
        return false;
    }

    ssize_t bytesSent = send(sockfd, (const char*)message.data(), message.size(), 0);
    if (bytesSent == -1) {
        std::cerr << "Error sending data" << std::endl;
        return false;
    }

    return true;
}

void TdlasWorker::turnonlaser(SOCKET sockfd) {
    SendData(sockfd, cmd_turnonLaser);
}

void TdlasWorker::turnofflaser(SOCKET sockfd) {
    SendData(sockfd, cmd_turnoffLaser);
}

void TdlasWorker::turnOnLaser() {
    qDebug() << "TdlasWorker::turnOnLaser() called, m_sockfd:" << m_sockfd;
    if (m_sockfd != INVALID_SOCKET) {
        qDebug() << "TdlasWorker: m_sockfd is valid, calling turnonlaser";
        turnonlaser(m_sockfd);
    } else {
        qWarning() << "TdlasWorker: m_sockfd is invalid (" << m_sockfd << "), cannot turn on laser";
    }
}

void TdlasWorker::turnOffLaser() {
    qDebug() << "TdlasWorker::turnOffLaser() called, m_sockfd:" << m_sockfd;
    if (m_sockfd != INVALID_SOCKET) {
        qDebug() << "TdlasWorker: m_sockfd is valid, calling turnofflaser";
        turnofflaser(m_sockfd);
    } else {
        qWarning() << "TdlasWorker: m_sockfd is invalid (" << m_sockfd << "), cannot turn off laser";
    }
}

// Q_PROPERTY getter
bool PtzDeviceCgi::gasConcentrationAlarm() const {
    return m_gasConcentrationAlarm;
}

// Modbus相关方法实现
void PtzDeviceCgi::mvSetVoltage(float value) {
    if (m_modbusWorker) {
        QMetaObject::invokeMethod(m_modbusWorker, "sendVoltageData", Qt::QueuedConnection, Q_ARG(float, value));
    } else {
        qWarning() << "PtzDeviceCgi::mvSetVoltage: ModbusWorker未初始化";
    }
}

bool PtzDeviceCgi::mvSendModbusData(const QString& ip, int port, const QVariantList& data) {
    // 将QVariantList转换为std::vector<unsigned char>
    std::vector<unsigned char> modbusData;
    for (const QVariant& item : data) {
        bool ok;
        int value = item.toInt(&ok);
        if (ok) {
            modbusData.push_back(static_cast<unsigned char>(value));
        }
    }
    
    // 使用现有的ModbusWorker在子线程中发送数据
    if (m_modbusWorker) {
        // 创建一个lambda来发送数据，直接使用传入的参数
        QMetaObject::invokeMethod(m_modbusWorker, [this, ip, port, modbusData]() {
            bool success = m_modbusWorker->sendDataOverTCP(ip.toStdString().c_str(), port, modbusData);
            emit m_modbusWorker->voltageDataSent(success);
        }, Qt::QueuedConnection);
        return true; // 返回true表示请求已发送
    } else {
        qWarning() << "ModbusWorker not initialized";
        return false;
    }
}
// ModbusWorker CRC表定义
const unsigned char ModbusWorker::auchCRCHi[] = {
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01,
0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01,
0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81,
0x40
};

const unsigned char ModbusWorker::auchCRCLo[] = {
0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06, 0x07, 0xC7, 0x05, 0xC5, 0xC4,
0x04, 0xCC, 0x0C, 0x0D, 0xCD, 0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A, 0x1E, 0xDE, 0xDF, 0x1F, 0xDD,
0x1D, 0x1C, 0xDC, 0x14, 0xD4, 0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3, 0xF2, 0x32, 0x36, 0xF6, 0xF7,
0x37, 0xF5, 0x35, 0x34, 0xF4, 0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29, 0xEB, 0x2B, 0x2A, 0xEA, 0xEE,
0x2E, 0x2F, 0xEF, 0x2D, 0xED, 0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60, 0x61, 0xA1, 0x63, 0xA3, 0xA2,
0x62, 0x66, 0xA6, 0xA7, 0x67, 0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68, 0x78, 0xB8, 0xB9, 0x79, 0xBB,
0x7B, 0x7A, 0xBA, 0xBE, 0x7E, 0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71, 0x70, 0xB0, 0x50, 0x90, 0x91,
0x51, 0x93, 0x53, 0x52, 0x92, 0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B, 0x99, 0x59, 0x58, 0x98, 0x88,
0x48, 0x49, 0x89, 0x4B, 0x8B, 0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42, 0x43, 0x83, 0x41, 0x81, 0x80,
0x40
};
// ModbusWorker类实现
ModbusWorker::ModbusWorker(QString ip, int port, PtzDeviceCgi* ptzCgiParent, QObject* parent) // <--- 修改这里
    : QObject(parent), m_ip(ip), m_port(port), m_isRunning(false), m_parent(ptzCgiParent) // <--- 修改这里
{
}

ModbusWorker::~ModbusWorker()
{
    stop();
}

void ModbusWorker::process()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    qDebug() << "ModbusWorker::process";
    if (m_isRunning) {
        return;
    }
    
    m_isRunning = true;
}

void ModbusWorker::stop()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    m_isRunning = false;
    emit finished();
}

void ModbusWorker::sendVoltageData(float value)
{
    // 在停止过程中忽略新的发送请求，避免阻塞退出
    if (!m_isRunning.load()) {
        emit voltageDataSent(false);
        return;
    }

    //qDebug() << "ModbusWorker::sendVoltageData";
    std::vector<unsigned char> data = setVoltage(value);
    
    unsigned short crc = ModBusCRC16(data.data(), static_cast<unsigned short>(data.size()));
    
    data.push_back(static_cast<unsigned char>((crc >> 8) & 0xFF));  // CRC高位
    data.push_back(static_cast<unsigned char>(crc & 0xFF));         // CRC低位

    bool success = sendDataOverTCP(m_ip.toStdString().c_str(), m_port, data);
    
    // 如果发送失败，发送设备异常报警 - 使用QueuedConnection确保线程安全
    if (!success && m_parent) {
        QMetaObject::invokeMethod(m_parent, "addDeviceExceptionAlarm", Qt::QueuedConnection,
                                 Q_ARG(QString, "002"), Q_ARG(QString, "通信异常"), Q_ARG(QString, "Modbus模块"));
    }
    
    emit voltageDataSent(success);
}

unsigned short ModbusWorker::ModBusCRC16(const unsigned char* puchMsg, unsigned short usDataLen)
{
    if (puchMsg == nullptr || usDataLen == 0) {
        return 0xFFFF;
    }

    unsigned char uchCRCHi = 0xFF;
    unsigned char uchCRCLo = 0xFF;
    unsigned int uIndex;

    while (usDataLen--) {
        uIndex = uchCRCHi ^ *puchMsg++;
        uchCRCHi = uchCRCLo ^ auchCRCHi[uIndex];
        uchCRCLo = auchCRCLo[uIndex];
    }

    return (static_cast<unsigned short>(uchCRCHi) << 8) | uchCRCLo;
}

std::vector<unsigned char> ModbusWorker::setVoltage(float value) // 输入为mA
{
    std::vector<unsigned char> data = { 0x01, 0x06, 0x00, 0x0A };
    uint16_t val = value <= 20 && value >= 4 ? value * 1000 : 4000;
    unsigned char hi = static_cast<unsigned char>(val >> 8);
    unsigned char lo = static_cast<unsigned char>(val & 0xFF);
    data.push_back(hi);
    data.push_back(lo);
    return data;
}

bool ModbusWorker::sendDataOverTCP(const char* ip, int port, const std::vector<unsigned char>& data) {
    // 如果已请求停止，直接返回，避免阻塞退出
    if (!m_isRunning.load()) {
        return false;
    }

    // 获取网络连接锁
    NetworkConnectionManager* connManager = NetworkConnectionManager::instance();
    if (!connManager->acquireConnectionLock(QString(ip), port, "ModbusWorker")) {
        // 连接被占用时直接返回true，避免上层频繁报错
        return true;
    }
    
    // 确保在函数结束时释放锁
    auto releaseLock = [connManager, ip, port]() {
        connManager->releaseConnectionLock(QString(ip), port, "ModbusWorker");
    };
    
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        qWarning() << "ModbusWorker::sendDataOverTCP: WSA初始化失败！错误码：" << WSAGetLastError();
        releaseLock();
        return false;
    }

    SOCKET clientSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (clientSock == INVALID_SOCKET) {
        qWarning() << "ModbusWorker::sendDataOverTCP: 创建socket失败！错误码：" << WSAGetLastError();
        WSACleanup();
        releaseLock();
        return false;
    }

    // 使关闭更快（避免 TIME_WAIT 阻塞）
    LINGER lingerOpt; lingerOpt.l_onoff = 1; lingerOpt.l_linger = 0;
    setsockopt(clientSock, SOL_SOCKET, SO_LINGER, (const char*)&lingerOpt, sizeof(lingerOpt));

    // 设置读写超时
    DWORD rw_timeout_ms = 3000; // 3秒超时
    setsockopt(clientSock, SOL_SOCKET, SO_RCVTIMEO, (const char*)&rw_timeout_ms, sizeof(rw_timeout_ms));
    setsockopt(clientSock, SOL_SOCKET, SO_SNDTIMEO, (const char*)&rw_timeout_ms, sizeof(rw_timeout_ms));

    // 设置服务器地址
    sockaddr_in serverAddr; serverAddr.sin_family = AF_INET;
    if (InetPtonA(AF_INET, ip, &serverAddr.sin_addr.s_addr) != 1) {
        qWarning() << "ModbusWorker::sendDataOverTCP: IP地址转换失败！错误码：" << WSAGetLastError();
        closesocket(clientSock); WSACleanup(); releaseLock();
        return false;
    }
    serverAddr.sin_port = htons(static_cast<u_short>(port));

    // 非阻塞connect + select 实现连接超时控制
    u_long nonblock = 1; ioctlsocket(clientSock, FIONBIO, &nonblock);
    int ret = ::connect(clientSock, (SOCKADDR*)&serverAddr, sizeof(serverAddr));
    if (ret == SOCKET_ERROR) {
        int err = WSAGetLastError();
        if (err == WSAEWOULDBLOCK || err == WSAEINPROGRESS || err == WSAEINVAL) {
            fd_set writefds; FD_ZERO(&writefds); FD_SET(clientSock, &writefds);
            timeval tv; tv.tv_sec = 2; tv.tv_usec = 0; // 2秒连接超时
            ret = select(0, NULL, &writefds, NULL, &tv);
            if (ret <= 0) {
                qWarning() << "ModbusWorker::sendDataOverTCP: 连接超时或select错误！ret=" << ret << " err=" << WSAGetLastError();
                closesocket(clientSock); WSACleanup(); releaseLock();
                return false;
            }
            int so_error = 0; int optlen = sizeof(so_error);
            if (getsockopt(clientSock, SOL_SOCKET, SO_ERROR, (char*)&so_error, &optlen) == SOCKET_ERROR || so_error != 0) {
                qWarning() << "ModbusWorker::sendDataOverTCP: 连接失败！SO_ERROR=" << so_error;
                closesocket(clientSock); WSACleanup(); releaseLock();
                return false;
            }
        } else {
            qWarning() << "ModbusWorker::sendDataOverTCP: 连接服务器失败！错误码：" << err;
            closesocket(clientSock); WSACleanup(); releaseLock();
            return false;
        }
    }

    // 恢复阻塞模式
    nonblock = 0; ioctlsocket(clientSock, FIONBIO, &nonblock);

    // 停止时尽早退出
    if (!m_isRunning.load()) {
        closesocket(clientSock); WSACleanup(); releaseLock();
        return false;
    }

    int bytesSent = send(clientSock, (const char*)data.data(), (int)data.size(), 0);
    if (bytesSent == SOCKET_ERROR) {
        qWarning() << "ModbusWorker::sendDataOverTCP: 发送数据失败！错误码：" << WSAGetLastError();
        closesocket(clientSock); WSACleanup(); releaseLock();
        return false;
    }

    closesocket(clientSock);
    WSACleanup();
    releaseLock();
    return true;
}

void PtzDeviceCgi::addDeviceExceptionAlarm(const QString& exceptionCode, const QString& exceptionName, const QString& exceptionComponent)
{
    qWarning() << "PTZ device exception detected:" << exceptionName << "for device" << QString::fromStdString(deviceName_) << "at" << QString::fromStdString(ip_);
   // qWarning() << "Device ID:" << QString::fromStdString(device_id_) << "Device Name:" << QString::fromStdString(deviceName_);
    // 如果设备ID为空，使用设备名称作为设备编号
    //QString deviceIdentifier = device_id_;
    // 创建设备异常报警数据
    AlarmData alarmData = {
        DEVICE_FAULT_ALARM,  // 报警模式：设备异常报警
        "",            // 不需要图片
        "",            // 不需要图片
        QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss"),
        "", "", "", "",  // 气体报警字段为空，包括距离字段
        QString::fromStdString(device_id_),  // 设备编号显示为"设备名称(设备ID)"或仅设备名称
        QString::fromStdString(deviceName_),  // 设备名称
        exceptionCode,     // 异常类型编号
        exceptionName,     // 异常类型名称
        exceptionComponent // 异常部件
    };
    QMetaObject::invokeMethod(AlarmModel::instance(), [alarmData]() {
        AlarmModel::instance()->addAlarm(alarmData);
    }, Qt::QueuedConnection);
}

// TOFWorker实现
TOFWorker::TOFWorker(QString ip, int port, PtzDeviceCgi* ptzCgiParent, QObject* parent) // <--- 修改这里
    : QObject(parent), m_ip(ip), m_port(port), m_isRunning(false), m_parent(ptzCgiParent) // <--- 修改这里
{
}

TOFWorker::~TOFWorker()
{
    stop();
}

void TOFWorker::process()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    //qDebug() << "TOFWorker::process";
    if (m_isRunning) {
        return;
    }
    
    m_isRunning = true;
    
    // 启动持续测距
    QMetaObject::invokeMethod(this, &TOFWorker::startContinuousRanging, Qt::QueuedConnection);
}

void TOFWorker::stop()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    m_isRunning = false;
    emit finished();
}

void TOFWorker::startContinuousRanging()
{
    //qDebug() << "TOFWorker::startContinuousRanging";
    // 启动持续测距循环
    QTimer* rangingTimer = new QTimer(this);
    rangingTimer->setInterval(1000); // 每秒测距一次
    
    connect(rangingTimer, &QTimer::timeout, this, [this, rangingTimer]() {
        // 检查是否还在运行
        {
            std::lock_guard<std::mutex> lock(m_mutex);
            if (!m_isRunning) {
                rangingTimer->stop();
                rangingTimer->deleteLater();
                return;
            }
        }
        
        // 检查网络连接是否可用
        NetworkConnectionManager* connManager = NetworkConnectionManager::instance();
        if (connManager->canAcquireConnectionLock(getIp(), getPort(), "TOFWorker")) {
            qDebug() << "TOFWorker::sendSingleRangingCmd";
            // 执行单次测距
            sendSingleRangingCmd();
        } else {
            //qDebug() << "TOFWorker: 网络连接被占用，跳过本次测距";
        }
    });
    
    rangingTimer->start();
}

void TOFWorker::sendSingleRangingCmd()
{
    // 检查是否还在运行
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (!m_isRunning) {
            return;
        }
    }
    
    std::vector<unsigned char> cmd = createSingleRangingCmd();
    
    std::vector<unsigned char> reply;
    
    if (sendDataAndReceiveReply(m_ip.toStdString().c_str(), m_port, cmd, reply)) {
        float distance;
        if (parseDistanceReply(reply, distance)) {
            if(distance < 6000) 
                emit distanceUpdated(distance);
            qDebug() << "TOFWorker::sendSingleRangingCmd: distanceUpdated(" << distance << ")";
        } else if (reply.size() >= 7) {
            parseErrorCode(reply[6]);
            emit rangingError("Ranging failed");
        }
    } else {
        //qWarning() << "TOFWorker::sendSingleRangingCmd: sendDataAndReceiveReply失败";
        // 如果发送失败，发送设备异常报警
        if (m_parent) {
            QMetaObject::invokeMethod(m_parent, "addDeviceExceptionAlarm", Qt::QueuedConnection,
                                     Q_ARG(QString, "003"), Q_ARG(QString, "通信异常"), Q_ARG(QString, "TOF模块"));
        }
        emit rangingError("Failed to send ranging command");
    }
}

void TOFWorker::sendContinuousRangingCmd()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    
    std::vector<unsigned char> cmd = createContinuousRangingCmd();
    std::vector<unsigned char> reply;
    
    if (sendDataAndReceiveReply(m_ip.toStdString().c_str(), m_port, cmd, reply)) {
        float distance;
        if (parseDistanceReply(reply, distance)) {
            emit distanceUpdated(distance);
        } else if (reply.size() >= 7) {
            parseErrorCode(reply[6]);
            emit rangingError("Ranging failed");
        }
    } else {
        emit rangingError("Failed to send ranging command");
    }
}

void TOFWorker::sendStopRangingCmd()
{
    std::lock_guard<std::mutex> lock(m_mutex);
    
    std::vector<unsigned char> cmd = createStopRangingCmd();
    std::vector<unsigned char> reply;
    
    sendDataAndReceiveReply(m_ip.toStdString().c_str(), m_port, cmd, reply);
}

std::vector<unsigned char> TOFWorker::createSingleRangingCmd()
{
    return { 0x55, 0xAA, 0x88, 0xFF, 0xFF, 0xFF, 0xFF, 0x84 };
}

std::vector<unsigned char> TOFWorker::createContinuousRangingCmd()
{
    return { 0x55, 0xAA, 0x89, 0xFF, 0xFF, 0xFF, 0xFF, 0x85 };
}

std::vector<unsigned char> TOFWorker::createStopRangingCmd()
{
    return { 0x55, 0xAA, 0x8E, 0xFF, 0xFF, 0xFF, 0xFF, 0x8A };
}

bool TOFWorker::parseDistanceReply(const std::vector<unsigned char>& reply, float& distance)
{
    if (reply.size() != 8) {
        return false;
    }
    if (reply[0] != 0x55 || reply[1] != 0xAA || reply[2] != 0x88) {
        return false;
    }
    unsigned char sta = reply[3];
    if (sta == 0) {
        return false;
    }
    unsigned short disRaw = (reply[5] << 8) | reply[6];
    distance = disRaw / 10.0f;
    return true;
}

void TOFWorker::parseErrorCode(unsigned char errCode)
{
    switch (errCode) {
    case 0x00:
    case 0x18:
        emit rangingError("未接收到回波信号");
        break;
    case 0x16:
        emit rangingError("超出测量范围（低于最小值）");
        break;
    default:
        if (errCode >= 0x00 && errCode <= 0x07) {
            emit rangingError("硬件错误");
        }
        else {
            emit rangingError(QString("未知错误码 0x%1").arg(errCode, 0, 16));
        }
        break;
    }
}

bool TOFWorker::sendDataAndReceiveReply(const char* ip, int port, const std::vector<unsigned char>& data, std::vector<unsigned char>& reply) {
    // 获取网络连接锁
    //qDebug() << "TOFWorker::sendDataAndReceiveReply: ip" << ip << "port" << port;   
    NetworkConnectionManager* connManager = NetworkConnectionManager::instance();
    if (!connManager->acquireConnectionLock(QString(ip), port, "TOFWorker")) {
        //qWarning() << "TOFWorker::sendDataAndReceiveReply: 无法获取网络连接锁，连接被占用";
        return false;
    }
    
    // 确保在函数结束时释放锁
    auto releaseLock = [connManager, ip, port]() {
        connManager->releaseConnectionLock(QString(ip), port, "TOFWorker");
    };
    
    //qDebug() << "TOFWorker::sendDataAndReceiveReply: ip" << ip << "port" << port;
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        qWarning() << "TOFWorker::sendDataAndReceiveReply: WSA初始化失败！错误码：" << WSAGetLastError();
        releaseLock();
        return false;
    }

    SOCKET clientSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (clientSock == INVALID_SOCKET) {
        qWarning() << "TOFWorker::sendDataAndReceiveReply: 创建socket失败！错误码：" << WSAGetLastError();
        WSACleanup();
        releaseLock();
        return false;
    }

    // 设置连接超时
    DWORD timeout = 3000; // 3秒超时
    setsockopt(clientSock, SOL_SOCKET, SO_RCVTIMEO, (const char*)&timeout, sizeof(timeout));
    setsockopt(clientSock, SOL_SOCKET, SO_SNDTIMEO, (const char*)&timeout, sizeof(timeout));

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;

    if (InetPtonA(AF_INET, ip, &serverAddr.sin_addr.s_addr) != 1) {
        qWarning() << "TOFWorker::sendDataAndReceiveReply: IP地址转换失败！错误码：" << WSAGetLastError();
        closesocket(clientSock);
        WSACleanup();
        releaseLock();
        return false;
    }

    serverAddr.sin_port = htons(static_cast<u_short>(port));

    // 使用非阻塞 connect + select 超时，避免关机时长时间阻塞
    if (!m_isRunning) {
        qWarning() << "TOFWorker::sendDataAndReceiveReply: 停止中，取消连接请求";
        closesocket(clientSock);
        WSACleanup();
        releaseLock();
        return false;
    }

    // 设置 SO_LINGER 为 0，加速关闭时释放资源
    struct linger sl;
    sl.l_onoff = 1;
    sl.l_linger = 0;
    setsockopt(clientSock, SOL_SOCKET, SO_LINGER, (const char*)&sl, sizeof(sl));

    // 设置为非阻塞
    u_long nonBlocking = 1;
    if (ioctlsocket(clientSock, FIONBIO, &nonBlocking) != NO_ERROR) {
        qWarning() << "TOFWorker::sendDataAndReceiveReply: 设置非阻塞失败！错误码：" << WSAGetLastError();
        closesocket(clientSock);
        WSACleanup();
        releaseLock();
        return false;
    }

    int connectRet = ::connect(clientSock, (SOCKADDR*)&serverAddr, sizeof(serverAddr));
    if (connectRet == SOCKET_ERROR) {
        int wsaErr = WSAGetLastError();
        if (wsaErr != WSAEWOULDBLOCK && wsaErr != WSAEINPROGRESS) {
            qWarning() << "TOFWorker::sendDataAndReceiveReply: 连接服务器失败(立即错误)！错误码：" << wsaErr;
            closesocket(clientSock);
            WSACleanup();
            releaseLock();
            return false;
        }

        // 等待连接完成（最多2秒）
        fd_set writefds;
        FD_ZERO(&writefds);
        FD_SET(clientSock, &writefds);
        TIMEVAL tv;
        tv.tv_sec = 2;
        tv.tv_usec = 0;

        int selRet = select(0, NULL, &writefds, NULL, &tv);
        if (selRet == 0) {
            qWarning() << "TOFWorker::sendDataAndReceiveReply: 连接超时(2s)！";
            closesocket(clientSock);
            WSACleanup();
            releaseLock();
            return false;
        } else if (selRet == SOCKET_ERROR) {
            qWarning() << "TOFWorker::sendDataAndReceiveReply: select 等待失败！错误码：" << WSAGetLastError();
            closesocket(clientSock);
            WSACleanup();
            releaseLock();
            return false;
        }

        // 检查连接结果
        int so_error = 0;
        int optLen = sizeof(so_error);
        if (getsockopt(clientSock, SOL_SOCKET, SO_ERROR, (char*)&so_error, &optLen) == SOCKET_ERROR || so_error != 0) {
            qWarning() << "TOFWorker::sendDataAndReceiveReply: 连接失败(SO_ERROR)！错误码：" << (so_error ? so_error : WSAGetLastError());
            closesocket(clientSock);
            WSACleanup();
            releaseLock();
            return false;
        }
    }

    // 还原为阻塞模式，方便后续 send/recv 直接使用超时
    u_long blocking = 0;
    ioctlsocket(clientSock, FIONBIO, &blocking);
    int bytesSent = send(clientSock, (const char*)data.data(), data.size(), 0);
    if (bytesSent == SOCKET_ERROR) {
        qWarning() << "TOFWorker::sendDataAndReceiveReply: 发送数据失败！错误码：" << WSAGetLastError();
        closesocket(clientSock);
        WSACleanup();
        releaseLock();
        return false;
    }

    unsigned char buffer[8];
    int bytesReceived = recv(clientSock, (char*)buffer, sizeof(buffer), 0);
    if (bytesReceived == SOCKET_ERROR) {
        qWarning() << "TOFWorker::sendDataAndReceiveReply: 接收数据失败！错误码：" << WSAGetLastError();
        closesocket(clientSock);
        WSACleanup();
        releaseLock();
        return false;
    }
    
    reply.assign(buffer, buffer + bytesReceived);

    closesocket(clientSock);
    WSACleanup();
    releaseLock();
    return true;
}

void PtzDeviceCgi::initializeTofWorker(const QString& ip, int port) {
    emit initializeTofWorkerInternalRequested(ip, port);
}

void PtzDeviceCgi::doInitializeTofWorkerInternal(const QString& ip, int intPort) {
    // 原始的初始化 TOFWorker 的逻辑从这里开始
    if (m_tofWorker && m_tofThread) {
        m_tofWorker->stop();
        m_tofThread->quit();
        m_tofThread->wait(1000);
        m_tofWorker = nullptr;
        m_tofThread = nullptr;
    }

    m_tofThread = new QThread(this); // 父对象为 PtzDeviceCgi
    // 将 PtzDeviceCgi 的 this 指针作为 ptzCgiParent 传入，QObject 的父对象仍为 nullptr
    m_tofWorker = new TOFWorker(ip, intPort, this, nullptr); // <--- 关键修改

    m_tofWorker->moveToThread(m_tofThread);

    connect(m_tofThread, &QThread::started, m_tofWorker, &TOFWorker::process);
    connect(m_tofWorker, &TOFWorker::finished, m_tofThread, &QThread::quit);
    connect(m_tofWorker, &TOFWorker::finished, m_tofWorker, &QObject::deleteLater);
    connect(m_tofThread, &QThread::finished, m_tofThread, &QThread::deleteLater);

    connect(m_tofWorker, &TOFWorker::distanceUpdated, this, [this](float distance) {
        m_currentTofDistance = distance;  // 更新当前TOF距离
        emit tofDistanceUpdated(QString::fromStdString(device_id_), distance);
    });
    connect(m_tofWorker, &TOFWorker::rangingError, this, [this](QString errorMessage) {
        emit tofRangingError(QString::fromStdString(device_id_), errorMessage);
    });

    m_tofThread->start();
    //qDebug() << "TOFWorker initialized with IP:" << ip << "Port:" << intPort;
}

void PtzDeviceCgi::initializeTofWorkerFromDevice(const QString& deviceId) {
    // 从设备模型获取TOF配置
    DeviceInfo deviceInfo = DeviceModel::instance()->getDevice(deviceId);
    if (!deviceInfo.tofIp.isEmpty() && deviceInfo.tofPort > 0) {
        initializeTofWorker(deviceInfo.tofIp, deviceInfo.tofPort);
    } else {
        qWarning() << "No TOF configuration found for device" << deviceId;
    }
}

void PtzDeviceCgi::mvSendSingleRangingCmd() {
    if (m_tofWorker) {
        QMetaObject::invokeMethod(m_tofWorker, &TOFWorker::sendSingleRangingCmd, Qt::QueuedConnection);
    } else {
        qWarning() << "PtzDeviceCgi::mvSendSingleRangingCmd: TOFWorker未初始化";
    }
}

void PtzDeviceCgi::mvSendContinuousRangingCmd() {
    if (m_tofWorker) {
        QMetaObject::invokeMethod(m_tofWorker, &TOFWorker::sendContinuousRangingCmd, Qt::QueuedConnection);
    } else {
        qWarning() << "TOFWorker not initialized";
    }
}

void PtzDeviceCgi::mvSendStopRangingCmd() {
    if (m_tofWorker) {
        QMetaObject::invokeMethod(m_tofWorker, &TOFWorker::sendStopRangingCmd, Qt::QueuedConnection);
    } else {
        qWarning() << "TOFWorker not initialized";
    }
}

// ==================== NetworkConnectionManager 实现 ====================

NetworkConnectionManager* NetworkConnectionManager::m_instance = nullptr;

NetworkConnectionManager* NetworkConnectionManager::instance()
{
    if (!m_instance) {
        m_instance = new NetworkConnectionManager();
    }
    return m_instance;
}

NetworkConnectionManager::NetworkConnectionManager(QObject* parent)
    : QObject(parent)
{
}

NetworkConnectionManager::~NetworkConnectionManager()
{
}

bool NetworkConnectionManager::acquireConnectionLock(const QString& ip, int port, const QString& workerType)
{
    QMutexLocker locker(&m_mutex);
    
    QString connectionKey = QString("%1:%2").arg(ip).arg(port);
    
    // 检查是否已经有其他worker在使用这个连接
    if (m_activeConnections.contains(connectionKey)) {
        QString currentWorker = m_activeConnections[connectionKey];
        //qWarning() << "NetworkConnectionManager: 连接" << connectionKey << "已被" << currentWorker << "占用，拒绝" << workerType << "的请求";
        return false;
    }
    
    // 获取连接锁
    m_activeConnections[connectionKey] = workerType;
    //qDebug() << "NetworkConnectionManager: " << workerType << "获取了连接" << connectionKey << "的锁";
    return true;
}

void NetworkConnectionManager::releaseConnectionLock(const QString& ip, int port, const QString& workerType)
{
    QMutexLocker locker(&m_mutex);
    
    QString connectionKey = QString("%1:%2").arg(ip).arg(port);
    
    if (m_activeConnections.contains(connectionKey)) {
        QString currentWorker = m_activeConnections[connectionKey];
        if (currentWorker == workerType) {
            m_activeConnections.remove(connectionKey);
            //qDebug() << "NetworkConnectionManager: " << workerType << "释放了连接" << connectionKey << "的锁";
        } else {
            qWarning() << "NetworkConnectionManager: 尝试释放连接" << connectionKey << "的锁，但当前占用者是" << currentWorker << "而不是" << workerType;
        }
    } else {
        qWarning() << "NetworkConnectionManager: 尝试释放不存在的连接锁" << connectionKey;
    }
}

bool NetworkConnectionManager::canAcquireConnectionLock(const QString& ip, int port, const QString& workerType)
{
    QMutexLocker locker(&m_mutex);
    
    QString connectionKey = QString("%1:%2").arg(ip).arg(port);
    
    // 检查是否已经有其他worker在使用这个连接
    if (m_activeConnections.contains(connectionKey)) {
        QString currentWorker = m_activeConnections[connectionKey];
        return currentWorker == workerType; // 只有同一个worker可以重复获取
    }
    
    return true; // 没有占用，可以获取
}

void PtzDeviceCgi::mvSetCruiseScan(){
    // 使用设备的巡航组启动巡航
    QVector<int> points = presetGroups[groupInfo.cruise];
    if (points.isEmpty()) {
        return;
    }
    // 重置并启动
    m_cruisePausedDueToAlarm = false;
    presetIdx = 0;
    startCruiseWithPoints(points);
}

Q_INVOKABLE void PtzDeviceCgi::mvLoadNetworkConfig(){
    // 只发信号，不做耗时工作
    emit mvLoadNetworkConfigRequested();
}

void PtzDeviceCgi::doMvLoadNetworkConfig(){
    if (ip_.empty() || uid_.empty()) {
        emit networkConfigLoadFailed("IP或UID为空");
        return;
    }
    qDebug() << "开始加载网络配置";
    std::map<std::string, std::string> config;
    bool success = GetNetworkConfig(ip_, uid_, config);
    
    if (success) {
        QVariantMap qConfig;
        for (const auto& pair : config) {
            qConfig[QString::fromStdString(pair.first)] = QString::fromStdString(pair.second);
        }
        emit networkConfigLoaded(qConfig);
    } else {
        emit networkConfigLoadFailed("获取网络配置失败");
    }
}

// 激光控制公共方法
void PtzDeviceCgi::mvTurnOnLaser() {
    qDebug() << "mvTurnOnLaser()";
    emit mvTurnOnLaserRequested();
}

void PtzDeviceCgi::mvTurnOffLaser() {
    emit mvTurnOffLaserRequested();
}

// 激光控制私有槽函数
void PtzDeviceCgi::doMvTurnOnLaser() {
    qDebug() << "doMvTurnOnLaser()";
    if (m_tdlasWorker) {
        qDebug() << "m_tdlasWorker is not null, attempting to invoke turnOnLaser";
        // 使用QMetaObject::invokeMethod调用TdlasWorker的公共方法
        bool success = QMetaObject::invokeMethod(m_tdlasWorker, "turnOnLaser", Qt::DirectConnection);
        if (success) {
            qDebug() << "激光已打开 - invokeMethod成功";
        } else {
            qWarning() << "调用TdlasWorker::turnOnLaser失败";
        }
    } else {
        qWarning() << "PtzDeviceCgi::doMvTurnOnLaser: TdlasWorker未初始化";
    }
}

void PtzDeviceCgi::doMvTurnOffLaser() {
    qDebug() << "doMvTurnOffLaser()";
    if (m_tdlasWorker) {
        qDebug() << "m_tdlasWorker is not null, attempting to invoke turnOffLaser";
        // 使用QMetaObject::invokeMethod调用TdlasWorker的公共方法
        bool success = QMetaObject::invokeMethod(m_tdlasWorker, "turnOffLaser", Qt::DirectConnection);
        if (success) {
            qDebug() << "激光已关闭 - invokeMethod成功";
        } else {
            qWarning() << "调用TdlasWorker::turnOffLaser失败";
        }
    } else {
        qWarning() << "PtzDeviceCgi::doMvTurnOffLaser: TdlasWorker未初始化";
    }
}

// 设备状态保存和恢复方法实现
void PtzDeviceCgi::saveDeviceStates(const QString& deviceId) {
    // 获取设备模型实例
    DeviceModel* deviceModel = DeviceModel::instance();
    if (!deviceModel) {
        qWarning() << "DeviceModel instance not available";
        return;
    }
    
    // 获取当前设备的所有状态
    bool laserState = deviceModel->getDeviceLaserState(deviceId);
    bool wiperState = deviceModel->getDeviceWiperState(deviceId);
    bool flapState = deviceModel->getDeviceFlapState(deviceId);
    
    qDebug() << "Saving device states for" << deviceId 
             << "- Laser:" << laserState 
             << "- Wiper:" << wiperState 
             << "- Flap:" << flapState;
}

void PtzDeviceCgi::restoreDeviceStates(const QString& deviceId) {
    // 获取设备模型实例
    DeviceModel* deviceModel = DeviceModel::instance();
    if (!deviceModel) {
        qWarning() << "DeviceModel instance not available";
        return;
    }
    
    // 获取保存的设备状态
    bool laserState = deviceModel->getDeviceLaserState(deviceId);
    bool wiperState = deviceModel->getDeviceWiperState(deviceId);
    bool flapState = deviceModel->getDeviceFlapState(deviceId);
    
    qDebug() << "Restoring device states for" << deviceId 
             << "- Laser:" << laserState 
             << "- Wiper:" << wiperState 
             << "- Flap:" << flapState;
    
    // 根据保存的状态恢复设备
    if (laserState) {
        mvTurnOnLaser();
    } else {
        mvTurnOffLaser();
    }
    
    // 恢复雨刷状态
    mvSetWiper(wiperState);
    
    // 恢复红外挡板状态
    mvSetInfFlap(flapState);
}

void PtzDeviceCgi::saveDeviceState(const QString& deviceId, const QString& stateType, bool state) {
    // 获取设备模型实例
    DeviceModel* deviceModel = DeviceModel::instance();
    if (!deviceModel) {
        qWarning() << "DeviceModel instance not available";
        return;
    }
    
    // 根据状态类型保存对应的状态
    if (stateType == "laser") {
        deviceModel->setDeviceLaserState(deviceId, state);
    } else if (stateType == "wiper") {
        deviceModel->setDeviceWiperState(deviceId, state);
    } else if (stateType == "flap") {
        deviceModel->setDeviceFlapState(deviceId, state);
    } else {
        qWarning() << "Unknown state type:" << stateType;
    }
    
    qDebug() << "Saved device state for" << deviceId << "- Type:" << stateType << "- State:" << state;
}

bool PtzDeviceCgi::getDeviceState(const QString& deviceId, const QString& stateType) {
    // 获取设备模型实例
    DeviceModel* deviceModel = DeviceModel::instance();
    if (!deviceModel) {
        qWarning() << "DeviceModel instance not available";
        return false;
    }
    
    // 根据状态类型获取对应的状态
    if (stateType == "laser") {
        return deviceModel->getDeviceLaserState(deviceId);
    } else if (stateType == "wiper") {
        return deviceModel->getDeviceWiperState(deviceId);
    } else if (stateType == "flap") {
        return deviceModel->getDeviceFlapState(deviceId);
    } else {
        qWarning() << "Unknown state type:" << stateType;
        return false;
    }
}

// 设置线扫和轨迹扫描状态的方法实现
void PtzDeviceCgi::setLineScanActive(bool active)
{
    m_lineScanActive = active;
    qDebug() << "Line scan active state set to:" << active;
}

void PtzDeviceCgi::setTrajectoryScanActive(bool active)
{
    m_trajectoryScanActive = active;
    qDebug() << "Trajectory scan active state set to:" << active;
}

// 处理前端扫描模式变化通知的方法
void PtzDeviceCgi::currentScanModeChanged(int scanMode)
{
    // 更新当前扫描模式
    m_previousScanMode = scanMode;
    qDebug() << "Current scan mode updated from frontend:" << scanMode;
    
    // 同步更新设备模型中的扫描状态
    updateDeviceModelScanMode(scanMode);
}

// 更新设备模型中的扫描状态
void PtzDeviceCgi::updateDeviceModelScanMode(int scanMode)
{
    // 获取当前设备ID
    if (!device_id_.empty()) {
        // 更新设备模型中的扫描状态
        QString deviceId = QString::fromStdString(device_id_);
        DeviceModel::instance()->setDeviceScanMode(deviceId, scanMode);
        qDebug() << "PtzDeviceCgi: Updated device" << QString::fromStdString(device_id_) << "scan mode to:" << scanMode;
    } else {
        qWarning() << "PtzDeviceCgi: Cannot update device scan mode, device_id is empty";
    }
}

bool PtzDeviceCgi::isLineScanActive() const
{
    return m_lineScanActive;
}

bool PtzDeviceCgi::isTrajectoryScanActive() const
{
    return m_trajectoryScanActive;
}

// 气体报警时的扫描控制方法实现
void PtzDeviceCgi::stopAllScansForAlarm()
{
    // 如果已经因为报警而暂停了扫描，则不再重复处理
    if (m_scanPausedDueToAlarm) {
        return;
    }
    
    // 停止云台转动
    doMvTurnStop();
    
    // 检查并停止线扫
    if (m_lineScanActive) {
        m_previousScanMode = 1; // 线扫
        m_lineScanActive = false; // 重置状态
        qDebug() << "Line scan stopped due to gas alarm";
    }
    
    // 检查并停止轨迹扫描
    if (m_trajectoryScanActive) {
        m_previousScanMode = 2; // 轨迹扫描
        m_trajectoryScanActive = false; // 重置状态
        qDebug() << "Trajectory scan stopped due to gas alarm";
    }
    
    // 停止巡航
    if (m_cruiseActive) {
        m_cruisePausedDueToAlarm = true;
        stopCruise();
        m_previousScanMode = 3; // 巡航
        qDebug() << "Cruise scan stopped due to gas alarm";
    }
    
    // 标记为因报警而暂停扫描
    m_scanPausedDueToAlarm = true;
    
    // 通知前端气体报警状态变化
    emit gasAlarmStateChanged(true);
    
    qDebug() << "All scans stopped due to gas alarm, current scan mode:" << m_previousScanMode;
}

void PtzDeviceCgi::resumeScanAfterAlarm()
{
    qDebug() << "Resuming scan after gas alarm";
    // 如果没有因为报警而暂停扫描，则不需要恢复
    if (!m_scanPausedDueToAlarm) {
        return;
    }
    
    // 通知前端气体报警状态变化
    //emit gasAlarmStateChanged(false);
    emit requestResumeScanAfterGasAlarm(m_previousScanMode);
    // 巡航恢复逻辑保留在这里，因为巡航不需要通过前端

    
    // 重置扫描暂停状态
    m_scanPausedDueToAlarm = false;
}

void PtzDeviceCgi::startAlarmDetectionTimer()
{
    // 启动15秒的气体报警检测计时器
    m_alarmDetectionTimer->start(ALARM_DETECTION_DURATION);
    m_alarmDetectionTimerActive = true;
    qDebug() << "Gas alarm detection timer started for" << ALARM_DETECTION_DURATION << "ms";
}

void PtzDeviceCgi::onAlarmDetectionTimerExpired()
{
    // 标记计时器不再活动
    m_alarmDetectionTimerActive = false;
    
    // 检查当前气体浓度状态
    if (m_gasConcentrationAlarm) {
        // 如果当前仍有气体浓度异常，重新启动计时器，延长等待时间
        qDebug() << "Gas alarm still active, extending detection timer for another" << ALARM_DETECTION_DURATION << "ms";
        startAlarmDetectionTimer();
    } else {
        // 气体浓度已恢复正常，恢复之前的扫描
        qDebug() << "Gas alarm detection timer expired and gas concentration is normal, resuming previous scan";
        resumeScanAfterAlarm();
    }
}

void PtzDeviceCgi::onCurrentScanModeReceived(int scanMode)
{
    // 接收前端返回的当前扫描模式
    m_previousScanMode = scanMode;
    qDebug() << "Received current scan mode from frontend:" << scanMode;
}

// void PtzDeviceCgi::onRequestStopScanForGasAlarm()
// {
//     // 接收到前端停止扫描的请求
//     qDebug() << "Received stop scan request from frontend";
    
//     // 如果已经因为报警而暂停了扫描，则不再重复处理
//     if (m_scanPausedDueToAlarm) {
//         return;
//     }
    
//     // 停止云台转动
//     doMvTurnStop();
    
//     // 检查并停止线扫
//     if (m_lineScanActive) {
//         m_previousScanMode = 1; // 线扫
//         m_lineScanActive = false; // 重置状态
//         qDebug() << "Line scan stopped due to frontend request";
//     }
    
//     // 检查并停止轨迹扫描
//     if (m_trajectoryScanActive) {
//         m_previousScanMode = 2; // 轨迹扫描
//         m_trajectoryScanActive = false; // 重置状态
//         qDebug() << "Trajectory scan stopped due to frontend request";
//     }
    
//     // 停止巡航
//     if (m_cruiseActive) {
//         m_cruisePausedDueToAlarm = true;
//         stopCruise();
//         m_previousScanMode = 3; // 巡航
//         qDebug() << "Cruise scan stopped due to frontend request";
//     }
    
//     // 标记为因报警而暂停扫描
//     m_scanPausedDueToAlarm = true;
    
//     // 通知前端气体报警状态变化
//     emit gasAlarmStateChanged(true);
    
//     qDebug() << "All scans stopped due to frontend request, current scan mode:" << m_previousScanMode;
// }

void PtzDeviceCgi::onRequestResumeScanAfterGasAlarm(int scanMode)
{
    // 接收到前端恢复扫描的请求
    qDebug() << "Received resume scan request from frontend, scan mode:" << scanMode;
    m_previousScanMode = scanMode;
    // 启动报警检测计时器，15秒后恢复扫描
    startAlarmDetectionTimer();
    
    // 直接在这里恢复迹扫和线扫，而不只是依赖信号传递
    // 根据扫描模式恢复对应的扫描
    switch (scanMode) {
    case 1: // 线扫
        // 恢复线扫
        qDebug() << "Directly resuming line scan after gas alarm";
        // 设置线扫状态为活动
        m_lineScanActive = true;
        // 调用线扫启动预置位
        doMvCallPreset(0xFE);
        break;
        
    case 2: // 轨迹扫描
        // 恢复轨迹扫描
        qDebug() << "Directly resuming trajectory scan after gas alarm";
        // 设置轨迹扫描状态为活动
        m_trajectoryScanActive = true;
        // 调用轨迹扫描启动预置位
        doMvCallPreset(0xFA);
        break;
        
    case 3: // 巡航

        qDebug() << "Cruise scan will be resumed by backend";

        // 恢复巡航
        if (m_cruisePausedDueToAlarm && !m_currentCruisePoints.isEmpty()) {
            resumeCruiseIfPaused();
            qDebug() << "Resuming cruise scan after gas alarm";
        }
        m_cruiseActive = true;
        
        break;
        
    default:
        // 无扫描或未知扫描模式，不需要恢复
        qDebug() << "No scan to resume after gas alarm, scan mode:" << scanMode;
        break;
    }
}

// 设置报警定点检测时长的方法实现
void PtzDeviceCgi::mvSetAlarmDetectionDuration(int durationMs)
{
    // 将毫秒转换为秒进行验证
    int durationSec = durationMs / 1000;
    
    // 验证输入值的有效性(1-60秒)
    if (durationSec < 1 || durationSec > 60) {
        qDebug() << "Invalid alarm detection duration:" << durationSec << "seconds. Must be between 1 and 60 seconds.";
        return;
    }
    
    // 更新报警检测时长(保持为毫秒)
    ALARM_DETECTION_DURATION = durationMs;
    
    // 如果当前有报警检测计时器在运行，则重新启动以应用新的时长
    if (m_alarmDetectionTimerActive) {
        m_alarmDetectionTimer->stop();
        m_alarmDetectionTimer->start(ALARM_DETECTION_DURATION);
        qDebug() << "Alarm detection duration updated to" << durationSec << "seconds and timer restarted";
    } else {
        qDebug() << "Alarm detection duration updated to" << durationSec << "seconds";
    }
    
    // 发出信号通知前端报警检测时长已更新(以秒为单位)
    emit alarmDetectionDurationChanged(durationSec);
}

// 设置巡航间隔时长的方法实现
void PtzDeviceCgi::mvSetCruiseIntervalDuration(int durationMs)
{
    // 将毫秒转换为秒进行验证
    int durationSec = durationMs / 1000;
    
    // 验证输入值的有效性(1-15秒)
    if (durationSec < 1 || durationSec > 15) {
        qDebug() << "Invalid cruise interval duration:" << durationSec << "seconds. Must be between 1 and 15 seconds.";
        return;
    }
    
    // 更新巡航间隔时长(保持为毫秒)
    CRUISE_SCAN_INTERVAL = durationMs;
    
    // 如果当前有巡航扫描计时器在运行，则重新启动以应用新的时长
    if (scanTimer && scanTimer->isActive()) {
        scanTimer->stop();
        scanTimer->start(CRUISE_SCAN_INTERVAL);
        qDebug() << "Cruise interval duration updated to" << durationSec << "seconds and timer restarted";
    } else {
        qDebug() << "Cruise interval duration updated to" << durationSec << "seconds";
    }
    
    // 发出信号通知前端巡航间隔时长已更新(以秒为单位)
    emit cruiseIntervalDurationChanged(durationSec);
}
