#include "tdlas_data_manager.h"
#include <QStandardPaths>
#include <QTextStream>
#include <QDateTime>
#include <QFileInfo>
#include <QDirIterator>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QApplication>

// TdlasConcentrationData 序列化为JSON
QJsonObject TdlasConcentrationData::toJson() const {
    QJsonObject obj;
    obj["id"] = id;
    obj["timestamp"] = timestamp;
    obj["concentration"] = concentration;
    obj["horizontalAngle"] = horizontalAngle;
    obj["verticalAngle"] = verticalAngle;
    obj["distance"] = distance;
    obj["deviceId"] = deviceId;
    return obj;
}

TdlasConcentrationData TdlasConcentrationData::fromJson(const QJsonObject& json) {
    TdlasConcentrationData data;
    data.id = json["id"].toInt();
    data.timestamp = json["timestamp"].toString();
    data.concentration = json["concentration"].toDouble();
    data.horizontalAngle = json["horizontalAngle"].toDouble();
    data.verticalAngle = json["verticalAngle"].toDouble();
    data.distance = json["distance"].toDouble();
    data.deviceId = json["deviceId"].toString();
    return data;
}

// TdlasTimeRangeData 序列化为JSON
QJsonObject TdlasTimeRangeData::toJson() const {
    QJsonObject obj;
    obj["startTime"] = startTime;
    obj["endTime"] = endTime;
    obj["avgConcentration"] = avgConcentration;
    obj["maxConcentration"] = maxConcentration;
    obj["minConcentration"] = minConcentration;
    obj["dataCount"] = dataCount;
    return obj;
}

TdlasTimeRangeData TdlasTimeRangeData::fromJson(const QJsonObject& json) {
    TdlasTimeRangeData data;
    data.startTime = json["startTime"].toString();
    data.endTime = json["endTime"].toString();
    data.avgConcentration = json["avgConcentration"].toDouble();
    data.maxConcentration = json["maxConcentration"].toDouble();
    data.minConcentration = json["minConcentration"].toDouble();
    data.dataCount = json["dataCount"].toInt();
    return data;
}

// TdlasDataManager 单例实现
TdlasDataManager* TdlasDataManager::m_instance = nullptr;

TdlasDataManager* TdlasDataManager::instance() {
    if (!m_instance) {
        m_instance = new TdlasDataManager();
    }
    return m_instance;
}

TdlasDataManager::TdlasDataManager(QObject *parent)
    : QObject(parent)
{
    qDebug() << "TdlasDataManager constructor called";
    
    // 创建数据库目录 - 使用程序运行目录下的路径
    QString appDir = QApplication::applicationDirPath();
    QString tdlasDir = appDir + "/config/tdlas";
    
    QDir dir(tdlasDir);
    if (!dir.exists()) {
        qDebug() << "Creating TDLAS directory:" << tdlasDir;
        dir.mkpath(tdlasDir);
    }
    
    QString dbPath = tdlasDir + "/tdlas.db";
    qDebug() << "TDLAS database path:" << dbPath;

    qDebug() << "Adding database to SQL engine";
    // 使用唯一的连接名确保线程安全
    QString connectionName = QString("tdlas_connection_%1").arg((quintptr)this);
    m_db = QSqlDatabase::addDatabase("QSQLITE", connectionName);
    m_db.setDatabaseName(dbPath);
    
    qDebug() << "Opening database";
    if (!m_db.open()) {
        qWarning() << "Failed to open TDLAS database:" << m_db.lastError().text();
    } else {
        qDebug() << "Database opened successfully";
    }

    initDatabase();
    qDebug() << "TdlasDataManager constructor finished";
}

TdlasDataManager::~TdlasDataManager() {
    qDebug() << "TdlasDataManager destructor called";
    if (m_db.isOpen()) {
        m_db.close();
        qDebug() << "Database closed";
    }
}

void TdlasDataManager::initDatabase() {
    qDebug() << "Initializing TDLAS database tables";
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    qDebug() << "Mutex locked for initDatabase operation";
    
    // 检查数据库连接
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open in initDatabase";
        return;
    }
    
    // Set database performance options
    QSqlQuery pragmaQuery(m_db);
    pragmaQuery.exec("PRAGMA journal_mode=WAL");
    pragmaQuery.exec("PRAGMA synchronous=NORMAL");
    pragmaQuery.exec("PRAGMA cache_size=10000");
    pragmaQuery.exec("PRAGMA temp_store=MEMORY");
    
    QSqlQuery query(m_db);
    
    // 创建浓度数据表 (使用Unix时间戳提高查询性能)
    qDebug() << "Creating TdlasConcentrationData table";
    QString createTableSql = "CREATE TABLE IF NOT EXISTS TdlasConcentrationData ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT,"
               "timestamp INTEGER NOT NULL,"  // Unix时间戳 (秒)
               "datetime TEXT NOT NULL,"      // 可读的时间格式
               "concentration REAL NOT NULL,"
               "horizontal_angle REAL DEFAULT 0.0,"  // 水平角度，默认值为0
               "vertical_angle REAL DEFAULT 0.0,"    // 垂直角度，默认值为0
               "distance REAL DEFAULT 0.0,"          // 距离信息，默认值为0
               "device_id TEXT DEFAULT ''"            // 设备ID，默认为空字符串
               ")";
    qDebug() << "Executing SQL:" << createTableSql;
    
    if (!query.exec(createTableSql)) {
        qWarning() << "Error creating TdlasConcentrationData table:" << query.lastError().text();
        return;
    } else {
        qDebug() << "TdlasConcentrationData table created or already exists";
    }
    
    // 创建主要索引：timestamp (用于时间范围查询)
    qDebug() << "Creating index on timestamp";
    QString createIndexSql = "CREATE INDEX IF NOT EXISTS idx_timestamp ON TdlasConcentrationData(timestamp)";
    qDebug() << "Executing SQL:" << createIndexSql;
    
    if (!query.exec(createIndexSql)) {
        qWarning() << "Error creating index on timestamp:" << query.lastError().text();
    } else {
        qDebug() << "Index on timestamp created or already exists";
    }
    
    // 创建复合索引：timestamp + concentration (优化统计查询)
    qDebug() << "Creating composite index on timestamp and concentration";
    QString createCompositeIndexSql = "CREATE INDEX IF NOT EXISTS idx_timestamp_concentration ON TdlasConcentrationData(timestamp, concentration)";
    qDebug() << "Executing SQL:" << createCompositeIndexSql;
    
    if (!query.exec(createCompositeIndexSql)) {
        qWarning() << "Error creating composite index:" << query.lastError().text();
    } else {
        qDebug() << "Composite index on timestamp and concentration created or already exists";
    }
    
    // 创建设备ID索引 (优化按设备查询)
    qDebug() << "Creating index on device_id";
    QString createDeviceIndexSql = "CREATE INDEX IF NOT EXISTS idx_device_id ON TdlasConcentrationData(device_id)";
    qDebug() << "Executing SQL:" << createDeviceIndexSql;
    
    if (!query.exec(createDeviceIndexSql)) {
        qWarning() << "Error creating device_id index:" << query.lastError().text();
    } else {
        qDebug() << "Index on device_id created or already exists";
    }
    
    // 创建复合索引：device_id + timestamp (优化按设备和时间查询)
    qDebug() << "Creating composite index on device_id and timestamp";
    QString createDeviceTimeIndexSql = "CREATE INDEX IF NOT EXISTS idx_device_timestamp ON TdlasConcentrationData(device_id, timestamp)";
    qDebug() << "Executing SQL:" << createDeviceTimeIndexSql;
    
    if (!query.exec(createDeviceTimeIndexSql)) {
        qWarning() << "Error creating device_timestamp index:" << query.lastError().text();
    } else {
        qDebug() << "Composite index on device_id and timestamp created or already exists";
    }
    
    // 删除不再使用的 datetime 索引（如果存在）
    qDebug() << "Dropping unused datetime index if exists";
    QString dropDatetimeIdxSql = "DROP INDEX IF EXISTS idx_datetime";
    qDebug() << "Executing SQL:" << dropDatetimeIdxSql;
    if (!query.exec(dropDatetimeIdxSql)) {
        qWarning() << "Error dropping idx_datetime:" << query.lastError().text();
    } else {
        qDebug() << "Dropped idx_datetime if it existed";
    }
    
    // 创建触发器定期清理旧数据（保留6个月）
    qDebug() << "Creating trigger for cleaning old data";
    QString createTriggerSql = "CREATE TRIGGER IF NOT EXISTS trg_clean_old_tdlas_data "
               "AFTER INSERT ON TdlasConcentrationData "
               "BEGIN "
               "  DELETE FROM TdlasConcentrationData "
               "  WHERE timestamp < strftime('%s', 'now', '-6 months'); "
               "END;";
    qDebug() << "Executing SQL:" << createTriggerSql;
    
    if (!query.exec(createTriggerSql)) {
        qWarning() << "Error creating trigger:" << query.lastError().text();
    } else {
        qDebug() << "Trigger for cleaning old data created or already exists";
    }
    
    // 数据库迁移：为现有表添加device_id列（向后兼容性）
    qDebug() << "Checking if device_id column exists";
    QSqlQuery checkColumnQuery(m_db);
    checkColumnQuery.exec("PRAGMA table_info(TdlasConcentrationData)");
    
    bool deviceIdExists = false;
    while (checkColumnQuery.next()) {
        QString columnName = checkColumnQuery.value("name").toString();
        if (columnName == "device_id") {
            deviceIdExists = true;
            break;
        }
    }
    
    if (!deviceIdExists) {
        qDebug() << "Adding device_id column to existing table";
        QSqlQuery alterQuery(m_db);
        QString alterSql = "ALTER TABLE TdlasConcentrationData ADD COLUMN device_id TEXT DEFAULT ''";
        qDebug() << "Executing SQL:" << alterSql;
        
        if (!alterQuery.exec(alterSql)) {
            qWarning() << "Error adding device_id column:" << alterQuery.lastError().text();
        } else {
            qDebug() << "device_id column added successfully";
            
            // 创建设备ID相关索引
            QSqlQuery indexQuery(m_db);
            indexQuery.exec("CREATE INDEX IF NOT EXISTS idx_device_id ON TdlasConcentrationData(device_id)");
            indexQuery.exec("CREATE INDEX IF NOT EXISTS idx_device_timestamp ON TdlasConcentrationData(device_id, timestamp)");
            qDebug() << "Device ID indexes created";
        }
    } else {
        qDebug() << "device_id column already exists";
    }
    
    qDebug() << "Executing PRAGMA optimize";
    pragmaQuery.exec("PRAGMA optimize");
    
    qDebug() << "TDLAS database initialized successfully";
}

QString TdlasDataManager::getCurrentDate() {
    return QDateTime::currentDateTime().toString("yyyy-MM-dd");
}

QDateTime TdlasDataManager::parseDateTime(const QString& dateTimeStr) {
    return QDateTime::fromString(dateTimeStr, "yyyy-MM-dd HH:mm:ss");
}

TdlasConcentrationData TdlasDataManager::fromQuery(const QSqlQuery& query) {
    TdlasConcentrationData data;
    data.id = query.value("id").toInt();
    // Convert Unix timestamp back to human-readable format
    qint64 timestamp = query.value("timestamp").toLongLong();
    data.timestamp = QDateTime::fromSecsSinceEpoch(timestamp).toString("yyyy-MM-dd HH:mm:ss");
    data.concentration = query.value("concentration").toDouble();
    data.horizontalAngle = query.value("horizontal_angle").toDouble();
    data.verticalAngle = query.value("vertical_angle").toDouble();
    data.distance = query.value("distance").toDouble();
    data.deviceId = query.value("device_id").toString();
    return data;
}

// 保存浓度数据（仅浓度值，其他字段使用默认值）
bool TdlasDataManager::saveConcentrationData(double concentration, const QString& deviceId) {
    return saveConcentrationData(concentration, 0.0, 0.0, 0.0, deviceId);
}

// 保存浓度数据
bool TdlasDataManager::saveConcentrationData(double concentration, double horizontalAngle, double verticalAngle, double distance, const QString& deviceId) {
    //qDebug() << "saveConcentrationData called with concentration:" << concentration << "deviceId:" << deviceId << "on thread:" << QThread::currentThread();
    
    qint64 timestamp = QDateTime::currentDateTime().toSecsSinceEpoch();  // Unix时间戳
    QString datetime = QDateTime::fromSecsSinceEpoch(timestamp).toString("yyyy-MM-dd HH:mm:ss");
    
    //qDebug() << "Preparing to insert data - timestamp:" << timestamp << "datetime:" << datetime << "concentration:" << concentration << "deviceId:" << deviceId;
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    //qDebug() << "Mutex locked for database operation";
    
    // 检查数据库连接
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open, trying to reopen";
        if (!m_db.open()) {
            qWarning() << "Failed to reopen database:" << m_db.lastError().text();
            return false;
        }
    }
    
    QSqlQuery query(m_db);
    //qDebug() << "SQL query object created";
    
    QString sql = "INSERT INTO TdlasConcentrationData (timestamp, datetime, concentration, horizontal_angle, vertical_angle, distance, device_id) VALUES (:timestamp, :datetime, :concentration, :horizontal_angle, :vertical_angle, :distance, :device_id)";
    //qDebug() << "Preparing SQL query:" << sql;
    
    if (!query.prepare(sql)) {
        qWarning() << "Failed to prepare SQL query:" << query.lastError().text();
        return false;
    }
    //qDebug() << "SQL query prepared";
    
    query.bindValue(":timestamp", timestamp);
    query.bindValue(":datetime", datetime);
    query.bindValue(":concentration", concentration);
    query.bindValue(":horizontal_angle", horizontalAngle);
    query.bindValue(":vertical_angle", verticalAngle);
    query.bindValue(":distance", distance);
    query.bindValue(":device_id", deviceId);
    //qDebug() << "Values bound to query";
    
    //qDebug() << "Database connection status:" << m_db.isOpen();
    //qDebug() << "Executing query";
    bool result = query.exec();
    //qDebug() << "Query executed, result:" << result;
    
    if (!result) {
        qWarning() << "Failed to insert TDLAS concentration data:" << query.lastError().text();
        return false;
    }
    
    //qDebug() << "TDLAS concentration data saved:" << datetime << concentration << "deviceId:" << deviceId;
    return true;
}

bool TdlasDataManager::saveBatchData(const QVariantList& dataList, const QString& deviceId) {
    qDebug() << "saveBatchData called with" << dataList.size() << "items" << "deviceId:" << deviceId;
    
    if (dataList.isEmpty()) {
        qDebug() << "Data list is empty, returning false";
        return false;
    }
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    
    // 检查数据库连接
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open in saveBatchData";
        return false;
    }
    
    QSqlQuery query(m_db);
    query.prepare("INSERT INTO TdlasConcentrationData (timestamp, datetime, concentration, horizontal_angle, vertical_angle, distance, device_id) "
                  "VALUES (:timestamp, :datetime, :concentration, :horizontal_angle, :vertical_angle, :distance, :device_id)");
    
    // 开始事务以提高性能
    qDebug() << "Starting database transaction";
    m_db.transaction();
    bool success = true;
    
    // Temporarily disable the trigger during batch insert for better performance
    QSqlQuery triggerQuery(m_db);
    triggerQuery.exec("DROP TRIGGER IF EXISTS trg_clean_old_tdlas_data");
    
    for (const QVariant& var : dataList) {
        QVariantMap map = var.toMap();
        QString datetimeStr = map["timestamp"].toString();
        QDateTime dateTime = QDateTime::fromString(datetimeStr, "yyyy-MM-dd HH:mm:ss");
        qint64 timestamp = dateTime.toSecsSinceEpoch();  // Convert to Unix timestamp
        double concentration = map["concentration"].toDouble();
        double horizontalAngle = map.contains("horizontalAngle") ? map["horizontalAngle"].toDouble() : 0.0;
        double verticalAngle = map.contains("verticalAngle") ? map["verticalAngle"].toDouble() : 0.0;
        double distance = map.contains("distance") ? map["distance"].toDouble() : 0.0;
        QString itemDeviceId = map.contains("deviceId") ? map["deviceId"].toString() : deviceId;
        
        query.bindValue(":timestamp", timestamp);
        query.bindValue(":datetime", datetimeStr);
        query.bindValue(":concentration", concentration);
        query.bindValue(":horizontal_angle", horizontalAngle);
        query.bindValue(":vertical_angle", verticalAngle);
        query.bindValue(":distance", distance);
        query.bindValue(":device_id", itemDeviceId);
        
        if (!query.exec()) {
            qWarning() << "Failed to insert TDLAS concentration data:" << query.lastError().text();
            success = false;
            break;
        }
    }
    
    if (success) {
        qDebug() << "Committing transaction";
        m_db.commit();
        qDebug() << "TDLAS batch data saved, count:" << dataList.size();
    } else {
        qDebug() << "Rolling back transaction";
        m_db.rollback();
        qWarning() << "Failed to save TDLAS batch data";
    }
    
    // Recreate the trigger after batch insert
    QSqlQuery recreateTriggerQuery(m_db);
    QString createTriggerSql = "CREATE TRIGGER IF NOT EXISTS trg_clean_old_tdlas_data "
               "AFTER INSERT ON TdlasConcentrationData "
               "BEGIN "
               "  DELETE FROM TdlasConcentrationData "
               "  WHERE timestamp < strftime('%s', 'now', '-6 months'); "
               "END;";
    recreateTriggerQuery.exec(createTriggerSql);
    
    return success;
}

// 查询浓度数据（智能采样版本，最多返回500个点）
QVariantList TdlasDataManager::queryConcentrationData(const QString& startTime,
                                                     const QString& endTime,
                                                     const QString& deviceId) {
    qDebug() << "queryConcentrationData called with startTime:" << startTime << "endTime:" << endTime << "deviceId:" << deviceId << "on thread:" << QThread::currentThread();
    
    // 直接使用采样查询，最多返回500个点，适配UI显示需求
    return queryConcentrationDataWithSampling(startTime, endTime, 500, deviceId);
}

// 查询浓度数据（分页）
QVariantList TdlasDataManager::queryConcentrationDataPaginated(const QString& startTime,
                                                              const QString& endTime,
                                                              int limit,
                                                              int offset,
                                                              const QString& deviceId) {
    qDebug() << "queryConcentrationDataPaginated called with startTime:" << startTime 
             << "endTime:" << endTime << "limit:" << limit << "offset:" << offset 
             << "deviceId:" << deviceId << "on thread:" << QThread::currentThread();
    
    QVariantList result;
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    qDebug() << "Mutex locked for query operation";
    
    // 检查数据库连接
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open in queryConcentrationDataPaginated";
        return result;
    }
    
    QSqlQuery query(m_db);
    query.setForwardOnly(true);
    
    // 构建查询语句
    QString sql = "SELECT id, timestamp, concentration, horizontal_angle, vertical_angle, distance, device_id FROM TdlasConcentrationData";
    QStringList conditions;
    
    // Convert string datetime to Unix timestamps for comparison
    if (!startTime.isEmpty()) {
        QDateTime startDateTime = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
        if (startDateTime.isValid()) {
            qint64 startTimestamp = startDateTime.toSecsSinceEpoch();
            conditions << "timestamp >= :start_time";
        }
    }
    
    if (!endTime.isEmpty()) {
        QDateTime endDateTime = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
        if (endDateTime.isValid()) {
            qint64 endTimestamp = endDateTime.toSecsSinceEpoch();
            conditions << "timestamp <= :end_time";
        }
    }
    
    if (!deviceId.isEmpty()) {
        conditions << "device_id = :device_id";
    }
    
    if (!deviceId.isEmpty()) {
        conditions << "device_id = :device_id";
    }
    
    if (!conditions.isEmpty()) {
        sql += " WHERE " + conditions.join(" AND ");
    }
    
    sql += " ORDER BY timestamp ASC LIMIT :limit OFFSET :offset";
    
    qDebug() << "Prepared SQL:" << sql;
    
    if (!query.prepare(sql)) {
        qWarning() << "Failed to prepare query:" << query.lastError().text();
        return result;
    }
    
    if (!startTime.isEmpty()) {
        QDateTime startDateTime = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
        if (startDateTime.isValid()) {
            qint64 startTimestamp = startDateTime.toSecsSinceEpoch();
            qDebug() << "Binding start_time:" << startTime << "(" << startTimestamp << ")";
            query.bindValue(":start_time", startTimestamp);
        }
    }
    
    if (!endTime.isEmpty()) {
        QDateTime endDateTime = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
        if (endDateTime.isValid()) {
            qint64 endTimestamp = endDateTime.toSecsSinceEpoch();
            qDebug() << "Binding end_time:" << endTime << "(" << endTimestamp << ")";
            query.bindValue(":end_time", endTimestamp);
        }
    }
    
    if (!deviceId.isEmpty()) {
        qDebug() << "Binding device_id:" << deviceId;
        query.bindValue(":device_id", deviceId);
    }
    
    if (!deviceId.isEmpty()) {
        qDebug() << "Binding device_id:" << deviceId;
        query.bindValue(":device_id", deviceId);
    }
    
    query.bindValue(":limit", limit);
    query.bindValue(":offset", offset);
    
    qDebug() << "Executing query";
    if (!query.exec()) {
        qWarning() << "Failed to query TDLAS concentration data:" << query.lastError().text();
        return result;
    }
    
    qDebug() << "Processing query results";
    while (query.next()) {
        QVariantMap dataMap;
        dataMap["id"] = query.value("id");
        qint64 timestamp = query.value("timestamp").toLongLong();
        dataMap["timestamp"] = QDateTime::fromSecsSinceEpoch(timestamp).toString("yyyy-MM-dd HH:mm:ss");
        dataMap["concentration"] = query.value("concentration");
        dataMap["horizontalAngle"] = query.value("horizontal_angle");
        dataMap["verticalAngle"] = query.value("vertical_angle");
        dataMap["distance"] = query.value("distance");
        dataMap["deviceId"] = query.value("device_id");
        result.append(dataMap);
    }
    
    qDebug() << "TDLAS data query result count:" << result.size();
    return result;
}

// 智能采样查询：数据库层面采样，避免UI层重复采样
QVariantList TdlasDataManager::queryConcentrationDataWithSampling(const QString& startTime,
                                                                  const QString& endTime,
                                                                  int maxSamples,
                                                                  const QString& deviceId) {
    qDebug() << "queryConcentrationDataWithSampling called with maxSamples:" << maxSamples << "deviceId:" << deviceId;
    
    QVariantList result;
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    
    // 检查数据库连接
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open in queryConcentrationDataWithSampling";
        return result;
    }
    
    QDateTime startDateTime = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
    QDateTime endDateTime = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
    
    if (!startDateTime.isValid() || !endDateTime.isValid()) {
        return result;
    }
    
    qint64 startTimestamp = startDateTime.toSecsSinceEpoch();
    qint64 endTimestamp = endDateTime.toSecsSinceEpoch();
    
    // 首先查询总数据量
    QSqlQuery countQuery(m_db);
    QString countSql = "SELECT COUNT(*) FROM TdlasConcentrationData WHERE timestamp >= :start_time AND timestamp <= :end_time";
    if (!deviceId.isEmpty()) {
        countSql += " AND device_id = :device_id";
    }
    countQuery.prepare(countSql);
    countQuery.bindValue(":start_time", startTimestamp);
    countQuery.bindValue(":end_time", endTimestamp);
    if (!deviceId.isEmpty()) {
        countQuery.bindValue(":device_id", deviceId);
    }
    
    int totalCount = 0;
    if (countQuery.exec() && countQuery.next()) {
        totalCount = countQuery.value(0).toInt();
    }
    
    qDebug() << "Total data count in range:" << totalCount << "maxSamples:" << maxSamples;
    
    if (totalCount == 0) {
        return result;
    }
    
    QSqlQuery query(m_db);
    query.setForwardOnly(true);
    
    QString sql;
    
    // 如果数据量小于等于maxSamples，直接返回所有数据
    if (totalCount <= maxSamples) {
        sql = "SELECT id, timestamp, concentration, horizontal_angle, vertical_angle, distance, device_id "
              "FROM TdlasConcentrationData "
              "WHERE timestamp >= :start_time AND timestamp <= :end_time";
        if (!deviceId.isEmpty()) {
            sql += " AND device_id = :device_id";
        }
        sql += " ORDER BY timestamp ASC";
        
        query.prepare(sql);
        query.bindValue(":start_time", startTimestamp);
        query.bindValue(":end_time", endTimestamp);
        if (!deviceId.isEmpty()) {
            query.bindValue(":device_id", deviceId);
        }
    } else {
        // 数据量超过maxSamples，使用简单的间隔采样
        int sampleInterval = totalCount / maxSamples;
        if (sampleInterval < 1) sampleInterval = 1;
        
        qDebug() << "Using interval sampling with interval:" << sampleInterval << "to get exactly" << maxSamples << "points";
        
        // SQLite不支持ROW_NUMBER()，直接使用LIMIT和OFFSET进行采样
        // 计算需要跳过的记录数来实现均匀采样
        sql = "SELECT id, timestamp, concentration, horizontal_angle, vertical_angle, distance, device_id "
              "FROM TdlasConcentrationData "
              "WHERE timestamp >= :start_time AND timestamp <= :end_time";
        if (!deviceId.isEmpty()) {
            sql += " AND device_id = :device_id";
        }
        sql += " ORDER BY timestamp ASC";
        
        query.prepare(sql);
        query.bindValue(":start_time", startTimestamp);
        query.bindValue(":end_time", endTimestamp);
        if (!deviceId.isEmpty()) {
            query.bindValue(":device_id", deviceId);
        }
    }
    
    if (!query.exec()) {
        qWarning() << "Failed to execute sampling query:" << query.lastError().text();
        // 最终回退到分页查询
        return queryConcentrationDataPaginated(startTime, endTime, maxSamples, 0, deviceId);
    }
    
    // 如果需要采样，则按间隔选择数据点
    int currentIndex = 0;
    int sampledCount = 0;
    int sampleInterval = (totalCount > maxSamples) ? (totalCount / maxSamples) : 1;
    if (sampleInterval < 1) sampleInterval = 1;
    
    while (query.next() && (totalCount <= maxSamples || sampledCount < maxSamples)) {
        // 如果总数据量小于等于maxSamples，或者当前索引是采样间隔的倍数，则添加数据点
        if (totalCount <= maxSamples || currentIndex % sampleInterval == 0) {
            QVariantMap dataMap;
            dataMap["id"] = query.value("id");
            qint64 timestamp = query.value("timestamp").toLongLong();
            dataMap["timestamp"] = QDateTime::fromSecsSinceEpoch(timestamp).toString("yyyy-MM-dd HH:mm:ss");
            dataMap["concentration"] = query.value("concentration");
            dataMap["horizontalAngle"] = query.value("horizontal_angle");
            dataMap["verticalAngle"] = query.value("vertical_angle");
            dataMap["distance"] = query.value("distance");
            dataMap["deviceId"] = query.value("device_id");
            result.append(dataMap);
            sampledCount++;
        }
        currentIndex++;
    }
    
    qDebug() << "Database sampling result count:" << result.size() << "from total:" << totalCount;
    return result;
}

// 查询浓度数据（带阈值筛选的智能采样版本）
QVariantList TdlasDataManager::queryConcentrationDataWithThreshold(const QString& startTime,
                                                                   const QString& endTime,
                                                                   double thresholdValue,
                                                                   int maxSamples,
                                                                   const QString& deviceId) {
    qDebug() << "queryConcentrationDataWithThreshold called with threshold:" << thresholdValue << "maxSamples:" << maxSamples << "deviceId:" << deviceId;
    
    QVariantList result;
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    
    // 检查数据库连接
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open in queryConcentrationDataWithThreshold";
        return result;
    }
    
    QDateTime startDateTime = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
    QDateTime endDateTime = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
    
    if (!startDateTime.isValid() || !endDateTime.isValid()) {
        return result;
    }
    
    qint64 startTimestamp = startDateTime.toSecsSinceEpoch();
    qint64 endTimestamp = endDateTime.toSecsSinceEpoch();
    
    // 首先查询满足阈值条件的数据总量
    QSqlQuery countQuery(m_db);
    QString countSql = "SELECT COUNT(*) FROM TdlasConcentrationData WHERE timestamp >= :start_time AND timestamp <= :end_time AND concentration >= :threshold";
    if (!deviceId.isEmpty()) {
        countSql += " AND device_id = :device_id";
    }
    countQuery.prepare(countSql);
    countQuery.bindValue(":start_time", startTimestamp);
    countQuery.bindValue(":end_time", endTimestamp);
    countQuery.bindValue(":threshold", thresholdValue);
    if (!deviceId.isEmpty()) {
        countQuery.bindValue(":device_id", deviceId);
    }
    
    int totalCount = 0;
    if (countQuery.exec() && countQuery.next()) {
        totalCount = countQuery.value(0).toInt();
    }
    
    qDebug() << "Total data count above threshold" << thresholdValue << ":" << totalCount << "maxSamples:" << maxSamples;
    
    if (totalCount == 0) {
        return result;
    }
    
    QSqlQuery query(m_db);
    query.setForwardOnly(true);
    
    QString sql;
    
    // 如果满足阈值的数据量小于等于maxSamples，直接返回所有数据
    if (totalCount <= maxSamples) {
        sql = "SELECT id, timestamp, concentration, horizontal_angle, vertical_angle, distance, device_id "
              "FROM TdlasConcentrationData "
              "WHERE timestamp >= :start_time AND timestamp <= :end_time AND concentration >= :threshold";
        if (!deviceId.isEmpty()) {
            sql += " AND device_id = :device_id";
        }
        sql += " ORDER BY timestamp ASC";
        
        query.prepare(sql);
        query.bindValue(":start_time", startTimestamp);
        query.bindValue(":end_time", endTimestamp);
        query.bindValue(":threshold", thresholdValue);
        if (!deviceId.isEmpty()) {
            query.bindValue(":device_id", deviceId);
        }
    } else {
        // 数据量超过maxSamples，使用间隔采样
        int sampleInterval = totalCount / maxSamples;
        if (sampleInterval < 1) sampleInterval = 1;
        
        qDebug() << "Using interval sampling with interval:" << sampleInterval << "for threshold data";
        
        // 使用ROW_NUMBER()进行均匀间隔采样
        sql = "SELECT id, timestamp, concentration, horizontal_angle, vertical_angle, distance, device_id "
              "FROM ("
              "  SELECT *, ROW_NUMBER() OVER (ORDER BY timestamp) as rn "
              "  FROM TdlasConcentrationData "
              "  WHERE timestamp >= :start_time AND timestamp <= :end_time AND concentration >= :threshold";
        if (!deviceId.isEmpty()) {
            sql += " AND device_id = :device_id";
        }
        sql += ") "
               "WHERE rn % :interval = 1 "
               "ORDER BY timestamp ASC "
               "LIMIT :max_samples";
        
        if (!query.prepare(sql)) {
            qWarning() << "ROW_NUMBER not supported for threshold query, using simple LIMIT fallback";
            // 如果ROW_NUMBER不支持，使用简单的LIMIT
            sql = "SELECT id, timestamp, concentration, horizontal_angle, vertical_angle, distance, device_id "
                  "FROM TdlasConcentrationData "
                  "WHERE timestamp >= :start_time AND timestamp <= :end_time AND concentration >= :threshold";
            if (!deviceId.isEmpty()) {
                sql += " AND device_id = :device_id";
            }
            sql += " ORDER BY timestamp ASC "
                   " LIMIT :max_samples";
            
            query.prepare(sql);
            query.bindValue(":start_time", startTimestamp);
            query.bindValue(":end_time", endTimestamp);
            query.bindValue(":threshold", thresholdValue);
            if (!deviceId.isEmpty()) {
                query.bindValue(":device_id", deviceId);
            }
            query.bindValue(":max_samples", maxSamples);
        } else {
            query.bindValue(":start_time", startTimestamp);
            query.bindValue(":end_time", endTimestamp);
            query.bindValue(":threshold", thresholdValue);
            if (!deviceId.isEmpty()) {
                query.bindValue(":device_id", deviceId);
            }
            query.bindValue(":interval", sampleInterval);
            query.bindValue(":max_samples", maxSamples);
        }
    }
    
    if (!query.exec()) {
        qWarning() << "Failed to execute threshold query:" << query.lastError().text();
        return result;
    }
    
    while (query.next()) {
        QVariantMap dataMap;
        dataMap["id"] = query.value("id");
        qint64 timestamp = query.value("timestamp").toLongLong();
        dataMap["timestamp"] = QDateTime::fromSecsSinceEpoch(timestamp).toString("yyyy-MM-dd HH:mm:ss");
        dataMap["concentration"] = query.value("concentration");
        dataMap["horizontalAngle"] = query.value("horizontal_angle");
        dataMap["verticalAngle"] = query.value("vertical_angle");
        dataMap["distance"] = query.value("distance");
        dataMap["deviceId"] = query.value("device_id");
        result.append(dataMap);
    }
    
    qDebug() << "Threshold query result count:" << result.size() << "from total:" << totalCount;
    return result;
}

QVariantList TdlasDataManager::queryTimeRangeData(const QString& startTime,
                                                 const QString& endTime,
                                                 const QString& deviceId) {
    qDebug() << "queryTimeRangeData called with startTime:" << startTime << "endTime:" << endTime << "deviceId:" << deviceId << "on thread:" << QThread::currentThread();
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    qDebug() << "Mutex locked for queryTimeRangeData operation";
    // 简化实现 - 直接返回空列表，因为现在使用数据库不需要单独的汇总表
    Q_UNUSED(startTime);
    Q_UNUSED(endTime);
    Q_UNUSED(deviceId);
    qDebug() << "Returning empty list for queryTimeRangeData";
    return QVariantList();
}

// 导出到CSV
bool TdlasDataManager::exportToCsv(const QString& outputPath,
                                     const QString& startTime,
                                     const QString& endTime,
                                     const QString& deviceId) {
    qDebug() << "exportToCsv called with startTime:" << startTime << "endTime:" << endTime << "outputPath:" << outputPath << "deviceId:" << deviceId << "on thread:" << QThread::currentThread();
    
    // 注意：这里不需要锁，因为内部调用的queryConcentrationData已经有锁了
    QVariantList dataList = queryConcentrationData(startTime, endTime, deviceId);
    
    if (dataList.isEmpty()) {
        qDebug() << "No data to export, returning false";
        return false;
    }
    
    QString csvPath = outputPath;
    if (csvPath.isEmpty()) {
        // 如果没有提供路径，则不执行任何操作
        qWarning() << "No output path provided for CSV export";
        return false;
    }
    
    qDebug() << "Exporting to CSV file:" << csvPath;
    
    QFile file(csvPath);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qWarning() << "Cannot open file for writing:" << csvPath;
        return false;
    }
    
    QTextStream out(&file);
    out.setCodec("UTF-8");
    
    // 写入CSV头
    out << "timestamp,concentration,horizontalAngle,verticalAngle,distance,deviceId\n";
    
    // 写入数据
    for (const QVariant& var : dataList) {
        QVariantMap map = var.toMap();
        out << QString("\"%1\",%2,%3,%4,%5,\"%6\"\n")
               .arg(map["timestamp"].toString())
               .arg(map["concentration"].toDouble())
               .arg(map["horizontalAngle"].toDouble())
               .arg(map["verticalAngle"].toDouble())
               .arg(map["distance"].toDouble())
               .arg(map["deviceId"].toString());
    }
    
    file.close();
    
    qDebug() << "TDLAS data exported to CSV:" << csvPath;
    return true;
}

bool TdlasDataManager::exportToJson(const QString& startTime,
                                   const QString& endTime,
                                   const QString& outputPath,
                                   const QString& deviceId) {
    qDebug() << "exportToJson called with startTime:" << startTime << "endTime:" << endTime << "outputPath:" << outputPath << "deviceId:" << deviceId << "on thread:" << QThread::currentThread();
    
    // 注意：这里不需要锁，因为内部调用的queryConcentrationData已经有锁了
    QVariantList dataList = queryConcentrationData(startTime, endTime, deviceId);
    
    if (dataList.isEmpty()) {
        qDebug() << "No data to export, returning false";
        return false;
    }
    
    QString jsonPath = outputPath;
    if (jsonPath.isEmpty()) {
        QString appDir = QApplication::applicationDirPath();
        QString tdlasDir = appDir + "/config/tdlas";
        
        QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss");
        jsonPath = tdlasDir + "/export_tdlas_" + timestamp + ".json";
    }
    
    qDebug() << "Exporting to JSON file:" << jsonPath;
    
    QFile file(jsonPath);
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "Cannot open file for writing:" << jsonPath;
        return false;
    }
    
    QJsonArray jsonArray;
    for (const QVariant& var : dataList) {
        QVariantMap map = var.toMap();
        QJsonObject obj;
        obj["timestamp"] = map["timestamp"].toString();
        obj["concentration"] = map["concentration"].toDouble();
        obj["horizontalAngle"] = map["horizontalAngle"].toDouble();
        obj["verticalAngle"] = map["verticalAngle"].toDouble();
        obj["distance"] = map["distance"].toDouble();
        obj["deviceId"] = map["deviceId"].toString();
        jsonArray.append(obj);
    }
    
    QJsonDocument doc(jsonArray);
    qint64 bytesWritten = file.write(doc.toJson());
    file.close();
    
    if (bytesWritten > 0) {
        qDebug() << "TDLAS data exported to JSON:" << jsonPath;
        return true;
    } else {
        qWarning() << "Failed to write JSON data to file:" << jsonPath;
        return false;
    }
}

// 删除数据
bool TdlasDataManager::deleteData(const QString& startTime,
                                 const QString& endTime,
                                 const QString& deviceId) {
    qDebug() << "deleteData called with startTime:" << startTime << "endTime:" << endTime << "on thread:" << QThread::currentThread();
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    qDebug() << "Mutex locked for delete operation";
    
    // 检查数据库连接
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open in deleteData";
        return false;
    }
    
    QSqlQuery query(m_db);
    
    QString sql = "DELETE FROM TdlasConcentrationData";
    QStringList conditions;
    
    // Convert string datetime to Unix timestamps for comparison
    if (!startTime.isEmpty()) {
        QDateTime startDateTime = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
        if (startDateTime.isValid()) {
            qint64 startTimestamp = startDateTime.toSecsSinceEpoch();
            conditions << "timestamp >= :start_time";
        }
    }
    
    if (!endTime.isEmpty()) {
        QDateTime endDateTime = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
        if (endDateTime.isValid()) {
            qint64 endTimestamp = endDateTime.toSecsSinceEpoch();
            conditions << "timestamp <= :end_time";
        }
    }
    
    if (!deviceId.isEmpty()) {
        conditions << "device_id = :device_id";
    }
    
    if (!conditions.isEmpty()) {
        sql += " WHERE " + conditions.join(" AND ");
    }
    
    qDebug() << "Prepared SQL:" << sql;
    
    if (!query.prepare(sql)) {
        qWarning() << "Failed to prepare delete query:" << query.lastError().text();
        return false;
    }
    
    if (!startTime.isEmpty()) {
        QDateTime startDateTime = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
        if (startDateTime.isValid()) {
            qint64 startTimestamp = startDateTime.toSecsSinceEpoch();
            qDebug() << "Binding start_time:" << startTime << "(" << startTimestamp << ")";
            query.bindValue(":start_time", startTimestamp);
        }
    }
    
    if (!endTime.isEmpty()) {
        QDateTime endDateTime = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
        if (endDateTime.isValid()) {
            qint64 endTimestamp = endDateTime.toSecsSinceEpoch();
            qDebug() << "Binding end_time:" << endTime << "(" << endTimestamp << ")";
            query.bindValue(":end_time", endTimestamp);
        }
    }
    
    if (!deviceId.isEmpty()) {
        qDebug() << "Binding device_id:" << deviceId;
        query.bindValue(":device_id", deviceId);
    }
    
    qDebug() << "Executing query";
    bool result = query.exec();
    if (!result) {
        qWarning() << "Failed to delete TDLAS data:" << query.lastError().text();
    } else {
        qDebug() << "Deleted" << query.numRowsAffected() << "TDLAS data records";
    }
    
    return result;
}

bool TdlasDataManager::deleteAllData() {
    qDebug() << "deleteAllData called on thread:" << QThread::currentThread();
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    qDebug() << "Mutex locked for deleteAll operation";
    
    // 检查数据库连接
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open in deleteAllData";
        return false;
    }
    
    QSqlQuery query(m_db);
    bool result = query.exec("DELETE FROM TdlasConcentrationData");
    
    if (!result) {
        qWarning() << "Failed to delete all TDLAS data:" << query.lastError().text();
    } else {
        qDebug() << "Deleted all TDLAS data records";
    }
    
    return result;
}

// 获取统计信息
QVariantMap TdlasDataManager::getStatistics(const QString& startTime,
                                           const QString& endTime,
                                           const QString& deviceId) {
    qDebug() << "getStatistics called with startTime:" << startTime << "endTime:" << endTime << "on thread:" << QThread::currentThread();
    
    QVariantMap stats;
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    qDebug() << "Mutex locked for statistics operation";
    
    // 检查数据库连接
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open in getStatistics";
        return stats;
    }
    
    QSqlQuery query(m_db);
    
    // Use SQL aggregate functions instead of loading all data into memory
    QString sql = "SELECT COUNT(*) as totalCount, "
                  "AVG(concentration) as avgConcentration, "
                  "MAX(concentration) as maxConcentration, "
                  "MIN(concentration) as minConcentration "
                  "FROM TdlasConcentrationData";
                  
    QStringList conditions;
    
    // Convert string datetime to Unix timestamps for comparison
    if (!startTime.isEmpty()) {
        QDateTime startDateTime = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
        if (startDateTime.isValid()) {
            qint64 startTimestamp = startDateTime.toSecsSinceEpoch();
            conditions << "timestamp >= :start_time";
        }
    }
    
    if (!endTime.isEmpty()) {
        QDateTime endDateTime = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
        if (endDateTime.isValid()) {
            qint64 endTimestamp = endDateTime.toSecsSinceEpoch();
            conditions << "timestamp <= :end_time";
        }
    }
    
    if (!conditions.isEmpty()) {
        sql += " WHERE " + conditions.join(" AND ");
    }
    
    qDebug() << "Prepared SQL:" << sql;
    
    if (!query.prepare(sql)) {
        qWarning() << "Failed to prepare statistics query:" << query.lastError().text();
        return stats;
    }
    
    if (!startTime.isEmpty()) {
        QDateTime startDateTime = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
        if (startDateTime.isValid()) {
            qint64 startTimestamp = startDateTime.toSecsSinceEpoch();
            qDebug() << "Binding start_time:" << startTime << "(" << startTimestamp << ")";
            query.bindValue(":start_time", startTimestamp);
        }
    }
    
    if (!endTime.isEmpty()) {
        QDateTime endDateTime = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
        if (endDateTime.isValid()) {
            qint64 endTimestamp = endDateTime.toSecsSinceEpoch();
            qDebug() << "Binding end_time:" << endTime << "(" << endTimestamp << ")";
            query.bindValue(":end_time", endTimestamp);
        }
    }
    
    qDebug() << "Executing query";
    if (!query.exec() || !query.next()) {
        qWarning() << "Failed to get TDLAS statistics:" << query.lastError().text();
        return stats;
    }
    
    stats["totalCount"] = query.value("totalCount");
    stats["avgConcentration"] = query.value("avgConcentration");
    stats["maxConcentration"] = query.value("maxConcentration");
    stats["minConcentration"] = query.value("minConcentration");
    
    qDebug() << "Statistics calculated - count:" << stats["totalCount"] 
             << "avg:" << stats["avgConcentration"] 
             << "max:" << stats["maxConcentration"] 
             << "min:" << stats["minConcentration"];
    
    return stats;
}