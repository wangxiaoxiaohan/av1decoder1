#ifndef THERMAL_CTL_H
#define THERMAL_CTL_H

#include <QObject>
#include <QString>
#include <QJsonObject>
#include <QJsonArray>
#include <QDateTime>

#include <thread>
#include <QTimer>
#include "src/model/alarmmodel.h"

// PTZ操作方法常量定义
enum PtzOperationMethod 
{
    PTZ_FOCUS_SHORT = 8,      // 焦距变短
    PTZ_FOCUS_LONG = 9,       // 焦距变长
    PTZ_FOCUS_NEAR = 10,      // 聚焦变近
    PTZ_FOCUS_FAR = 11,       // 聚焦变远
    PTZ_APERTURE_SMALL = 12,  // 光圈变小
    PTZ_APERTURE_LARGE = 13   // 光圈变大
};

enum PseudocolorType 
{
    WHITE_HOT,      // 白热
    BLACK_HOT,      // 黑热
    IRON_RED,       // 铁红
    CYANIDE_BLUE,   // 花青（使用专业化学色名）
    RAINBOW,        // 彩虹
    INVERSE_RAINBOW,// 反彩虹
    RED_BROWN,      // 红棕
    HOT_IRON,       // 热铁
    COOL_COLOR,     // 冷色
    FIRE            // 火灾
};

class ThermalCtl : public QObject{
Q_OBJECT
public:
    // 登录重试相关常量
    static const int MAX_LOGIN_RETRY_COUNT = 3;  // 最大登录重试次数
    static const int LOGIN_RETRY_DELAY_MS = 2000; // 登录重试延迟(毫秒)
    
    explicit ThermalCtl(QObject* parent = nullptr);
    ~ThermalCtl();
    Q_INVOKABLE void LoginThermal(QString ip, QString user, QString passwd, QString deviceName = QString(), QString deviceId = QString());
    Q_INVOKABLE void mvKeepAlive();
    Q_INVOKABLE void setPseudoMode(int mode);
    Q_INVOKABLE void enhanceInfraRed(bool brightMutation = true,
                              bool denoise2DEnable = true, int denoise2DLevel = 2,
                              bool denoise3DEnable = true, int denoise3DLevel = 3,
                              bool ddeEnable = true, int ddeLevel = 4,
                              int flipMode = 4,
                              bool regionalEnable = true, int regionalLevel = 4,
                              int coordX = 4, int coordY = 4);
    
    // New method to set thermal image parameters
    Q_INVOKABLE void setThermalImageParams(int brightness, int contrast, int flipMode = 0);
    // New method to get thermal image parameters
    Q_INVOKABLE QJsonObject getThermalImageParams(bool defaultConfig = false);
    Q_INVOKABLE void rebootThermal(); // New method to reboot the thermal camera
    Q_INVOKABLE void factoryResetThermal(); // New method to factory reset the thermal camera

    // Recording related APIs
    Q_INVOKABLE QJsonObject getRecordCtrl(bool defaultConfig = false);
    Q_INVOKABLE bool setRecordCtrl(int packageTime, int prerecordTime, int streamType);
    Q_INVOKABLE QJsonObject getRecordSchedule(int channel, bool defaultConfig = false);
    Q_INVOKABLE bool setRecordSchedule(int channel, const QJsonObject& scheduleConfig);
    
    // Snapshot related APIs
    Q_INVOKABLE QJsonObject getSnapSchedule(int channel, bool defaultConfig = false);
    Q_INVOKABLE bool setSnapSchedule(int channel, int mode, bool storageFTP, bool storageLocal, QString startTime = "00:00:00", QString endTime = "23:59:59");
    
    // ONVIF related APIs
    Q_INVOKABLE bool addOnvifUser(const QString& name, const QString& password, int group = 0);
    Q_INVOKABLE bool getOnvifAuth(bool defaultConfig = false);
    Q_INVOKABLE bool setOnvifAuth(bool authEnabled);
    Q_INVOKABLE bool changeOnvifUserPassword(const QString& name, const QString& newPassword);
    Q_INVOKABLE bool deleteOnvifUser(const QString& name);
    Q_INVOKABLE QJsonArray getOnvifUsers();
    
    // GB28181 related APIs
    Q_INVOKABLE QJsonObject getGb28181Config(bool defaultConfig = false);
    Q_INVOKABLE bool setGb28181Config(const QJsonObject& gbConfig);
    
    // Focus Zoom related APIs
    Q_INVOKABLE QJsonObject getFocusZoom(int channel = 0, bool defaultConfig = false);
    Q_INVOKABLE bool setFocusZoom(int channel = 0, int digitalZoom = 0, bool debug = false);
    
    // PTZ Operation APIs (变倍/聚焦/光圈控制)
    Q_INVOKABLE bool ptzOperation(int method);
    Q_INVOKABLE bool ptzStopFocus();  // 变倍聚焦停止
    
    // Device exception alarm
    void addDeviceExceptionAlarm(const QString& exceptionCode, const QString& exceptionName, const QString& exceptionComponent);

signals:
    void mvKeepAliveRequested();
    void setPseudoModeRequested(int mode);
    void enhanceInfraRedRequested(bool brightMutation, bool denoise2DEnable, int denoise2DLevel,
                                 bool denoise3DEnable, int denoise3DLevel, bool ddeEnable, int ddeLevel,
                                 int flipMode, bool regionalEnable, int regionalLevel, int coordX, int coordY);
    void setThermalImageParamsRequested(int brightness, int contrast, int flipMode);
    void getThermalImageParamsRequested(bool defaultConfig);
    void rebootThermalRequested();
    void factoryResetThermalRequested();
    void setRecordCtrlRequested(int packageTime, int prerecordTime, int streamType);
    void setRecordScheduleRequested(int channel, const QJsonObject& scheduleConfig);
    void setSnapScheduleRequested(int channel, int mode, bool storageFTP, bool storageLocal, QString startTime, QString endTime);
    void addOnvifUserRequested(const QString& name, const QString& password, int group);
    void setOnvifAuthRequested(bool authEnabled);
    void changeOnvifUserPasswordRequested(const QString& name, const QString& newPassword);
    void deleteOnvifUserRequested(const QString& name);
    void setGb28181ConfigRequested(const QJsonObject& gbConfig);
    void setFocusZoomRequested(int channel, int digitalZoom, bool debug);
    void ptzOperationRequested(int method);
    void ptzStopFocusRequested();  // 变倍聚焦停止信号
    void loginThermalRequested(QString ip, QString user, QString passwd, QString deviceName, QString deviceId);

private slots:
    void doMvKeepAlive();
    void doSetPseudoMode(int mode);
    void doEnhanceInfraRed(bool brightMutation, bool denoise2DEnable, int denoise2DLevel,
                          bool denoise3DEnable, int denoise3DLevel, bool ddeEnable, int ddeLevel,
                          int flipMode, bool regionalEnable, int regionalLevel, int coordX, int coordY);
    void doSetThermalImageParams(int brightness, int contrast, int flipMode);
    QJsonObject dogetThermalImageParams(bool defaultConfig);
    void doRebootThermal();
    void doFactoryResetThermal();
    void doSetRecordCtrl(int packageTime, int prerecordTime, int streamType);
    void doSetRecordSchedule(int channel, const QJsonObject& scheduleConfig);
    void doSetSnapSchedule(int channel, int mode, bool storageFTP, bool storageLocal, QString startTime, QString endTime);
    void doAddOnvifUser(const QString& name, const QString& password, int group);
    void doSetOnvifAuth(bool authEnabled);
    void doChangeOnvifUserPassword(const QString& name, const QString& newPassword);
    void doDeleteOnvifUser(const QString& name);
    void doSetGb28181Config(const QJsonObject& gbConfig);
    void doSetFocusZoom(int channel, int digitalZoom, bool debug);
    void doPtzOperation(int method);
    void doPtzStopFocus();  // 变倍聚焦停止槽函数
    void doLoginThermal(QString ip, QString user, QString passwd, QString deviceName, QString deviceId);
    void retryLoginThermal(); // 重试登录槽函数

private:
    QString mUsername;
    QString mPassWord;
    QString mServerIp;
    QString mToken;
    QString mDeviceName;  // 添加设备名称字段
    QString mDeviceId;
    
    // 登录重试相关成员
    int mLoginRetryCount;  // 当前登录重试次数
    QString mPendingIp;     // 待重试的登录IP
    QString mPendingUser;  // 待重试的用户名
    QString mPendingPasswd; // 待重试的密码
    QString mPendingDeviceName; // 待重试的设备名称
    QString mPendingDeviceId;   // 待重试的设备ID
    QTimer* mLoginRetryTimer;   // 登录重试定时器
    
    // AES-CBC encryption method for password
    QString encryptPassword(const QString& password);
};

#endif //THERMAL_CTL_H
