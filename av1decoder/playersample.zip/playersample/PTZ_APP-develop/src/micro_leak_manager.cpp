
#include "micro_leak_manager.h"
#include "gasDeviceDetApi.h"
#include "overlay.h"
#include <QDebug>
#include <QFile>
#include <QDir>
#include <QDateTime>
#include <cmath>

MicroLeakManager* MicroLeakManager::m_instance = nullptr;

MicroLeakManager* MicroLeakManager::instance()
{
    if (!m_instance) {
        m_instance = new MicroLeakManager();
    }
    return m_instance;
}

MicroLeakManager::MicroLeakManager(QObject* parent)
    : QObject(parent)
    , m_workerThread(nullptr)
    , m_worker(nullptr)
    , m_initialized(false)
{
    m_workerThread = new QThread();
    m_worker = new MicroLeakWorker();
    m_worker->moveToThread(m_workerThread);

    connect(m_worker, &MicroLeakWorker::processingCompleted, this, &MicroLeakManager::processingFinished);
    connect(m_worker, &MicroLeakWorker::errorOccurred, this, &MicroLeakManager::errorOccurred);
    
    connect(m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    connect(m_workerThread, &QThread::finished, m_workerThread, &QThread::deleteLater);

    m_workerThread->start();
}

MicroLeakManager::~MicroLeakManager()
{
    if (m_workerThread) {
        m_workerThread->quit();
        m_workerThread->wait();
    }
}

bool MicroLeakManager::initialize(const QString& configPath)
{
    QMutexLocker locker(&m_mutex);
    if (m_initialized) return true;

    // Call worker init via invokeMethod to run in worker thread? 
    // Or just call init here if it's thread safe. 
    // gasDeviceDet_create might take time or be thread specific? 
    // Usually creation is fine on main thread if usage is on worker.
    // But let's do it on worker to be safe and consistent.
    
    bool result = false;
    QMetaObject::invokeMethod(m_worker, "init", Qt::BlockingQueuedConnection, 
                              Q_RETURN_ARG(bool, result),
                              Q_ARG(QString, configPath));
    
    m_initialized = result;
    return m_initialized;
}

void MicroLeakManager::processAsync(const QByteArray& yuvData, int width, int height, float tdlas)
{
    if (!m_initialized) return;

    QMetaObject::invokeMethod(m_worker, "process", Qt::QueuedConnection,
                              Q_ARG(QByteArray, yuvData),
                              Q_ARG(int, width),
                              Q_ARG(int, height),
                              Q_ARG(float, tdlas));
}

bool MicroLeakManager::isAvailable() const
{
    return m_initialized;
}

// Worker Implementation

MicroLeakWorker::MicroLeakWorker(QObject* parent)
    : QObject(parent)
    , m_detectorHandle(nullptr)
    , m_initSuccess(false)
{
}

MicroLeakWorker::~MicroLeakWorker()
{
    if (m_detectorHandle) {
        gasDeviceDet_destroy(&m_detectorHandle);
        m_detectorHandle = nullptr;
    }
}

bool MicroLeakWorker::init(const QString& configPath)
{
    qDebug() << "MicroLeakWorker initializing with config:" << configPath;
    
    QByteArray configPathBytes = configPath.toLocal8Bit();
    m_detectorHandle = gasDeviceDet_create(configPathBytes.constData());
    
    if (!m_detectorHandle) {
        qWarning() << "Failed to create gas detector handle";
        return false;
    }

    // Load LUT
    QString lutPath = QDir(configPath).filePath("heatmap_lut.json");
    loadLut(lutPath);

    // Setup default params (reference gaussiandemo.cpp)
    m_params.x_range = {100.0, 2000.0};
    m_params.y_range = {-500.0, 500.0};
    m_params.z = 0.0;
    m_params.stability_class = "D";
    m_params.nx = 100;
    m_params.ny = 80;
    m_params.irregularity_strength = 0.7f;
    m_params.irregularity_scale = 15;
    m_params.clip_min_ratio = 1e-4f;
    m_params.visible_min_ratio = 0.05f;
    m_params.visible_quantile = 0.85f;
    m_params.width_px = 320;
    m_params.height_px = 256;
    m_params.num_directions = 4;
    m_params.direction_spread = 0.7f;
    m_params.random_rotation = true;
    m_params.rotation_min_angle = 10.0f;
    m_params.rotation_max_angle = 60.0f;

    m_initSuccess = true;
    return true;
}

void MicroLeakWorker::loadLut(const QString& path)
{
    std::string stdPath = path.toStdString();
    if (!load_heatmap_lut(stdPath, m_lut)) {
        qWarning() << "Failed to load heatmap LUT from:" << path;
    } else {
        qDebug() << "Loaded heatmap LUT, size:" << m_lut.size();
    }
}

void MicroLeakWorker::process(const QByteArray& yuvData, int width, int height, float tdlas)
{
    if (!m_detectorHandle || yuvData.isEmpty()) {
        emit errorOccurred("Invalid state or data");
        return;
    }

    // Copy data because overlay modifies it
    QByteArray dstData = yuvData;
    unsigned char* pDst = reinterpret_cast<unsigned char*>(dstData.data());

    int offsetX = 0;
    int offsetY = 0;
    // Assume center for TDLAS cursor
    int tdlasX = width / 2;
    int tdlasY = height / 2;

    // 0. Detect
    // Note: gasDeviceDet_detect signature takes `unsigned char *data`.
    // It's unclear if it modifies data. Assuming it reads.
    // Also `channel` should be 1 for YUV? Demo uses 1.
    gasDeviceDet_detect(m_detectorHandle, pDst, width, height, 1, tdlasX, tdlasY, &offsetX, &offsetY);

    // 1. Generate Plume
    // Randomize stability class as in demo?
    // Demo: "C" or "D"
    // For consistency, let's just pick one or randomize lightly.
    // We can use a static counter or random generator.
    // For now, stick to default "D" or what's in params.
    
    // Create Plume object
    GaussianPlumeModel::GaussianPlume plume(
        100.0, // Source strength
        3.0,   // Wind speed
        50.0,  // Stack height
        55.0   // Effective height
    );

    std::vector<unsigned char> plumeImage = GaussianPlumeModel::concentrationMapIrregular(plume, m_params);

    // 2. Render Heatmap
    render_heatmap(plumeImage.data(), m_params.width_px, m_params.height_px, m_lut);

    // 3. Overlay
    // Overlay plume onto dstData
    overlay(plumeImage.data(), m_params.width_px, m_params.height_px,
            pDst, width, height,
            offsetX, offsetY, tdlasX, tdlasY, POSITION_BOTTOM_LEFT);

    // 4. Convert to RGB QImage
    QImage result = yuvToRgb(pDst, width, height);
    
    emit processingCompleted(result, true);
}

QImage MicroLeakWorker::yuvToRgb(const unsigned char* yuv, int width, int height)
{
    // Simple YUV NV12 to RGB conversion
    // Assuming NV12 (YUV420SP)
    
    QImage image(width, height, QImage::Format_RGB888);
    uchar* rgbData = image.bits();
    int rgbStride = image.bytesPerLine();

    const uchar* yData = yuv;
    const uchar* uvData = yuv + width * height;

    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            int Y = yData[y * width + x];
            int uvIndex = (y / 2) * width + (x & ~1);
            int U = uvData[uvIndex] - 128;
            int V = uvData[uvIndex + 1] - 128;

            // Standard conversion
            int R = Y + 1.402 * V;
            int G = Y - 0.344136 * U - 0.714136 * V;
            int B = Y + 1.772 * U;

            // Clamp
            R = (R < 0) ? 0 : (R > 255) ? 255 : R;
            G = (G < 0) ? 0 : (G > 255) ? 255 : G;
            B = (B < 0) ? 0 : (B > 255) ? 255 : B;

            int rgbIndex = y * rgbStride + x * 3;
            rgbData[rgbIndex] = R;
            rgbData[rgbIndex + 1] = G;
            rgbData[rgbIndex + 2] = B;
        }
    }
    return image;
}
