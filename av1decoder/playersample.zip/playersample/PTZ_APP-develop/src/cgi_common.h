#ifndef CGI_COMMON_H
#define CGI_COMMON_H

enum steering_direction {
    STEERING_LEFT = 0,
    STEERING_RIGHT,
    STEERING_UP,
    STEERING_DOWN,
};

#endif //CGI_COMMON_H