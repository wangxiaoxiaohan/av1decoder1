#include "gas_cloud_manager.h"
#include "vis_heatmap_api.h"
#include <QDebug>
#include <QFile>
#include <QDir>
#include <QStandardPaths>
#include <QCoreApplication>
#include <QDateTime>

// 单例实例
GasCloudManager* GasCloudManager::m_instance = nullptr;

GasCloudManager* GasCloudManager::instance()
{
    if (!m_instance) {
        m_instance = new GasCloudManager();
    }
    return m_instance;
}

GasCloudManager::GasCloudManager(QObject* parent)
    : QObject(parent)
    , m_initialized(false)
    , m_workerThread(nullptr)
    , m_worker(nullptr)
{
    qDebug() << "GasCloudManager created";
    
    // 创建工作线程
    m_workerThread = new QThread();
    m_worker = new GasCloudWorker();
    m_worker->moveToThread(m_workerThread);
    
    // 连接信号和槽
    connect(m_worker, &GasCloudWorker::processingCompleted,
            this, &GasCloudManager::gasCloudCompleted);
    
    // 设置线程清理
    connect(m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    connect(m_workerThread, &QThread::finished, m_workerThread, &QThread::deleteLater);
    
    // 启动工作线程
    m_workerThread->start();
    
    qDebug() << "GasCloudManager initialized with worker thread";
}

GasCloudManager::~GasCloudManager()
{
    if (m_workerThread) {
        m_workerThread->quit();
        m_workerThread->wait();
    }
    
    qDebug() << "GasCloudManager destroyed";
}

bool GasCloudManager::initializeGasCloud(const QString& modelPath, const QString& calibrationJsonPath)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        qDebug() << "GasCloudManager already initialized";
        return true;
    }
    
    // 检查文件是否存在
    QFile modelFile(modelPath);
    if (!modelFile.exists()) {
        QString errorMsg = QString("气云分割模型文件不存在: %1").arg(modelPath);
        qCritical() << errorMsg;
        emit gasCloudError(errorMsg);
        return false;
    }
    
    QFile configFile(calibrationJsonPath);
    if (!configFile.exists()) {
        QString errorMsg = QString("标定配置文件不存在: %1").arg(calibrationJsonPath);
        qCritical() << errorMsg;
        emit gasCloudError(errorMsg);
        return false;
    }
    
    // 在工作线程中初始化
    bool result = false;
    QMetaObject::invokeMethod(m_worker, "initialize", Qt::BlockingQueuedConnection,
                             Q_RETURN_ARG(bool, result),
                             Q_ARG(QString, modelPath),
                             Q_ARG(QString, calibrationJsonPath));
    
    if (result) {
        m_initialized = true;
        qDebug() << "GasCloudManager初始化成功";
    } else {
        qCritical() << "GasCloudManager初始化失败";
    }
    
    return result;
}

void GasCloudManager::processGasCloudAsync(const QByteArray& visibleYUV, int visibleWidth, int visibleHeight,
                                          const QByteArray& infraredYUV, int infraredWidth, int infraredHeight,
                                          int depth, float tdlas)
{
    if (!m_initialized) {
        emit gasCloudError("GasCloudManager not initialized");
        return;
    }
    
    // 检查输入数据
    if (visibleYUV.isEmpty() || infraredYUV.isEmpty()) {
        emit gasCloudError("Input YUV data is empty");
        return;
    }
    qDebug() << "processGasCloudAsync";
    // 异步执行气云分割
    QMetaObject::invokeMethod(m_worker, "processGasCloud", Qt::QueuedConnection,
                             Q_ARG(QByteArray, visibleYUV),
                             Q_ARG(int, visibleWidth),
                             Q_ARG(int, visibleHeight),
                             Q_ARG(QByteArray, infraredYUV),
                             Q_ARG(int, infraredWidth),
                             Q_ARG(int, infraredHeight),
                             Q_ARG(int, depth),
                             Q_ARG(float, tdlas));
}

bool GasCloudManager::isGasCloudAvailable() const
{
    QMutexLocker locker(&m_mutex);
    return m_initialized;
}

QString GasCloudManager::getGasCloudStatus() const
{
    if (isGasCloudAvailable()) {
        return "气云分割功能已就绪";
    } else {
        return "气云分割功能未初始化";
    }
}

void GasCloudManager::releaseGasCloud()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        QMetaObject::invokeMethod(m_worker, "release", Qt::QueuedConnection);
        m_initialized = false;
        qDebug() << "GasCloudManager resources released";
    }
}

// GasCloudWorker 实现
GasCloudWorker::GasCloudWorker(QObject* parent)
    : QObject(parent)
    , m_initialized(false)
{
    qDebug() << "GasCloudWorker created";
}

GasCloudWorker::~GasCloudWorker()
{
    release();
    qDebug() << "GasCloudWorker destroyed";
}

bool GasCloudWorker::initialize(const QString& modelPath, const QString& calibrationJsonPath)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        qDebug() << "GasCloudWorker already initialized";
        return true;
    }
    
    m_modelPath = modelPath;
    m_calibrationJsonPath = calibrationJsonPath;
    
    // 调用C API初始化
    int result = vis_heatmap_init(modelPath.toLocal8Bit().constData(), 
                                 calibrationJsonPath.toLocal8Bit().constData());
    
    if (result == 0) {
        m_initialized = true;
        qDebug() << "GasCloudWorker初始化成功";
        qDebug() << "模型路径:" << modelPath;
        qDebug() << "标定文件路径:" << calibrationJsonPath;
    } else {
        qCritical() << "GasCloudWorker初始化失败，错误码:" << result;
    }
    
    return m_initialized;
}

void GasCloudWorker::processGasCloud(const QByteArray& visibleYUV, int visibleWidth, int visibleHeight,
                                    const QByteArray& infraredYUV, int infraredWidth, int infraredHeight,
                                    int depth, float tdlas)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_initialized) {
        emit processingCompleted(QVideoFrame(), QVideoFrame(), false, "GasCloudWorker not initialized");
        return;
    }
    
    // qDebug() << "开始执行气云分割...";
    // qDebug() << "输入: 可见光(" << visibleWidth << "x" << visibleHeight << "), 红外(" << infraredWidth << "x" << infraredHeight << ")";
    
    try {
        // 计算输出缓冲区大小
        int visibleYUVSize = visibleWidth * visibleHeight * 3 / 2;
        int infraredYUVSize = infraredWidth * infraredHeight * 3 / 2;
        int fusionYUVSize = visibleYUVSize;  // 融合结果与可见光同尺寸
        int maskYUVSize = infraredYUVSize;    // mask与可见光同尺寸
        
        // qDebug() << "visibleYUVSize: " << visibleYUVSize;
        // qDebug() << "infraredYUVSize: " << infraredYUVSize;
        // qDebug() << "fusionYUVSize: " << fusionYUVSize;
        // qDebug() << "maskYUVSize: " << maskYUVSize;
        
        // 检查NV12数据大小
        if (visibleYUV.size() != visibleYUVSize) {
            QString errorMsg = QString("可见光NV12数据大小不匹配: 期望%1, 实际%2")
                             .arg(visibleYUVSize).arg(visibleYUV.size());
            qWarning() << errorMsg;
            emit processingCompleted(QVideoFrame(), QVideoFrame(), false, errorMsg);
            return;
        }
        
        if (infraredYUV.size() != infraredYUVSize) {
            QString errorMsg = QString("红外NV12数据大小不匹配: 期望%1, 实际%2")
                             .arg(infraredYUVSize).arg(infraredYUV.size());
            qWarning() << errorMsg;
            emit processingCompleted(QVideoFrame(), QVideoFrame(), false, errorMsg);
            return;
        }
        
        QString timestamp1 = QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss_zzz");
                    QString saveDir1 = QDir::currentPath() + "/gas_cloud_images";
            QDir dir1(saveDir1);
            if (!dir1.exists()) {
                dir1.mkpath(".");
            }

        // saveNV12ToJPG(infraredYUV, infraredWidth, infraredHeight, 
        //             saveDir1 + "/infraredYUV" + timestamp1 + ".jpg");

        // // 保存fusionYUV为JPG
        // saveNV12ToJPG(visibleYUV, visibleWidth, visibleHeight,
        //             saveDir1 + "/visibleYUV" + timestamp1 + ".jpg");

        QByteArray irHeatmapYUV(infraredYUVSize, 0);
        QByteArray fusionYUV(fusionYUVSize, 0);
        QByteArray maskYUV(maskYUVSize, 0);

        //qDebug() << "vis_heatmap_process start time" << QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
        int result = vis_heatmap_process(
            reinterpret_cast<const unsigned char*>(visibleYUV.data()),
            visibleWidth, visibleHeight,
            reinterpret_cast<const unsigned char*>(infraredYUV.data()),
            infraredWidth, infraredHeight,
            depth, tdlas,
            reinterpret_cast<unsigned char*>(irHeatmapYUV.data()),
            infraredYUVSize,
            reinterpret_cast<unsigned char*>(fusionYUV.data()),
            fusionYUVSize,
            reinterpret_cast<unsigned char*>(maskYUV.data()),
            maskYUVSize
        );
        //qDebug() << "vis_heatmap_process end time" << QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
        if (result == 0) {
            // 测试：将YUV数据保存为JPG图像
            QString saveDir = QDir::currentPath() + "/gas_cloud_images";
            QDir dir(saveDir);
            if (!dir.exists()) {
                dir.mkpath(".");
            }
            
            QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss_zzz");
            
            // // 保存irHeatmapYUV为JPG
            //  saveNV12ToJPG(irHeatmapYUV, infraredWidth, infraredHeight, 
            //               saveDir + "/ir_heatmap_" + timestamp + ".jpg");
            
            // // 保存fusionYUV为JPG
            // saveNV12ToJPG(fusionYUV, visibleWidth, visibleHeight,
            //              saveDir + "/fusion_" + timestamp + ".jpg");

            // 转换为QVideoFrame
            // irHeatmapYUV: 红外叠加mask的结果
            QVideoFrame irHeatmapFrame = yuvToVideoFrame(irHeatmapYUV, infraredWidth, infraredHeight);
            // fusionYUV: 可见光叠加mask的结果
            QVideoFrame fusionFrame = yuvToVideoFrame(fusionYUV, visibleWidth, visibleHeight);
            
            emit processingCompleted(fusionFrame, irHeatmapFrame, true, "");
            //qDebug() << "气云分割成功完成";
            //qDebug() << "输出: 可见光叠加mask(" << visibleWidth << "x" << visibleHeight << "), 红外叠加mask(" << infraredWidth << "x" << infraredHeight << ")";
            
        
        } else {
            QString errorMsg = QString("气云分割失败，错误码: %1").arg(result);
            qWarning() << errorMsg;
            emit processingCompleted(QVideoFrame(), QVideoFrame(), false, errorMsg);
        }
        
    } catch (const std::exception& e) {
        QString errorMsg = QString("气云分割过程中发生异常: %1").arg(e.what());
        qCritical() << errorMsg;
        emit processingCompleted(QVideoFrame(), QVideoFrame(), false, errorMsg);
    } catch (...) {
        QString errorMsg = "气云分割过程中发生未知异常";
        qCritical() << errorMsg;
        emit processingCompleted(QVideoFrame(), QVideoFrame(), false, errorMsg);
    }
}

void GasCloudWorker::release()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        vis_heatmap_release();
        m_initialized = false;
        qDebug() << "GasCloudWorker resources released";
    }
}

QVideoFrame GasCloudWorker::yuvToVideoFrame(const QByteArray& yuvData, int width, int height) const
{
    if (yuvData.isEmpty()) {
        return QVideoFrame();
    }
    
    // 创建NV12格式的QVideoFrame（算法返回的是NV12数据）
    QVideoFrame frame(yuvData.size(), QSize(width, height), width, QVideoFrame::Format_NV12);
    if (!frame.map(QAbstractVideoBuffer::WriteOnly)) {
        qWarning() << "Failed to map video frame for writing";
        return QVideoFrame();
    }
    
    // 复制NV12数据
    memcpy(frame.bits(), yuvData.data(), yuvData.size());
    frame.unmap();
    
    return frame;
}

// 添加将NV12格式YUV数据保存为JPG图像的函数
void GasCloudWorker::saveNV12ToJPG(const QByteArray& nv12Data, int width, int height, const QString& filename) const
{
    if (nv12Data.isEmpty()) {
        qWarning() << "NV12 data is empty, cannot save to" << filename;
        return;
    }

    // NV12解码为RGB
    QImage image(width, height, QImage::Format_RGB888);
    const uchar* nv12 = reinterpret_cast<const uchar*>(nv12Data.constData());
    
    // Y plane size
    int ySize = width * height;
    
    const uchar* yPlane = nv12;
    const uchar* uvPlane = nv12 + ySize;
    
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            // Y分量
            int Y = yPlane[y * width + x];
            
            // UV分量(每两个水平像素共享一个UV值)
            int uvIndex = (y / 2) * width + (x / 2) * 2;
            int U = uvPlane[uvIndex];
            int V = uvPlane[uvIndex + 1];
            
            // YUV到RGB转换
            int C = Y - 16;
            int D = U - 128;
            int E = V - 128;
            
            int R = qBound(0, ((298 * C + 409 * E + 128) >> 8), 255);
            int G = qBound(0, ((298 * C - 100 * D - 208 * E + 128) >> 8), 255);
            int B = qBound(0, ((298 * C + 516 * D + 128) >> 8), 255);
            
            image.setPixel(x, y, qRgb(R, G, B));
        }
    }
    
    // 保存为JPG
    if (!image.save(filename, "JPG")) {
        qWarning() << "Failed to save image to" << filename;
    } else {
        qDebug() << "Saved NV12 frame to" << filename;
    }
}

QByteArray GasCloudWorker::videoFrameToYUV(const QVideoFrame& frame) const
{
    if (!frame.isValid()) {
        return QByteArray();
    }
    
    QVideoFrame cloneFrame(frame);
    if (!cloneFrame.map(QAbstractVideoBuffer::ReadOnly)) {
        qWarning() << "Failed to map video frame";
        return QByteArray();
    }
    
    QByteArray yuvData(cloneFrame.bits(), cloneFrame.mappedBytes());
    cloneFrame.unmap();
    
    return yuvData;
}

 