#include "player.h"
#include <QFile>
#include <QCoreApplication>
#include <QDateTime>
#include <iostream>
#include "src/audiooutput.h"
extern "C"{
    #include <libswscale/swscale.h>
    #include <libavutil/time.h>
    #include <libavutil/mathematics.h>
    #include <libavutil/imgutils.h>
}

// 添加像素格式转换函数 (Qt 5.15.2 兼容版本)
static QVideoFrame::PixelFormat avPixelFormatToQt(AVPixelFormat avFormat)
{
    switch (avFormat) {
        case AV_PIX_FMT_YUV420P:
            return QVideoFrame::Format_YUV420P;
        case AV_PIX_FMT_YUV422P:
            return QVideoFrame::Format_YUV422P;
        case AV_PIX_FMT_RGB24:
            return QVideoFrame::Format_RGB24;
        case AV_PIX_FMT_BGR24:
            return QVideoFrame::Format_BGR24;
        case AV_PIX_FMT_ARGB:
            return QVideoFrame::Format_ARGB32;
        case AV_PIX_FMT_BGRA:
            return QVideoFrame::Format_BGRA32;
        case AV_PIX_FMT_YUYV422:
            return QVideoFrame::Format_YUYV;
        case AV_PIX_FMT_UYVY422:
            return QVideoFrame::Format_UYVY;
        case AV_PIX_FMT_NV12:
            return QVideoFrame::Format_NV12;
        case AV_PIX_FMT_NV21:
            return QVideoFrame::Format_NV21;
        // Qt 5中不支持的格式，都转换为YUV420P
        case AV_PIX_FMT_RGBA:
        case AV_PIX_FMT_ABGR:
        case AV_PIX_FMT_YUV420P10LE:
        case AV_PIX_FMT_YUV422P10LE:
        case AV_PIX_FMT_YUV444P:
        default:
            // 如果不支持的格式，返回YUV420P作为默认
            return QVideoFrame::Format_YUV420P;
    }
}

/* no AV sync correction is done if below the minimum AV sync threshold */
#define AV_SYNC_THRESHOLD_MIN 0.04
/* AV sync correction is done if above the maximum AV sync threshold */
#define AV_SYNC_THRESHOLD_MAX 0.1
/* If a frame duration is longer than this, it will not be duplicated to compensate AV sync */
#define AV_SYNC_FRAMEDUP_THRESHOLD 0.1
/* no AV correction is done if too big error */
#define AV_NOSYNC_THRESHOLD 10.0

static QAudioFormat::SampleType avSampleFormatToQt(AVSampleFormat sampleFormat)
{
    switch (sampleFormat) {
        case AV_SAMPLE_FMT_U8:
        case AV_SAMPLE_FMT_U8P:
            return QAudioFormat::UnSignedInt;
        case AV_SAMPLE_FMT_S16:
        case AV_SAMPLE_FMT_S16P:
            return QAudioFormat::SignedInt;
        case AV_SAMPLE_FMT_S32:
        case AV_SAMPLE_FMT_S32P:
            return QAudioFormat::SignedInt;
        case AV_SAMPLE_FMT_FLT:
        case AV_SAMPLE_FMT_FLTP:
            return QAudioFormat::Float;
        case AV_SAMPLE_FMT_DBL:
        case AV_SAMPLE_FMT_DBLP:
            return QAudioFormat::Float;
        default:
            return QAudioFormat::Unknown;
    }
}

playThread::playThread(splayer *player,AVMediaType type):
    mMediaType(type),
    mPlayer(player)
{

}

double vp_duration(splayer *is, AVFrame *vp, AVFrame *nextvp) {
    if (vp && nextvp && vp->pts != AV_NOPTS_VALUE && nextvp->pts != AV_NOPTS_VALUE) {
        double duration = (nextvp->pts - vp->pts) * av_q2d(is->video_timebase);
        if (isnan(duration) || duration <= 0 || duration > is->max_frame_duration) {
             return vp->duration * av_q2d(is->video_timebase);
        }
        else{
            return duration;
        }
    } else {
        return vp->duration * av_q2d(is->video_timebase);
    }
}

double compute_target_delay(double delay, splayer *is)
{
    double sync_threshold, diff = 0;

    /* update delay to follow master synchronisation source */
    if (is->av_sync_type != AV_SYNC_VIDEO_MASTER) {
        /* if video is slave, we try to correct big delays by
           duplicating or deleting a frame */
        diff = is->vidclk.getClock() - is->get_master_clock();

        /* skip or repeat frame. We take into account the
           delay to compute the threshold. */
        sync_threshold = FFMAX(AV_SYNC_THRESHOLD_MIN, FFMIN(AV_SYNC_THRESHOLD_MAX, delay));
        if (!isnan(diff) && fabs(diff) < is->max_frame_duration) {
            if (diff <= -sync_threshold)
                delay = FFMAX(0, delay + diff);
            else if (diff >= sync_threshold && delay > AV_SYNC_FRAMEDUP_THRESHOLD)
                delay = delay + diff;
            else if (diff >= sync_threshold)
                delay = 2 * delay;
        }
    }

    //qDebug() << "video: delay=" << delay << " A-V=" << -diff;

    return delay;
}


void playThread::play_loop(){
        if(mMediaType == AVMEDIA_TYPE_AUDIO){
            while(mPlayer->mMediaStatus != media_stopped){
                AVFrame* aframe = mPlayer->decoder->audio_frame_q->getFilledFrame();
                if (!aframe) {
                    QThread::msleep(10);
                    continue;
                }
                
                if (aframe->pts != AV_NOPTS_VALUE) {
                    double latency = mPlayer->audioOut->getLatency();
                    mPlayer->audclk.setClock(aframe->pts * av_q2d(mPlayer->audio_timebase) - latency);
                }

                int data_size = av_get_bytes_per_sample(mPlayer->decoder->audio_decCtx->sample_fmt);
                if (data_size < 0) {
                    qDebug() << "Failed to calculate audio sample size";
                    mPlayer->decoder->audio_frame_q->releaseFrame(aframe);
                    break;
                }
                
                int size = av_samples_get_buffer_size(NULL, mPlayer->decoder->audio_decCtx->ch_layout.nb_channels,
                                                   aframe->nb_samples,
                                                   mPlayer->decoder->audio_decCtx->sample_fmt, 1);

                if (size <= 0){
                    mPlayer->decoder->audio_frame_q->releaseFrame(aframe);
                    continue;
                }
                
                double pts_duration = aframe->nb_samples * av_q2d(mPlayer->audio_timebase);
                double start_time = av_gettime_relative() / 1000000.0;

                if (av_sample_fmt_is_planar(mPlayer->decoder->audio_decCtx->sample_fmt)) {
                     QByteArray buffer(size, Qt::Uninitialized);
                     char *ptr = buffer.data();
                     for (int i = 0; i < aframe->nb_samples; i++) {
                         for (int ch = 0; ch < mPlayer->decoder->audio_decCtx->ch_layout.nb_channels; ch++) {
                             memcpy(ptr, aframe->data[ch] + data_size * i, data_size);
                             ptr += data_size;
                         }
                     }
                     mPlayer->audioOut->playRawAudio(buffer);
                } else {
                     mPlayer->audioOut->playRawAudio(QByteArray((const char*)aframe->data[0], size));
                }

                mPlayer->decoder->audio_frame_q->releaseFrame(aframe);

                double end_time = av_gettime_relative() / 1000000.0;
                double write_duration = end_time - start_time;

                double time_for_frame = pts_duration / mPlayer->playSpeed;
                double sleep_time = time_for_frame - write_duration;

                if(sleep_time > 0)
                {
                    QThread::usleep(sleep_time * 1000000);
                }
                    
                while(mPlayer->mMediaStatus == media_paused){
                    QThread::msleep(10);
                }
                while(mPlayer->mMediaStatus == media_seeking){
                    mPlayer->audclk.setClock(0);
                    QThread::msleep(10);
                }
            }
        }else{
            AVFrame* last_vp = av_frame_alloc();
            if (!last_vp) {
                qCritical() << "Could not allocate frame for last_vp";
                return;
            }

            double remaining_time = 0.0;
            long long loop_count = 0;
            while(mPlayer->mMediaStatus != media_stopped){

                //if (loop_count++ % 100 == 0) qDebug() << QTime::currentTime().toString("hh:mm:ss.zzz") << "Player heartbeat:" << loop_count << "Queue size:" << mPlayer->decoder->video_frame_q->getFilledCount();

                if (remaining_time > 0.0) {
                    //qDebug() << QTime::currentTime().toString("hh:mm:ss.zzz") << "Player: sleeping for" << remaining_time * 1000 << "ms.";
                    QThread::usleep(remaining_time * 1000000.0);
                }
                remaining_time = 0.01; 
                
                if (mPlayer->mMediaStatus == media_paused || mPlayer->mMediaStatus == media_seeking) {
                     QThread::msleep(10);
                    continue;
                }

                if (mPlayer->decoder->video_frame_q->getFilledCount() == 0) {
                    continue;
                }

                double last_duration, duration, delay;
                AVFrame *vp, *next_vp;

                vp = mPlayer->decoder->video_frame_q->peek();
                if (!vp) {
                    continue;
                }

                last_duration = vp_duration(mPlayer, last_vp, vp);
                delay = compute_target_delay(last_duration, mPlayer);
                
                double time = av_gettime_relative()/1000000.0;

                if (time < mPlayer->frame_timer + delay) {
                    remaining_time = FFMIN(mPlayer->frame_timer + delay - time, remaining_time);
                    //qDebug() << QTime::currentTime().toString("hh:mm:ss.zzz") << "Player: frame too early, will sleep for" << remaining_time * 1000 << "ms.";
                    continue;
                }

                mPlayer->frame_timer += delay;
                if (delay > 0 && time - mPlayer->frame_timer > AV_SYNC_THRESHOLD_MAX) {
                    //qDebug() << QTime::currentTime().toString("hh:mm:ss.zzz") << "Player: frame timer reset. Old:" << mPlayer->frame_timer << "New:" << time;
                    mPlayer->frame_timer = time;
                }

                if (vp->pts != AV_NOPTS_VALUE)
                    mPlayer->vidclk.setClock(vp->pts * av_q2d(mPlayer->video_timebase));
                if (mPlayer->decoder->video_frame_q->getFilledCount() > 1) {
                    next_vp = mPlayer->decoder->video_frame_q->peekNext();
                    duration = vp_duration(mPlayer, vp, next_vp);
                    if(time > mPlayer->frame_timer + duration){
                        //qDebug() << "Dropping late frame";
                        AVFrame* drop_frame = mPlayer->decoder->video_frame_q->getFilledFrame();
                        mPlayer->decoder->video_frame_q->releaseFrame(drop_frame);
                        //continue;
                    }
                }

                // Drop frames if the queue is getting too full, indicating a slow UI
                //实时流的时候强制丢帧减少延时，这种情况下video_frame_q 设置缓冲数量其实是没有作用的，以这里为准
                //如果存在音频，还需要考虑如何与音频匹配
                if(mPlayer->is_realtime_stream)
                {
                    while (mPlayer->decoder->video_frame_q->getFilledCount() > 4) {
                        //qWarning() << "Video frame queue is full. Dropping one frame to smoothly correct.";
                        AVFrame* drop_frame = mPlayer->decoder->video_frame_q->getFilledFrame();
                        mPlayer->decoder->video_frame_q->releaseFrame(drop_frame);
                        continue;
                    }
                }

                AVFrame* vframe = mPlayer->decoder->video_frame_q->getFilledFrame();
                if (!vframe) {
                    continue;
                }
  
                //qDebug() << QTime::currentTime().toString("hh:mm:ss.zzz") << "Player: emitting frame, queue size is" << mPlayer->decoder->video_frame_q->getFilledCount();
                
                // 获取原始格式和目标格式
                AVPixelFormat srcFormat = (AVPixelFormat)vframe->format;
                QVideoFrame::PixelFormat qtFormat = avPixelFormatToQt(srcFormat);
                
                // 检查是否需要格式转换
                bool needConversion = false;
                AVPixelFormat targetFormat = srcFormat;
                
                // 如果Qt不支持此格式或格式是默认的YUV420P（意味着不支持），则转换为YUV420P
                if (qtFormat == QVideoFrame::Format_YUV420P && srcFormat != AV_PIX_FMT_YUV420P) {
                    needConversion = true;
                    targetFormat = AV_PIX_FMT_YUV420P;
                    qtFormat = QVideoFrame::Format_YUV420P;
                }
                
                AVFrame* displayFrame = vframe;
                AVFrame* convertedFrame = nullptr;
                SwsContext* swsCtx = nullptr;
                
                if (needConversion) {
                    // 创建转换上下文
                    swsCtx = sws_getContext(
                        vframe->width, vframe->height, srcFormat,
                        vframe->width, vframe->height, targetFormat,
                        SWS_FAST_BILINEAR, nullptr, nullptr, nullptr);
                    
                    if (swsCtx) {
                        convertedFrame = av_frame_alloc();
                        convertedFrame->width = vframe->width;
                        convertedFrame->height = vframe->height;
                        convertedFrame->format = targetFormat;
                        
                        if (av_frame_get_buffer(convertedFrame, 32) >= 0) {
                            // 执行格式转换
                            sws_scale(swsCtx, vframe->data, vframe->linesize, 0, vframe->height,
                                     convertedFrame->data, convertedFrame->linesize);
                            displayFrame = convertedFrame;
                        }
                    }
                }
                
                // 计算缓冲区大小
                int size = av_image_get_buffer_size(targetFormat, displayFrame->width, displayFrame->height, 1);
                
                // 对于YUV420P等格式，使用实际宽度作为stride，而不是linesize[0]
                int bytesPerLine = displayFrame->width;
                if (targetFormat == AV_PIX_FMT_RGB24 || targetFormat == AV_PIX_FMT_BGR24) {
                    bytesPerLine = displayFrame->width * 3;
                } else if (targetFormat == AV_PIX_FMT_ARGB || targetFormat == AV_PIX_FMT_BGRA) {
                    bytesPerLine = displayFrame->width * 4;
                }
                
                QVideoFrame f(size, QSize(displayFrame->width, displayFrame->height), bytesPerLine, qtFormat);
                if (f.map(QAbstractVideoBuffer::WriteOnly)) {
                    av_image_copy_to_buffer(
                        (uint8_t*)f.bits(), size,
                        displayFrame->data, displayFrame->linesize,
                        targetFormat, 
                        displayFrame->width, displayFrame->height, 1);
                    f.setStartTime(0);
                    f.unmap();
                    emit mPlayer->newFrameAvailable(f);
                }
                
                // 清理资源
                if (convertedFrame) {
                    av_frame_free(&convertedFrame);
                }
                if (swsCtx) {
                    sws_freeContext(swsCtx);
                }

                av_frame_unref(last_vp);
                av_frame_move_ref(last_vp, vframe);
                mPlayer->decoder->video_frame_q->releaseFrame(vframe);

            }

            av_frame_free(&last_vp);
            qDebug()  << "vvvvvvvvv!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! video play loop exit";
        }
}
splayer::splayer(){
    demuxer = new demux();
    decoder = new decode();
    decoder->audio_packq =  demuxer->audio_packq;
    decoder->video_packq =  demuxer->video_packq;
    decoder->subtitle_packq =  demuxer->subtitle_packq;
    audioOut = new audioOutput(this);

    mMediaStatus  = media_idle;
    playSpeed = 1.0;
    //av_sync_type = AV_SYNC_EXTERNAL_CLOCK;
    av_sync_type = AV_SYNC_AUDIO_MASTER;
    frame_timer = 0;
    max_frame_duration = 10.0;
    is_realtime_stream = false;
    
    // 初始化线程指针
    audio_th = nullptr;
    video_th = nullptr;
    fmt_ctx = nullptr;
    
    // 连接所有信号和槽，确保异步执行
    connect(this, &splayer::playRequested,
            this, &splayer::doPlay,
            Qt::QueuedConnection);
    connect(this, &splayer::pauseRequested,
            this, &splayer::doPause,
            Qt::QueuedConnection);
    connect(this, &splayer::stopRequested,
            this, &splayer::doStop,
            Qt::QueuedConnection);
    connect(this, &splayer::seekRequested,
            this, &splayer::doSeek,
            Qt::QueuedConnection);
    connect(this, &splayer::setPlayRateRequested,
            this, &splayer::doSetPlayRate,
            Qt::QueuedConnection);
    connect(this, &splayer::prepareRequested,
            this, &splayer::doPrepare,
            Qt::QueuedConnection);
    connect(this, &splayer::resetRequested,
            this, &splayer::doReset,
            Qt::QueuedConnection);
    connect(this, &splayer::switchUrlRequested,
            this, &splayer::doSwitchUrl,
            Qt::QueuedConnection);
    connect(this, &splayer::fastSwitchUrlRequested, this, &splayer::doFastSwitchUrl, Qt::QueuedConnection);
    
    qDebug() << "main thread id" << QThread::currentThreadId();
}
splayer::~splayer(){
    // 确保播放器完全停止
    if(mMediaStatus != media_idle && mMediaStatus != media_stopped) {
        doStop();
    }
    
    // 等待所有线程结束
    if(audio_th) {
        audio_th->wait(3000);
    }
    if(video_th) {
        video_th->wait(3000);
    }
    
    // 清理资源
    if(demuxer) {
        delete demuxer;
        demuxer = nullptr;
    }
    if(decoder) {
        delete decoder; 
        decoder = nullptr;
    }
    if(audioOut) {
        delete audioOut;
        audioOut = nullptr;
    }
    
    qDebug() << "splayer destructor completed";
}

void splayer::play(){
    // 只发信号，不做耗时工作
    emit playRequested();
}

void splayer::doPlay(){
    if (mMediaStatus == media_paused) {
        vidclk.resume();
        audclk.resume();
        extclk.resume();
        audioOut->resume();
    }
    mMediaStatus = media_playing;
}
void splayer::reset(){
    // 只发信号，不做耗时工作
    emit resetRequested();
}

void splayer::doReset(){
    mMediaStatus = media_idle;
}
void splayer::play_loop(){
    if(demuxer->audio_steam_index >= 0){
        audio_th = new QThread;
        playThread *aP =  new playThread(this,AVMEDIA_TYPE_AUDIO);
        aP->moveToThread(audio_th);
        connect(audio_th, SIGNAL(started()), aP, SLOT(play_loop()));
        connect(audio_th, SIGNAL(finished()), audio_th, SLOT(deleteLater()));
        connect(audio_th, SIGNAL(finished()), aP, SLOT(deleteLater()));
        audio_th->start();

    }

    if(demuxer->video_steam_index >= 0){
        video_th = new QThread;
        playThread *vP =  new playThread(this,AVMEDIA_TYPE_VIDEO);
        vP->moveToThread(video_th);
        connect(video_th, SIGNAL(started()), vP, SLOT(play_loop()));
        connect(video_th, SIGNAL(finished()), video_th, SLOT(deleteLater()));
        connect(video_th, SIGNAL(finished()), vP, SLOT(deleteLater()));
        video_th->start();
    }

}
void splayer::pause(){
    // 只发信号，不做耗时工作
    emit pauseRequested();
}

void splayer::doPause(){
    if (mMediaStatus == media_playing) {
        double time = av_gettime_relative()/1000000.0;
        vidclk.pause(time);
        audclk.pause(time);
        extclk.pause(time);
        audioOut->suspend();
        mMediaStatus = media_paused;
    }
}
void splayer::stop(){
    // 只发信号，不做耗时工作
    emit stopRequested();
}

void splayer::doStop(){
    stopState();
    QThread::usleep(30000);
    if(audioOut) audioOut->stop();
    stopDecoderDemuxer();
    
    // 等待所有线程完全结束
    if(audio_th) {
        audio_th->wait(3000);  // 等待最多3秒
        audio_th = nullptr;
    }
    if(video_th) {
        video_th->wait(3000);  // 等待最多3秒
        video_th = nullptr;
    }
    
    // 重置状态
    fmt_ctx = nullptr;
    qDebug() << "Player stop completed, all threads terminated";
}
void splayer::stopState(){
    if(mMediaStatus == media_stopped)
        return;
    mMediaStatus = media_stopped;
    if(demuxer->audio_steam_index >= 0)
        audio_th->quit();
    if(demuxer->video_steam_index >= 0)
        video_th->quit();

}
void splayer::stopDecoderDemuxer(){
    demuxer->stop();
    std::cout <<"demux quit done"<< std::endl  << std::flush;

    decoder->stop();
    std::cout << "decoder quit  done" << std::endl  << std::flush;
}

double splayer::get_master_clock()
{
    double val;
    int sync_type = av_sync_type;

    if (sync_type == AV_SYNC_VIDEO_MASTER) {
        if (demuxer->video_steam_index >= 0)
            val = vidclk.getClock();
        else
            val = audclk.getClock();
    } else if (sync_type == AV_SYNC_AUDIO_MASTER) {
        if (demuxer->audio_steam_index >= 0)
            val = audclk.getClock();
        else
            val = vidclk.getClock();
    } else {
        val = extclk.getClock();
    }
    return val;
}

void splayer::seek(double precent){
    // 只发信号，不做耗时工作
    emit seekRequested(precent);
}

void splayer::doSeek(double precent){
    mMediaStatus = media_seeking;
    decoder->pauseDecode();
    if(audioOut) {
        QMetaObject::invokeMethod(audioOut, "stop", Qt::QueuedConnection);
    }
    QThread::usleep(30000);

    qDebug() << "seek precent" << precent;
    
    // 获取有效的duration
    int64_t duration = 0;
    
    // 首先尝试从格式上下文获取duration
    if (fmt_ctx->duration != AV_NOPTS_VALUE) {
        duration = fmt_ctx->duration;
        qDebug() << "Using format context duration:" << duration;
    } else {
        // 如果格式上下文没有duration，尝试从视频流获取
        if (demuxer->video_steam_index >= 0) {
            AVStream *video_stream = fmt_ctx->streams[demuxer->video_steam_index];
            if (video_stream->duration != AV_NOPTS_VALUE) {
                duration = av_rescale_q(video_stream->duration, video_stream->time_base, AV_TIME_BASE_Q);
                qDebug() << "Using video stream duration:" << duration;
            }
        }
        
        // 如果视频流也没有，尝试从音频流获取
        if (duration == 0 && demuxer->audio_steam_index >= 0) {
            AVStream *audio_stream = fmt_ctx->streams[demuxer->audio_steam_index];
            if (audio_stream->duration != AV_NOPTS_VALUE) {
                duration = av_rescale_q(audio_stream->duration, audio_stream->time_base, AV_TIME_BASE_Q);
                qDebug() << "Using audio stream duration:" << duration;
            }
        }
        
        // 最后尝试估算（适用于某些文件）
        if (duration == 0) {
            // 对于实时流或无法确定duration的文件，使用一个默认值或跳过seek
            qWarning() << "Cannot determine file duration, seek may not work properly";
            mMediaStatus = media_playing;
            return;
        }
    }
    
    // 计算目标时间戳
    // duration已经是AV_TIME_BASE单位，直接按百分比计算
    double target_timestamp = (double)duration * precent / 100.0;
    qDebug() << "Final duration:" << duration << "target_timestamp (AV_TIME_BASE units):" << target_timestamp;
    qDebug() << "Target time in seconds:" << target_timestamp / AV_TIME_BASE;
    
    // demuxer->seek接受double，这个值会直接传递给avformat_seek_file作为target_ts
    demuxer->seek(target_timestamp);
    
    vidclk.setClock(0);
    audclk.setClock(0);
    extclk.setClock(0);
    frame_timer = av_gettime_relative()/1000000.0;

    if(audioOut && demuxer->audio_steam_index >=0) {
        QMetaObject::invokeMethod(audioOut, "start", Qt::QueuedConnection);
    }
    QThread::usleep(60000);
    decoder->continueDecode();
    QThread::usleep(30000);
    doPlay();
}
void splayer::setPlayRate(double speed){
    // 只发信号，不做耗时工作
    emit setPlayRateRequested(speed);
}

void splayer::doSetPlayRate(double speed){
    playSpeed = speed;
}
double splayer::playRate(){
    return playSpeed;
}
enum mediaStatus splayer::mediaStatus(){
    return mMediaStatus;
}
void splayer::prepare(QString file){
    // 只发信号，不做耗时工作
    emit prepareRequested(file);
}

void splayer::doPrepare(QString file){
    // 确保之前的播放已经完全停止
    if(mMediaStatus == media_playing) {
        doStop();
    }
    
    // 如果正在停止过程中，等待完成
    while(mMediaStatus == media_stopped && (audio_th != nullptr || video_th != nullptr)) {
        QThread::msleep(10);
    }

    if (file.startsWith("rtsp://", Qt::CaseInsensitive) || file.startsWith("rtmp://", Qt::CaseInsensitive)) {
        is_realtime_stream = true;
        qDebug() << "Detected real-time stream.";
    } else {
        is_realtime_stream = false;
        qDebug() << "Detected file stream.";
    }

    mMediaStatus = media_paused;
    
    // 确保demuxer和decoder完全重置
    if(demuxer) {
        delete demuxer;
        demuxer = new demux();
    }
    if(decoder) {
        delete decoder;
        decoder = new decode();
        // 重新连接packet queue
        decoder->audio_packq =  demuxer->audio_packq;
        decoder->video_packq =  demuxer->video_packq;
        decoder->subtitle_packq =  demuxer->subtitle_packq;
    }

// start demuxer
    qDebug()  << "demux openfile start ";
    int ret  = demuxer->openFile(file);
    if(ret < 0) {
        qWarning() << "Failed to open file" << file;
        mMediaStatus = media_idle;
        return;
    }
    qDebug()  << "demux openfile done " ;

    fmt_ctx = demuxer->fmtCtx;
    max_frame_duration = (fmt_ctx->iformat->flags & AVFMT_TS_DISCONT) ? 10.0 : 3600.0;

    // 调试duration信息
    qDebug() << "=== Duration Information ===";
    qDebug() << "Format context duration:" << fmt_ctx->duration;
    qDebug() << "Format context duration (seconds):" << (fmt_ctx->duration != AV_NOPTS_VALUE ? (double)fmt_ctx->duration / AV_TIME_BASE : -1);
    
    if(demuxer->video_steam_index >= 0) {
        AVStream *video_stream = fmt_ctx->streams[demuxer->video_steam_index];
        qDebug() << "Video stream duration:" << video_stream->duration;
        qDebug() << "Video stream duration (seconds):" << (video_stream->duration != AV_NOPTS_VALUE ? 
            av_q2d(video_stream->time_base) * video_stream->duration : -1);
        video_timebase = video_stream->time_base;
    }

    if(demuxer->audio_steam_index >= 0) {
        AVStream *audio_stream = fmt_ctx->streams[demuxer->audio_steam_index];
        qDebug() << "Audio stream duration:" << audio_stream->duration;
        qDebug() << "Audio stream duration (seconds):" << (audio_stream->duration != AV_NOPTS_VALUE ? 
            av_q2d(audio_stream->time_base) * audio_stream->duration : -1);
        audio_timebase = audio_stream->time_base;
    }
    
    qDebug() << "=============================";


// start play loop
    play_loop();

    qDebug() << "audio_timebase" << audio_timebase.num << audio_timebase.den;
    qDebug() << "video_timebase" << video_timebase.num << video_timebase.den;
    demuxer->start(file);
    qDebug()  << "demux start done ";

// start decoder
    
    vidclk.setClock(0);
    audclk.setClock(0);
    extclk.setClock(0);

    decoder->start(fmt_ctx);
    if(demuxer->audio_steam_index >= 0){
        AVCodecContext *audioCtx = decoder->audio_decCtx;
        audioOut->setAudioFormat("audio/pcm",
                                 audioCtx->sample_rate,
                                 av_get_bytes_per_sample(audioCtx->sample_fmt) * 8,
                                 audioCtx->ch_layout.nb_channels,
                                 avSampleFormatToQt(audioCtx->sample_fmt),
                                 QAudioFormat::LittleEndian);
        audioOut->start();
    }
    qDebug()  << "decode start done ";
    frame_timer = av_gettime_relative() / 1000000.0;

}

void splayer::switchUrl(QString newUrl){
    // 只发信号，不做耗时工作
    emit switchUrlRequested(newUrl);
}

void splayer::doSwitchUrl(QString newUrl){
    qDebug() << "Switching from current URL to:" << newUrl;
    
    // 停止当前播放
    doStop();
    
    // 短暂延迟确保停止完成
    QThread::msleep(100);
    
    // 准备新URL
    doPrepare(newUrl);
    
    // 开始播放
    doPlay();
    
    qDebug() << "URL switch completed successfully";
}

void splayer::fastSwitchUrl(QString newUrl){
    qDebug() << "fastSwitchUrl" << newUrl;
    emit fastSwitchUrlRequested(newUrl);
}

void splayer::doFastSwitchUrl(QString newUrl){
    static QMutex switchMutex;
    QMutexLocker locker(&switchMutex);
    
    qDebug() << "=== Fast switching START ===";
    qDebug() << "Switching from current URL to:" << newUrl;
    qDebug() << "Current media status:" << mMediaStatus;
    
    // 在开始时就检查decoder状态
    qDebug() << "DEMUX: At start - video_decCtx address:" << decoder->video_decCtx;
    qDebug() << "DEMUX: At start - audio_decCtx address:" << decoder->audio_decCtx;
    if(decoder->video_decCtx) {
        qDebug() << "DEMUX: At start - video_decCtx->codec_id:" << decoder->video_decCtx->codec_id;
    }
    if(decoder->audio_decCtx) {
        qDebug() << "DEMUX: At start - audio_decCtx->codec_id:" << decoder->audio_decCtx->codec_id;
    }
    
    if(mMediaStatus != media_playing && mMediaStatus != media_paused) {
        qWarning() << "Cannot fast switch when not playing/paused, current status:" << mMediaStatus;
        return;
    }
    
    // 防止重复切换同一个URL
    static QString lastUrl;
    if(newUrl == lastUrl) {
        qDebug() << "Same URL already switching/switched, ignoring duplicate request";
        return;
    }
    lastUrl = newUrl;
    
    qDebug() << "Step 1: Pausing playback...";
    bool wasPlaying = (mMediaStatus == media_playing);
    doPause();
    qDebug() << "Media status after pause:" << mMediaStatus;
    
    qDebug() << "Step 2: Pausing decoders...";
    qDebug() << "DEMUX: Before pause - video_decCtx address:" << decoder->video_decCtx;
    qDebug() << "DEMUX: Before pause - audio_decCtx address:" << decoder->audio_decCtx;
    if(decoder->video_decCtx) {
        qDebug() << "DEMUX: Before pause - video_decCtx->codec_id:" << decoder->video_decCtx->codec_id;
    }
    if(decoder->audio_decCtx) {
        qDebug() << "DEMUX: Before pause - audio_decCtx->codec_id:" << decoder->audio_decCtx->codec_id;
    }
    decoder->pauseDecode();
    
    qDebug() << "Step 3: Stopping audio output...";
    if(audioOut) {
        audioOut->stop();
        qDebug() << "Audio output stopped";
    }
    
    // 等待解码器暂停完成
    qDebug() << "Step 3.5: Waiting for decoders to pause...";
    QThread::msleep(100);
    
    qDebug() << "DEMUX: After pause - video_decCtx address:" << decoder->video_decCtx;
    qDebug() << "DEMUX: After pause - audio_decCtx address:" << decoder->audio_decCtx;
    if(decoder->video_decCtx) {
        qDebug() << "DEMUX: After pause - video_decCtx->codec_id:" << decoder->video_decCtx->codec_id;
    }
    if(decoder->audio_decCtx) {
        qDebug() << "DEMUX: After pause - audio_decCtx->codec_id:" << decoder->audio_decCtx->codec_id;
    }
    
    qDebug() << "Step 4: Switching demuxer URL...";
    qDebug() << "DEMUX: Before URL switch - video_decCtx address:" << decoder->video_decCtx;
    qDebug() << "DEMUX: Before URL switch - audio_decCtx address:" << decoder->audio_decCtx;
    if(decoder->video_decCtx) {
        qDebug() << "DEMUX: Before URL switch - video_decCtx->codec_id:" << decoder->video_decCtx->codec_id;
    }
    if(decoder->audio_decCtx) {
        qDebug() << "DEMUX: Before URL switch - audio_decCtx->codec_id:" << decoder->audio_decCtx->codec_id;
    }
    demuxer->switchUrl(newUrl);
    qDebug() << "Demuxer URL switch requested";
    
    qDebug() << "Step 5: Waiting for demuxer to switch...";
    QThread::msleep(500); // 增加等待时间确保切换完成
    
    // 等待demuxer切换完成
    int waitCount = 0;
    while (demuxer->isSwitching() && waitCount < 50) { // 最多等待5秒
        QThread::msleep(100);
        waitCount++;
        qDebug() << "DEMUX: Waiting for switch to complete, attempt" << waitCount;
    }
    
    if (demuxer->isSwitching()) {
        qCritical() << "DEMUX: URL switch timeout after 5 seconds!";
        lastUrl.clear();
        return;
    }
    
    qDebug() << "DEMUX: After URL switch - video_decCtx address:" << decoder->video_decCtx;
    qDebug() << "DEMUX: After URL switch - audio_decCtx address:" << decoder->audio_decCtx;
    if(decoder->video_decCtx) {
        qDebug() << "DEMUX: After URL switch - video_decCtx->codec_id:" << decoder->video_decCtx->codec_id;
    }
    if(decoder->audio_decCtx) {
        qDebug() << "DEMUX: After URL switch - audio_decCtx->codec_id:" << decoder->audio_decCtx->codec_id;
    }
    
    qDebug() << "Step 6: Updating format context...";
    fmt_ctx = demuxer->fmtCtx;
    if(!fmt_ctx) {
        qCritical() << "Format context is null after URL switch!";
        lastUrl.clear(); // 清除失败的URL记录
        return;
    }
    qDebug() << "Format context updated successfully";
    qDebug() << "New fmt_ctx address:" << fmt_ctx;
    qDebug() << "New fmt_ctx->nb_streams:" << fmt_ctx->nb_streams;
    
    // Check and reinitialize decoders if codec changed
    bool videoCodecChanged = false;
    bool audioCodecChanged = false;
    
    if(demuxer->video_steam_index >= 0) {
        qDebug() << "Step 7a: Checking video codec...";
        qDebug() << "DEMUX: fmt_ctx address:" << fmt_ctx;
        qDebug() << "DEMUX: fmt_ctx->streams address:" << fmt_ctx->streams;
        qDebug() << "DEMUX: fmt_ctx->nb_streams:" << fmt_ctx->nb_streams;
        qDebug() << "DEMUX: video_steam_index:" << demuxer->video_steam_index;
        
        // 添加严格的边界检查
        if (!fmt_ctx || !fmt_ctx->streams || 
            demuxer->video_steam_index >= fmt_ctx->nb_streams || 
            demuxer->video_steam_index < 0) {
            qCritical() << "DEMUX: Invalid video stream index or format context!";
            qCritical() << "DEMUX: fmt_ctx:" << fmt_ctx;
            qCritical() << "DEMUX: fmt_ctx->streams:" << (fmt_ctx ? fmt_ctx->streams : nullptr);
            qCritical() << "DEMUX: fmt_ctx->nb_streams:" << (fmt_ctx ? fmt_ctx->nb_streams : -1);
            qCritical() << "DEMUX: video_steam_index:" << demuxer->video_steam_index;
            lastUrl.clear(); // 清除失败的URL记录
            return;
        }
        
        AVStream *new_video_stream = fmt_ctx->streams[demuxer->video_steam_index];
        qDebug() << "DEMUX: new_video_stream address:" << new_video_stream;
        
        // 添加更详细的检查
        if (!new_video_stream) {
            qCritical() << "DEMUX: new_video_stream is null!";
            lastUrl.clear();
            return;
        }
        
        qDebug() << "DEMUX: new_video_stream->codecpar address:" << new_video_stream->codecpar;
        
        if (!new_video_stream->codecpar) {
            qCritical() << "DEMUX: new_video_stream->codecpar is null!";
            lastUrl.clear();
            return;
        }
        
        qDebug() << "DEMUX: new_video_stream->codecpar->codec_id:" << new_video_stream->codecpar->codec_id;
        
        if (!decoder->video_decCtx) {
            qCritical() << "DEMUX: decoder->video_decCtx is null!";
            lastUrl.clear();
            return;
        }
        
        qDebug() << "DEMUX: decoder->video_decCtx address:" << decoder->video_decCtx;
        qDebug() << "DEMUX: decoder->video_decCtx->codec_id:" << decoder->video_decCtx->codec_id;
        
        if (!new_video_stream || !new_video_stream->codecpar) {
            qCritical() << "DEMUX: Invalid video stream or codec parameters!";
            qCritical() << "DEMUX: new_video_stream:" << new_video_stream;
            qCritical() << "DEMUX: codecpar:" << (new_video_stream ? new_video_stream->codecpar : nullptr);
            lastUrl.clear(); // 清除失败的URL记录
            return;
        }
        
        if (new_video_stream->codecpar->codec_id != decoder->video_decCtx->codec_id) {
            qDebug() << "Video codec changed, reinitializing decoder...";
            decoder->reinitCodec(AVMEDIA_TYPE_VIDEO, fmt_ctx);
            videoCodecChanged = true;
            qDebug() << "Video decoder reinitialized";
        } else {
            qDebug() << "Video codec unchanged, no reinit needed";
        }
        video_timebase = new_video_stream->time_base;
        qDebug() << "Video timebase updated:" << video_timebase.num << "/" << video_timebase.den;
    } else {
        qDebug() << "No video stream found";
    }
    
    if(demuxer->audio_steam_index >= 0) {
        qDebug() << "Step 7b: Checking audio codec...";
        qDebug() << "DEMUX: fmt_ctx address:" << fmt_ctx;
        qDebug() << "DEMUX: fmt_ctx->streams address:" << fmt_ctx->streams;
        qDebug() << "DEMUX: fmt_ctx->nb_streams:" << fmt_ctx->nb_streams;
        qDebug() << "DEMUX: audio_steam_index:" << demuxer->audio_steam_index;
        
        // 添加严格的边界检查
        if (!fmt_ctx || !fmt_ctx->streams || 
            demuxer->audio_steam_index >= fmt_ctx->nb_streams || 
            demuxer->audio_steam_index < 0) {
            qCritical() << "DEMUX: Invalid audio stream index or format context!";
            qCritical() << "DEMUX: fmt_ctx:" << fmt_ctx;
            qCritical() << "DEMUX: fmt_ctx->streams:" << (fmt_ctx ? fmt_ctx->streams : nullptr);
            qCritical() << "DEMUX: fmt_ctx->nb_streams:" << (fmt_ctx ? fmt_ctx->nb_streams : -1);
            qCritical() << "DEMUX: audio_steam_index:" << demuxer->audio_steam_index;
            lastUrl.clear(); // 清除失败的URL记录
            return;
        }
        
        AVStream *new_audio_stream = fmt_ctx->streams[demuxer->audio_steam_index];
        qDebug() << "DEMUX: new_audio_stream address:" << new_audio_stream;
        
        // 添加更详细的检查
        if (!new_audio_stream) {
            qCritical() << "DEMUX: new_audio_stream is null!";
            lastUrl.clear();
            return;
        }
        
        qDebug() << "DEMUX: new_audio_stream->codecpar address:" << new_audio_stream->codecpar;
        
        if (!new_audio_stream->codecpar) {
            qCritical() << "DEMUX: new_audio_stream->codecpar is null!";
            lastUrl.clear();
            return;
        }
        
        qDebug() << "DEMUX: new_audio_stream->codecpar->codec_id:" << new_audio_stream->codecpar->codec_id;
        
        if (!decoder->audio_decCtx) {
            qCritical() << "DEMUX: decoder->audio_decCtx is null!";
            lastUrl.clear();
            return;
        }
        
        qDebug() << "DEMUX: decoder->audio_decCtx address:" << decoder->audio_decCtx;
        qDebug() << "DEMUX: decoder->audio_decCtx->codec_id:" << decoder->audio_decCtx->codec_id;
        
        if (new_audio_stream->codecpar->codec_id != decoder->audio_decCtx->codec_id) {
            qDebug() << "Audio codec changed, reinitializing decoder...";
            decoder->reinitCodec(AVMEDIA_TYPE_AUDIO, fmt_ctx);
            audioCodecChanged = true;
            qDebug() << "Audio decoder reinitialized";
        } else {
            qDebug() << "Audio codec unchanged, no reinit needed";
        }
        audio_timebase = new_audio_stream->time_base;
        qDebug() << "Audio timebase updated:" << audio_timebase.num << "/" << audio_timebase.den;
        
        // Reconfigure audio output
        qDebug() << "Step 8: Reconfiguring audio output...";
        AVCodecContext *audioCtx = decoder->audio_decCtx;
        qDebug() << "Audio sample rate:" << audioCtx->sample_rate;
        qDebug() << "Audio channels:" << audioCtx->ch_layout.nb_channels;
        qDebug() << "Audio sample format:" << audioCtx->sample_fmt;
        
        audioOut->setAudioFormat("audio/pcm",
                                 audioCtx->sample_rate,
                                 av_get_bytes_per_sample(audioCtx->sample_fmt) * 8,
                                 audioCtx->ch_layout.nb_channels,
                                 avSampleFormatToQt(audioCtx->sample_fmt),
                                 QAudioFormat::LittleEndian);
        audioOut->start();
        qDebug() << "Audio output reconfigured and started";
    } else {
        qDebug() << "No audio stream found";
    }
    
    // 等待编解码器重新初始化完成
    if(videoCodecChanged || audioCodecChanged) {
        qDebug() << "Step 8.5: Waiting for codec reinitialization...";
        QThread::msleep(100);
    }
    
    qDebug() << "Step 9: Continuing decode...";
    decoder->continueDecode();
    
    qDebug() << "Step 10: Resetting clocks...";
    vidclk.setClock(0);
    audclk.setClock(0);
    extclk.setClock(0);
    frame_timer = av_gettime_relative()/1000000.0;
    qDebug() << "Clocks reset, frame_timer:" << frame_timer;
    
    qDebug() << "Step 11: Resuming playback...";
    qDebug() << "wasPlaying:" << wasPlaying << "current mMediaStatus:" << mMediaStatus;
    if(wasPlaying) {
        doPlay();
    } else {
        // 即使之前是暂停状态，快速切换后通常也需要播放
        qDebug() << "Force playing after fast switch (was paused)";
        doPlay();
    }
    qDebug() << "Media status after resume:" << mMediaStatus;
    
    qDebug() << "=== Fast switching COMPLETED ===";
}

