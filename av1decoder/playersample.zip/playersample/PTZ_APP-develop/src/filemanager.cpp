#include "filemanager.h"
#include <QStandardPaths>
#include <QJsonDocument>
#include <QJsonObject>
#include <QDir>
#include <QFile>
#include <QTextStream>
#include <QDebug>
#include <QApplication>

const QString FileManager::CONFIG_DIR = "config/user";

FileManager::FileManager(QObject *parent)
    : QObject(parent)
{
    ensureConfigDirectoryExists();
}

bool FileManager::saveUserConfig(const QString &username, const QVariantMap &userInfo)
{
    if (username.isEmpty()) {
        qWarning() << "Username cannot be empty";
        return false;
    }
    
    QString filePath = getUserConfigPath(username);
    
    // 转换QVariantMap到QJsonObject
    QJsonObject jsonObj = QJsonObject::fromVariantMap(userInfo);
    QJsonDocument jsonDoc(jsonObj);
    
    QFile file(filePath);
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "Failed to open file for writing:" << filePath;
        return false;
    }
    
    QTextStream stream(&file);
    stream.setCodec("UTF-8");
    stream << jsonDoc.toJson();
    file.close();
    
    qDebug() << "User config saved successfully:" << filePath;
    return true;
}

bool FileManager::deleteUserConfig(const QString &username)
{
    if (username.isEmpty()) {
        qWarning() << "Username cannot be empty";
        return false;
    }
    
    QString filePath = getUserConfigPath(username);
    
    QFile file(filePath);
    if (!file.exists()) {
        qWarning() << "User config file does not exist:" << filePath;
        return false;
    }
    
    if (!file.remove()) {
        qWarning() << "Failed to delete user config file:" << filePath;
        return false;
    }
    
    qDebug() << "User config deleted successfully:" << filePath;
    return true;
}

QVariantMap FileManager::loadUserConfig(const QString &username)
{
    if (username.isEmpty()) {
        qWarning() << "Username cannot be empty";
        return QVariantMap();
    }
    
    QString filePath = getUserConfigPath(username);
    
    QFile file(filePath);
    if (!file.exists()) {
        qWarning() << "User config file does not exist:" << filePath;
        return QVariantMap();
    }
    
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "Failed to open file for reading:" << filePath;
        return QVariantMap();
    }
    
    QByteArray data = file.readAll();
    file.close();
    
    QJsonParseError error;
    QJsonDocument jsonDoc = QJsonDocument::fromJson(data, &error);
    
    if (error.error != QJsonParseError::NoError) {
        qWarning() << "Failed to parse JSON:" << error.errorString();
        return QVariantMap();
    }
    
    return jsonDoc.object().toVariantMap();
}

bool FileManager::userConfigExists(const QString &username)
{
    if (username.isEmpty()) {
        return false;
    }
    
    QString filePath = getUserConfigPath(username);
    return QFile::exists(filePath);
}

QStringList FileManager::getAllUserConfigs()
{
    QString appDir = QApplication::applicationDirPath();
    QString configDir = appDir + "/config/user";
    QDir dir(configDir);
    QStringList users;
    
    if (dir.exists()) {
        QStringList filters;
        filters << "*.json";
        QFileInfoList files = dir.entryInfoList(filters, QDir::Files);
        
        for (const QFileInfo &file : files) {
            users.append(file.baseName());
        }
    }
    
    return users;
}

QString FileManager::getUserConfigPath(const QString &username)
{
    QString appDir = QApplication::applicationDirPath();
    QString configDir = appDir + "/config/user";
    QDir().mkpath(configDir);
    return configDir + "/" + username + ".json";
}

void FileManager::ensureConfigDirectoryExists()
{
    QString appDir = QApplication::applicationDirPath();
    QString configDir = appDir + "/" + CONFIG_DIR;
    QDir dir;
    if (!dir.exists(configDir)) {
        if (dir.mkpath(configDir)) {
            qDebug() << "Created config directory:" << configDir;
        } else {
            qWarning() << "Failed to create config directory:" << configDir;
        }
    }
}