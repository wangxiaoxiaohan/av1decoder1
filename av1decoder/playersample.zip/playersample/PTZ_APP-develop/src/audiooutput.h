#ifndef AUDIOOUTPUT_H
#define AUDIOOUTPUT_H

#include <QObject>
#include <QAudioOutput>
#include <QAudioFormat>
#include <QIODevice>
#include <QByteArray>

class audioOutput : public QObject
{
    Q_OBJECT
public:
    explicit audioOutput(QObject *parent = nullptr);
    ~audioOutput();
    
    void setAudioFormat(QString codec, int sampleRate, int sampleSize, int channelCount,
                       QAudioFormat::SampleType sampleType, QAudioFormat::Endian byteOrder);
    void playRawAudio(const QByteArray &data);
    void setVolume(qreal volume);
    double getLatency() const;
    void suspend();
    void resume();
    
    QAudioFormat getFormat() const { return format; }
    double getBufferStatus() const; // Returns buffer fill level (0.0 to 1.0)

public slots:
    void start();
    void stop();

private:
    QAudioFormat format;
    QAudioOutput* output;
    QIODevice* device;
};

#endif // AUDIOOUTPUT_H 