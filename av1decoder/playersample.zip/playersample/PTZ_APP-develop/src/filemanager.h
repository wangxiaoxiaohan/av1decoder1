#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <QObject>
#include <QString>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QVariantMap>
#include <QDebug>

class FileManager : public QObject
{
    Q_OBJECT

public:
    explicit FileManager(QObject *parent = nullptr);
    
    static FileManager* instance() {
        static FileManager _instance;
        return &_instance;
    }

public slots:
    // 保存用户配置到文件
    Q_INVOKABLE bool saveUserConfig(const QString &username, const QVariantMap &userInfo);
    
    // 删除用户配置文件
    Q_INVOKABLE bool deleteUserConfig(const QString &username);
    
    // 加载用户配置
    Q_INVOKABLE QVariantMap loadUserConfig(const QString &username);
    
    // 检查用户配置文件是否存在
    Q_INVOKABLE bool userConfigExists(const QString &username);
    
    // 获取所有用户配置文件列表
    Q_INVOKABLE QStringList getAllUserConfigs();

private:
    QString getUserConfigPath(const QString &username);
    void ensureConfigDirectoryExists();
    
    static const QString CONFIG_DIR;
};

#endif // FILEMANAGER_H