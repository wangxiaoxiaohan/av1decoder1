#include "image_fusion_manager.h"
#include <QDebug>
#include <QFile>
#include <QDir>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QBuffer>
#include <QPainter>
#include <QStandardPaths>
#include <QCoreApplication>
#include <QFileInfo>
//#include <nlohmann/json.hpp>

// 定义宏来保留旧代码
#define USE_OLD_WREGISTRATION_INTERFACE 0

//using json = nlohmann::json;

// 单例实例
ImageFusionManager* ImageFusionManager::m_instance = nullptr;

ImageFusionManager* ImageFusionManager::instance()
{
    if (!m_instance) {
        m_instance = new ImageFusionManager();
    }
    return m_instance;
}

ImageFusionManager::ImageFusionManager(QObject* parent)
    : QObject(parent)
    , m_initialized(false)
    , m_workerThread(nullptr)
    , m_worker(nullptr)
    , m_defaultVisibleWidth(2592)
    , m_defaultVisibleHeight(1944)
    , m_defaultInfraredWidth(640)
    , m_defaultInfraredHeight(480)
{
    qDebug() << "ImageFusionManager created";
    
    // 创建工作线程
    m_workerThread = new QThread();
    m_worker = new ImageFusionWorker();
    m_worker->moveToThread(m_workerThread);
    
    // 连接信号和槽
    connect(m_worker, &ImageFusionWorker::processingCompleted,
            this, &ImageFusionManager::dualFusionCompleted);
    
    // 设置线程清理
    connect(m_workerThread, &QThread::finished, m_worker, &QObject::deleteLater);
    connect(m_workerThread, &QThread::finished, m_workerThread, &QThread::deleteLater);
    
    // 启动工作线程
    m_workerThread->start();
    
    qDebug() << "ImageFusionManager initialized with worker thread";
}

ImageFusionManager::~ImageFusionManager()
{
    if (m_workerThread) {
        m_workerThread->quit();
        m_workerThread->wait();
    }
    
    qDebug() << "ImageFusionManager destroyed";
}

bool ImageFusionManager::initializeFusion(const QString& calibrationConfigPath)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        qDebug() << "ImageFusionManager already initialized";
        return true;
    }
    
    // 检查配置文件是否存在
    QFile configFile(calibrationConfigPath);
    if (!configFile.exists()) {
        QString errorMsg = QString("标定配置文件不存在: %1").arg(calibrationConfigPath);
        qCritical() << errorMsg;
        emit fusionError(errorMsg);
        return false;
    }
    
    // 在工作线程中初始化
    bool result = false;
    QMetaObject::invokeMethod(m_worker, "initialize", Qt::BlockingQueuedConnection,
                             Q_RETURN_ARG(bool, result),
                             Q_ARG(QString, calibrationConfigPath));
    
    if (result) {
        m_initialized = true;
        qDebug() << "ImageFusionManager初始化成功";
    } else {
        qCritical() << "ImageFusionManager初始化失败";
    }
    
    return result;
}

void ImageFusionManager::performDualFusionWithYUVAsync(const QByteArray& visibleYUV, int visibleWidth, int visibleHeight,
                                                      const QByteArray& infraredYUV, int infraredWidth, int infraredHeight,
                                                      float depth)
{
    if (!m_initialized) {
        emit fusionError("Fusion manager not initialized");
        return;
    }
    
    // 检查输入数据
    if (visibleYUV.isEmpty() || infraredYUV.isEmpty()) {
        emit fusionError("Input YUV data is empty");
        return;
    }
    
    // 异步执行融合
    QMetaObject::invokeMethod(m_worker, "performDualFusion", Qt::QueuedConnection,
                             Q_ARG(QByteArray, visibleYUV),
                             Q_ARG(int, visibleWidth),
                             Q_ARG(int, visibleHeight),
                             Q_ARG(QByteArray, infraredYUV),
                             Q_ARG(int, infraredWidth),
                             Q_ARG(int, infraredHeight),
                             Q_ARG(float, depth));
}

// ImageFusionWorker 实现
ImageFusionWorker::ImageFusionWorker(QObject* parent)
    : QObject(parent)
    , m_initialized(false)
    , m_algHandle(nullptr)
{
    qDebug() << "ImageFusionWorker created";
}

ImageFusionWorker::~ImageFusionWorker()
{
    release();
    qDebug() << "ImageFusionWorker destroyed";
}

bool ImageFusionWorker::initialize(const QString& calibrationConfigPath)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
        qDebug() << "ImageFusionWorker already initialized";
        return true;
    }
    
    m_calibrationConfigPath = calibrationConfigPath;
    
    // 检查配置文件是否存在
    QFile configFile(calibrationConfigPath);
    if (!configFile.exists()) {
        qCritical() << "标定配置文件不存在:" << calibrationConfigPath;
        return false;
    }
    
    // 读取配置文件
    if (!configFile.open(QIODevice::ReadOnly)) {
        qCritical() << "无法打开标定配置文件:" << calibrationConfigPath;
        return false;
    }
    
    QByteArray configData = configFile.readAll();
    configFile.close();
    
    try {
        // 使用nlohmann解析JSON
        // m_calibrationParams = json::parse(configData.toStdString());
        // qDebug() << "calibrationConfigPath" << calibrationConfigPath;
        // qDebug() << "m_calibrationParams size" << m_calibrationParams.size();
        // qDebug() << "标定参数加载成功";
        // qDebug() << "标定参数内容:" << QString::fromStdString(m_calibrationParams.dump(2));
        
#if USE_OLD_WREGISTRATION_INTERFACE
        // 旧接口不需要初始化算法句柄
        m_algHandle = nullptr;
        qDebug() << "使用旧接口，跳过算法句柄初始化";
#else
        // 初始化算法句柄
        QFileInfo configFileInfo(calibrationConfigPath);
        QString configFolderPath = configFileInfo.absolutePath();
        m_algHandle = winit_fuse_alg(configFolderPath.toLocal8Bit().constData());
        
        if (m_algHandle == nullptr) {
            qCritical() << "算法句柄初始化失败";
            return false;
        }
        
        qDebug() << "算法句柄初始化成功:" << m_algHandle;
#endif
        
        m_initialized = true;
        qDebug() << "ImageFusionWorker初始化成功";
        return true;
        
    } catch (const std::exception& e) {
        qCritical() << "解析标定配置文件失败:" << e.what();
        return false;
    }
}

void ImageFusionWorker::saveNV12ToJPG(const QByteArray& nv12Data, int width, int height, const QString& filename) const
{
    if (nv12Data.isEmpty()) {
        qWarning() << "NV12 data is empty, cannot save to" << filename;
        return;
    }

    // NV12解码为RGB
    QImage image(width, height, QImage::Format_RGB888);
    const uchar* nv12 = reinterpret_cast<const uchar*>(nv12Data.constData());
    
    // Y plane size
    int ySize = width * height;
    
    const uchar* yPlane = nv12;
    const uchar* uvPlane = nv12 + ySize;
    
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            // Y分量
            int Y = yPlane[y * width + x];
            
            // UV分量(每两个水平像素共享一个UV值)
            int uvIndex = (y / 2) * width + (x / 2) * 2;
            int U = uvPlane[uvIndex];
            int V = uvPlane[uvIndex + 1];
            
            // YUV到RGB转换
            int C = Y - 16;
            int D = U - 128;
            int E = V - 128;
            
            int R = qBound(0, ((298 * C + 409 * E + 128) >> 8), 255);
            int G = qBound(0, ((298 * C - 100 * D - 208 * E + 128) >> 8), 255);
            int B = qBound(0, ((298 * C + 516 * D + 128) >> 8), 255);
            
            image.setPixel(x, y, qRgb(R, G, B));
        }
    }
    
    // 保存为JPG
    if (!image.save(filename, "JPG")) {
        qWarning() << "Failed to save image to" << filename;
    } else {
        qDebug() << "Saved NV12 frame to" << filename;
    }
}
void ImageFusionWorker::performDualFusion(const QByteArray& visibleYUV, int visibleWidth, int visibleHeight,
                                         const QByteArray& infraredYUV, int infraredWidth, int infraredHeight,
                                         float depth)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_initialized) {
        emit processingCompleted(QVideoFrame(), false, "ImageFusionWorker not initialized");
        return;
    }
    
    //qDebug() << "开始执行异步双光融合...";
    
        // QString timestamp1 = QDateTime::currentDateTime().toString("yyyyMMdd_hhmmss_zzz");
        //             QString saveDir1 = QDir::currentPath() + "/dual_fuse_images";
        //     QDir dir1(saveDir1);
        //     if (!dir1.exists()) {
        //         dir1.mkpath(".");
        //     }

        // saveNV12ToJPG(infraredYUV, infraredWidth, infraredHeight, 
        //             saveDir1 + "/infraredYUV" + timestamp1 + ".jpg");

        // // 保存fusionYUV为JPG
        // saveNV12ToJPG(visibleYUV, visibleWidth, visibleHeight,
        //             saveDir1 + "/visibleYUV" + timestamp1 + ".jpg");

    try {
        QByteArray outputYUV(visibleYUV.size(), 0);
        
#if USE_OLD_WREGISTRATION_INTERFACE
        // 旧的接口（使用标定参数）
        int result = wregistration(
            reinterpret_cast<const unsigned char*>(visibleYUV.data()),
            reinterpret_cast<const unsigned char*>(infraredYUV.data()),
            visibleWidth,
            visibleHeight,
            infraredWidth,
            infraredHeight,
            static_cast<int>(depth), 
            //m_calibrationParams,
            FUSE_MODE_ALG, 
            reinterpret_cast<unsigned char*>(outputYUV.data())
        );
#else
        // 新的接口（需要算法句柄）
        //qDebug() << "wregistration start time" << QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
        int result = wregistration(
            m_algHandle,  // 算法句柄
            reinterpret_cast<const unsigned char*>(visibleYUV.data()),
            reinterpret_cast<const unsigned char*>(infraredYUV.data()),
            visibleWidth,
            visibleHeight,
            infraredWidth,
            infraredHeight,
            static_cast<int>(depth), 
            FUSE_MODE_ALG, 
            reinterpret_cast<unsigned char*>(outputYUV.data())
        );
        //qDebug() << "wregistration end time" << QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss.zzz");
#endif
        
        if (result == 0) {
            // 直接从YUV数据创建QVideoFrame
            QVideoFrame frame = yuvToVideoFrame(outputYUV, visibleWidth, visibleHeight);
            
            emit processingCompleted(frame, true, "");
            //qDebug() << "异步双光融合成功完成";
        } else {
            QString errorMsg = QString("专业双光融合失败，错误码: %1").arg(result);
            qWarning() << errorMsg;
            emit processingCompleted(QVideoFrame(), false, errorMsg);
        }
        
    } catch (const std::exception& e) {
        QString errorMsg = QString("异步双光融合过程中发生异常: %1").arg(e.what());
        qCritical() << errorMsg;
        emit processingCompleted(QVideoFrame(), false, errorMsg);
    } catch (...) {
        QString errorMsg = "异步双光融合过程中发生未知异常";
        qCritical() << errorMsg;
        emit processingCompleted(QVideoFrame(), false, errorMsg);
    }
}

void ImageFusionWorker::release()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_initialized) {
#if USE_OLD_WREGISTRATION_INTERFACE
        // 旧接口不需要释放算法句柄
        qDebug() << "使用旧接口，跳过算法句柄释放";
#else
        // 释放算法句柄
        if (m_algHandle != nullptr) {
            fuseAlgHandleFree(&m_algHandle);
            m_algHandle = nullptr;
            qDebug() << "算法句柄已释放";
        }
#endif
        
        m_initialized = false;
        qDebug() << "ImageFusionWorker resources released";
    }
}

QVideoFrame ImageFusionWorker::yuvToVideoFrame(const QByteArray& yuvData, int width, int height) const
{
    if (yuvData.isEmpty()) {
        return QVideoFrame();
    }
    
    // 创建NV12格式的QVideoFrame（算法返回的是NV12数据）
    QVideoFrame frame(yuvData.size(), QSize(width, height), width, QVideoFrame::Format_NV12);
    if (!frame.map(QAbstractVideoBuffer::WriteOnly)) {
        qWarning() << "Failed to map video frame for writing";
        return QVideoFrame();
    }
    
    // 复制NV12数据
    memcpy(frame.bits(), yuvData.data(), yuvData.size());
    frame.unmap();
    
    return frame;
}





bool ImageFusionManager::isFusionAvailable() const
{
    return m_initialized;
}

QString ImageFusionManager::getFusionStatus() const
{
    if (m_initialized) {
        return "融合功能已就绪";
    } else {
        return "融合功能未初始化";
    }
}


 