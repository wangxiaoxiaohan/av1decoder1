#ifndef ALARM_AUDIO_PLAYER_H
#define ALARM_AUDIO_PLAYER_H

#include <QObject>
#include <QMediaPlayer>
#include <QAudioOutput>
#include <QUrl>
#include <QUrlQuery>

class AlarmAudioPlayer : public QObject
{
    Q_OBJECT

public:
    static AlarmAudioPlayer* instance();
    
    // 播放报警音频
    Q_INVOKABLE void playAlarmAudio();
    
    // 停止播放
    Q_INVOKABLE void stopAlarmAudio();
    
    // 设置音量
    Q_INVOKABLE void setVolume(qreal volume);
    
    // 检查是否正在播放
    Q_INVOKABLE bool isPlaying() const;

signals:
    void audioPlaybackStarted();
    void audioPlaybackFinished();
    void audioPlaybackError(const QString& error);

private:
    explicit AlarmAudioPlayer(QObject* parent = nullptr);
    ~AlarmAudioPlayer();
    
    static AlarmAudioPlayer* m_instance;
    
    QMediaPlayer* m_player;
    
    void initializePlayer();

private slots:
    void onPlayerStateChanged(QMediaPlayer::State state);
    void onPlayerError(QMediaPlayer::Error error);
};

#endif // ALARM_AUDIO_PLAYER_H 