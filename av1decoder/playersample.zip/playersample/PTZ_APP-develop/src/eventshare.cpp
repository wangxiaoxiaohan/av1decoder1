#include "eventshare.h"
#include <QJsonArray>
#include <QJsonDocument>
#include <QNetworkRequest>
#include <QNetworkReply>
#include <QHttpMultiPart>
#include <QHttpPart>
#include <QFileInfo>
#include <QFile>

EventShare* EventShare::m_instance = nullptr;

EventShare* EventShare::instance() {
    if (!m_instance) {
        m_instance = new EventShare();
    }
    return m_instance;
}

EventShare::EventShare(QObject *parent) : QObject(parent) {
    manager = new QNetworkAccessManager(this);
    connect(manager, &QNetworkAccessManager::finished, this, &EventShare::onReplyFinished);
}

QString EventShare::buildUrl(const QString &serverIp, int port, const QString &endpoint) const {
    return QString("http://%1:%2%3").arg(serverIp).arg(port).arg(endpoint);
}

void EventShare::reportAlarms(const QList<HwAlarmLogEntry> &alarms, const QString &serverIp, int port) {
    QString url = buildUrl(serverIp, port, "/api/v1/alarms/report");
    reportAlarms(alarms, serverIp, port, QString());
}

void EventShare::reportAlarms(const QList<HwAlarmLogEntry> &alarms, const QString &serverIp, int port, const QString &authToken) {
    QString url = buildUrl(serverIp, port, "/api/v1/alarms/report");
    
    QJsonArray arr;
    for (const auto &alarm : alarms) {
        arr.append(alarm.toJson());
    }

    QJsonObject root;
    root["alarms"] = arr;
    QJsonDocument doc(root);

    QByteArray jsonData = doc.toJson(QJsonDocument::Compact);

    QUrl qurl(url);
    QNetworkRequest req(qurl);
    req.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    
    if (!authToken.isEmpty()) {
        req.setRawHeader("Authorization", authToken.toUtf8());
    }

    QNetworkReply *reply = manager->post(req, jsonData);

    // 设置超时
    QTimer *timer = new QTimer(reply);
    timer->setSingleShot(true);
    connect(timer, &QTimer::timeout, this, [this, reply]() {
        if (reply->isRunning()) {
            reply->abort(); // 取消请求
            emit httpResponse("Error: Request timed out");
        }
    });
    timer->start(10000); // 10秒

    timeoutMap.insert(reply, timer);
}

void EventShare::uploadFiles(const QStringList &filePaths, const QString &url, const QString &authToken) {
    QHttpMultiPart *multiPart = new QHttpMultiPart(QHttpMultiPart::FormDataType);

    for (const QString &path : filePaths) {
        QFile *file = new QFile(path);
        if (!file->open(QIODevice::ReadOnly)) {
            delete file;
            continue;
        }

        QHttpPart part;
        part.setHeader(QNetworkRequest::ContentDispositionHeader,
                       QVariant(QString("form-data; name=\"file\"; filename=\"%1\"").arg(QFileInfo(path).fileName())));
        part.setBodyDevice(file);
        file->setParent(multiPart);
        multiPart->append(part);
    }

    QUrl qurl(url);
    QNetworkRequest req(qurl);
    if (!authToken.isEmpty()) {
        req.setRawHeader("Authorization", authToken.toUtf8());
    }
    
    QNetworkReply *reply = manager->post(req, multiPart);
    multiPart->setParent(reply);  // 防止泄漏

    // 设置超时
    QTimer *timer = new QTimer(reply);
    timer->setSingleShot(true);
    connect(timer, &QTimer::timeout, this, [this, reply]() {
        if (reply->isRunning()) {
            reply->abort(); // 取消请求
            emit httpResponse("Error: Upload timed out");
        }
    });
    timer->start(10000); // 10秒

    timeoutMap.insert(reply, timer);
}

void EventShare::uploadImages(const QStringList &filePaths, const QString &serverIp, int port) {
    QString url = buildUrl(serverIp, port, "/api/v1/alarms/upload/image");
    uploadFiles(filePaths, url, QString());
}

void EventShare::uploadImages(const QStringList &filePaths, const QString &serverIp, int port, const QString &authToken) {
    QString url = buildUrl(serverIp, port, "/api/v1/alarms/upload/image");
    uploadFiles(filePaths, url, authToken);
}

void EventShare::uploadVideos(const QStringList &filePaths, const QString &serverIp, int port) {
    QString url = buildUrl(serverIp, port, "/api/v1/alarms/upload/video");
    uploadFiles(filePaths, url, QString());
}

void EventShare::uploadVideos(const QStringList &filePaths, const QString &serverIp, int port, const QString &authToken) {
    QString url = buildUrl(serverIp, port, "/api/v1/alarms/upload/video");
    uploadFiles(filePaths, url, authToken);
}

void EventShare::onReplyFinished(QNetworkReply *reply) {
    if (timeoutMap.contains(reply)) {
        timeoutMap[reply]->stop();
        timeoutMap[reply]->deleteLater();
        timeoutMap.remove(reply);
    }

    if(reply->error() != QNetworkReply::NoError) {
        emit httpResponse(QString("Error: %1").arg(reply->errorString()));
    } else {
        QString result = QString::fromUtf8(reply->readAll());
        emit httpResponse(result);
    }
    reply->deleteLater();
}