#include "cruise_record_manager.h"
#include <QStandardPaths>
#include <QTextStream>
#include <QDateTime>
#include <QFileInfo>
#include <QDirIterator>
#include <QApplication>

// CruiseRecordData 序列化为JSON
QJsonObject CruiseRecordData::toJson() const {
    QJsonObject obj;
    obj["id"] = id;
    obj["timestamp"] = timestamp;
    obj["deviceId"] = deviceId;
    obj["presetId"] = presetId;
    obj["concentration"] = concentration;
    obj["threshold"] = threshold;
    obj["status"] = status;
    return obj;
}

CruiseRecordData CruiseRecordData::fromJson(const QJsonObject& json) {
    CruiseRecordData data;
    data.id = json["id"].toInt();
    data.timestamp = json["timestamp"].toString();
    data.deviceId = json["deviceId"].toString();
    data.presetId = json["presetId"].toInt();
    data.concentration = json["concentration"].toDouble();
    data.threshold = json["threshold"].toDouble();
    data.status = json["status"].toString();
    return data;
}

// CruiseRecordManager 单例实现
CruiseRecordManager* CruiseRecordManager::m_instance = nullptr;

CruiseRecordManager* CruiseRecordManager::instance() {
    if (!m_instance) {
        m_instance = new CruiseRecordManager();
    }
    return m_instance;
}

CruiseRecordManager::CruiseRecordManager(QObject *parent)
    : QObject(parent)
{
    qDebug() << "CruiseRecordManager constructor called";
    
    // 创建数据库目录 - 使用程序运行目录下的路径
    QString appDir = QApplication::applicationDirPath();
    QString cruiseDir = appDir + "/config/cruises";
    
    QDir dir(cruiseDir);
    if (!dir.exists()) {
        qDebug() << "Creating Cruise directory:" << cruiseDir;
        dir.mkpath(cruiseDir);
    }
    
    QString dbPath = cruiseDir + "/cruise.db";
    qDebug() << "Cruise database path:" << dbPath;

    qDebug() << "Adding database to SQL engine";
    // 使用唯一的连接名确保线程安全
    QString connectionName = QString("cruise_connection_%1").arg((quintptr)this);
    m_db = QSqlDatabase::addDatabase("QSQLITE", connectionName);
    m_db.setDatabaseName(dbPath);
    
    qDebug() << "Opening database";
    if (!m_db.open()) {
        qWarning() << "Failed to open Cruise database:" << m_db.lastError().text();
    } else {
        qDebug() << "Database opened successfully";
    }

    initDatabase();
    qDebug() << "CruiseRecordManager constructor finished";
}

CruiseRecordManager::~CruiseRecordManager() {
    qDebug() << "CruiseRecordManager destructor called";
    if (m_db.isOpen()) {
        m_db.close();
        qDebug() << "Database closed";
    }
}

void CruiseRecordManager::initDatabase() {
    qDebug() << "Initializing Cruise database tables";
    
    // 使用互斥锁确保线程安全
    QMutexLocker locker(&m_dbMutex);
    
    if (!m_db.isOpen()) {
        qWarning() << "Database is not open in initDatabase";
        return;
    }
    
    // Set database performance options
    QSqlQuery pragmaQuery(m_db);
    pragmaQuery.exec("PRAGMA journal_mode=WAL");
    pragmaQuery.exec("PRAGMA synchronous=NORMAL");
    
    QSqlQuery query(m_db);
    
    // 创建巡航记录表
    QString createTableSql = "CREATE TABLE IF NOT EXISTS CruiseRecords ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT,"
               "timestamp INTEGER NOT NULL,"  // Unix时间戳 (秒)
               "datetime TEXT NOT NULL,"      // 可读的时间格式
               "device_id TEXT NOT NULL,"
               "preset_id INTEGER NOT NULL,"
               "concentration REAL NOT NULL,"
               "threshold REAL NOT NULL,"
               "status TEXT NOT NULL"
               ")";
    
    if (!query.exec(createTableSql)) {
        qWarning() << "Error creating CruiseRecords table:" << query.lastError().text();
    }
    
    // 创建索引
    query.exec("CREATE INDEX IF NOT EXISTS idx_timestamp ON CruiseRecords(timestamp)");
    query.exec("CREATE INDEX IF NOT EXISTS idx_device_id ON CruiseRecords(device_id)");

    // 兼容旧版本：尝试为已有表添加threshold字段（若已存在会忽略失败）
    QSqlQuery alterQuery(m_db);
    alterQuery.exec("ALTER TABLE CruiseRecords ADD COLUMN threshold REAL");
}

QString CruiseRecordManager::getCurrentDate() {
    return QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
}

bool CruiseRecordManager::saveCruiseRecord(const QString& deviceId, int presetId, double concentration, double threshold, const QString& status) {
    QMutexLocker locker(&m_dbMutex);
    
    if (!m_db.isOpen()) return false;
    
    QSqlQuery query(m_db);
    query.prepare("INSERT INTO CruiseRecords (timestamp, datetime, device_id, preset_id, concentration, threshold, status) "
                  "VALUES (:timestamp, :datetime, :device_id, :preset_id, :concentration, :threshold, :status)");
    
    qint64 currentTimestamp = QDateTime::currentSecsSinceEpoch();
    QString currentDatetime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    
    query.bindValue(":timestamp", currentTimestamp);
    query.bindValue(":datetime", currentDatetime);
    query.bindValue(":device_id", deviceId);
    query.bindValue(":preset_id", presetId);
    query.bindValue(":concentration", concentration);
    query.bindValue(":threshold", threshold);
    query.bindValue(":status", status);
    
    if (!query.exec()) {
        qWarning() << "Error saving cruise record:" << query.lastError().text();
        return false;
    }
    
    return true;
}

QVariantList CruiseRecordManager::queryCruiseRecords(const QString& startTime, const QString& endTime, const QString& deviceId) {
    return queryCruiseRecordsPaginated(startTime, endTime, 1000, 0, deviceId);
}

QVariantList CruiseRecordManager::queryCruiseRecordsPaginated(const QString& startTime, const QString& endTime, int limit, int offset, const QString& deviceId) {
    QMutexLocker locker(&m_dbMutex);
    QVariantList resultList;
    
    if (!m_db.isOpen()) return resultList;
    
    QString sql = "SELECT * FROM CruiseRecords WHERE 1=1";
    
    if (!startTime.isEmpty()) {
        QDateTime start = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
        if (start.isValid()) {
            sql += QString(" AND timestamp >= %1").arg(start.toSecsSinceEpoch());
        }
    }
    
    if (!endTime.isEmpty()) {
        QDateTime end = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
        if (end.isValid()) {
            sql += QString(" AND timestamp <= %1").arg(end.toSecsSinceEpoch());
        }
    }
    
    if (!deviceId.isEmpty()) {
        sql += QString(" AND device_id = '%1'").arg(deviceId);
    }
    
    sql += QString(" ORDER BY timestamp DESC LIMIT %1 OFFSET %2").arg(limit).arg(offset);
    
    QSqlQuery query(m_db);
    if (query.exec(sql)) {
        while (query.next()) {
            QJsonObject record;
            record["id"] = query.value("id").toInt();
            record["timestamp"] = query.value("timestamp").toLongLong();
            record["datetime"] = query.value("datetime").toString();
            record["deviceId"] = query.value("device_id").toString();
            record["presetId"] = query.value("preset_id").toInt();
            record["concentration"] = query.value("concentration").toDouble();
            record["threshold"] = query.value("threshold").toDouble();
            record["status"] = query.value("status").toString();
            resultList.append(record);
        }
    } else {
        qWarning() << "Error querying cruise records:" << query.lastError().text();
    }
    
    return resultList;
}

bool CruiseRecordManager::deleteRecords(const QString& startTime, const QString& endTime, const QString& deviceId) {
    QMutexLocker locker(&m_dbMutex);
    
    if (!m_db.isOpen()) return false;
    
    QString sql = "DELETE FROM CruiseRecords WHERE 1=1";
    
    if (!startTime.isEmpty()) {
        QDateTime start = QDateTime::fromString(startTime, "yyyy-MM-dd HH:mm:ss");
        if (start.isValid()) {
            sql += QString(" AND timestamp >= %1").arg(start.toSecsSinceEpoch());
        }
    }
    
    if (!endTime.isEmpty()) {
        QDateTime end = QDateTime::fromString(endTime, "yyyy-MM-dd HH:mm:ss");
        if (end.isValid()) {
            sql += QString(" AND timestamp <= %1").arg(end.toSecsSinceEpoch());
        }
    }
    
    if (!deviceId.isEmpty()) {
        sql += QString(" AND device_id = '%1'").arg(deviceId);
    }
    
    QSqlQuery query(m_db);
    if (!query.exec(sql)) {
        qWarning() << "Error deleting cruise records:" << query.lastError().text();
        return false;
    }
    
    return true;
}

bool CruiseRecordManager::deleteAllRecords() {
    return deleteRecords();
}
