//
// Created by Chian on 4/8/2024.
//

#include "frame_provider_ctrl.h"
//FrameProviderCtrl* FrameProviderCtrl::instance_;
std::mutex FrameProviderCtrl::mutex_;