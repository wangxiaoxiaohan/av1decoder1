#include "device_proxy.h"
#include "model/devicemodel.h"
#include <QDebug>

DeviceProxy::DeviceProxy(QObject* parent)
    : QObject(parent)
    , m_ptzManager(PtzDeviceManager::instance())
    , m_thermalManager(ThermalDeviceManager::instance())
{
    qDebug() << "DeviceProxy created";
}

// PTZ设备代理方法
void DeviceProxy::mvTurnUp()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvTurnUp", Qt::QueuedConnection);
    }
}

void DeviceProxy::mvTurnDown()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvTurnDown", Qt::QueuedConnection);
    }
}

void DeviceProxy::mvTurnLeft()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvTurnLeft", Qt::QueuedConnection);
    }
}

void DeviceProxy::mvTurnRight()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvTurnRight", Qt::QueuedConnection);
    }
}

void DeviceProxy::mvTurnStop()
{
    // 获取当前设备的红外选中状态
    bool isInfraredSelected = getCurrentDeviceInfraredSelected();
    
    if (isInfraredSelected) {
        // 红外被选中，使用红外停止操作
        ptzStopFocus();
        qDebug() << "红外镜头停止操作: ptzStopFocus";
    } else {
        // 可见光被选中，使用原有的可见光停止操作
        QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
        PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
        if (device) {
            QMetaObject::invokeMethod(device, "mvTurnStop", Qt::QueuedConnection);
        }
        qDebug() << "可见光镜头停止操作: mvTurnStop";
    }
}
void DeviceProxy::mvDirectionTurnStop()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvTurnStop", Qt::QueuedConnection);
    }
}
void DeviceProxy::mvSetZoomIn(int val)
{
    // 获取当前设备的红外选中状态
    bool isInfraredSelected = getCurrentDeviceInfraredSelected();
    
    if (isInfraredSelected) {
        // 红外被选中，使用红外PTZ操作
        int method;
        if (val > 0) {
            method = PTZ_FOCUS_LONG;  // 焦距变长 (9)
        } else {
            method = PTZ_FOCUS_SHORT; // 焦距变短 (8)
        }
        ptzOperation(method);
        qDebug() << "红外镜头变倍操作:" << (val > 0 ? "焦距变长" : "焦距变短");
    } else {
        // 可见光被选中，使用原有的可见光操作
        QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
        PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
        if (device) {
            QMetaObject::invokeMethod(device, "mvSetZoomIn", Qt::QueuedConnection, Q_ARG(int, val));
        }
        qDebug() << "可见光镜头变倍操作:" << val;
    }
}

void DeviceProxy::mvSetFocus(int val)
{
    // 获取当前设备的红外选中状态
    bool isInfraredSelected = getCurrentDeviceInfraredSelected();
    
    if (isInfraredSelected) {
        // 红外被选中，使用红外PTZ操作
        int method;
        if (val > 0) {
            method = PTZ_FOCUS_NEAR;  // 聚焦变近 (10)
        } else {
            method = PTZ_FOCUS_FAR;   // 聚焦变远 (11)
        }
        ptzOperation(method);
        qDebug() << "红外镜头聚焦操作:" << (val > 0 ? "聚焦变近" : "聚焦变远");
    } else {
        // 可见光被选中，使用原有的可见光操作
        QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
        PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
        if (device) {
            QMetaObject::invokeMethod(device, "mvSetFocus", Qt::QueuedConnection, Q_ARG(int, val));
        }
        qDebug() << "可见光镜头聚焦操作:" << val;
    }
}

void DeviceProxy::mvSetAperture(int val)
{
    // 获取当前设备的红外选中状态
    bool isInfraredSelected = getCurrentDeviceInfraredSelected();
    
    if (isInfraredSelected) {
        // 红外被选中，使用红外PTZ操作
        int method;
        if (val > 0) {
            method = PTZ_APERTURE_LARGE;  // 光圈变大 (13)
        } else {
            method = PTZ_APERTURE_SMALL;  // 光圈变小 (12)
        }
        ptzOperation(method);
        qDebug() << "红外镜头光圈操作:" << (val > 0 ? "光圈变大" : "光圈变小");
    } else {
        // 可见光被选中，使用原有的可见光操作
        QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
        PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
        if (device) {
            QMetaObject::invokeMethod(device, "mvSetAperture", Qt::QueuedConnection, Q_ARG(int, val));
        }
        qDebug() << "可见光镜头光圈操作:" << val;
    }
}

void DeviceProxy::mvSetPreset(int id)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvSetPreset", Qt::QueuedConnection, Q_ARG(int, id));
    }
}

void DeviceProxy::mvCallPreset(int id)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvCallPreset", Qt::QueuedConnection, Q_ARG(int, id));
    }
}

void DeviceProxy::mvDeletePreset(int id)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvDeletePreset", Qt::QueuedConnection, Q_ARG(int, id));
    }
}

void DeviceProxy::mvSetCruiseScan(const QString &cruiseNumber, const QVariantList &presetPoints)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvSetCruiseScan", Qt::QueuedConnection, 
                                 Q_ARG(QString, cruiseNumber), Q_ARG(QVariantList, presetPoints));
    }
}

void DeviceProxy::mvSetLight(bool val)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvSetLight", Qt::QueuedConnection, Q_ARG(bool, val));
    }
}

void DeviceProxy::mvSetWiper(bool val)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvSetWiper", Qt::QueuedConnection, Q_ARG(bool, val));
    }
}

void DeviceProxy::mvSetAssiFocus(bool val)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvSetAssiFocus", Qt::QueuedConnection, Q_ARG(bool, val));
    }
}

void DeviceProxy::mvSetInfFlap(bool val)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvSetInfFlap", Qt::QueuedConnection, Q_ARG(bool, val));
    }
}

bool DeviceProxy::mvReboot()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvReboot", Qt::QueuedConnection);
        return true;
    }
    return false;
}

bool DeviceProxy::mvFactoryReset(bool retain_network)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvFactoryReset", Qt::QueuedConnection, Q_ARG(bool, retain_network));
        return true;
    }
    return false;
}

QList<int> DeviceProxy::getConcetList()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);

    if (device) {

        return device->getConcetList();
        
    }
    return QList<int>();
}

void DeviceProxy::mvModifyImageSettings(int bright, int contrac, int saturation, int sharpness, int hlc, int blc, int nr2d, int nr3d, int tvsystem, int antificker)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvModifyImageSettings", Qt::QueuedConnection,
                                 Q_ARG(int, bright), Q_ARG(int, contrac), Q_ARG(int, saturation), Q_ARG(int, sharpness),
                                 Q_ARG(int, hlc), Q_ARG(int, blc), Q_ARG(int, nr2d), Q_ARG(int, nr3d),
                                 Q_ARG(int, tvsystem), Q_ARG(int, antificker));
    }
}

QVariantMap DeviceProxy::mvGetImageSettings()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        return device->mvGetImageSettings();
    }
    return QVariantMap();
}

void DeviceProxy::mvModifyVideoSettings(QString encode_mode, QString resolution, QString framerate, QString govlength, QString bitrate, QString bitrate_control, int index)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvModifyVideoSettings", Qt::QueuedConnection,
                                 Q_ARG(QString, encode_mode), Q_ARG(QString, resolution), Q_ARG(QString, framerate),
                                 Q_ARG(QString, govlength), Q_ARG(QString, bitrate), Q_ARG(QString, bitrate_control),
                                 Q_ARG(int, index));
    }
}

void DeviceProxy::mvModifyAudioSettings(bool enable_1, QString encode_type, QString samplerate, QString bitrate, QString input_volume, QString output_volume, QString amplify)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvModifyAudioSettings", Qt::QueuedConnection,
                                 Q_ARG(bool, enable_1), Q_ARG(QString, encode_type), Q_ARG(QString, samplerate),
                                 Q_ARG(QString, bitrate), Q_ARG(QString, input_volume), Q_ARG(QString, output_volume),
                                 Q_ARG(QString, amplify));
    }
}

QVariantMap DeviceProxy::mvGetVideoEncoderCapabilities(int streamIndex)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        return device->mvGetVideoEncoderCapabilities(streamIndex);
    }
    return QVariantMap();
}

QVariantMap DeviceProxy::mvGetAudioEncoderCapabilities()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        return device->mvGetAudioEncoderCapabilities();
    }
    return QVariantMap();
}

QVariantMap DeviceProxy::mvGetEventStorageConfig()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        return device->mvGetEventStorageConfig();
    }
    return QVariantMap();
}

void DeviceProxy::mvSetSpeed(int speed)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvSetTurnSpeed", Qt::QueuedConnection, Q_ARG(int, speed));
    }
}

QVariantMap DeviceProxy::mvGetMotionDetectConfig()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        return device->mvGetMotionDetectConfig();
    }
    return QVariantMap();
}

void DeviceProxy::mvConfigUserOSD(int title_index, int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvConfigUserOSD", Qt::QueuedConnection,
                                 Q_ARG(int, title_index), Q_ARG(int, enable), Q_ARG(int, color), 
                                 Q_ARG(int, fontsize), Q_ARG(int, title_pos_type), Q_ARG(int, title_pos_x), 
                                 Q_ARG(int, title_pos_y), Q_ARG(QString, title_utf8));
    }
}

void DeviceProxy::mvConfigOSD(int enable, int color, int fontsize, int title_pos_type, int title_pos_x, int title_pos_y, QString title_utf8)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvConfigOSD", Qt::QueuedConnection,
                                 Q_ARG(int, enable), Q_ARG(int, color), Q_ARG(int, fontsize),
                                 Q_ARG(int, title_pos_type), Q_ARG(int, title_pos_x),
                                 Q_ARG(int, title_pos_y), Q_ARG(QString, title_utf8));
    }
}

void DeviceProxy::mvConfigTimeOSD(int enable, int show_week, QString time_format, int title_pos_x, int title_pos_y)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "mvConfigTimeOSD", Qt::QueuedConnection,
                                 Q_ARG(int, enable), Q_ARG(int, show_week), Q_ARG(QString, time_format),
                                 Q_ARG(int, title_pos_x), Q_ARG(int, title_pos_y));
    }
}

void DeviceProxy::mvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway, QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns, QString dns)
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        // 连接信号以转发结果
        connect(device, &PtzDeviceCgi::networkPropertyModified,
                this, &DeviceProxy::networkPropertyModified,
                Qt::UniqueConnection);
                
        QMetaObject::invokeMethod(device, "mvModifyLocalNetworkProperty", Qt::QueuedConnection,
                                 Q_ARG(bool, static_ip), Q_ARG(QString, ip4_ip), Q_ARG(QString, ip4_mask),
                                 Q_ARG(QString, ip4_gateway), Q_ARG(QString, ip6_ip), Q_ARG(QString, ip6_prefix),
                                 Q_ARG(QString, ip6_gateway), Q_ARG(QString, pre_dns), Q_ARG(QString, dns));
    }
}

// 热成像设备代理方法
void DeviceProxy::setPseudoMode(int mode)
{
    m_thermalManager->setPseudoMode(mode);
}

void DeviceProxy::setFocusZoom(int channel, int digitalZoom, bool debug)
{
    m_thermalManager->setFocusZoom(channel, digitalZoom, debug);
}

void DeviceProxy::enhanceInfraRed(bool brightMutation, bool denoise2DEnable, int denoise2DLevel,
                                 bool denoise3DEnable, int denoise3DLevel, bool ddeEnable, int ddeLevel,
                                 int flipMode, bool regionalEnable, int regionalLevel,
                                 int coordX, int coordY)
{
    m_thermalManager->enhanceInfraRed(brightMutation, denoise2DEnable, denoise2DLevel,
                                     denoise3DEnable, denoise3DLevel, ddeEnable, ddeLevel,
                                     flipMode, regionalEnable, regionalLevel,
                                     coordX, coordY);
}

void DeviceProxy::setThermalImageParams(int brightness, int contrast, int flipMode)
{
    QString currentDeviceId = m_thermalManager->getCurrentDeviceId();
    ThermalCtl* device = m_thermalManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "setThermalImageParams", Qt::QueuedConnection,
                                 Q_ARG(int, brightness), Q_ARG(int, contrast), Q_ARG(int, flipMode));
    }
}

QJsonObject DeviceProxy::getThermalImageParams(bool defaultConfig)
{
    QString currentDeviceId = m_thermalManager->getCurrentDeviceId();
    ThermalCtl* device = m_thermalManager->getDevice(currentDeviceId);
    if (device) {
        return device->getThermalImageParams(defaultConfig);
    }
    return QJsonObject(); // Return empty object if device not found
}

void DeviceProxy::rebootThermal()
{
    QString currentDeviceId = m_thermalManager->getCurrentDeviceId();
    ThermalCtl* device = m_thermalManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "rebootThermal", Qt::QueuedConnection);
    }
}

void DeviceProxy::factoryResetThermal()
{
    QString currentDeviceId = m_thermalManager->getCurrentDeviceId();
    ThermalCtl* device = m_thermalManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "factoryResetThermal", Qt::QueuedConnection);
    }
}

void DeviceProxy::ptzOperation(int method)
{
    QString currentDeviceId = m_thermalManager->getCurrentDeviceId();
    ThermalCtl* device = m_thermalManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "ptzOperation", Qt::QueuedConnection, Q_ARG(int, method));
    }
}

void DeviceProxy::ptzStopFocus()
{
    QString currentDeviceId = m_thermalManager->getCurrentDeviceId();
    ThermalCtl* device = m_thermalManager->getDevice(currentDeviceId);
    if (device) {
        QMetaObject::invokeMethod(device, "ptzStopFocus", Qt::QueuedConnection);
    }
}

bool DeviceProxy::getCurrentDeviceInfraredSelected()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    return DeviceModel::instance()->getDeviceInfraredSelected(currentDeviceId);
}

// 设备管理方法
void DeviceProxy::setCurrentDevice(const QString &deviceId)
{
    m_ptzManager->setCurrentDevice(deviceId);
    m_thermalManager->setCurrentDevice(deviceId);
    
    // 同时设置DeviceModel中的当前设备
    DeviceModel::instance()->selectDevice(deviceId);
}

QString DeviceProxy::getCurrentDeviceId()
{
    return m_ptzManager->getCurrentDeviceId();
}

bool DeviceProxy::isDeviceInitialized(const QString &deviceId)
{
    return m_ptzManager->isDeviceInitialized(deviceId) && m_thermalManager->isDeviceInitialized(deviceId);
}

QStringList DeviceProxy::getInitializedDevices()
{
    QStringList ptzDevices = m_ptzManager->getInitializedDevices();
    QStringList thermalDevices = m_thermalManager->getInitializedDevices();
    
    // 返回两个列表的交集
    QStringList commonDevices;
    for (const QString& device : ptzDevices) {
        if (thermalDevices.contains(device)) {
            commonDevices.append(device);
        }
    }
    return commonDevices;
}

void DeviceProxy::mvLoadNetworkConfig()
{
    QString currentDeviceId = m_ptzManager->getCurrentDeviceId();
    PtzDeviceCgi* device = m_ptzManager->getDevice(currentDeviceId);
    if (device) {
        // 连接信号（如果尚未连接）
        connect(device, &PtzDeviceCgi::networkConfigLoaded, this, &DeviceProxy::networkConfigLoaded, Qt::UniqueConnection);
        connect(device, &PtzDeviceCgi::networkConfigLoadFailed, this, &DeviceProxy::networkConfigLoadFailed, Qt::UniqueConnection);
        
        QMetaObject::invokeMethod(device, "mvLoadNetworkConfig", Qt::QueuedConnection);
    }
}