#ifndef ALARMLOG_H
#define ALARMLOG_H

#include <QObject>
#include <QSqlDatabase>
#include <QVariantList>
#include <QSqlQuery>
#include <QSqlError>
#include <QDebug>
#include <QJsonObject>

typedef enum {
    ALARM_T_MDA = 0,    // 移动侦测报警
    ALARM_T_TA,         // 遮挡报警
    ALARM_T_GLA,        // 气体泄漏报警
    ALARM_T_DFA,        // 设备故障报警

    ALARM_T_NONE = 99
} ALARM_T;

struct HwAlarmLogEntry {
    int id;                     // 数据库ID，新增时不需要赋值
    QString alarm_time;         // 报警时间
    ALARM_T alarm_type;         // 报警类型（数字）
    QString alarm_type_code;    // 异常类型编号（字符串）
    QString alarm_type_name;    // 异常类型
    QString alarm_part;         // 异常部件
    QString device_code;        // 设备编号
    QString device_name;        // 设备名称
    QString alarm_medium;       // 报警介质
    QString alarm_value;        // 报警值
    QString preset;             // 报警预置位
    QString area;               // 报警区域
    QString ir_image_url;       // 红外图片地址
    QString ir_video_url;       // 红外视频地址
    QString vi_image_url;       // 可见光图片地址
    QString vi_video_url;       // 可见光视频地址
    int handle_status = 0;      // 处理状态：0-未处理，1-已处理
    QString distance;           // 测量距离
    
    // 新增字段：水平角度和垂直角度
    QString horizontal_angle;  // 水平角度
    QString vertical_angle;    // 垂直角度
    
    QJsonObject toJson() const;
};

struct HwAlarmActionEntry {
    int id = -1;
    int alarm_log_id = -1;          // 关联报警记录id
    QString handler;                // 处理人
    QString handle_time;            // 处理时间
    QString handle_result;          // 处理结果
    QString handle_process_image;   // 处理过程图片路径（单个图片，保持兼容性）
    QList<QString> handle_process_images; // 处理过程图片路径列表（多个图片）
};

class AlarmLog : public QObject
{
    Q_OBJECT
public:
    static AlarmLog* instance();

    // 报警记录接口
    // C++ 调用
    void addLog(const HwAlarmLogEntry& entry);

    // QML 调用
    Q_INVOKABLE void addLog(ALARM_T alarmType, const QString& alarmTypeCode,
                            const QString& alarmTypeName, const QString& alarmPart,
                            const QString& deviceCode, const QString& deviceName,
                            const QString& alarmMedium, const QString& alarmValue,
                            const QString& preset, const QString& area, const QString& distance,
                            const QString& irImageUrl, const QString& irVideoUrl,
                            const QString& viImageUrl, const QString& viVideoUrl,
                            int handleStatus = 0);

        /*
        type:
            case 0: // 全部
            case 1: // 移动侦测报警
            case 2: // 遮挡报警
            case 3: // 气体泄漏报警
            case 4: // 设备故障报警
        status:
            case 1: // 未处理
            case 2: // 已处理
        */
    Q_INVOKABLE QVariantMap queryLogs(int type = -1, int status = -1,
                                      const QString& devSn = "",
                                      const QString& start = "",
                                      const QString& end = "",
                                      int page = 0,
                                      int pageSize = 4);

    Q_INVOKABLE bool deleteLog(int id);
    Q_INVOKABLE bool deleteAll();

    // 报警记录处理
    bool alarmHandle(int id);

    // 导出
    Q_INVOKABLE bool exportLogsToCsv(int type = -1, int status = -1,
                                       const QString& devSn = "",
                                       const QString& start = "",
                                       const QString& end = "");
    
    // 导出到指定路径
    Q_INVOKABLE bool exportLogsToCsvWithPath(const QString& filePath, int type = -1, int status = -1,
                                               const QString& devSn = "",
                                               const QString& start = "",
                                               const QString& end = "");

    Q_INVOKABLE QVariantMap queryPresetLogs(const QString& preset,
                                            int type = -1,
                                            int status = -1,
                                            const QString& devSn = "",
                                            const QString& start = "",
                                            const QString& end = "",
                                            int page = 0,
                                            int pageSize = 10);


    // 报警处理记录接口
    void addAction(const HwAlarmActionEntry& entry);
    Q_INVOKABLE void addAction(int alarmLogId, const QString& handler, const QString& handleTime, const QString& handleResult, const QString& handleProcessImage = "");
    Q_INVOKABLE void addActionWithImages(int alarmLogId, const QString& handler, const QString& handleTime, const QString& handleResult, const QVariantList& handleProcessImages);
    Q_INVOKABLE QVariantList queryActionsByAlarmId(int alarmLogId);
    Q_INVOKABLE QVariantList queryActionImages(int actionId);
    Q_INVOKABLE bool addActionImage(int actionId, const QString& imagePath);
    Q_INVOKABLE bool deleteActionImage(int imageId);
    Q_INVOKABLE bool deleteAction(int id);
    Q_INVOKABLE bool deleteAllActions();

signals:
    void logAdded();
    void actionAdded();

private:
    explicit AlarmLog(QObject* parent = nullptr);
    static AlarmLog* m_instance;
    QSqlDatabase m_db;

    void initDatabase();
    HwAlarmLogEntry fromQuery(const QSqlQuery& query);
    HwAlarmActionEntry fromActionQuery(const QSqlQuery& query);
};

#endif // ALARMLOG_H
