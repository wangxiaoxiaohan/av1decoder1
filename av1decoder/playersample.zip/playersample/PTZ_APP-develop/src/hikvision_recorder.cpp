#include "hikvision_recorder.h"
#include <QJsonDocument>
#include <QCoreApplication>
#include <QThread>
#include <QTimer>
#include <QDir>
#include <QFileInfo>
#include <QDateTime>
#include <QDebug>
#include <QByteArray>
#include <cstring>

// 包含海康SDK头文件
#include "HCNetSDK.h"

// ==================== HikvisionRecorder 主类实现 ====================

HikvisionRecorder::HikvisionRecorder(QObject* parent)
    : QObject(parent)
    , m_sdkInitialized(false)
    , m_userId(-1)
    , m_workerThread(nullptr)
    , m_worker(nullptr)
    , m_currentPort(8000)
{
    qDebug() << "HikvisionRecorder created, starting initialization...";
    
    // 创建工作线程
    m_workerThread = new QThread(this);
    m_worker = new DownloadWorker();
    m_worker->moveToThread(m_workerThread);
    
    // 连接工作线程信号槽 - 使用QueuedConnection确保跨线程安全
    connect(m_worker, &DownloadWorker::progressUpdated,
            this, &HikvisionRecorder::onWorkerProgressUpdated,
            Qt::QueuedConnection);
    connect(m_worker, &DownloadWorker::taskCompleted,
            this, &HikvisionRecorder::onWorkerTaskCompleted,
            Qt::QueuedConnection);
    connect(m_worker, &DownloadWorker::batchCompleted,
            this, &HikvisionRecorder::onWorkerBatchCompleted,
            Qt::QueuedConnection);
    connect(m_worker, &DownloadWorker::errorOccurred,
            this, &HikvisionRecorder::onWorkerError,
            Qt::QueuedConnection);
    
    // 启动工作线程
    m_workerThread->start();
    
    qDebug() << "HikvisionRecorder created, worker thread started";
}

HikvisionRecorder::~HikvisionRecorder()
{
    qDebug() << "HikvisionRecorder destructor called";
    
    // 停止工作线程
    if (m_workerThread) {
        m_workerThread->quit();
        m_workerThread->wait();
    }
    
    // 清理SDK资源
    if (m_sdkInitialized) {
        NET_DVR_Cleanup();
    }
    
    qDebug() << "HikvisionRecorder destroyed";
}

bool HikvisionRecorder::initializeSDK()
{
    QMutexLocker locker(&m_mutex);
    
    if (m_sdkInitialized) {
        return true;
    }
    
    // 初始化SDK
    if (!NET_DVR_Init()) {
        QString errorMsg = QString("SDK初始化失败，错误码: %1").arg(NET_DVR_GetLastError());
        qCritical() << errorMsg;
        emit errorOccurred(errorMsg);
        return false;
    }
    
    // 设置连接时间和重连时间
    NET_DVR_SetConnectTime(2000, 1);
    NET_DVR_SetReconnect(10000, true);
    
    m_sdkInitialized = true;
    qDebug() << "海康SDK初始化成功";
    return true;
}

bool HikvisionRecorder::loginDevice(const QString& deviceIp, int port, 
                                   const QString& username, const QString& password)
{
    qDebug() << "loginDevice: 开始登录设备" << deviceIp << ":" << port;
    
    QMutexLocker locker(&m_mutex);
    
    if (!m_sdkInitialized) {
        qDebug() << "loginDevice: SDK未初始化，开始初始化...";
        if (!initializeSDK()) {
            qDebug() << "loginDevice: SDK初始化失败";
            return false;
        }
        qDebug() << "loginDevice: SDK初始化成功";
    }
    
    // 如果已经登录了同一个设备，直接返回成功
    if (m_userId >= 0 && m_currentDeviceIp == deviceIp && 
        m_currentPort == port && m_currentUsername == username) {
        qDebug() << "loginDevice: 已经登录了同一个设备，直接返回成功";
        return true;
    }
    
    // 如果之前登录了其他设备，先注销
    if (m_userId >= 0) {
        qDebug() << "loginDevice: 注销之前的登录";
        NET_DVR_Logout(m_userId);
        m_userId = -1;
    }
    
    // 准备登录参数
    NET_DVR_USER_LOGIN_INFO struLoginInfo = { 0 };
    struLoginInfo.bUseAsynLogin = 0; // 同步登录方式
    
    // 转换为char*类型
    QByteArray deviceIpBytes = deviceIp.toLocal8Bit();
    QByteArray usernameBytes = username.toLocal8Bit();
    QByteArray passwordBytes = password.toLocal8Bit();
    
    strcpy(struLoginInfo.sDeviceAddress, deviceIpBytes.data());
    struLoginInfo.wPort = static_cast<WORD>(port);
    strcpy(struLoginInfo.sUserName, usernameBytes.data());
    strcpy(struLoginInfo.sPassword, passwordBytes.data());
    
    qDebug() << "loginDevice: 准备登录参数完成，设备地址:" << struLoginInfo.sDeviceAddress 
             << "端口:" << struLoginInfo.wPort 
             << "用户名:" << struLoginInfo.sUserName;
    
    // 设备信息
    NET_DVR_DEVICEINFO_V40 struDeviceInfoV40 = { 0 };
    
    // 执行登录
    qDebug() << "loginDevice: 开始执行登录...";
    m_userId = NET_DVR_Login_V40(&struLoginInfo, &struDeviceInfoV40);
    qDebug() << "loginDevice: 登录调用完成，返回用户ID:" << m_userId;
    
    if (m_userId < 0) {
        QString errorMsg = QString("设备登录失败，错误码: %1").arg(NET_DVR_GetLastError());
        qCritical() << errorMsg;
        emit errorOccurred(errorMsg);
        return false;
    }
    
    // 保存当前设备信息
    m_currentDeviceIp = deviceIp;
    m_currentPort = port;
    m_currentUsername = username;
    m_currentPassword = password;
    
    qDebug() << "loginDevice: 设备登录成功，用户ID:" << m_userId;
    return true;
}

bool HikvisionRecorder::loginDeviceWithoutLock(const QString& deviceIp, int port, 
                                              const QString& username, const QString& password)
{
    qDebug() << "loginDeviceWithoutLock: 开始登录设备" << deviceIp << ":" << port;
    
    if (!m_sdkInitialized) {
        qDebug() << "loginDeviceWithoutLock: SDK未初始化，开始初始化...";
        if (!initializeSDK()) {
            qDebug() << "loginDeviceWithoutLock: SDK初始化失败";
            return false;
        }
        qDebug() << "loginDeviceWithoutLock: SDK初始化成功";
    }
    
    // 如果已经登录了同一个设备，直接返回成功
    if (m_userId >= 0 && m_currentDeviceIp == deviceIp && 
        m_currentPort == port && m_currentUsername == username) {
        qDebug() << "loginDeviceWithoutLock: 已经登录了同一个设备，直接返回成功";
        return true;
    }
    
    // 如果之前登录了其他设备，先注销
    if (m_userId >= 0) {
        qDebug() << "loginDeviceWithoutLock: 注销之前的登录";
        NET_DVR_Logout(m_userId);
        m_userId = -1;
    }
    
    // 准备登录参数
    NET_DVR_USER_LOGIN_INFO struLoginInfo = { 0 };
    struLoginInfo.bUseAsynLogin = 0; // 同步登录方式
    
    // 转换为char*类型
    QByteArray deviceIpBytes = deviceIp.toLocal8Bit();
    QByteArray usernameBytes = username.toLocal8Bit();
    QByteArray passwordBytes = password.toLocal8Bit();
    
    strcpy(struLoginInfo.sDeviceAddress, deviceIpBytes.data());
    struLoginInfo.wPort = static_cast<WORD>(port);
    strcpy(struLoginInfo.sUserName, usernameBytes.data());
    strcpy(struLoginInfo.sPassword, passwordBytes.data());
    
    qDebug() << "loginDeviceWithoutLock: 准备登录参数完成，设备地址:" << struLoginInfo.sDeviceAddress 
             << "端口:" << struLoginInfo.wPort 
             << "用户名:" << struLoginInfo.sUserName;
    
    // 设备信息
    NET_DVR_DEVICEINFO_V40 struDeviceInfoV40 = { 0 };
    
    // 执行登录
    qDebug() << "loginDeviceWithoutLock: 开始执行登录...";
    m_userId = NET_DVR_Login_V40(&struLoginInfo, &struDeviceInfoV40);
    qDebug() << "loginDeviceWithoutLock: 登录调用完成，返回用户ID:" << m_userId;
    
    if (m_userId < 0) {
        DWORD errorCode = NET_DVR_GetLastError();
        QString errorMsg = QString("设备登录失败，错误码: %1").arg(errorCode);
        qCritical() << errorMsg;
        qCritical() << "详细错误信息:";
        qCritical() << "  - 设备IP:" << deviceIp;
        qCritical() << "  - 端口:" << port;
        qCritical() << "  - 用户名:" << username;
        qCritical() << "  - 密码长度:" << password.length();
        qCritical() << "  - SDK初始化状态:" << m_sdkInitialized;
        emit errorOccurred(errorMsg);
        return false;
    }
    
    // 保存当前设备信息
    m_currentDeviceIp = deviceIp;
    m_currentPort = port;
    m_currentUsername = username;
    m_currentPassword = password;
    
    qDebug() << "loginDeviceWithoutLock: 设备登录成功，用户ID:" << m_userId;
    return true;
}

QString HikvisionRecorder::downloadRecordByTime(const QString& deviceIp, int port,
                                               const QString& username, const QString& password,
                                               int channel, const QDateTime& startTime, 
                                               const QDateTime& endTime, const QString& savePath)
{
    qDebug() << "downloadRecordByTime called";
    
    // 创建下载任务
    DownloadTask task(deviceIp, port, username, password, channel, startTime, endTime, savePath);
    QString taskId = task.taskId;
    
    // 添加到任务列表
    addTask(taskId, task);
    
    // 发送任务到工作线程 - 使用简单参数而不是结构体
    QMetaObject::invokeMethod(m_worker, "processDownloadTask", 
                             Qt::QueuedConnection,
                             Q_ARG(QString, taskId),
                             Q_ARG(QString, task.deviceIp),
                             Q_ARG(int, task.port),
                             Q_ARG(QString, task.username),
                             Q_ARG(QString, task.password),
                             Q_ARG(int, task.channel),
                             Q_ARG(QDateTime, task.startTime),
                             Q_ARG(QDateTime, task.endTime),
                             Q_ARG(QString, task.savePath));
    
    qDebug() << "downloadRecordByTime: 任务已提交，任务ID:" << taskId;
    return taskId;
}

QString HikvisionRecorder::downloadRecordsByTime(const QString& deviceIp, int port,
                                                const QString& username, const QString& password,
                                                const QList<QPair<QDateTime, QDateTime>>& timeRanges,
                                                int channel, const QString& saveDir)
{
    qDebug() << "downloadRecordsByTime called";
    
    // 创建批量下载任务
    BatchDownloadTask task(deviceIp, port, username, password, timeRanges, channel, saveDir);
    QString taskId = task.taskId;
    
    // 添加到任务列表
    addBatchTask(taskId, task);
    
    // 发送任务到工作线程 - 使用简单参数而不是结构体
    // 注意：批量下载暂时简化为单个下载，避免复杂的参数传递
    if (!task.timeRanges.isEmpty()) {
        const auto& timeRange = task.timeRanges.first();
        QMetaObject::invokeMethod(m_worker, "processDownloadTask", 
                                 Qt::QueuedConnection,
                                 Q_ARG(QString, taskId),
                                 Q_ARG(QString, task.deviceIp),
                                 Q_ARG(int, task.port),
                                 Q_ARG(QString, task.username),
                                 Q_ARG(QString, task.password),
                                 Q_ARG(int, task.channel),
                                 Q_ARG(QDateTime, timeRange.first),
                                 Q_ARG(QDateTime, timeRange.second),
                                 Q_ARG(QString, QDir(task.saveDir).filePath(generateFileName(timeRange.first, timeRange.second, task.channel) + ".mp4")));
    }
    
    qDebug() << "downloadRecordsByTime: 批量任务已提交，任务ID:" << taskId;
    return taskId;
}

bool HikvisionRecorder::cancelDownload(const QString& taskId)
{
    qDebug() << "cancelDownload: 取消任务" << taskId;
    
    QMutexLocker locker(&m_taskMutex);
    
    // 检查任务是否存在
    if (!m_singleTasks.contains(taskId) && !m_batchTasks.contains(taskId)) {
        qWarning() << "cancelDownload: 任务不存在" << taskId;
        return false;
    }
    
    // 更新任务状态
    updateTaskStatus(taskId, DownloadStatus::Cancelled);
    
    // 发送取消命令到工作线程
    QMetaObject::invokeMethod(m_worker, "cancelTask", 
                             Qt::QueuedConnection,
                             Q_ARG(QString, taskId));
    
    qDebug() << "cancelDownload: 任务取消命令已发送" << taskId;
    return true;
}

int HikvisionRecorder::getDownloadStatus(const QString& taskId)
{
    QMutexLocker locker(&m_taskMutex);
    
    if (m_taskProgress.contains(taskId)) {
        return static_cast<int>(m_taskProgress[taskId].status);
    }
    
    return 0;//pengding
}

int HikvisionRecorder::getDownloadProgress(const QString& taskId)
{
    QMutexLocker locker(&m_taskMutex);
    
    if (m_taskProgress.contains(taskId)) {
        return m_taskProgress[taskId].progress;
    }
    
    return 0;
}

QStringList HikvisionRecorder::getActiveTaskIds()
{
    QMutexLocker locker(&m_taskMutex);
    
    QStringList activeTasks;
    
    // 获取单个任务
    for (auto it = m_singleTasks.begin(); it != m_singleTasks.end(); ++it) {
        activeTasks.append(it.key());
    }
    
    // 获取批量任务
    for (auto it = m_batchTasks.begin(); it != m_batchTasks.end(); ++it) {
        activeTasks.append(it.key());
    }
    
    return activeTasks;
}

void HikvisionRecorder::onWorkerTaskCompleted(const QString& taskId, const QString& fileName, bool success, const QString& errorMsg)
{
    qDebug() << "onWorkerTaskCompleted: 任务" << taskId << "完成，成功:" << success;
    
    QMutexLocker locker(&m_taskMutex);
    
    if (m_singleTasks.contains(taskId)) {
        // 更新任务状态
        updateTaskStatus(taskId, success ? DownloadStatus::Completed : DownloadStatus::Failed);
        
        // 发送完成信号
        emit downloadCompleted(taskId, fileName, success, errorMsg);
        
        // 从任务列表中移除
        removeTask(taskId);
    }
}

void HikvisionRecorder::onWorkerProgressUpdated(const QString& taskId, const QString& fileName, int progress)
{
    qDebug() << "onWorkerProgressUpdated: 任务" << taskId << "进度" << progress << "%";
    
    QMutexLocker locker(&m_taskMutex);
    
    // 更新任务进度
    updateTaskProgress(taskId, fileName, progress);
    
    // 发送进度信号
    emit downloadProgressUpdated(taskId, fileName, progress);
}

void HikvisionRecorder::onWorkerBatchCompleted(const QString& taskId, int successCount, int totalCount)
{
    qDebug() << "onWorkerBatchCompleted: 批量任务" << taskId << "完成，成功:" << successCount << "/" << totalCount;
    
    QMutexLocker locker(&m_taskMutex);
    
    // 更新任务状态
    updateTaskStatus(taskId, DownloadStatus::Completed);
    
    // 发送批量完成信号
    emit downloadAllCompleted(taskId, successCount, totalCount);
    
    // 从任务列表中移除
    removeTask(taskId);
}

void HikvisionRecorder::onWorkerError(const QString& errorMessage)
{
    qCritical() << "onWorkerError:" << errorMessage;
    emit errorOccurred(errorMessage);
}

void HikvisionRecorder::addTask(const QString& taskId, const DownloadTask& task)
{
    QMutexLocker locker(&m_taskMutex);
    
    m_singleTasks[taskId] = task;
    
    // 初始化进度信息
    DownloadProgress progress;
    progress.taskId = taskId;
    progress.fileName = QFileInfo(task.savePath).fileName();
    progress.status = DownloadStatus::Pending;
    m_taskProgress[taskId] = progress;
    
    qDebug() << "addTask: 添加任务" << taskId;
}

void HikvisionRecorder::addBatchTask(const QString& taskId, const BatchDownloadTask& task)
{
    QMutexLocker locker(&m_taskMutex);
    
    m_batchTasks[taskId] = task;
    
    // 初始化进度信息
    DownloadProgress progress;
    progress.taskId = taskId;
    progress.fileName = QString("批量下载_%1个文件").arg(task.timeRanges.size());
    progress.status = DownloadStatus::Pending;
    m_taskProgress[taskId] = progress;
    
    qDebug() << "addBatchTask: 添加批量任务" << taskId;
}

void HikvisionRecorder::removeTask(const QString& taskId)
{
    m_singleTasks.remove(taskId);
    m_batchTasks.remove(taskId);
    m_taskProgress.remove(taskId);
    
    qDebug() << "removeTask: 移除任务" << taskId;
}

void HikvisionRecorder::updateTaskStatus(const QString& taskId, DownloadStatus status)
{
    if (m_taskProgress.contains(taskId)) {
        m_taskProgress[taskId].status = status;
        emit taskStatusChanged(taskId, status);
    }
}

void HikvisionRecorder::updateTaskProgress(const QString& taskId, const QString& fileName, int progress)
{
    if (m_taskProgress.contains(taskId)) {
        m_taskProgress[taskId].fileName = fileName;
        m_taskProgress[taskId].progress = progress;
        if (progress > 0) {
            m_taskProgress[taskId].status = DownloadStatus::Running;
        }
    }
}

bool HikvisionRecorder::saveRecordByTime(int userId, int channel, 
                                        const QDateTime& startTime, const QDateTime& endTime,
                                        const QString& destFile)
{
    // 这个方法现在由DownloadWorker处理
    return false;
}

void HikvisionRecorder::convertTimeToDownloadCondition(const QDateTime& dateTime, 
                                                       DWORD& year, DWORD& month, DWORD& day, 
                                                       DWORD& hour, DWORD& minute, DWORD& second)
{
    year = static_cast<DWORD>(dateTime.date().year());
    month = static_cast<DWORD>(dateTime.date().month());
    day = static_cast<DWORD>(dateTime.date().day());
    hour = static_cast<DWORD>(dateTime.time().hour());
    minute = static_cast<DWORD>(dateTime.time().minute());
    second = static_cast<DWORD>(dateTime.time().second());
}

QString HikvisionRecorder::generateFileName(const QDateTime& startTime, const QDateTime& endTime, int channel)
{
    QString fileName = QString("channel_%1_%2_to_%3")
                      .arg(channel)
                      .arg(startTime.toString("yyyyMMdd_hhmmss"))
                      .arg(endTime.toString("yyyyMMdd_hhmmss"));
    return fileName;
}

QString HikvisionRecorder::getLastErrorMessage()
{
    DWORD errorCode = NET_DVR_GetLastError();
    return QString("错误码: %1").arg(errorCode);
}

// ==================== DownloadWorker 工作线程类实现 ====================

DownloadWorker::DownloadWorker(QObject* parent)
    : QObject(parent)
    , m_sdkInitialized(false)
    , m_userId(-1)
    , m_cancelled(false)
    , m_currentPort(8000)
{
    qDebug() << "DownloadWorker created";
}

DownloadWorker::~DownloadWorker()
{
    qDebug() << "DownloadWorker destroyed";
    
    // 清理SDK资源
    if (m_sdkInitialized) {
        NET_DVR_Cleanup();
    }
}

void DownloadWorker::processDownloadTask(const QString& taskId, const QString& deviceIp, int port,
                                       const QString& username, const QString& password, int channel,
                                       const QDateTime& startTime, const QDateTime& endTime, const QString& savePath)
{
    qDebug() << "processDownloadTask: 开始处理任务" << taskId;
    
    m_cancelled = false;
    m_currentTaskId = taskId;  // 保存当前任务ID
    
    // 检查是否被取消
    if (m_cancelled) {
        qDebug() << "processDownloadTask: 任务已被取消" << taskId;
        emit taskCompleted(taskId, savePath, false, "任务已被取消");
        return;
    }
    
    // 创建下载任务对象，但使用传入的taskId而不是生成新的
    DownloadTask task(deviceIp, port, username, password, channel, startTime, endTime, savePath);
    task.taskId = taskId;  // 使用传入的任务ID，覆盖自动生成的ID
    
    // 执行下载
    bool success = doDownloadRecordByTime(task);
    
    // 发送完成信号
    emit taskCompleted(taskId, savePath, success, success ? "" : getLastErrorMessage());
    
    // 清除当前任务ID
    m_currentTaskId = "";
    
    qDebug() << "processDownloadTask: 任务处理完成" << taskId;
}

// void DownloadWorker::processBatchDownloadTask(const QString& taskId, const BatchDownloadTask& task)
// {
//     qDebug() << "processBatchDownloadTask: 开始处理批量任务" << taskId;
//     
//     m_cancelled = false;
//     
//     // 检查是否被取消
//     if (m_cancelled) {
//         qDebug() << "processBatchDownloadTask: 任务已被取消" << taskId;
//         emit batchCompleted(taskId, 0, task.timeRanges.size());
//         return;
//     }
//     
//     // 执行批量下载
//     bool success = doDownloadRecordsByTime(task);
//     
//     qDebug() << "processBatchDownloadTask: 批量任务处理完成" << taskId;
// }

void DownloadWorker::cancelTask(const QString& taskId)
{
    qDebug() << "cancelTask: 设置取消标志" << taskId;
    m_cancelled = true;
    
    // 如果是当前任务被取消，清除任务ID
    if (m_currentTaskId == taskId) {
        m_currentTaskId = "";
    }
}

bool DownloadWorker::doDownloadRecordByTime(const DownloadTask& task)
{
    qDebug() << "doDownloadRecordByTime: 开始下载任务" << task.taskId;
    
    // 登录设备
    if (!loginDevice(task.deviceIp, task.port, task.username, task.password)) {
        qDebug() << "doDownloadRecordByTime: 设备登录失败";
        return false;
    }
    
    // 确保保存目录存在
    QFileInfo fileInfo(task.savePath);
    QDir dir = fileInfo.dir();
    if (!dir.exists()) {
        dir.mkpath(".");
    }
    
    // 执行下载
    bool success = saveRecordByTime(m_userId, task.channel, task.startTime, task.endTime, task.savePath, task.taskId);
    
    if (success) {
        qDebug() << "doDownloadRecordByTime: 下载成功" << task.savePath;
    } else {
        qDebug() << "doDownloadRecordByTime: 下载失败" << task.savePath;
    }
    
    return success;
}

bool DownloadWorker::doDownloadRecordsByTime(const BatchDownloadTask& task)
{
    qDebug() << "doDownloadRecordsByTime: 开始批量下载" << task.taskId;
    
    // 登录设备
    if (!loginDevice(task.deviceIp, task.port, task.username, task.password)) {
        qDebug() << "doDownloadRecordsByTime: 设备登录失败";
        emit batchCompleted(task.taskId, 0, task.timeRanges.size());
        return false;
    }
    
    // 确保保存目录存在
    QDir dir(task.saveDir);
    if (!dir.exists()) {
        dir.mkpath(".");
    }
    
    int successCount = 0;
    int totalCount = task.timeRanges.size();
    
    qDebug() << "doDownloadRecordsByTime: 开始批量下载" << totalCount << "个文件";
    
    for (int i = 0; i < task.timeRanges.size(); ++i) {
        // 检查是否被取消
        if (m_cancelled) {
            qDebug() << "doDownloadRecordsByTime: 任务被取消";
            emit batchCompleted(task.taskId, successCount, totalCount);
            return false;
        }
        
        const auto& timeRange = task.timeRanges[i];
        const QDateTime& startTime = timeRange.first;
        const QDateTime& endTime = timeRange.second;
        
        QString fileName = generateFileName(startTime, endTime, task.channel);
        QString savePath = QDir(task.saveDir).filePath(fileName + ".mp4");
        
        qDebug() << "doDownloadRecordsByTime: 下载进度" << (i + 1) << "/" << totalCount << ":" << fileName;
        emit progressUpdated(task.taskId, fileName, (i + 1) * 100 / totalCount);
        
        // 执行下载
        bool success = saveRecordByTime(m_userId, task.channel, startTime, endTime, savePath, task.taskId);
        
        if (success) {
            successCount++;
            qDebug() << "doDownloadRecordsByTime: 文件下载成功" << fileName;
            emit taskCompleted(task.taskId, fileName, true, "");
        } else {
            QString errorMsg = QString("文件下载失败，错误码: %1").arg(NET_DVR_GetLastError());
            qDebug() << "doDownloadRecordsByTime: 文件下载失败" << fileName << errorMsg;
            emit taskCompleted(task.taskId, fileName, false, errorMsg);
        }
        
        // 短暂延迟，避免过于频繁的请求
        QThread::msleep(100);
    }
    
    qDebug() << "doDownloadRecordsByTime: 批量下载完成，成功:" << successCount << "失败:" << (totalCount - successCount);
    emit batchCompleted(task.taskId, successCount, totalCount);
    
    return successCount > 0;
}

bool DownloadWorker::saveRecordByTime(int userId, int channel, 
                                     const QDateTime& startTime, const QDateTime& endTime,
                                     const QString& destFile, const QString& taskId)
{
    int hPlayback = 0;
    
    qDebug() << "=== 开始按时间下载录像 ===";
    qDebug() << "用户ID:" << userId;
    qDebug() << "通道:" << channel;
    qDebug() << "开始时间:" << startTime.toString("yyyy-MM-dd hh:mm:ss");
    qDebug() << "结束时间:" << endTime.toString("yyyy-MM-dd hh:mm:ss");
    qDebug() << "目标文件:" << destFile;
    
    // 准备下载条件
    NET_DVR_PLAYCOND struDownloadCond = { 0 };
    struDownloadCond.dwChannel = static_cast<DWORD>(channel);
    
    // 设置开始时间
    convertTimeToDownloadCondition(startTime, 
                                  struDownloadCond.struStartTime.dwYear,
                                  struDownloadCond.struStartTime.dwMonth,
                                  struDownloadCond.struStartTime.dwDay,
                                  struDownloadCond.struStartTime.dwHour,
                                  struDownloadCond.struStartTime.dwMinute,
                                  struDownloadCond.struStartTime.dwSecond);
    
    // 设置结束时间
    convertTimeToDownloadCondition(endTime,
                                  struDownloadCond.struStopTime.dwYear,
                                  struDownloadCond.struStopTime.dwMonth,
                                  struDownloadCond.struStopTime.dwDay,
                                  struDownloadCond.struStopTime.dwHour,
                                  struDownloadCond.struStopTime.dwMinute,
                                  struDownloadCond.struStopTime.dwSecond);
    
    qDebug() << "下载条件设置完成";
    
    // 转换为char*类型，因为SDK需要非const的char*
    QByteArray destFileBytes = destFile.toLocal8Bit();
    char* destFileName = destFileBytes.data();
    
    qDebug() << "调用NET_DVR_GetFileByTime_V40...";
    
    // 按时间下载
    hPlayback = NET_DVR_GetFileByTime_V40(userId, destFileName, &struDownloadCond);
    if (hPlayback < 0) {
        DWORD errorCode = NET_DVR_GetLastError();
        qWarning() << "NET_DVR_GetFileByTime_V40 failed, error:" << errorCode;
        return false;
    }
    
    qDebug() << "NET_DVR_GetFileByTime_V40成功，返回句柄:" << hPlayback;
    
    // 开始下载
    qDebug() << "调用NET_DVR_PlayBackControl_V40开始下载...";
    if (!NET_DVR_PlayBackControl_V40(hPlayback, NET_DVR_PLAYSTART, NULL, 0, NULL, NULL)) {
        DWORD errorCode = NET_DVR_GetLastError();
        qWarning() << "play back control failed, error:" << errorCode;
        return false;
    }
    
    qDebug() << "下载已开始，开始监控进度...";
    
    // 获取下载进度
    int nPos = 0;
    int maxWaitTime = 300; // 最大等待时间300秒
    int waitCount = 0;
    
    while (nPos < 100 && nPos >= 0 && waitCount < maxWaitTime) {
        // 检查是否被取消
        if (m_cancelled) {
            qDebug() << "下载被取消";
            NET_DVR_StopGetFile(hPlayback);
            return false;
        }
        
        nPos = NET_DVR_GetDownloadPos(hPlayback);
        qDebug() << "下载进度:" << nPos << "%";
        
        // 发送进度更新信号
        if (nPos >= 0 && nPos <= 100) {
            QString fileName = QFileInfo(destFile).fileName();
            QString currentTaskId = taskId.isEmpty() ? m_currentTaskId : taskId;
            emit progressUpdated(currentTaskId, fileName, nPos);
        }
        
        if (nPos >= 100) {
            qDebug() << "下载完成，进度100%";
            break;
        }
        
        if (nPos < 0) {
            DWORD errorCode = NET_DVR_GetLastError();
            qWarning() << "下载出错，错误码:" << errorCode;
            break;
        }
        
        QThread::msleep(1000); // 1秒检查一次进度
        waitCount++;
    }
    
    if (waitCount >= maxWaitTime) {
        qWarning() << "下载超时，等待时间超过" << maxWaitTime << "秒";
        return false;
    }
    
    if (nPos < 0 || nPos > 100) {
        DWORD errorCode = NET_DVR_GetLastError();
        qWarning() << "download error, error:" << errorCode;
        return false;
    }
    
    // 停止下载，释放资源
    qDebug() << "停止下载并释放资源...";
    if (!NET_DVR_StopGetFile(hPlayback)) {
        DWORD errorCode = NET_DVR_GetLastError();
        qWarning() << "failed to stop get file, error:" << errorCode;
        return false;
    }
    
    qDebug() << "下载完成，最终进度:" << nPos << "%";
    qDebug() << "=== 录像下载完成 ===";
    return true;
}

void DownloadWorker::convertTimeToDownloadCondition(const QDateTime& dateTime, 
                                                   DWORD& year, DWORD& month, DWORD& day, 
                                                   DWORD& hour, DWORD& minute, DWORD& second)
{
    year = static_cast<DWORD>(dateTime.date().year());
    month = static_cast<DWORD>(dateTime.date().month());
    day = static_cast<DWORD>(dateTime.date().day());
    hour = static_cast<DWORD>(dateTime.time().hour());
    minute = static_cast<DWORD>(dateTime.time().minute());
    second = static_cast<DWORD>(dateTime.time().second());
}

QString DownloadWorker::generateFileName(const QDateTime& startTime, const QDateTime& endTime, int channel)
{
    QString fileName = QString("channel_%1_%2_to_%3")
                      .arg(channel)
                      .arg(startTime.toString("yyyyMMdd_hhmmss"))
                      .arg(endTime.toString("yyyyMMdd_hhmmss"));
    return fileName;
}

bool DownloadWorker::loginDevice(const QString& deviceIp, int port, 
                                const QString& username, const QString& password)
{
    qDebug() << "loginDevice: 开始登录设备" << deviceIp << ":" << port;
    
    QMutexLocker locker(&m_mutex);
    
    if (!m_sdkInitialized) {
        qDebug() << "loginDevice: SDK未初始化，开始初始化...";
        if (!initializeSDK()) {
            qDebug() << "loginDevice: SDK初始化失败";
            return false;
        }
        qDebug() << "loginDevice: SDK初始化成功";
    }
    
    // 如果已经登录了同一个设备，直接返回成功
    if (m_userId >= 0 && m_currentDeviceIp == deviceIp && 
        m_currentPort == port && m_currentUsername == username) {
        qDebug() << "loginDevice: 已经登录了同一个设备，直接返回成功";
        return true;
    }
    
    // 如果之前登录了其他设备，先注销
    if (m_userId >= 0) {
        qDebug() << "loginDevice: 注销之前的登录";
        NET_DVR_Logout(m_userId);
        m_userId = -1;
    }
    
    // 准备登录参数
    NET_DVR_USER_LOGIN_INFO struLoginInfo = { 0 };
    struLoginInfo.bUseAsynLogin = 0; // 同步登录方式
    
    // 转换为char*类型
    QByteArray deviceIpBytes = deviceIp.toLocal8Bit();
    QByteArray usernameBytes = username.toLocal8Bit();
    QByteArray passwordBytes = password.toLocal8Bit();
    
    strcpy(struLoginInfo.sDeviceAddress, deviceIpBytes.data());
    struLoginInfo.wPort = static_cast<WORD>(port);
    strcpy(struLoginInfo.sUserName, usernameBytes.data());
    strcpy(struLoginInfo.sPassword, passwordBytes.data());
    
    qDebug() << "loginDevice: 准备登录参数完成";
    
    // 设备信息
    NET_DVR_DEVICEINFO_V40 struDeviceInfoV40 = { 0 };
    
    // 执行登录
    qDebug() << "loginDevice: 开始执行登录...";
    m_userId = NET_DVR_Login_V40(&struLoginInfo, &struDeviceInfoV40);
    qDebug() << "loginDevice: 登录调用完成，返回用户ID:" << m_userId;
    
    if (m_userId < 0) {
        QString errorMsg = QString("设备登录失败，错误码: %1").arg(NET_DVR_GetLastError());
        qCritical() << errorMsg;
        return false;
    }
    
    // 保存当前设备信息
    m_currentDeviceIp = deviceIp;
    m_currentPort = port;
    m_currentUsername = username;
    m_currentPassword = password;
    
    qDebug() << "loginDevice: 设备登录成功，用户ID:" << m_userId;
    return true;
}

bool DownloadWorker::initializeSDK()
{
    if (m_sdkInitialized) {
        return true;
    }
    
    // 初始化SDK
    if (!NET_DVR_Init()) {
        QString errorMsg = QString("SDK初始化失败，错误码: %1").arg(NET_DVR_GetLastError());
        qCritical() << errorMsg;
        return false;
    }
    
    // 设置连接时间和重连时间
    NET_DVR_SetConnectTime(2000, 1);
    NET_DVR_SetReconnect(10000, true);
    
    m_sdkInitialized = true;
    qDebug() << "海康SDK初始化成功";
    return true;
}

QString DownloadWorker::getLastErrorMessage()
{
    DWORD errorCode = NET_DVR_GetLastError();
    return QString("错误码: %1").arg(errorCode);
} 