#include "thermal_device_manager.h"
#include <QDebug>
#include <QCoreApplication>
#include "src/model/devicemodel.h"

ThermalDeviceManager* ThermalDeviceManager::m_instance = nullptr;

ThermalDeviceManager* ThermalDeviceManager::instance()
{
    if (!m_instance) {
        m_instance = new ThermalDeviceManager();
    }
    return m_instance;
}

ThermalDeviceManager::ThermalDeviceManager(QObject* parent)
    : QObject(parent)
{
    qDebug() << "ThermalDeviceManager created";
}

ThermalDeviceManager::~ThermalDeviceManager()
{
    removeAllDevices();
    qDebug() << "ThermalDeviceManager destroyed";
}

void ThermalDeviceManager::initializeDevice(const QString &deviceId, const QString &username, const QString &password, const QString &ip)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_devices.contains(deviceId)) {
        qWarning() << "Thermal device" << deviceId << "already initialized";
        return;
    }
    
    qDebug() << "Initializing thermal device:" << deviceId << "at" << ip;
    
    // 创建设备线程
    QThread* deviceThread = new QThread();
    
    // 创建热成像设备实例
    ThermalCtl* device = new ThermalCtl();
    device->moveToThread(deviceThread);
    
    // 连接线程信号
    QObject::connect(deviceThread, &QThread::finished, device, &QObject::deleteLater);
    QObject::connect(deviceThread, &QThread::finished, deviceThread, &QThread::deleteLater);
    
    // 启动线程
    deviceThread->start();
    
    // 获取设备信息以设置正确的设备名称
    DeviceInfo deviceInfo = DeviceModel::instance()->getDevice(deviceId);
    QString deviceName = deviceInfo.deviceName.isEmpty() ? deviceId : deviceInfo.deviceName;
    qDebug() << "ThermalDeviceManager::initializeDevice deviceName: deviceId" << deviceId << "deviceName" << deviceName;
    
    // 初始化设备
    // QMetaObject::invokeMethod(device, "LoginThermal", Qt::QueuedConnection,
    //                          Q_ARG(QString, ip),
    //                          Q_ARG(QString, username),
    //                          Q_ARG(QString, password),
    //                          Q_ARG(QString, deviceName),
    //                          Q_ARG(QString, deviceId));
    device->LoginThermal(ip, username, password, deviceName, deviceId);
    
    // 存储设备实例
    m_devices[deviceId] = device;
    m_deviceThreads[deviceId] = deviceThread;
    
    // 设置第一个设备为当前设备
    if (m_currentDeviceId.isEmpty()) {
        m_currentDeviceId = deviceId;
    }
    
    emit deviceInitialized(deviceId);
    qDebug() << "Thermal device" << deviceId << "initialized successfully";
}

void ThermalDeviceManager::removeDevice(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "Thermal device" << deviceId << "not found";
        return;
    }
    
    qDebug() << "Removing thermal device:" << deviceId;
    
    // 获取设备和线程
    ThermalCtl* device = m_devices[deviceId];
    QThread* deviceThread = m_deviceThreads[deviceId];
    
    // 从映射中移除
    m_devices.remove(deviceId);
    m_deviceThreads.remove(deviceId);
    
    // 如果移除的是当前设备，清空当前设备ID
    if (m_currentDeviceId == deviceId) {
        m_currentDeviceId.clear();
        // 设置第一个可用设备为当前设备
        if (!m_devices.isEmpty()) {
            m_currentDeviceId = m_devices.firstKey();
        }
    }
    
    // 停止线程
    if (deviceThread) {
        deviceThread->quit();
        deviceThread->wait(3000); // 等待最多3秒
    }
    
    emit deviceRemoved(deviceId);
    qDebug() << "Thermal device" << deviceId << "removed";
}

ThermalCtl* ThermalDeviceManager::getDevice(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    
    if (deviceId.isEmpty()) {
        // 返回当前设备
        return m_devices.value(m_currentDeviceId, nullptr);
    }
    
    return m_devices.value(deviceId, nullptr);
}

QString ThermalDeviceManager::getCurrentDeviceId()
{
    QMutexLocker locker(&m_mutex);
    return m_currentDeviceId;
}

void ThermalDeviceManager::setCurrentDevice(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "Thermal device" << deviceId << "not found, cannot set as current";
        return;
    }
    
    if (m_currentDeviceId != deviceId) {
        m_currentDeviceId = deviceId;
        emit currentDeviceChanged(deviceId);
        qDebug() << "Current thermal device changed to:" << deviceId;
    }
}

void ThermalDeviceManager::initializeAllDevices()
{
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "Initializing all thermal devices...";
    
    // 从设备模型获取所有设备
    QList<DeviceInfo> devices = DeviceModel::instance()->getAllDevices();
    
    for (const DeviceInfo& device : devices) {
        // 使用红外IP和用户名密码初始化热成像设备
        if (!device.deviceId.isEmpty() && !device.infraredUsername.isEmpty() && !device.infraredIp.isEmpty()) {
            qDebug() << "Initializing thermal device:" << device.deviceId << "at" << device.infraredIp;
            initializeDevice(device.deviceId, device.infraredUsername, device.infraredPassword, device.infraredIp);     
        }
    }
    
    qDebug() << "All thermal devices initialization completed";
}

void ThermalDeviceManager::removeAllDevices()
{
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "Removing all thermal devices";
    
    // 获取所有设备ID的副本
    QStringList deviceIds = m_devices.keys();
    
    // 移除所有设备
    for (const QString& deviceId : deviceIds) {
        removeDevice(deviceId);
    }
    
    m_currentDeviceId.clear();
    qDebug() << "All thermal devices removed";
}

bool ThermalDeviceManager::isDeviceInitialized(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    return m_devices.contains(deviceId);
}

QStringList ThermalDeviceManager::getInitializedDevices()
{
    QMutexLocker locker(&m_mutex);
    return m_devices.keys();
}

void ThermalDeviceManager::setPseudoMode(int mode)
{
    QMutexLocker locker(&m_mutex);
    
    ThermalCtl* device = m_devices.value(m_currentDeviceId, nullptr);
    if (device) {
        QMetaObject::invokeMethod(device, "setPseudoMode", Qt::QueuedConnection,
                                 Q_ARG(int, mode));
        qDebug() << "Set pseudo mode" << mode << "for thermal device:" << m_currentDeviceId;
    } else {
        qWarning() << "No current thermal device available for setPseudoMode";
    }
}

void ThermalDeviceManager::setFocusZoom(int channel, int digitalZoom, bool debug)
{
    QMutexLocker locker(&m_mutex);
    
    ThermalCtl* device = m_devices.value(m_currentDeviceId, nullptr);
    if (device) {
        QMetaObject::invokeMethod(device, "setFocusZoom", Qt::QueuedConnection,
                                 Q_ARG(int, channel),
                                 Q_ARG(int, digitalZoom),
                                 Q_ARG(bool, debug));
        qDebug() << "Set focus zoom channel:" << channel << "zoom:" << digitalZoom << "for thermal device:" << m_currentDeviceId;
    } else {
        qWarning() << "No current thermal device available for setFocusZoom";
    }
}

void ThermalDeviceManager::enhanceInfraRed(bool brightMutation, bool denoise2DEnable, int denoise2DLevel,
                                          bool denoise3DEnable, int denoise3DLevel, bool ddeEnable, int ddeLevel,
                                          int flipMode, bool regionalEnable, int regionalLevel,
                                          int coordX, int coordY)
{
    QMutexLocker locker(&m_mutex);
    
    ThermalCtl* device = m_devices.value(m_currentDeviceId, nullptr);
    if (device) {
        // 直接调用方法，因为参数太多无法使用QMetaObject::invokeMethod
        device->enhanceInfraRed(brightMutation, denoise2DEnable, denoise2DLevel,
                               denoise3DEnable, denoise3DLevel, ddeEnable, ddeLevel,
                               flipMode, regionalEnable, regionalLevel, coordX, coordY);
    }
}

QJsonObject ThermalDeviceManager::getThermalImageParams(bool defaultConfig)
{
    QMutexLocker locker(&m_mutex);
    
    ThermalCtl* device = m_devices.value(m_currentDeviceId, nullptr);
    if (device) {
        return device->getThermalImageParams(defaultConfig);
    }
    return QJsonObject(); // Return empty object if device not found or not initialized
}