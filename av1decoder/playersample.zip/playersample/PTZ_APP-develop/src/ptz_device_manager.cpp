#include "ptz_device_manager.h"
#include <QDebug>
#include <QCoreApplication>
#include <QPointer>
#include "model/devicemodel.h"
PtzDeviceManager* PtzDeviceManager::m_instance = nullptr;

PtzDeviceManager* PtzDeviceManager::instance()
{
    if (!m_instance) {
        m_instance = new PtzDeviceManager();
    }
    return m_instance;
}

PtzDeviceManager::PtzDeviceManager(QObject* parent)
    : QObject(parent)
    , m_defaultVisibleLightProvider(nullptr)
    , m_defaultInfraredProvider(nullptr)
{
    qDebug() << "PtzDeviceManager created";
}

PtzDeviceManager::~PtzDeviceManager()
{
    removeAllDevices();
    qDebug() << "PtzDeviceManager destroyed";
}

void PtzDeviceManager::initializeDevice(const QString &deviceId, const QString &username, const QString &password, const QString &ip, const QString &tdlasIp, int tdlasPort, const QString &modbusIp, int modbusPort, const QString &tofIp, int tofPort)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_devices.contains(deviceId)) {
        qWarning() << "Device" << deviceId << "already initialized";
        return;
    }
    
    // 检查可见光IP连通性
    if (!ip.isEmpty()) {
        if (!DeviceModel::instance()->pingDevice(ip)) {
            qWarning() << "Device" << deviceId << "Visible Light IP" << ip << "is unreachable. Skipping initialization.";
            return;
        }
    }
    
    qDebug() << "Initializing PTZ device:" << deviceId << "at" << ip;
    
    // 创建设备线程
    QThread* deviceThread = new QThread();
    
    // 创建PTZ设备实例
    PtzDeviceCgi* device = new PtzDeviceCgi();
    device->moveToThread(deviceThread);
    
    // 设置FrameProvider
    if (m_defaultVisibleLightProvider && m_defaultInfraredProvider) {
        device->setFrameProviders(m_defaultVisibleLightProvider, m_defaultInfraredProvider);
    }
    
    // 连接线程信号
    QObject::connect(deviceThread, &QThread::finished, device, &QObject::deleteLater);
    QObject::connect(deviceThread, &QThread::finished, deviceThread, &QThread::deleteLater);
    
    // 启动线程
    deviceThread->start();
    
    // 获取设备信息以设置正确的设备名称
    DeviceInfo deviceInfo = DeviceModel::instance()->getDevice(deviceId);
    QString deviceName = deviceInfo.deviceName.isEmpty() ? deviceId : deviceInfo.deviceName;
    
    // 初始化设备
    device->mvInit(username, password, ip, deviceName, deviceId);
    
    // 初始化TOFWorker（如果提供了TOF信息
    qDebug() << "PtzDeviceManager::initializeDevice: tofIp" << tofIp << "tofPort" << tofPort;
    if (!tofIp.isEmpty() && tofPort > 0) {
        if (DeviceModel::instance()->pingDevice(tofIp)) {
            device->initializeTofWorker(tofIp, tofPort);
            emit tofDeviceInitialized(deviceId);
            qDebug() << "TOFWorker initialized for device" << deviceId << "at" << tofIp << ":" << tofPort;
        } else {
            qWarning() << "Device" << deviceId << "TOF IP" << tofIp << "is unreachable. Skipping TOF initialization.";
        }
    }

    
    // 初始化TdlasWorker（如果提供了TDLAS信息）
    if (!tdlasIp.isEmpty() && tdlasPort > 0) {
        if (DeviceModel::instance()->pingDevice(tdlasIp)) {
            qDebug() << "Initializing TdlasWorker for device" << deviceId << "at" << tdlasIp << ":" << tdlasPort;
            device->initializeTdlasWorker(tdlasIp, tdlasPort);
        } else {
            qWarning() << "Device" << deviceId << "TDLAS IP" << tdlasIp << "is unreachable. Skipping TDLAS initialization.";
        }
    }
    
    // 初始化ModbusWorker（如果提供了Modbus信息）
    if (!modbusIp.isEmpty() && modbusPort > 0) {
        if (DeviceModel::instance()->pingDevice(modbusIp)) {
            device->initializeModbusWorker(modbusIp, modbusPort);
            emit modbusDeviceInitialized(deviceId);
            qDebug() << "ModbusWorker initialized for device" << deviceId << "at" << modbusIp << ":" << modbusPort;
        } else {
            qWarning() << "Device" << deviceId << "Modbus IP" << modbusIp << "is unreachable. Skipping Modbus initialization.";
        }
    }
    

    
    
    // 存储设备实例
    m_devices[deviceId] = device;
    m_deviceThreads[deviceId] = deviceThread;
    
    // 设置第一个设备为当前设备
    if (m_currentDeviceId.isEmpty()) {
        m_currentDeviceId = deviceId;
    }
    
    // 连接设备的报警状态变化信号
    connect(device, &PtzDeviceCgi::gasConcentrationAlarmChanged, 
            this, [this, deviceId](bool alarm, QString signalDeviceId) {
        // 只有当是当前设备时才发出信号
        if (signalDeviceId == m_currentDeviceId) {
            emit gasConcentrationAlarmChanged(alarm);
        }
    });
    
    // 连接TOF距离更新信号
    connect(device, &PtzDeviceCgi::tofDistanceUpdated, 
            this, [this, deviceId](QString signalDeviceId, float distance) {
        // 只有当是当前设备时才发出信号
        //qDebug() << "PtzDeviceManager::tofDistanceUpdated: signalDeviceId:" << signalDeviceId << "distance:" << distance;
        
        // 根据设备ID获取对应的通道索引
        int channelIndex = DeviceModel::instance()->getDeviceChannelIndex(deviceId);
        //qDebug() << "PtzDeviceManager::tofDistanceUpdated: emit tofDistanceUpdated with channel" << channelIndex << "for deviceId" << deviceId;
        emit tofDistanceUpdated(deviceId, channelIndex, distance);
    });
    
    // 连接TOF测距错误信号
    connect(device, &PtzDeviceCgi::tofRangingError, 
            this, [this, deviceId](QString signalDeviceId, QString errorMessage) {
        // 只有当是当前设备时才发出信号
        if (signalDeviceId == m_currentDeviceId) {
            emit tofRangingError(deviceId, errorMessage);
        }
    });
    
    emit deviceInitialized(deviceId);
    qDebug() << "PTZ device" << deviceId << "initialized successfully";
}

void PtzDeviceManager::removeDevice(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "Device" << deviceId << "not found";
        return;
    }
    
    qDebug() << "Removing PTZ device:" << deviceId;
    
    // 获取设备和线程，使用QPointer确保安全访问
    QPointer<PtzDeviceCgi> device = m_devices[deviceId];
    QPointer<QThread> deviceThread = m_deviceThreads[deviceId];
    
    // 从映射中移除
    m_devices.remove(deviceId);
    m_deviceThreads.remove(deviceId);
    
    // 如果移除的是当前设备，清空当前设备ID
    if (m_currentDeviceId == deviceId) {
        m_currentDeviceId.clear();
        // 设置第一个可用设备为当前设备
        if (!m_devices.isEmpty()) {
            m_currentDeviceId = m_devices.firstKey();
        }
    }
    qDebug() << "Removing PTZ device:  111" << deviceId;
    // 先停止设备的所有子线程（在设备线程上下文中同步执行）
    if (device && !device.isNull()) {
        // 确保设备对象仍然有效
        if (QMetaObject::invokeMethod(device.data(), "stopAllWorkerThreads", Qt::BlockingQueuedConnection)) {
            qDebug() << "Successfully stopped all worker threads for device:" << deviceId;
        } else {
            qWarning() << "Failed to invoke stopAllWorkerThreads for device:" << deviceId;
        }

        // 断开设备所有信号，避免删除过程中仍有事件投递
        QObject::disconnect(device.data(), nullptr, nullptr, nullptr);
    }
    qDebug() << "Removing PTZ device:  222" << deviceId;
    // 停止设备线程（不在这里调用deleteLater，依赖initializeDevice中的finished连接自动删除device和deviceThread）
    if (deviceThread && !deviceThread.isNull()) {
        if (deviceThread->isRunning()) {
            deviceThread->quit();
            if (!deviceThread->wait(5000)) {
                qWarning() << "Device thread" << deviceId << "failed to quit within 5 seconds, terminating...";
                deviceThread->terminate();
                deviceThread->wait(1000);
            }
        }
    }
    qDebug() << "Removing PTZ device:  333" << deviceId;
    // 此处不显式调用 device->deleteLater() 或 deviceThread->deleteLater()
    // 因为在 initializeDevice() 中已连接：
    // connect(deviceThread, &QThread::finished, device, &QObject::deleteLater);
    // connect(deviceThread, &QThread::finished, deviceThread, &QThread::deleteLater);

    emit deviceRemoved(deviceId);
    qDebug() << "PTZ device" << deviceId << "removed";
}

PtzDeviceCgi* PtzDeviceManager::getDevice(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    

    
    if (deviceId.isEmpty()) {
        // 返回当前设备
        PtzDeviceCgi* currentDevice = m_devices.value(m_currentDeviceId, nullptr);

        return currentDevice;
    }
    
    PtzDeviceCgi* device = m_devices.value(deviceId, nullptr);

    return device;
}

QString PtzDeviceManager::getCurrentDeviceId()
{
    QMutexLocker locker(&m_mutex);
    return m_currentDeviceId;
}

void PtzDeviceManager::setCurrentDevice(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "Device" << deviceId << "not found, cannot set as current";
        return;
    }
    
    if (m_currentDeviceId != deviceId) {
        m_currentDeviceId = deviceId;
        emit currentDeviceChanged(deviceId);
        qDebug() << "Current PTZ device changed to:" << deviceId;
    }
}

PtzDeviceCgi* PtzDeviceManager::getCurrentPtzDevice()
{
    QMutexLocker locker(&m_mutex);
    return m_devices.value(m_currentDeviceId, nullptr);
}

void PtzDeviceManager::initializeAllDevices()
{
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "Initializing all PTZ devices...";
    
    // 从设备模型获取所有设备
    QList<DeviceInfo> devices = DeviceModel::instance()->getAllDevices();
    
    for (const DeviceInfo& device : devices) {
        // 使用可见光IP和用户名密码初始化PTZ设备
        if (!device.deviceId.isEmpty() && !device.visibleLightUsername.isEmpty() && !device.visibleLightIp.isEmpty()) {
            qDebug() << "Initializing PTZ device:" << device.deviceId << "at" << device.visibleLightIp;
            initializeDevice(device.deviceId, device.visibleLightUsername, device.visibleLightPassword, device.visibleLightIp, device.tdlasIp, device.tdlasPort, device.modbusIp, device.modbusPort, device.tofIp, device.tofPort);     
        }
    }
    
    qDebug() << "All PTZ devices initialization completed";
}

void PtzDeviceManager::removeAllDevices()
{
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "Removing all PTZ devices";
    
    // 获取所有设备ID的副本
    QStringList deviceIds = m_devices.keys();
    
    // 移除所有设备
    for (const QString& deviceId : deviceIds) {
        removeDevice(deviceId);
    }
    
    m_currentDeviceId.clear();
    qDebug() << "All PTZ devices removed";
}

bool PtzDeviceManager::isDeviceInitialized(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    return m_devices.contains(deviceId);
}

QStringList PtzDeviceManager::getInitializedDevices()
{
    QMutexLocker locker(&m_mutex);
    return m_devices.keys();
}

void PtzDeviceManager::setFrameProviders(FrameProvider* visibleLight, FrameProvider* infrared)
{
    QMutexLocker locker(&m_mutex);
    
    m_defaultVisibleLightProvider = visibleLight;
    m_defaultInfraredProvider = infrared;
    
    // 为所有已初始化的设备设置FrameProvider
    for (auto it = m_devices.begin(); it != m_devices.end(); ++it) {
        PtzDeviceCgi* device = it.value();
        if (device) {
            device->setFrameProviders(visibleLight, infrared);
        }
    }
    
    qDebug() << "FrameProviders set for all PTZ devices";
}



void PtzDeviceManager::setDeviceFrameProviders(const QString &deviceId, FrameProvider* visibleLight, FrameProvider* infrared)
{
    QMutexLocker locker(&m_mutex);
    
    PtzDeviceCgi* device = m_devices.value(deviceId, nullptr);
    if (device) {
        device->setFrameProviders(visibleLight, infrared);
        qDebug() << "FrameProviders set for PTZ device:" << deviceId;
    } else {
        qWarning() << "PTZ device" << deviceId << "not found for FrameProvider setting";
    }
} 

// 添加气体浓度报警状态读取方法
bool PtzDeviceManager::gasConcentrationAlarm() const
{
    QMutexLocker locker(&m_mutex);
    
    // 获取当前设备
    PtzDeviceCgi* currentDevice = m_devices.value(m_currentDeviceId, nullptr);
    if (currentDevice) {
        return currentDevice->gasConcentrationAlarm();
    }
    
    return false;
}

// 获取当前设备的报警浓度值
int PtzDeviceManager::getCurrentDeviceAlarmConcentration() const
{
    QMutexLocker locker(&m_mutex);
    
    if (m_currentDeviceId.isEmpty()) {
        return 300; // 默认值
    }
    
    return DeviceModel::instance()->getAlarmConcentration(m_currentDeviceId);
}

// 设置当前设备的报警浓度值
void PtzDeviceManager::setCurrentDeviceAlarmConcentration(int concentration)
{
    QMutexLocker locker(&m_mutex);
    
    if (m_currentDeviceId.isEmpty()) {
        qWarning() << "No current device selected";
        return;
    }
    
    // 获取当前设备信息
    DeviceInfo deviceInfo = DeviceModel::instance()->getDevice(m_currentDeviceId);
    if (deviceInfo.deviceId.isEmpty()) {
        qWarning() << "Current device not found in DeviceModel";
        return;
    }
    
    // 更新报警浓度值
    deviceInfo.alarmConcentration = concentration;
    DeviceModel::instance()->updateDevice(deviceInfo);
    
    qDebug() << "Updated alarm concentration for device" << m_currentDeviceId << "to" << concentration;
} 

// 获取当前报警设备的通道号
int PtzDeviceManager::getCurrentAlarmDeviceChannel() const
{
    QMutexLocker locker(&m_mutex);
    if (m_currentDeviceId.isEmpty()) {
        return -1; // 没有当前设备
    }
    // 获取当前设备信息
    DeviceInfo deviceInfo = DeviceModel::instance()->getDevice(m_currentDeviceId);
    if (deviceInfo.deviceId.isEmpty()) {
        return -1; // 设备不存在
    }
    return deviceInfo.channelIndex;
} 

// Modbus设备管理方法实现
void PtzDeviceManager::initializeModbusDevice(const QString &deviceId, const QString &modbusIp, int modbusPort)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "Device" << deviceId << "not found, cannot initialize Modbus";
        return;
    }
    
    PtzDeviceCgi* device = m_devices[deviceId];
    if (device) {
        device->initializeModbusWorker(modbusIp, modbusPort);
        emit modbusDeviceInitialized(deviceId);
        qDebug() << "ModbusWorker initialized for device" << deviceId << "at" << modbusIp << ":" << modbusPort;
    } else {
        qWarning() << "PTZ device" << deviceId << "instance not found";
    }
}

void PtzDeviceManager::sendModbusVoltage(const QString &deviceId, float voltage)
{
    qDebug() << "=== PtzDeviceManager::sendModbusVoltage 开始 ===";
    qDebug() << "设备ID:" << deviceId << "电压值:" << voltage << "mA";
    
    QMutexLocker locker(&m_mutex);
    qDebug() << "PtzDeviceManager::sendModbusVoltage: 互斥锁获取成功";
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "PtzDeviceManager::sendModbusVoltage: 设备" << deviceId << "未找到";
        return;
    }
    
    PtzDeviceCgi* device = m_devices[deviceId];
    if (device) {
        qDebug() << "PtzDeviceManager::sendModbusVoltage: 找到设备实例，准备调用mvSetVoltage";
        device->mvSetVoltage(voltage);
        qDebug() << "PtzDeviceManager::sendModbusVoltage: mvSetVoltage调用完成";
        qDebug() << "Modbus电压" << voltage << "已发送到设备" << deviceId;
    } else {
        qWarning() << "PtzDeviceManager::sendModbusVoltage: PTZ设备" << deviceId << "实例未找到";
    }
    
    qDebug() << "=== PtzDeviceManager::sendModbusVoltage 结束 ===";
}

void PtzDeviceManager::sendModbusData(const QString &deviceId, const QVariantList &data)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "Device" << deviceId << "not found, cannot send Modbus data";
        return;
    }
    
    PtzDeviceCgi* device = m_devices[deviceId];
    if (device) {
        // 从设备配置中获取Modbus IP和端口
        DeviceInfo deviceInfo = DeviceModel::instance()->getDevice(deviceId);
        if (!deviceInfo.modbusIp.isEmpty() && deviceInfo.modbusPort > 0) {
            bool success = device->mvSendModbusData(deviceInfo.modbusIp, deviceInfo.modbusPort, data);
            emit modbusDataSent(deviceId, success);
            qDebug() << "Modbus data sent to device" << deviceId << "success:" << success;
        } else {
            qWarning() << "Modbus IP or port not configured for device" << deviceId;
            emit modbusDataSent(deviceId, false);
        }
    } else {
        qWarning() << "PTZ device" << deviceId << "instance not found";
        emit modbusDataSent(deviceId, false);
    }
} 

void PtzDeviceManager::initializeTofDevice(const QString &deviceId, const QString &tofIp, int tofPort)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "Device" << deviceId << "not found, cannot initialize TOF";
        return;
    }
    
    PtzDeviceCgi* device = m_devices[deviceId];
    device->initializeTofWorker(tofIp, tofPort);
    emit tofDeviceInitialized(deviceId);
    qDebug() << "TOFWorker initialized for device" << deviceId << "at" << tofIp << ":" << tofPort;
}

void PtzDeviceManager::sendTofSingleRangingCmd(const QString &deviceId)
{
    qDebug() << "=== PtzDeviceManager::sendTofSingleRangingCmd 开始 ===";
    qDebug() << "设备ID:" << deviceId;
    
    QMutexLocker locker(&m_mutex);
    qDebug() << "PtzDeviceManager::sendTofSingleRangingCmd: 互斥锁获取成功";
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "PtzDeviceManager::sendTofSingleRangingCmd: 设备" << deviceId << "未找到";
        return;
    }
    
    PtzDeviceCgi* device = m_devices[deviceId];
    if (device) {
        qDebug() << "PtzDeviceManager::sendTofSingleRangingCmd: 找到设备实例，准备调用mvSendSingleRangingCmd";
        device->mvSendSingleRangingCmd();
        qDebug() << "PtzDeviceManager::sendTofSingleRangingCmd: mvSendSingleRangingCmd调用完成";
        qDebug() << "TOF单次测距命令已发送到设备" << deviceId;
    } else {
        qWarning() << "PtzDeviceManager::sendTofSingleRangingCmd: PTZ设备" << deviceId << "实例未找到";
    }
    
    qDebug() << "=== PtzDeviceManager::sendTofSingleRangingCmd 结束 ===";
}

void PtzDeviceManager::sendTofContinuousRangingCmd(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "Device" << deviceId << "not found, cannot send TOF command";
        return;
    }
    
    PtzDeviceCgi* device = m_devices[deviceId];
    device->mvSendContinuousRangingCmd();
}

void PtzDeviceManager::sendTofStopRangingCmd(const QString &deviceId)
{
    QMutexLocker locker(&m_mutex);
    
    if (!m_devices.contains(deviceId)) {
        qWarning() << "Device" << deviceId << "not found, cannot send TOF command";
        return;
    }
    
    PtzDeviceCgi* device = m_devices[deviceId];
    device->mvSendStopRangingCmd();
}

