#ifndef GASCLOUDMANAGER_H
#define GASCLOUDMANAGER_H

#include <QObject>
#include <QMutex>
#include <QThread>
#include <QVideoFrame>
#include <QByteArray>
#include <QString>

// 前向声明
class GasCloudWorker;

class GasCloudManager : public QObject
{
    Q_OBJECT

public:
    static GasCloudManager* instance();
    
    // 初始化气云分割
    bool initializeGasCloud(const QString& modelPath, const QString& calibrationJsonPath);
    
    // 异步处理气云分割
    void processGasCloudAsync(const QByteArray& visibleYUV, int visibleWidth, int visibleHeight,
                             const QByteArray& infraredYUV, int infraredWidth, int infraredHeight,
                             int depth, float tdlas);
    
    // 检查是否已初始化
    bool isGasCloudAvailable() const;
    
    // 获取状态信息
    QString getGasCloudStatus() const;
    
    // 释放资源
    void releaseGasCloud();

signals:
    // 气云分割完成信号
    // fusionFrame: 可见光叠加mask的结果
    // maskFrame: 红外叠加mask的结果
    void gasCloudCompleted(const QVideoFrame& fusionFrame, const QVideoFrame& maskFrame, 
                          bool success, const QString& errorMessage);
    
    // 错误信号
    void gasCloudError(const QString& errorMessage);

private:
    explicit GasCloudManager(QObject* parent = nullptr);
    ~GasCloudManager();
    
    // 单例实例
    static GasCloudManager* m_instance;
    
    // 工作线程
    QThread* m_workerThread;
    
    // 工作对象
    GasCloudWorker* m_worker;
    
    // 初始化状态
    bool m_initialized;
    
    // 互斥锁
    mutable QMutex m_mutex;
};

// 工作类，用于在线程中执行气云分割
class GasCloudWorker : public QObject
{
    Q_OBJECT

public:
    explicit GasCloudWorker(QObject* parent = nullptr);
    ~GasCloudWorker();

public slots:
    // 初始化气云分割
    bool initialize(const QString& modelPath, const QString& calibrationJsonPath);
    
    // 处理气云分割
    void processGasCloud(const QByteArray& visibleYUV, int visibleWidth, int visibleHeight,
                        const QByteArray& infraredYUV, int infraredWidth, int infraredHeight,
                        int depth, float tdlas);
    
    // 释放资源
    void release();

signals:
    // 处理完成信号
    // fusionFrame: 可见光叠加mask的结果
    // maskFrame: 红外叠加mask的结果
    void processingCompleted(const QVideoFrame& fusionFrame, const QVideoFrame& maskFrame, 
                           bool success, const QString& errorMessage);

private:
    // 初始化状态
    bool m_initialized;
    
    // 模型路径
    QString m_modelPath;
    
    // 标定文件路径
    QString m_calibrationJsonPath;
    
    // 互斥锁
    mutable QMutex m_mutex;
    
    // 将YUV数据转换为QVideoFrame
    QVideoFrame yuvToVideoFrame(const QByteArray& yuvData, int width, int height) const;
    
    // 将QVideoFrame转换为YUV数据
    QByteArray videoFrameToYUV(const QVideoFrame& frame) const;
    
    // 将NV12数据保存为JPG图像
    void saveNV12ToJPG(const QByteArray& nv12Data, int width, int height, const QString& filename) const;
};

#endif // GASCLOUDMANAGER_H 