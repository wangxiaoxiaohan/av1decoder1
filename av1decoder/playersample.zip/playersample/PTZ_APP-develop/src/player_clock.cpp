#include "player_clock.h"

Clock::Clock() : pts(0.0), pts_drift(0.0), last_updated(0.0), speed(1.0), paused(false) {
    setClock(NAN);
}

double Clock::getClock() {
    QMutexLocker locker(&mutex);
    if (paused) {
        return pts;
    } else {
        double time = av_gettime_relative() / 1000000.0;
        return pts_drift + time;
    }
}

void Clock::setClockAt(double pts, double time) {
    QMutexLocker locker(&mutex);
    this->pts = pts;
    this->last_updated = time;
    this->pts_drift = this->pts - time;
}

void Clock::setClock(double pts) {
    double time = av_gettime_relative() / 1000000.0;
    setClockAt(pts, time);
}

void Clock::setSpeed(double speed) {
    setClock(getClock());
    this->speed = speed;
}

void Clock::pause(double time)
{
    QMutexLocker locker(&mutex);
    if (!paused) {
        pts = pts_drift + time;
        paused = true;
    }
}

void Clock::resume()
{
    QMutexLocker locker(&mutex);
    if (paused) {
        double time = av_gettime_relative() / 1000000.0;
        pts_drift = pts - time;
        paused = false;
    }
}

double Clock::getLastUpdated()
{
    return last_updated;
} 