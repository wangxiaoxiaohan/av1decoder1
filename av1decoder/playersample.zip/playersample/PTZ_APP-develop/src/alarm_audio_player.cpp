#include "alarm_audio_player.h"
#include <QDebug>
#include <QUrl>
#include <QMediaContent>

AlarmAudioPlayer* AlarmAudioPlayer::m_instance = nullptr;

AlarmAudioPlayer* AlarmAudioPlayer::instance()
{
    if (!m_instance) {
        m_instance = new AlarmAudioPlayer();
    }
    return m_instance;
}

AlarmAudioPlayer::AlarmAudioPlayer(QObject* parent)
    : QObject(parent)
    , m_player(nullptr)
{
    qDebug() << "AlarmAudioPlayer created";
    initializePlayer();
}

AlarmAudioPlayer::~AlarmAudioPlayer()
{
    if (m_player) {
        m_player->stop();
        delete m_player;
    }
    qDebug() << "AlarmAudioPlayer destroyed";
}

void AlarmAudioPlayer::initializePlayer()
{
    // 创建媒体播放器
    m_player = new QMediaPlayer(this);
    
    // 连接信号
    connect(m_player, &QMediaPlayer::stateChanged, 
            this, &AlarmAudioPlayer::onPlayerStateChanged);
    connect(m_player, QOverload<QMediaPlayer::Error>::of(&QMediaPlayer::error),
            this, &AlarmAudioPlayer::onPlayerError);
    
    // 使用QRC资源文件中的音频文件
    QString audioPath = "qrc:/data/alarmaudio.MP3";
    QUrl audioUrl = QUrl(audioPath);
    qDebug() << "Setting alarm audio file from QRC resource:" << audioPath;
    m_player->setMedia(QMediaContent(audioUrl));
    
    // 设置音量
    m_player->setVolume(80); // 设置默认音量为80%
}

void AlarmAudioPlayer::playAlarmAudio()
{
    if (!m_player) {
        qWarning() << "Media player not initialized";
        return;
    }
    
    qDebug() << "Playing alarm audio";
    m_player->play();
    
    // 设置循环播放
    connect(m_player, &QMediaPlayer::stateChanged, this, [this](QMediaPlayer::State state) {
        if (state == QMediaPlayer::StoppedState) {
            // 如果播放结束，重新开始播放（循环播放）
            m_player->play();
        }
    });
}

void AlarmAudioPlayer::stopAlarmAudio()
{
    if (!m_player) {
        qWarning() << "Media player not initialized";
        return;
    }
    
    qDebug() << "Stopping alarm audio";
    m_player->stop();
    
    // 断开循环播放连接
    disconnect(m_player, &QMediaPlayer::stateChanged, this, nullptr);
}

void AlarmAudioPlayer::setVolume(qreal volume)
{
    if (!m_player) {
        qWarning() << "Media player not initialized";
        return;
    }
    
    // 确保音量在0到100之间
    int volumeInt = qBound(0, static_cast<int>(volume * 100), 100);
    m_player->setVolume(volumeInt);
    qDebug() << "Alarm audio volume set to:" << volumeInt;
}

bool AlarmAudioPlayer::isPlaying() const
{
    if (!m_player) {
        return false;
    }
    
    return m_player->state() == QMediaPlayer::PlayingState;
}

void AlarmAudioPlayer::onPlayerStateChanged(QMediaPlayer::State state)
{
    switch (state) {
        case QMediaPlayer::PlayingState:
            qDebug() << "Alarm audio playback started";
            emit audioPlaybackStarted();
            break;
        case QMediaPlayer::StoppedState:
            qDebug() << "Alarm audio playback stopped";
            emit audioPlaybackFinished();
            break;
        case QMediaPlayer::PausedState:
            qDebug() << "Alarm audio playback paused";
            break;
    }
}

void AlarmAudioPlayer::onPlayerError(QMediaPlayer::Error error)
{
    QString errorString = m_player->errorString();
    qCritical() << "Alarm audio playback error:" << error << "-" << errorString;
    emit audioPlaybackError(errorString);
} 
 