#ifndef LOG_MODEL_H
#define LOG_MODEL_H

#include <QAbstractListModel>
#include <QList>
#include <QObject>
#include <QString>
#include <QHash>
#include <QVariantMap>
#include <QDateTime>

struct LogData {
    QString operatorName;
    QString logType;
    QString action;
    QString datetime;
    QString result;
    QString ip;
};

class LogModel : public QAbstractListModel {
    Q_OBJECT
    Q_PROPERTY(int currentPage READ currentPage WRITE setCurrentPage NOTIFY currentPageChanged)
    Q_PROPERTY(int totalPages READ totalPages NOTIFY totalPagesChanged)
    Q_PROPERTY(int itemsPerPage READ itemsPerPage WRITE setItemsPerPage NOTIFY itemsPerPageChanged)
    Q_PROPERTY(int totalItems READ totalItems NOTIFY totalItemsChanged)

public:
    enum Roles { 
        OperatorRole = Qt::UserRole + 1,
        LogTypeRole,
        ActionRole,
        DatetimeRole,
        ResultRole,
        IpRole
    };

    QHash<int, QByteArray> roleNames() const override {
        return { 
            {OperatorRole, "operator"},
            {LogTypeRole, "logType"},
            {ActionRole, "action"},
            {DatetimeRole, "datetime"},
            {ResultRole, "result"},
            {IpRole, "ip"}
        };
    }
    
    explicit LogModel(QObject *parent = nullptr) 
        : QAbstractListModel(parent), m_currentPage(1), m_itemsPerPage(10), m_totalItems(0) {}
    
    static LogModel* instance() {
        static LogModel _instance;
        return &_instance;
    }
    
    // Current page accessor
    int currentPage() const { return m_currentPage; }
    void setCurrentPage(int page) {
        if (m_currentPage != page && page > 0 && page <= totalPages()) {
            m_currentPage = page;
            updateDisplayedLogs();
            emit currentPageChanged();
        }
    }
    
    // Items per page accessor
    int itemsPerPage() const { return m_itemsPerPage; }
    void setItemsPerPage(int count) {
        if (m_itemsPerPage != count && count > 0) {
            m_itemsPerPage = count;
            updateDisplayedLogs();
            emit itemsPerPageChanged();
            emit totalPagesChanged();
        }
    }
    
    // Total pages calculation
    int totalPages() const {
        return m_totalItems > 0 ? (m_totalItems + m_itemsPerPage - 1) / m_itemsPerPage : 1;
    }
    
    // Total items accessor
    int totalItems() const { return m_totalItems; }
    
    // Update which logs are being displayed based on current page
    void updateDisplayedLogs() {
        beginResetModel();
        m_displayedLogs.clear();
        
        int startIndex = (m_currentPage - 1) * m_itemsPerPage;
        int endIndex = qMin(startIndex + m_itemsPerPage, m_allLogs.size());
        
        for (int i = startIndex; i < endIndex; ++i) {
            m_displayedLogs.append(m_allLogs.at(i));
        }
        
        endResetModel();
    }
    
    Q_INVOKABLE void addLog(const LogData &log) {
        m_allLogs.append(log);
        m_totalItems = m_allLogs.size();
        emit totalItemsChanged();
        emit totalPagesChanged();
        updateDisplayedLogs();
    }

    Q_INVOKABLE void addLog(const QVariantMap &map) {
        LogData log;
        log.operatorName = map["operator"].toString();
        log.logType = map["logType"].toString();
        log.action = map["action"].toString();
        log.datetime = map["datetime"].toString();
        log.result = map["result"].toString();
        log.ip = map["ip"].toString();
        
        m_allLogs.append(log);
        m_totalItems = m_allLogs.size();
        emit totalItemsChanged();
        emit totalPagesChanged();
        updateDisplayedLogs();
    }

    Q_INVOKABLE void clearLogs() {
        beginResetModel();
        m_allLogs.clear();
        m_displayedLogs.clear();
        m_totalItems = 0;
        m_currentPage = 1;
        endResetModel();
        emit totalItemsChanged();
        emit totalPagesChanged();
        emit currentPageChanged();
    }
    
    // 批量添加日志，提高性能
    Q_INVOKABLE void addLogsBatch(const QVariantList &logs) {
        if (logs.isEmpty()) {
            // 空数据也要清空模型
            clearLogs();
            return;
        }
        
        // 清空现有数据
        m_allLogs.clear();
        
        // 批量转换并添加数据
        for (const QVariant &logVariant : logs) {
            QVariantMap map = logVariant.value<QVariantMap>();
            LogData log;
            log.operatorName = map["operator"].toString();
            log.logType = map["logType"].toString();
            log.action = map["action"].toString();
            log.datetime = map["datetime"].toString();
            log.result = map["result"].toString();
            log.ip = map["ip"].toString();
            m_allLogs.append(log);
        }
        
        m_totalItems = m_allLogs.size();
        m_currentPage = 1; // 重置到第一页
        
        // 使用updateDisplayedLogs来正确更新显示的数据，它会处理模型重置
        updateDisplayedLogs();
        
        emit totalItemsChanged();
        emit totalPagesChanged();
        emit currentPageChanged();
    }
    
    // Search logs by criteria
    Q_INVOKABLE void searchLogs(const QString &operator_, const QString &logType, 
                               const QString &action, const QString &startDate, 
                               const QString &endDate) {
        beginResetModel();
        
        // Store the original logs if this is our first search
        if (m_originalLogs.isEmpty() && !m_allLogs.isEmpty()) {
            m_originalLogs = m_allLogs;
        }
        
        // If all search fields are empty, restore the original data
        if (operator_.isEmpty() && logType.isEmpty() && action.isEmpty() && 
            startDate.isEmpty() && endDate.isEmpty()) {
            if (!m_originalLogs.isEmpty()) {
                m_allLogs = m_originalLogs;
                m_originalLogs.clear();
            }
        } else {
            // Start with all logs (or original logs if we stored them)
            QList<LogData> baseData = m_originalLogs.isEmpty() ? m_allLogs : m_originalLogs;
            m_allLogs.clear();
            
            QDateTime startDateTime = startDate.isEmpty() ? QDateTime() : QDateTime::fromString(startDate, "yyyy-MM-dd");
            QDateTime endDateTime = endDate.isEmpty() ? QDateTime() : QDateTime::fromString(endDate, "yyyy-MM-dd").addDays(1).addSecs(-1);
            
            // Filter the logs
            for (const LogData &log : baseData) {
                bool match = true;
                
                if (!operator_.isEmpty() && log.operatorName != operator_)
                    match = false;
                    
                if (match && !logType.isEmpty() && log.logType != logType)
                    match = false;
                    
                if (match && !action.isEmpty() && !log.action.contains(action))
                    match = false;
                    
                if (match && !startDate.isEmpty()) {
                    QDateTime logDate = QDateTime::fromString(log.datetime, "yyyy-MM-dd hh:mm:ss");
                    if (logDate < startDateTime)
                        match = false;
                }
                
                if (match && !endDate.isEmpty()) {
                    QDateTime logDate = QDateTime::fromString(log.datetime, "yyyy-MM-dd hh:mm:ss");
                    if (logDate > endDateTime)
                        match = false;
                }
                
                if (match)
                    m_allLogs.append(log);
            }
        }
        
        m_totalItems = m_allLogs.size();
        m_currentPage = 1;  // Reset to first page
        
        updateDisplayedLogs();
        emit totalItemsChanged();
        emit totalPagesChanged();
        emit currentPageChanged();
        endResetModel();
    }
    
    // Add sample data for testing
    Q_INVOKABLE void addSampleData() {
        // Clear existing data
        clearLogs();
        
        // Generate sample log entries
        QStringList operators = {"admin", "operator", "system"};
        QStringList logTypes = {"查询日志", "操作日志", "系统日志"};
        QStringList actions = {"执行了查询操作", "执行了编辑操作", "执行了配置操作", "执行了登录操作", "执行了导出操作"};
        QStringList results = {"成功", "失败", "警告", "超时"};
        QStringList ips = {"192.168.1.100", "192.168.1.101", "192.168.1.102", "127.0.0.1"};
        
        QDateTime now = QDateTime::currentDateTime();
        
        // Generate 60 sample logs
        for (int i = 0; i < 60; i++) {
            LogData log;
            log.operatorName = operators[i % operators.size()];
            log.logType = logTypes[i % logTypes.size()];
            log.action = actions[i % actions.size()] + " #" + QString::number(i + 1);
            
            // Generate a date within the last 30 days
            QDateTime logDate = now.addDays(-(i % 30)).addSecs(-(i * 3600));
            log.datetime = logDate.toString("yyyy-MM-dd hh:mm:ss");
            
            log.result = results[i % results.size()];
            log.ip = ips[i % ips.size()];
            
            m_allLogs.append(log);
        }
        
        m_totalItems = m_allLogs.size();
        emit totalItemsChanged();
        emit totalPagesChanged();
        updateDisplayedLogs();
    }
    
    int rowCount(const QModelIndex &parent = QModelIndex()) const override {
        Q_UNUSED(parent);
        return m_displayedLogs.count();
    }

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override {
        if (!index.isValid() || index.row() >= m_displayedLogs.size())
            return QVariant();

        const LogData &item = m_displayedLogs[index.row()];
        
        switch(role) {
        case OperatorRole:
            return item.operatorName;
        case LogTypeRole:
            return item.logType;
        case ActionRole:
            return item.action;
        case DatetimeRole:
            return item.datetime;
        case ResultRole:
            return item.result;
        case IpRole:
            return item.ip;
        default:
            return QVariant();
        }
    }
    
signals:
    void currentPageChanged();
    void totalPagesChanged();
    void itemsPerPageChanged();
    void totalItemsChanged();
    
private:
    QList<LogData> m_allLogs;         // All logs in the system
    QList<LogData> m_displayedLogs;   // Logs for the current page
    QList<LogData> m_originalLogs;    // Original logs before search filtering
    int m_currentPage;
    int m_itemsPerPage;
    int m_totalItems;
};

// Function to register the model with QML
void registerLogModel();

#endif // LOG_MODEL_H