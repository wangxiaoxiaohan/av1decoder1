#ifndef DEVICETREEMODEL_H
#define DEVICETREEMODEL_H

#include <QObject>
#include <QAbstractItemModel>
#include <QModelIndex>
#include <QVariant>
#include <QString>
#include <QList>
#include <QHash>

// 前向声明
struct DeviceInfo;

// 树形节点结构
struct TreeNode {
    enum NodeType {
        GroupNode,
        DeviceNode
    };
    
    NodeType type;
    QString name;           // 显示名称
    QString id;             // 唯一标识
    QString groupName;      // 分组名称（仅设备节点）
    QString deviceId;       // 设备ID（仅设备节点）
    TreeNode* parent;       // 父节点
    QList<TreeNode*> children; // 子节点
    bool isExpanded;        // 是否展开
    
    TreeNode(NodeType t, const QString& n, const QString& i, TreeNode* p = nullptr) 
        : type(t), name(n), id(i), parent(p), isExpanded(false) {}
    
    ~TreeNode() {
        qDeleteAll(children);
    }
};

class DeviceTreeModel : public QAbstractItemModel
{
    Q_OBJECT

public:
    enum TreeRoles {
        NameRole = Qt::UserRole + 1,
        IdRole,
        TypeRole,
        GroupNameRole,
        DeviceIdRole,
        IsExpandedRole,
        HasChildrenRole
    };

    explicit DeviceTreeModel(QObject *parent = nullptr);
    ~DeviceTreeModel();

    // QAbstractItemModel 接口
    QModelIndex index(int row, int column, const QModelIndex &parent = QModelIndex()) const override;
    QModelIndex parent(const QModelIndex &index) const override;
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    int columnCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;

    // 公共接口
    Q_INVOKABLE void addDevice(const DeviceInfo &device);
    Q_INVOKABLE void removeDevice(const QString &deviceId);
    Q_INVOKABLE void updateDevice(const DeviceInfo &device);
    Q_INVOKABLE void addGroup(const QString &groupName);
    Q_INVOKABLE void removeGroup(const QString &groupName);
    Q_INVOKABLE void clear();
    Q_INVOKABLE void setExpanded(int row, bool expanded);
    Q_INVOKABLE bool isExpanded(const QModelIndex &index) const;
    Q_INVOKABLE QVariantList getTreeData() const; // 返回用于HwTreeView的modelData格式

    // 信号
signals:
    void deviceAdded(const QString &deviceId);
    void deviceRemoved(const QString &deviceId);
    void deviceUpdated(const QString &deviceId);
    void groupAdded(const QString &groupName);
    void groupRemoved(const QString &groupName);

private:
    TreeNode* m_rootNode;
    QHash<QString, TreeNode*> m_groupNodes;      // 分组名称 -> 分组节点
    QHash<QString, TreeNode*> m_deviceNodes;     // 设备ID -> 设备节点
    
    TreeNode* findGroupNode(const QString &groupName) const;
    TreeNode* findDeviceNode(const QString &deviceId) const;
    void rebuildTree();
    QModelIndex indexForNode(TreeNode* node) const;
    TreeNode* nodeForIndex(const QModelIndex &index) const;
    TreeNode* getNodeAtFlatIndex(int flatIndex) const;
    int rowForNode(TreeNode* node) const;

};

#endif // DEVICETREEMODEL_H 