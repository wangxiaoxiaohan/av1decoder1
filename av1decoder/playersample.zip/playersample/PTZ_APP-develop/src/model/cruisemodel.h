#ifndef CRUISE_MODEL_H
#define CRUISE_MODEL_H

#include <QAbstractListModel>
#include <QList>
#include <QObject>
#include <QString>
#include <QHash>
#include <QVariantMap>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QStandardPaths>
#include <QDir>
#include <QDebug>

struct CruiseData {
    QString deviceId;       // 设备ID，用于区分不同设备
    QString cruiseNumber;   // 巡航编号
    QString cruiseName;     // 巡航名称
    QList<int> presetPoints; // 预置位点列表
};

class CruiseModel : public QAbstractListModel {
    Q_OBJECT

public:
    enum Roles { 
        DeviceIdRole = Qt::UserRole + 1,
        CruiseNumberRole,
        CruiseNameRole,
        PresetPointsRole
    };

    QHash<int, QByteArray> roleNames() const override {
        return {
            {DeviceIdRole, "deviceId"},
            {CruiseNumberRole, "cruiseNumber"},
            {CruiseNameRole, "cruiseName"},
            {PresetPointsRole, "presetPoints"}
        };
    }
    
    explicit CruiseModel(QObject *parent = nullptr);
    
    static CruiseModel* instance() {
        static CruiseModel _instance;
        return &_instance;
    }
    
    // 添加巡航
    Q_INVOKABLE void addCruise(const QString &deviceId, const CruiseData &cruise);
    Q_INVOKABLE void addCruise(const QString &deviceId, const QVariantMap &map);
    
    // 删除巡航
    Q_INVOKABLE void removeCruise(const QString &deviceId, int index);
    Q_INVOKABLE void removeCruiseByNumber(const QString &deviceId, const QString &cruiseNumber);
    
    // 修改巡航
    Q_INVOKABLE void modifyCruise(const QString &deviceId, int index, const CruiseData &cruise);
    Q_INVOKABLE void modifyCruise(const QString &deviceId, int index, const QVariantMap &map);
    Q_INVOKABLE void modifyCruiseByNumber(const QString &deviceId, const QString &cruiseNumber, const QVariantMap &map);
    
    // 查询巡航
    Q_INVOKABLE QList<CruiseData> getCruisesForDevice(const QString &deviceId);
    Q_INVOKABLE CruiseData getCruiseByNumber(const QString &deviceId, const QString &cruiseNumber);
    Q_INVOKABLE int getCruiseCount(const QString &deviceId);
    
    // 设备管理
    Q_INVOKABLE void clearCruisesForDevice(const QString &deviceId);
    Q_INVOKABLE QStringList getDeviceIds();
    
    // 数据持久化
    Q_INVOKABLE void saveCruisesToFile();
    Q_INVOKABLE void loadCruisesFromFile();
    Q_INVOKABLE void saveCruisesForDevice(const QString &deviceId);
    Q_INVOKABLE void loadCruisesForDevice(const QString &deviceId);
    
    // 当前选中设备
    Q_INVOKABLE void setCurrentDevice(const QString &deviceId);
    Q_INVOKABLE QString getCurrentDevice() const;
    
    // 获取指定索引的巡航数据（用于QML访问）
    Q_INVOKABLE QVariantMap get(int index) const;
    
    // QAbstractListModel 接口实现
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    
    // 测试数据
    Q_INVOKABLE void addSampleData();
    Q_INVOKABLE void clearData();
    
signals:
    void cruiseAdded(const QString &deviceId, const QString &cruiseNumber);
    void cruiseRemoved(const QString &deviceId, const QString &cruiseNumber);
    void cruiseModified(const QString &deviceId, const QString &cruiseNumber);
    void currentDeviceChanged(const QString &deviceId);
    
private:
    QHash<QString, QList<CruiseData>> m_deviceCruises; // 按设备ID分组的巡航数据
    QString m_currentDeviceId; // 当前选中的设备ID
    
    QString getConfigDir() const;
    QString getCruiseFilePath(const QString &deviceId) const;
    QString getGlobalCruiseFilePath() const;
    void updateModel(); // 更新模型显示当前设备的巡航
    int findCruiseIndex(const QString &deviceId, const QString &cruiseNumber) const;
};

// Function to register the model with QML
void registerCruiseModel();

#endif // CRUISE_MODEL_H