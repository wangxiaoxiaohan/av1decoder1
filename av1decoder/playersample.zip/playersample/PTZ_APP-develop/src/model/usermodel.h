#ifndef USER_MODEL_H
#define USER_MODEL_H

#include <QAbstractListModel>
#include <QList>
#include <QObject>
#include <QString>
#include <QHash>
#include <QVariantMap>

struct UserData {
    QString username;
    QString permission;
    QString password;
    QString status;
    bool checked;
};

class UserModel : public QAbstractListModel {
    Q_OBJECT

public:
    enum Roles { 
        UsernameRole = Qt::UserRole + 1,
        PermissionRole,
        PasswordRole,
        StatusRole,
        CheckedRole
    };

    QHash<int, QByteArray> roleNames() const override {
        return { 
            {UsernameRole, "username"},
            {PermissionRole, "permission"},
            {PasswordRole, "password"},
            {StatusRole, "status"},
            {CheckedRole, "checked"}
        };
    }
    
    explicit UserModel(QObject *parent = nullptr) : QAbstractListModel(parent) {}
    
    static UserModel* instance() {
        static UserModel _instance;
        return &_instance;
    }
    
    Q_INVOKABLE void addUser(const UserData &user) {
        beginInsertRows(QModelIndex(), rowCount(), rowCount());
        m_users.append(user);
        endInsertRows();
    }

    Q_INVOKABLE void addUser(const QVariantMap &map) {
        UserData user;
        user.username = map["username"].toString();
        user.permission = map["permission"].toString();
        user.password = map["password"].toString();
        user.status = map["status"].toString();
        user.checked = map["checked"].toBool();
        
        beginInsertRows(QModelIndex(), rowCount(), rowCount());
        m_users.append(user);
        endInsertRows();
    }

    Q_INVOKABLE void removeUser(int index) {
        if (index < 0 || index >= m_users.size())
            return;
            
        beginRemoveRows(QModelIndex(), index, index);
        m_users.removeAt(index);
        endRemoveRows();
    }
    
    Q_INVOKABLE void modifyUser(int index, const UserData &user) {
        if (index < 0 || index >= m_users.size())
            return;
            
        m_users[index] = user;
        QModelIndex modelIndex = createIndex(index, 0);
        emit dataChanged(modelIndex, modelIndex);
    }
    
    Q_INVOKABLE void modifyUser(int index, const QVariantMap &map) {
        if (index < 0 || index >= m_users.size())
            return;
            
        m_users[index].username = map["username"].toString();
        m_users[index].permission = map["permission"].toString();
        m_users[index].password = map["password"].toString();
        m_users[index].status = map["status"].toString();
        m_users[index].checked = map["checked"].toBool();
        
        QModelIndex modelIndex = createIndex(index, 0);
        emit dataChanged(modelIndex, modelIndex);
    }
    
    int rowCount(const QModelIndex &parent = QModelIndex()) const override {
        Q_UNUSED(parent);
        return m_users.count();
    }

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override {
        if (!index.isValid() || index.row() >= m_users.size())
            return QVariant();

        const UserData &item = m_users[index.row()];
        
        switch(role) {
        case UsernameRole:
            return item.username;
        case PermissionRole:
            return item.permission;
        case PasswordRole:
            return item.password;
        case StatusRole:
            return item.status;
        case CheckedRole:
            return item.checked;
        default:
            return QVariant();
        }
    }
    
    // Add sample data for testing
    Q_INVOKABLE void addSampleData() {
        // Add some sample user data
        addUser({"admin", "超级管理员", "xxxxxxxx", "正常", false});
        addUser({"operator", "管理员", "xxxxxxxx", "正常", false});
        addUser({"guest", "普通用户", "xxxxxxxx", "冻结", false});
    }
    
    // Clear all data
    Q_INVOKABLE void clearData() {
        beginResetModel();
        m_users.clear();
        endResetModel();
    }
    
private:
    QList<UserData> m_users;
};

// Function to register the model with QML
void registerUserModel();

#endif // USER_MODEL_H 