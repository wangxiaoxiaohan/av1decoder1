#ifndef ALARM_MODEL_H
#define ALARM_MODEL_H

#include <QAbstractListModel>
#include <QAbstractTableModel>
#include <QList>
#include <QObject>
#include <QString>
#include <QHash>
#include "src/alarmlog.h" // 引入AlarmLog头文件
#include "src/eventshare.h" // 引入EventShare头文件

// 报警模式枚举


// enum AlarmMode {
//     GAS_ALARM = 0,      // 气体报警
//     DEVICE_ALARM = 1    // 设备故障报警
// };

enum AlarmMode {
    MOVE_DETECT_ALARM = 0, // 移动侦测报警
    OBSTRUCTION_ALARM = 1, // 遮挡报警
    GAS_LEAK_ALARM = 2,    // 气体泄漏报警
    DEVICE_FAULT_ALARM = 3,// 设备故障报警
};

struct AlarmData {
    // 通用字段
    AlarmMode alarmMode;        // 报警模式
    QString errorImage1;        // 错误图片1
    QString errorImage2;        // 错误图片2
    QString alarmTime;          // 报警时间
    
    // 气体报警专用字段
    QString concentration;      // 气体浓度
    QString pressure;           // 压力信息
    QString position;           // 位置信息
    QString distance;           // 测量距离
    
    // 设备故障报警专用字段
    QString deviceId;           // 设备编号
    QString deviceName;         // 设备名称
    QString exceptionType;      // 异常类型编号 (001, 002, ...)
    QString exceptionName;      // 异常类型名称 (网络异常, 云台水平转动异常, ...)
    QString exceptionComponent; // 异常部件 (主板, 水平电机, ...)
    
    // 角度信息（气体报警专用）
    QString horizontalAngle;    // 水平角度
    QString verticalAngle;      // 垂直角度

    // 巡航/预置位信息
    QString presetName;         // 预置位名称（在巡航时记录报警发生的预置位名称）
};

class AlarmModel : public QAbstractListModel {
    Q_OBJECT

public:
    enum Roles { 
        AlarmModeRole = Qt::UserRole + 1,
        ErrorImage1Role,
        ErrorImage2Role,    
        AlarmTimeRole,
        // 气体报警字段
        ConcentrationRole,
        PressureRole,
        PositionRole,
        DistanceRole,
        // 设备异常字段
        DeviceIdRole,
        ExceptionTypeRole,
        ExceptionNameRole,
        ExceptionComponentRole,
        HorizontalAngleRole,
        VerticalAngleRole,
        PresetNameRole
    };

    QHash<int,QByteArray> roleNames() const override {
        return { 
            {AlarmModeRole, "alarmMode"},
            {ErrorImage1Role, "errorImage1"},
            {ErrorImage2Role, "errorImage2"},
            {AlarmTimeRole, "alarmTime"},
            {ConcentrationRole, "concentration"},
            {PressureRole, "pressure"},
            {PositionRole, "position"},
            {DistanceRole, "distance"},
            {HorizontalAngleRole, "horizontalAngle"},  // 新增
            {VerticalAngleRole, "verticalAngle"},      // 新增
            {DeviceIdRole, "deviceId"},
            {ExceptionTypeRole, "exceptionType"},
            {ExceptionNameRole, "exceptionName"},
            {ExceptionComponentRole, "exceptionComponent"},
            {PresetNameRole, "presetName"}
        };
    }
    explicit AlarmModel(QObject *parent = nullptr) : QAbstractListModel(parent) {}
    static AlarmModel* instance() {
        static AlarmModel _instance;
        return &_instance;
    }
    void addAlarm(const AlarmData &alarm) {
        beginInsertRows(QModelIndex(), 0, 0);
        m_alarms.prepend(alarm);
        endInsertRows();

        printf("-------alarmtype : %d\n", alarm.alarmMode);
        // --- 将AlarmData转换为HwAlarmLogEntry，并写入数据库 ---
        HwAlarmLogEntry entry;
        // 1. 报警时间
        entry.alarm_time = alarm.alarmTime;
        // 2. 报警类型（0=移动侦测报警，1=遮挡报警，2=气体泄漏报警，3=设备故障报警）
        entry.alarm_type = static_cast<ALARM_T>(alarm.alarmMode);
        // 3. 异常类型编号
        entry.alarm_type_code = alarm.exceptionType; // 仅设备故障报警时有意义
        // 4. 异常类型名称
        entry.alarm_type_name = alarm.exceptionName; // 仅设备故障报警时有意义
        // 5. 异常部件
        entry.alarm_part = alarm.exceptionComponent; // 仅设备故障报警时有意义
        // 6. 设备编号
        entry.device_code = alarm.deviceId;
        // 7. 设备名称（无对应，留空）
        entry.device_name = alarm.deviceName;
        // 8. 报警介质（无对应，留空）
        entry.alarm_medium = "";
        // 9. 报警值（气体泄漏报警时为浓度）
        entry.alarm_value = alarm.concentration;
        // 10. 预置位（无对应，留空）
        entry.preset = alarm.presetName;
        qDebug() << "add alarm to db PRESET NAME" << entry.preset;
        // 11. 检测区域（气体泄漏报警时为位置）
        entry.area = alarm.position;
        // 12. 红外图片
        entry.ir_image_url = alarm.errorImage2;
        // 13. 红外视频（无对应，留空）
        entry.ir_video_url = "";
        // 14. 可见光图片
        entry.vi_image_url = alarm.errorImage1;
        // 15. 可见光视频（无对应，留空）
        entry.vi_video_url = "";
        // 16. 处理状态，默认未处理
        entry.handle_status = 0;
        // 17. 测量距离
        entry.distance = alarm.distance;
        // 18. 水平角度
        entry.horizontal_angle = alarm.horizontalAngle;
        // 19. 垂直角度
        entry.vertical_angle = alarm.verticalAngle;
        // 写入数据库
        AlarmLog::instance()->addLog(entry);
        qDebug() << "add alarm to db";
        EventShare* eventShare = EventShare::instance();
        QList<HwAlarmLogEntry> alarms;
        alarms.append(entry);
        eventShare->reportAlarms(alarms, "192.168.35.130", 8080);

    }

    void removeAlarm(int index) {
        beginRemoveRows(QModelIndex(), index, index);
        m_alarms.removeAt(index);
        endRemoveRows();
    }
    int rowCount(const QModelIndex &parent = QModelIndex()) const override {
        Q_UNUSED(parent);
        return m_alarms.count();
    }

    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override {
        if (!index.isValid() || index.row() >= m_alarms.size())
            return QVariant();

        const AlarmData &item = m_alarms[index.row()];
        
        switch(role) {
        case AlarmModeRole:
            return static_cast<int>(item.alarmMode);
        case ErrorImage1Role:
            return item.errorImage1;
        case ErrorImage2Role:  
            return item.errorImage2;
        case AlarmTimeRole:    
            return item.alarmTime;
        case ConcentrationRole:
            return item.concentration;
        case PressureRole:
            return item.pressure;
        case PositionRole:     
            return item.position;
        case DistanceRole:
            return item.distance;
        case DeviceIdRole:
            return item.deviceId;
        case ExceptionTypeRole:
            return item.exceptionType;
        case ExceptionNameRole:
            return item.exceptionName;
        case ExceptionComponentRole:
            return item.exceptionComponent;
        case HorizontalAngleRole:
            return item.horizontalAngle;
        case VerticalAngleRole:
            return item.verticalAngle;
        case PresetNameRole:
            return item.presetName;
        default:
            return QVariant();
        }
    }
private:
    QList<AlarmData> m_alarms;
};
#endif
