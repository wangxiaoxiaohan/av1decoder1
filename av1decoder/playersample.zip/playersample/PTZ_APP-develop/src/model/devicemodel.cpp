#include "devicemodel.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QDebug>
#include <QTimer>
#include <QDateTime>
#include "hikvision_ctrl.h"

DeviceModel* DeviceModel::m_instance = nullptr;

DeviceModel::DeviceModel(QObject *parent)
    : QAbstractListModel(parent)
    , m_treeModel(nullptr)
    , m_hikvisionCtrl(nullptr)
{
    // 初始化默认设备分组
    addDeviceGroup("第一园区");
    addDeviceGroup("第二园区");
    
    // 启动设备状态检查定时器
    QTimer *statusTimer = new QTimer(this);
    connect(statusTimer, &QTimer::timeout, this, &DeviceModel::checkDeviceStatus);
    statusTimer->start(30000); // 每30秒检查一次设备状态
}

DeviceModel* DeviceModel::instance()
{
    if (!m_instance) {
        m_instance = new DeviceModel();
    }
    return m_instance;
}

int DeviceModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    return m_devices.size();
}

QVariant DeviceModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_devices.size())
        return QVariant();

    const DeviceInfo &device = m_devices[index.row()];

    switch (role) {
    case DeviceIdRole:
        return device.deviceId;
    case DeviceNameRole:
        return device.deviceName;
    case DeviceTypeRole:
        return device.deviceType;
    case VisibleLightIpRole:
        return device.visibleLightIp;
    case InfraredIpRole:
        return device.infraredIp;
    case HikvisionIpRole:
        return device.hikvisionIp;
    case PortRole:
        return device.port;
    case VisibleLightUsernameRole:
        return device.visibleLightUsername;
    case VisibleLightPasswordRole:
        return device.visibleLightPassword;
    case InfraredUsernameRole:
        return device.infraredUsername;
    case InfraredPasswordRole:
        return device.infraredPassword;
    case HikvisionUsernameRole:
        return device.hikvisionUsername;
    case HikvisionPasswordRole:
        return device.hikvisionPassword;
    case HikvisionPortRole:
        return device.hikvisionPort;
    case InfraredDownloadChannelRole:
        return device.infraredDownloadChannel;
    case VisibleLightDownloadChannelRole:
        return device.visibleLightDownloadChannel;
    case AlarmConcentrationRole:
        return device.alarmConcentration;
    case AlarmRecordDurationRole:
        return device.alarmRecordDuration;
    case AlarmOutputDurationRole:
        return device.alarmOutputDuration;
    case VisibleLightUrlRole:
        return device.visibleLightUrl;
    case InfraredUrlRole:
        return device.infraredUrl;
    case VisibleLightRecordUrlRole:
        return device.visibleLightRecordUrl;
    case InfraredRecordUrlRole:
        return device.infraredRecordUrl;
    case RecordUrlbaseRole:
        return device.recordUrlbase;
    case GroupNameRole:
        return device.groupName;
    case IsOnlineRole:
        return device.isOnline;
    case IsSelectedRole:
        return device.isSelected;
    case ChannelIndexRole:
        return device.channelIndex;
    case IsInfraredSelectedRole:
        return device.isInfraredSelected;
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> DeviceModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[DeviceIdRole] = "deviceId";
    roles[DeviceNameRole] = "deviceName";
    roles[DeviceTypeRole] = "deviceType";
    roles[VisibleLightIpRole] = "visibleLightIp";
    roles[InfraredIpRole] = "infraredIp";
    roles[HikvisionIpRole] = "hikvisionIp";
    roles[PortRole] = "port";
    roles[VisibleLightUsernameRole] = "visibleLightUsername";
    roles[VisibleLightPasswordRole] = "visibleLightPassword";
    roles[InfraredUsernameRole] = "infraredUsername";
    roles[InfraredPasswordRole] = "infraredPassword";
    roles[HikvisionUsernameRole] = "hikvisionUsername";
    roles[HikvisionPasswordRole] = "hikvisionPassword";
    roles[HikvisionPortRole] = "hikvisionPort";
    roles[InfraredDownloadChannelRole] = "infraredDownloadChannel";
    roles[VisibleLightDownloadChannelRole] = "visibleLightDownloadChannel";
    roles[AlarmConcentrationRole] = "alarmConcentration";
    roles[AlarmRecordDurationRole] = "alarmRecordDuration";
    roles[AlarmOutputDurationRole] = "alarmOutputDuration";
    roles[VisibleLightUrlRole] = "visibleLightUrl";
    roles[InfraredUrlRole] = "infraredUrl";
    roles[VisibleLightRecordUrlRole] = "visibleLightRecordUrl";
    roles[InfraredRecordUrlRole] = "infraredRecordUrl";
    roles[RecordUrlbaseRole] = "recordUrlbase";
    roles[GroupNameRole] = "groupName";
    roles[IsOnlineRole] = "isOnline";
    roles[IsSelectedRole] = "isSelected";
    roles[ChannelIndexRole] = "channelIndex";
    roles[IsInfraredSelectedRole] = "isInfraredSelected";
    return roles;
}

void DeviceModel::addDevice(const DeviceInfo &device)
{
    beginInsertRows(QModelIndex(), m_devices.size(), m_devices.size());
    m_devices.append(device);
    endInsertRows();
    
    // 同时更新树形模型
    if (m_treeModel) {
        qDebug() << "Adding device to tree model:" << device.deviceName << "in group:" << device.groupName;
        m_treeModel->addDevice(device);
    } else {
        qDebug() << "Tree model is null!";
    }
    
    updateDeviceGroups();
    emit deviceAdded(device.deviceId);
}

void DeviceModel::removeDevice(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        beginRemoveRows(QModelIndex(), index, index);
        m_devices.removeAt(index);
        endRemoveRows();
        
        // 同时从树形模型中移除
        if (m_treeModel) {
            m_treeModel->removeDevice(deviceId);
        }
        
        updateDeviceGroups();
        emit deviceRemoved(deviceId);
    }
}

void DeviceModel::updateDevice(const DeviceInfo &device)
{
    int index = findDeviceIndex(device.deviceId);
    if (index >= 0) {
        m_devices[index] = device;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        
        // 同时更新树形模型
        if (m_treeModel) {
            m_treeModel->updateDevice(device);
        }
        
        updateDeviceGroups();
        emit deviceUpdated(device.deviceId);
    }
}

DeviceInfo DeviceModel::getDevice(const QString &deviceId)
{
    //qDebug() << "getDevice: deviceId =" << deviceId;
    int index = findDeviceIndex(deviceId);
    //qDebug() << "getDevice: found index =" << index;
    if (index >= 0) {
        //qDebug() << "getDevice: returning device with infraredDownloadChannel =" << m_devices[index].infraredDownloadChannel;
        //qDebug() << "getDevice: returning device with visibleLightDownloadChannel =" << m_devices[index].visibleLightDownloadChannel;
        return m_devices[index];
    }
    //qDebug() << "getDevice: device not found, returning empty DeviceInfo";
    return DeviceInfo{};
}

DeviceInfo DeviceModel::getDeviceByIndex(int index)
{
    if (index >= 0 && index < m_devices.size()) {
        return m_devices[index];
    }
    return DeviceInfo{};
}

QList<DeviceInfo> DeviceModel::getAllDevices() const
{
    return m_devices;
}

void DeviceModel::selectDevice(const QString &deviceId)
{
    // 清除之前的选择
    for (int i = 0; i < m_devices.size(); ++i) {
        if (m_devices[i].isSelected) {
            m_devices[i].isSelected = false;
            QModelIndex index = this->index(i);
            emit dataChanged(index, index);
        }
    }
    
    // 设置新的选择
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        m_devices[index].isSelected = true;
        m_selectedDeviceId = deviceId;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        emit deviceSelected(deviceId);
    }
}

void DeviceModel::selectDeviceByIndex(int index)
{
    if (index >= 0 && index < m_devices.size()) {
        selectDevice(m_devices[index].deviceId);
    }
}

void DeviceModel::setDeviceOnlineStatus(const QString &deviceId, bool isOnline)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].isOnline != isOnline) {
        m_devices[index].isOnline = isOnline;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        emit deviceStatusChanged(deviceId, isOnline);
    }
}

void DeviceModel::setDeviceChannelIndex(const QString &deviceId, int channelIndex)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].channelIndex != channelIndex) {
        m_devices[index].channelIndex = channelIndex;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
    }
}

int DeviceModel::getDeviceChannelIndex(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].channelIndex;
    }
    return -1; // 未找到设备
}

QList<DeviceGroup> DeviceModel::getDeviceGroups() const
{
    return m_deviceGroups;
}

void DeviceModel::addDeviceGroup(const QString &groupName)
{
    // 检查分组是否已存在
    for (const auto &group : m_deviceGroups) {
        if (group.groupName == groupName) {
            return;
        }
    }
    
    DeviceGroup newGroup;
    newGroup.groupName = groupName;
    newGroup.isExpanded = true;
    m_deviceGroups.append(newGroup);
}

void DeviceModel::removeDeviceGroup(const QString &groupName)
{
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == groupName) {
            // 将该分组下的设备移动到默认分组
            for (const auto &device : m_deviceGroups[i].devices) {
                DeviceInfo updatedDevice = device;
                updatedDevice.groupName = "默认分组";
                updateDevice(updatedDevice);
            }
            m_deviceGroups.removeAt(i);
            break;
        }
    }
}

void DeviceModel::expandDeviceGroup(const QString &groupName, bool expanded)
{
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == groupName) {
            m_deviceGroups[i].isExpanded = expanded;
            break;
        }
    }
}

QString DeviceModel::getVisibleLightUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightUrl;
}

QString DeviceModel::getInfraredUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredUrl;
}



QString DeviceModel::getSelectedDeviceVisibleLightUrl()
{
    return getVisibleLightUrl(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredUrl()
{
    return getInfraredUrl(m_selectedDeviceId);
}



QString DeviceModel::getVisibleLightRecordUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightRecordUrl;
}

QString DeviceModel::getInfraredRecordUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredRecordUrl;
}

QString DeviceModel::getSelectedDeviceVisibleLightRecordUrl()
{
    return getVisibleLightRecordUrl(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredRecordUrl()
{
    return getInfraredRecordUrl(m_selectedDeviceId);
}

// IP地址管理方法
QString DeviceModel::getVisibleLightIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightIp;
}

QString DeviceModel::getInfraredIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredIp;
}

QString DeviceModel::getTdlasIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.tdlasIp;
}

QString DeviceModel::getSelectedDeviceVisibleLightIp()
{
    return getVisibleLightIp(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredIp()
{
    return getInfraredIp(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceTdlasIp()
{
    return getTdlasIp(m_selectedDeviceId);
}

// 用户名和密码管理方法
QString DeviceModel::getVisibleLightUsername(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightUsername;
}

QString DeviceModel::getVisibleLightPassword(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightPassword;
}

QString DeviceModel::getInfraredUsername(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredUsername;
}

QString DeviceModel::getInfraredPassword(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredPassword;
}



QString DeviceModel::getSelectedDeviceVisibleLightUsername()
{
    return getVisibleLightUsername(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceVisibleLightPassword()
{
    return getVisibleLightPassword(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredUsername()
{
    return getInfraredUsername(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredPassword()
{
    return getInfraredPassword(m_selectedDeviceId);
}



QString DeviceModel::getDeviceUrlByChannelIndex(int channelIndex, bool isVisibleLight)
{
    for (const auto &device : m_devices) {
        if (device.channelIndex == channelIndex) {
            return isVisibleLight ? device.visibleLightUrl : device.infraredUrl;
        }
    }
    return QString();
}

QString DeviceModel::getDeviceRecordUrlByChannelIndex(int channelIndex, bool isVisibleLight)
{
    for (const auto &device : m_devices) {
        if (device.channelIndex == channelIndex) {
            return isVisibleLight ? device.visibleLightRecordUrl : device.infraredRecordUrl;
        }
    }
    return QString();
}

QString DeviceModel::getDeviceIdByChannelIndex(int channelIndex)
{
    for (const auto &device : m_devices) {
        if (device.channelIndex == channelIndex) {
            return device.deviceId;
        }
    }
    return QString();
}

int DeviceModel::getChannelCount()
{
    return m_devices.size() > 9 ? 9 : m_devices.size();
}

void DeviceModel::saveDevicesToFile(const QString &filename)
{
    QJsonArray devicesArray;
    for (const auto &device : m_devices) {
        QJsonObject deviceObj;
        deviceObj["deviceId"] = device.deviceId;
        deviceObj["deviceName"] = device.deviceName;
        deviceObj["deviceType"] = device.deviceType;
        deviceObj["visibleLightIp"] = device.visibleLightIp;
        deviceObj["infraredIp"] = device.infraredIp;
        deviceObj["tdlasIp"] = device.tdlasIp;
        deviceObj["modbusIp"] = device.modbusIp;
        deviceObj["tofIp"] = device.tofIp;
        deviceObj["hikvisionIp"] = device.hikvisionIp;
        deviceObj["port"] = device.port;
        deviceObj["tdlasPort"] = device.tdlasPort;
        deviceObj["modbusPort"] = device.modbusPort;
        deviceObj["tofPort"] = device.tofPort;
        deviceObj["visibleLightUsername"] = device.visibleLightUsername;
        deviceObj["visibleLightPassword"] = device.visibleLightPassword;
        deviceObj["infraredUsername"] = device.infraredUsername;
        deviceObj["infraredPassword"] = device.infraredPassword;

        deviceObj["hikvisionUsername"] = device.hikvisionUsername;
        deviceObj["hikvisionPassword"] = device.hikvisionPassword;
        deviceObj["hikvisionPort"] = device.hikvisionPort;
        deviceObj["infraredDownloadChannel"] = device.infraredDownloadChannel;
        deviceObj["visibleLightDownloadChannel"] = device.visibleLightDownloadChannel;
        deviceObj["visibleLightUrl"] = device.visibleLightUrl;
        deviceObj["infraredUrl"] = device.infraredUrl;

        deviceObj["visibleLightRecordUrl"] = device.visibleLightRecordUrl;
        deviceObj["infraredRecordUrl"] = device.infraredRecordUrl;
        deviceObj["recordUrlbase"] = device.recordUrlbase;
        deviceObj["groupName"] = device.groupName;
        deviceObj["isOnline"] = device.isOnline;
        deviceObj["isSelected"] = device.isSelected;
        deviceObj["channelIndex"] = device.channelIndex;
        deviceObj["isInfraredSelected"] = device.isInfraredSelected;
        deviceObj["alarmConcentration"] = device.alarmConcentration;
        deviceObj["alarmRecordDuration"] = device.alarmRecordDuration;
        deviceObj["alarmOutputDuration"] = device.alarmOutputDuration;
        devicesArray.append(deviceObj);
    }
    
    QJsonObject rootObj;
    rootObj["devices"] = devicesArray;
    
    QJsonDocument doc(rootObj);
    QFile file(filename);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        qDebug() << "设备配置已保存到:" << filename;
    }
}

void DeviceModel::loadDevicesFromFile(const QString &filename)
{
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "无法打开设备配置文件:" << filename;
        return;
    }
    
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    QJsonObject rootObj = doc.object();
    QJsonArray devicesArray = rootObj["devices"].toArray();
    
    beginResetModel();
    m_devices.clear();
    
    for (const auto &deviceValue : devicesArray) {
        QJsonObject deviceObj = deviceValue.toObject();
        DeviceInfo device;
        device.deviceId = deviceObj["deviceId"].toString();
        device.deviceName = deviceObj["deviceName"].toString();
        device.deviceType = deviceObj["deviceType"].toString();
        device.visibleLightIp = deviceObj["visibleLightIp"].toString();
        device.infraredIp = deviceObj["infraredIp"].toString();
        device.tdlasIp = deviceObj["tdlasIp"].toString();
        device.modbusIp = deviceObj["modbusIp"].toString();
        device.tofIp = deviceObj["tofIp"].toString();
        device.hikvisionIp = deviceObj["hikvisionIp"].toString();
        device.port = deviceObj["port"].toInt();
        device.tdlasPort = deviceObj["tdlasPort"].toInt();
        device.modbusPort = deviceObj["modbusPort"].toInt();
        device.tofPort = deviceObj["tofPort"].toInt();
        device.visibleLightUsername = deviceObj["visibleLightUsername"].toString();
        device.visibleLightPassword = deviceObj["visibleLightPassword"].toString();
        device.infraredUsername = deviceObj["infraredUsername"].toString();
        device.infraredPassword = deviceObj["infraredPassword"].toString();

        device.hikvisionUsername = deviceObj["hikvisionUsername"].toString();
        device.hikvisionPassword = deviceObj["hikvisionPassword"].toString();
        device.hikvisionPort = deviceObj["hikvisionPort"].toInt();
        device.infraredDownloadChannel = deviceObj["infraredDownloadChannel"].toInt();
        device.visibleLightDownloadChannel = deviceObj["visibleLightDownloadChannel"].toInt();
        device.visibleLightUrl = deviceObj["visibleLightUrl"].toString();
        device.infraredUrl = deviceObj["infraredUrl"].toString();

        device.visibleLightRecordUrl = deviceObj["visibleLightRecordUrl"].toString();
        device.infraredRecordUrl = deviceObj["infraredRecordUrl"].toString();
        device.recordUrlbase = deviceObj["recordUrlbase"].toString();
        device.groupName = deviceObj["groupName"].toString();
        device.isOnline = deviceObj["isOnline"].toBool();
        device.isSelected = deviceObj["isSelected"].toBool();
        device.channelIndex = deviceObj["channelIndex"].toInt();
        device.isInfraredSelected = deviceObj["isInfraredSelected"].toBool();
        device.alarmConcentration = deviceObj["alarmConcentration"].toInt();
        device.alarmRecordDuration = deviceObj["alarmRecordDuration"].toInt();
        device.alarmOutputDuration = deviceObj["alarmOutputDuration"].toInt();
        m_devices.append(device);
    }
    
    endResetModel();
    updateDeviceGroups();
    qDebug() << "设备配置已从文件加载:" << filename;
}

void DeviceModel::loadDefaultDevices()
{

    
    DeviceInfo device1;
    device1.deviceId = "device_001";
    device1.deviceName = "监控点1";
    device1.deviceType = "PTZ";
    device1.visibleLightIp = "192.168.1.2";  // 可见光设备IP
    device1.infraredIp = "192.168.1.124";      // 红外设备IP
    device1.tdlasIp = "192.168.1.200";         // TDLAS设备IP
    device1.modbusIp = "192.168.1.201";        // Modbus设备IP
    device1.tofIp = "192.168.1.201";           // TOF设备IP (修改为不同的IP)
    device1.hikvisionIp = "192.168.1.102";    // 海康设备IP
    device1.port = 554;
    device1.tdlasPort = 2000;                  // TDLAS设备端口
    device1.modbusPort = 2000;                  
    device1.tofPort = 2000;                    
    device1.visibleLightUsername = "admin";
    device1.visibleLightPassword = "123456";
    device1.infraredUsername = "admin";
    device1.infraredPassword = "system123";
    device1.hikvisionUsername = "admin";
    device1.hikvisionPassword = "WANG234WH";
    device1.hikvisionPort = 8000;
    device1.infraredDownloadChannel = 33;  // 红外下载通道
    device1.visibleLightDownloadChannel = 34; // 可见光下载通道
    device1.visibleLightUrl = "rtsp://admin:123456@192.168.1.2/video2";
    device1.infraredUrl = "rtsp://admin:system123@192.168.1.124:554/live?channel=0&subtype=1";
    device1.recordUrlbase = "rtsp://admin:WANG234WH@192.168.1.102:554/Streaming/tracks";
    // 使用动态方法生成录像URL
    device1.visibleLightRecordUrl = generateRecordUrl(device1.recordUrlbase, device1.hikvisionIp, 
                                                     device1.hikvisionPort, device1.hikvisionUsername, 
                                                     device1.hikvisionPassword, device1.visibleLightIp);
    device1.infraredRecordUrl = generateRecordUrl(device1.recordUrlbase, device1.hikvisionIp, 
                                                 device1.hikvisionPort, device1.hikvisionUsername, 
                                                 device1.hikvisionPassword, device1.infraredIp);
    device1.groupName = "第一园区";
    device1.isOnline = true;
    device1.isSelected = false;
    device1.channelIndex = 0;
    device1.isInfraredSelected = false;  // 默认可见光被选中
    device1.alarmConcentration = 300;  // 默认报警浓度值300ppm
    device1.alarmRecordDuration = 30;  // 默认报警录制时长30秒
    device1.alarmOutputDuration = 10;  // 默认报警输出时长10秒
    addDevice(device1);  
    
    DeviceInfo device2;
    device2.deviceId = "device_002";
    device2.deviceName = "监控点2";
    device2.deviceType = "PTZ";
    device2.visibleLightIp = "192.168.1.105";  // 可见光设备IP
    device2.infraredIp = "192.168.1.123";      // 红外设备IP
    device2.tdlasIp = "192.168.1.204";         // TDLAS设备IP
    device2.modbusIp = "192.168.1.205";        // Modbus设备IP
    device2.tofIp = "192.168.1.205";           // TOF设备IP (修改为不同的IP)
    device2.hikvisionIp = "192.168.1.102";    // 海康设备IP
    device2.port = 554;
    device2.tdlasPort = 2000;                  // TDLAS设备端口
    device2.modbusPort = 2000;                  
    device2.tofPort = 2000;                    
    device2.visibleLightUsername = "admin";
    device2.visibleLightPassword = "123456";
    device2.infraredUsername = "admin";
    device2.infraredPassword = "system123";
    device2.hikvisionUsername = "admin";
    device2.hikvisionPassword = "WANG234WH";
    device2.hikvisionPort = 8000;
    device2.infraredDownloadChannel = 33;  // 红外下载通道
    device2.visibleLightDownloadChannel = 34; // 可见光下载通道
    device2.visibleLightUrl = "rtsp://admin:123456@192.168.1.105/video2";
    device2.infraredUrl = "rtsp://admin:system123@192.168.1.123:554/live?channel=0&subtype=1";
    device2.recordUrlbase = "rtsp://admin:WANG234WH@192.168.1.102:554/Streaming/tracks";
    // 使用动态方法生成录像URL
    device2.visibleLightRecordUrl = generateRecordUrl(device2.recordUrlbase, device2.hikvisionIp, 
                                                     device2.hikvisionPort, device2.hikvisionUsername, 
                                                     device2.hikvisionPassword, device2.visibleLightIp);
    device2.infraredRecordUrl = generateRecordUrl(device2.recordUrlbase, device2.hikvisionIp, 
                                                 device2.hikvisionPort, device2.hikvisionUsername, 
                                                 device2.hikvisionPassword, device2.infraredIp);
    device2.groupName = "第一园区";
    device2.isOnline = true;
    device2.isSelected = false;
    device2.channelIndex = 1;
    device2.isInfraredSelected = false;  // 默认可见光被选中
    device2.alarmConcentration = 300;  // 默认报警浓度值300ppm
    device2.alarmRecordDuration = 30;  // 默认报警录制时长30秒
    device2.alarmOutputDuration = 10;  // 默认报警输出时长10秒
    addDevice(device2);


//---------------------------------
    // DeviceInfo device2;
    // device2.deviceId = "device_002";
    // device2.deviceName = "监控点2";
    // device2.deviceType = "PTZ";
    // device2.visibleLightIp = "192.168.1.103";  // 可见光设备IP
    // device2.infraredIp = "192.168.1.125";      // 红外设备IP
    // device2.tdlasIp = "192.168.1.202";         // TDLAS设备IP
    // device2.modbusIp = "192.168.1.203";        // Modbus设备IP
    // device2.tofIp = "192.168.1.203";           // TOF设备IP (修改为不同的IP)
    // device2.hikvisionIp = "192.168.1.102";    // 海康设备IP
    // device2.port = 554;
    // device2.tdlasPort = 2000;                  // TDLAS设备端口
    // device2.modbusPort = 2000;                  
    // device2.tofPort = 2000;                    
    // device2.visibleLightUsername = "admin";
    // device2.visibleLightPassword = "123456";
    // device2.infraredUsername = "admin";
    // device2.infraredPassword = "system123";
    // device2.hikvisionUsername = "admin";
    // device2.hikvisionPassword = "WANG234WH";
    // device2.hikvisionPort = 8000;
    // device2.infraredDownloadChannel = 35;  // 红外下载通道
    // device2.visibleLightDownloadChannel = 36; // 可见光下载通道
    // device2.visibleLightUrl = "rtsp://admin:123456@192.168.1.103/video2";
    // device2.infraredUrl = "rtsp://admin:system123@192.168.1.125:554/live?channel=0&subtype=1";
    // device2.recordUrlbase = "rtsp://admin:WANG234WH@192.168.1.102:554/Streaming/tracks";
    // // 使用动态方法生成录像URL
    // //device2.visibleLightRecordUrl = generateRecordUrl(device2.recordUrlbase, device2.hikvisionIp, 
    // //                                                 device2.hikvisionPort, device2.hikvisionUsername, 
    // //                                                 device2.hikvisionPassword, device2.visibleLightIp);
    // //device2.infraredRecordUrl = generateRecordUrl(device2.recordUrlbase, device2.hikvisionIp, 
    // //                                             device2.hikvisionPort, device2.hikvisionUsername, 
    // //                                             device2.hikvisionPassword, device2.infraredIp);
    // device2.groupName = "第一园区";
    // device2.isOnline = true;
    // device2.isSelected = false;
    // device2.channelIndex = 0;
    // device2.isInfraredSelected = false;  // 默认可见光被选中
    // device2.alarmConcentration = 300;  // 默认报警浓度值300ppm
    // device2.alarmRecordDuration = 30;  // 默认报警录制时长30秒
    // device2.alarmOutputDuration = 10;  // 默认报警输出时长10秒
    // addDevice(device2);
//---------------------------------   
    qDebug() << "默认设备配置加载完成";

}

void DeviceModel::checkDeviceStatus()
{
    // 这里可以实现设备在线状态检查逻辑
    // 可以通过ping IP地址或尝试连接RTSP流来检查
    qDebug() << "检查设备在线状态...";
    
    // 示例：模拟状态检查
    for (int i = 0; i < m_devices.size(); ++i) {
        // 这里应该实现真正的设备状态检查
        // 暂时保持原有状态
        bool wasOnline = m_devices[i].isOnline;
        // m_devices[i].isOnline = checkDeviceConnectivity(m_devices[i].ipAddress);
        
        if (wasOnline != m_devices[i].isOnline) {
            QModelIndex index = this->index(i);
            emit dataChanged(index, index);
            emit deviceStatusChanged(m_devices[i].deviceId, m_devices[i].isOnline);
        }
    }
}

void DeviceModel::updateDeviceGroups()
{
    // 清空分组中的设备列表
    for (auto &group : m_deviceGroups) {
        group.devices.clear();
    }
    
    // 重新分配设备到分组
    for (const auto &device : m_devices) {
        int groupIndex = findGroupIndex(device.groupName);
        if (groupIndex >= 0) {
            m_deviceGroups[groupIndex].devices.append(device);
        } else {
            // 如果分组不存在，创建新分组
            addDeviceGroup(device.groupName);
            groupIndex = findGroupIndex(device.groupName);
            if (groupIndex >= 0) {
                m_deviceGroups[groupIndex].devices.append(device);
            }
        }
    }
}

int DeviceModel::findDeviceIndex(const QString &deviceId) const
{
    for (int i = 0; i < m_devices.size(); ++i) {
        if (m_devices[i].deviceId == deviceId) {
            return i;
        }
    }
    return -1;
}

int DeviceModel::findGroupIndex(const QString &groupName) const
{
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == groupName) {
            return i;
        }
    }
    return -1;
}

// 报警配置管理方法实现
int DeviceModel::getAlarmConcentration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmConcentration;
}

int DeviceModel::getAlarmRecordDuration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmRecordDuration;
}

int DeviceModel::getAlarmOutputDuration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmOutputDuration;
}

int DeviceModel::getSelectedDeviceAlarmConcentration()
{
    return getAlarmConcentration(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceAlarmRecordDuration()
{
    return getAlarmRecordDuration(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceAlarmOutputDuration()
{
    return getAlarmOutputDuration(m_selectedDeviceId);
}

// Modbus相关方法实现
QString DeviceModel::getModbusIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.modbusIp;
}

QString DeviceModel::getSelectedDeviceModbusIp()
{
    return getModbusIp(m_selectedDeviceId);
}

 

QString DeviceModel::getTofIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.tofIp;
}

QString DeviceModel::getSelectedDeviceTofIp()
{
    return getTofIp(m_selectedDeviceId);
}





// 海康相关方法实现
QString DeviceModel::getHikvisionUsername(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionUsername;
}

QString DeviceModel::getHikvisionPassword(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionPassword;
}

int DeviceModel::getHikvisionPort(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionPort;
}

QString DeviceModel::getSelectedDeviceHikvisionUsername()
{
    return getHikvisionUsername(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceHikvisionPassword()
{
    return getHikvisionPassword(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceHikvisionPort()
{
    return getHikvisionPort(m_selectedDeviceId);
}

int DeviceModel::getInfraredDownloadChannel(const QString &deviceId)
{
    qDebug() << "getInfraredDownloadChannel: deviceId =" << deviceId;
    DeviceInfo device = getDevice(deviceId);
    qDebug() << "getInfraredDownloadChannel: device.infraredDownloadChannel =" << device.infraredDownloadChannel;
    return device.infraredDownloadChannel;
}

int DeviceModel::getVisibleLightDownloadChannel(const QString &deviceId)
{
    qDebug() << "getVisibleLightDownloadChannel: deviceId =" << deviceId;
    DeviceInfo device = getDevice(deviceId);
    qDebug() << "getVisibleLightDownloadChannel: device.visibleLightDownloadChannel =" << device.visibleLightDownloadChannel;
    return device.visibleLightDownloadChannel;
}

int DeviceModel::getSelectedDeviceInfraredDownloadChannel()
{
    qDebug() << "getSelectedDeviceInfraredDownloadChannel: m_selectedDeviceId =" << m_selectedDeviceId;
    int channel = getInfraredDownloadChannel(m_selectedDeviceId);
    qDebug() << "getSelectedDeviceInfraredDownloadChannel: returned channel =" << channel;
    return channel;
}

int DeviceModel::getSelectedDeviceVisibleLightDownloadChannel()
{
    qDebug() << "getSelectedDeviceVisibleLightDownloadChannel: m_selectedDeviceId =" << m_selectedDeviceId;
    int channel = getVisibleLightDownloadChannel(m_selectedDeviceId);
    qDebug() << "getSelectedDeviceVisibleLightDownloadChannel: returned channel =" << channel;
    return channel;
}

int DeviceModel::getSelectedDeviceChannelIndex()
{
    return getDeviceChannelIndex(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceId()
{
    return m_selectedDeviceId;
}

QString DeviceModel::getHikvisionIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionIp;
}

QString DeviceModel::getSelectedDeviceHikvisionIp()
{
    return getHikvisionIp(m_selectedDeviceId);
}

// 树形模型管理方法
DeviceTreeModel* DeviceModel::getTreeModel() const
{
    return m_treeModel;
}

void DeviceModel::setTreeModel(DeviceTreeModel* treeModel)
{
    if (m_treeModel != treeModel) {
        m_treeModel = treeModel;
        
        // 如果设置了新的树形模型，将现有设备添加到树形模型中
        if (m_treeModel) {
            qDebug() << "Setting tree model, adding" << m_devices.size() << "existing devices";
            for (const DeviceInfo& device : m_devices) {
                qDebug() << "Adding existing device:" << device.deviceName << "in group:" << device.groupName;
                m_treeModel->addDevice(device);
            }
        }
    }
}

// 红外选中状态管理方法实现
void DeviceModel::setDeviceInfraredSelected(const QString &deviceId, bool isInfraredSelected)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].isInfraredSelected != isInfraredSelected) {
        m_devices[index].isInfraredSelected = isInfraredSelected;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        qDebug() << "Device" << deviceId << "infrared selected status changed to:" << isInfraredSelected;
    }
}

bool DeviceModel::getDeviceInfraredSelected(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].isInfraredSelected;
    }
    return false; // 默认返回false（可见光）
}

bool DeviceModel::getSelectedDeviceInfraredSelected()
{
    return getDeviceInfraredSelected(m_selectedDeviceId);
}

// recordUrlbase相关方法实现
QString DeviceModel::getRecordUrlbase(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.recordUrlbase;
}

QString DeviceModel::getSelectedDeviceRecordUrlbase()
{
    return getRecordUrlbase(m_selectedDeviceId);
}

// HikvisionCtrl 设置方法实现
void DeviceModel::setHikvisionCtrl(HikvisionCtrl* hikvisionCtrl)
{
    m_hikvisionCtrl = hikvisionCtrl;
    qDebug() << "HikvisionCtrl set for DeviceModel";
    
    // 连接HikvisionCtrl的信号，监听通道查找完成事件
    if (m_hikvisionCtrl) {
        connect(m_hikvisionCtrl, &HikvisionCtrl::channelLookupCompleted,
                this, &DeviceModel::onChannelLookupCompleted);
        connect(m_hikvisionCtrl, &HikvisionCtrl::channelLookupFailed,
                this, &DeviceModel::onChannelLookupFailed);
        connect(m_hikvisionCtrl, &HikvisionCtrl::channelInitializationCompleted,
                this, &DeviceModel::onChannelInitializationCompleted);
    }
}

// 通道信息管理方法实现
void DeviceModel::forceUpdateDeviceChannelInfo(const QString &deviceId)
{
    qDebug() << "强制更新设备通道信息:" << deviceId;
    
    if (!m_hikvisionCtrl) {
        qWarning() << "HikvisionCtrl未设置，无法更新通道信息";
        return;
    }
    
    DeviceInfo device = getDevice(deviceId);
    if (device.deviceId.isEmpty()) {
        qWarning() << "设备不存在:" << deviceId;
        return;
    }
    
    // 强制更新可见光设备通道
    if (!device.visibleLightIp.isEmpty() && !device.hikvisionIp.isEmpty()) {
        qDebug() << "强制更新可见光设备通道:" << device.visibleLightIp;
        m_hikvisionCtrl->forceUpdateChannelInfo(
            device.hikvisionIp, 
            device.hikvisionPort, 
            device.hikvisionUsername, 
            device.hikvisionPassword, 
            device.visibleLightIp
        );
    }
    
    // 强制更新红外设备通道
    if (!device.infraredIp.isEmpty() && !device.hikvisionIp.isEmpty()) {
        qDebug() << "强制更新红外设备通道:" << device.infraredIp;
        m_hikvisionCtrl->forceUpdateChannelInfo(
            device.hikvisionIp, 
            device.hikvisionPort, 
            device.hikvisionUsername, 
            device.hikvisionPassword, 
            device.infraredIp
        );
    }
}

void DeviceModel::initializeAllChannelInfo()
{
    qDebug() << "初始化所有设备的通道信息";
    
    if (!m_hikvisionCtrl) {
        qWarning() << "HikvisionCtrl未设置，无法初始化通道信息";
        return;
    }
    
    // 准备批量初始化数据
    QStringList hikvisionIps;
    QStringList hikvisionUsernames; 
    QStringList hikvisionPasswords;
    QStringList visibleLightIps;
    QStringList infraredIps;
    
    for (const auto& device : m_devices) {
        if (!device.hikvisionIp.isEmpty()) {
            // 收集可见光设备信息
            if (!device.visibleLightIp.isEmpty()) {
                hikvisionIps.append(device.hikvisionIp);
                hikvisionUsernames.append(device.hikvisionUsername);
                hikvisionPasswords.append(device.hikvisionPassword);
                visibleLightIps.append(device.visibleLightIp);
            }
            
            // 收集红外设备信息
            if (!device.infraredIp.isEmpty()) {
                hikvisionIps.append(device.hikvisionIp);
                hikvisionUsernames.append(device.hikvisionUsername);
                hikvisionPasswords.append(device.hikvisionPassword);
                infraredIps.append(device.infraredIp);
            }
        }
    }
    
    // 批量初始化
    if (!hikvisionIps.isEmpty()) {
        if (!visibleLightIps.isEmpty()) {
            qDebug() << "批量初始化可见光设备通道，数量:" << visibleLightIps.size();
            m_hikvisionCtrl->initializeChannelInfo(hikvisionIps, hikvisionUsernames, hikvisionPasswords, visibleLightIps);
        }
        
        if (!infraredIps.isEmpty()) {
            qDebug() << "批量初始化红外设备通道，数量:" << infraredIps.size();
            m_hikvisionCtrl->initializeChannelInfo(hikvisionIps, hikvisionUsernames, hikvisionPasswords, infraredIps);
        }
    }
}

bool DeviceModel::isDeviceChannelCacheValid(const QString &deviceId)
{
    if (!m_hikvisionCtrl) {
        return false;
    }
    
    DeviceInfo device = getDevice(deviceId);
    if (device.deviceId.isEmpty()) {
        return false;
    }
    
    bool visibleLightValid = true;
    bool infraredValid = true;
    
    // 检查可见光设备通道缓存
    if (!device.visibleLightIp.isEmpty() && !device.hikvisionIp.isEmpty()) {
        visibleLightValid = m_hikvisionCtrl->isChannelCacheValid(device.hikvisionIp, device.visibleLightIp);
    }
    
    // 检查红外设备通道缓存
    if (!device.infraredIp.isEmpty() && !device.hikvisionIp.isEmpty()) {
        infraredValid = m_hikvisionCtrl->isChannelCacheValid(device.hikvisionIp, device.infraredIp);
    }
    
    return visibleLightValid && infraredValid;
}

// 新增：通道查找完成的槽函数
void DeviceModel::onChannelLookupCompleted(const QString& nvrIp, const QString& ipcIp, int channelNumber)
{
    qDebug() << "通道查找完成 - NVR:" << nvrIp << "IPC:" << ipcIp << "通道:" << channelNumber;
    // 这里可以进一步处理，比如更新UI或日志
}

void DeviceModel::onChannelLookupFailed(const QString& nvrIp, const QString& ipcIp, const QString& errorMessage)
{
    qWarning() << "通道查找失败 - NVR:" << nvrIp << "IPC:" << ipcIp << "错误:" << errorMessage;
    // 这里可以进一步处理，比如显示错误消息
}

void DeviceModel::onChannelInitializationCompleted()
{
    qDebug() << "所有通道信息初始化完成";
    // 这里可以进一步处理，比如通知UI更新
}

// 生成录像URL的辅助方法
QString DeviceModel::generateRecordUrl(const QString& recordUrlBase, const QString& hikvisionIp, 
                                      int hikvisionPort, const QString& hikvisionUsername, 
                                      const QString& hikvisionPassword, const QString& ipcIp)
{
    QString result = recordUrlBase;
    
    // 获取通道号
    int channelNumber = -1;
    if (m_hikvisionCtrl) {
        qDebug() << "Using HikvisionCtrl to find channel for IPC:" << ipcIp;
        channelNumber = m_hikvisionCtrl->findChannelByIP(hikvisionIp, hikvisionPort, 
                                                        hikvisionUsername, hikvisionPassword, ipcIp);
        
        if (channelNumber > 0) {
            // findChannelByIP返回的值已经加了32，需要减去32得到实际通道号
            channelNumber = channelNumber - 32;
            qDebug() << "Found channel via HikvisionCtrl, adjusted channel number:" << channelNumber;
        } else {
            qWarning() << "Failed to find channel via HikvisionCtrl for IPC:" << ipcIp;
            channelNumber = 1; // 默认通道1
        }
    } else {
        qWarning() << "HikvisionCtrl not available, using default channel 1";
        channelNumber = 1; // 默认通道1
    }
    
    // 构建通道编号（通道号 + 01，表示主码流）
    QString channelCode = QString("%1%2").arg(channelNumber).arg("01");
    
    // 获取当前时间减1小时作为开始时间
    QDateTime currentTime = QDateTime::currentDateTime();
    QDateTime startTime = currentTime.addSecs(-28800); // 减去8小时（28800秒）
    QString formattedStartTime = startTime.toString("yyyyMMddThhmmssZ");
    
    // 构建完整URL
    result += QString("/%1/?starttime=%2").arg(channelCode).arg(formattedStartTime);
    
    qDebug() << "Generated record URL:" << result;
    return result;
}

// 生成带时间参数的录像URL方法
QString DeviceModel::generateTimedRecordUrl(const QString &deviceId, bool isVisibleLight, const QString &timeStr)
{
    DeviceInfo device = getDevice(deviceId);
    if (device.deviceId.isEmpty()) {
        qWarning() << "Device not found:" << deviceId;
        return QString();
    }
    
    if (device.recordUrlbase.isEmpty()) {
        qWarning() << "No record URL base for device:" << deviceId;
        return QString();
    }
    
    // 选择对应的IPC IP地址
    QString ipcIp = isVisibleLight ? device.visibleLightIp : device.infraredIp;
    if (ipcIp.isEmpty()) {
        qWarning() << "No IPC IP for device:" << deviceId << "isVisibleLight:" << isVisibleLight;
        return QString();
    }
    
    QString result = device.recordUrlbase;
    
    // 获取通道号
    int channelNumber = -1;
    if (m_hikvisionCtrl) {
        qDebug() << "Using HikvisionCtrl to find channel for IPC:" << ipcIp;
        channelNumber = m_hikvisionCtrl->findChannelByIP(device.hikvisionIp, device.hikvisionPort, 
                                                        device.hikvisionUsername, device.hikvisionPassword, ipcIp);
        
        if (channelNumber > 0) {
            // findChannelByIP返回的值已经加了32，需要减去32得到实际通道号
            channelNumber = channelNumber - 32;
            qDebug() << "Found channel via HikvisionCtrl, adjusted channel number:" << channelNumber;
        } else {
            qWarning() << "Failed to find channel via HikvisionCtrl for IPC:" << ipcIp;
            channelNumber = 1; // 默认通道1
        }
    } else {
        qWarning() << "HikvisionCtrl not available, using default channel 1";
        channelNumber = 1; // 默认通道1
    }
    
    // 构建通道编号（通道号 + 01，表示主码流）
    QString channelCode = QString("%1%2").arg(channelNumber).arg("01");
    
    // 构建完整URL，使用传入的时间参数
    result += QString("/%1/?starttime=%2").arg(channelCode).arg(timeStr);
    
    qDebug() << "Generated timed record URL:" << result << "for device:" << deviceId << "isVisibleLight:" << isVisibleLight;
    return result;
}

// 便捷方法：获取选中设备的带时间参数的可见光录像URL
QString DeviceModel::getSelectedDeviceTimedVisibleLightRecordUrl(const QString &timeStr)
{
    return generateTimedRecordUrl(m_selectedDeviceId, true, timeStr);
}

// 便捷方法：获取选中设备的带时间参数的红外录像URL
QString DeviceModel::getSelectedDeviceTimedInfraredRecordUrl(const QString &timeStr)
{
    return generateTimedRecordUrl(m_selectedDeviceId, false, timeStr);
}