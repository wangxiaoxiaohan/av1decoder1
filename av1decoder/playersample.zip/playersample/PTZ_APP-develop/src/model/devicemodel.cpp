#include "devicemodel.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QDebug>
#include <QTimer>
#include <QDateTime>
#include <QCoreApplication>
#include <QDir>
#include "hikvision_ctrl.h"
#include "../playermanager.h"
#include "../systemlog.h"

DeviceModel* DeviceModel::m_instance = nullptr;

DeviceModel::DeviceModel(QObject *parent)
    : QAbstractListModel(parent)
    , m_treeModel(nullptr)
    , m_hikvisionCtrl(nullptr)
{
    // 初始化默认设备分组
    
    // 启动设备状态检查定时器
    QTimer *statusTimer = new QTimer(this);
    connect(statusTimer, &QTimer::timeout, this, &DeviceModel::checkDeviceStatus);
    statusTimer->start(30000); // 每30秒检查一次设备状态
}

DeviceModel* DeviceModel::instance()
{
    if (!m_instance) {
        m_instance = new DeviceModel();
    }
    return m_instance;
}

int DeviceModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    return m_devices.size();
}

QVariant DeviceModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_devices.size())
        return QVariant();

    const DeviceInfo &device = m_devices[index.row()];

    switch (role) {
    case DeviceIdRole:
        return device.deviceId;
    case DeviceNameRole:
        return device.deviceName;
    case DeviceTypeRole:
        return device.deviceType;
    case VisibleLightIpRole:
        return device.visibleLightIp;
    case InfraredIpRole:
        return device.infraredIp;
    case HikvisionIpRole:
        return device.hikvisionIp;
    case PortRole:
        return device.port;
    case VisibleLightUsernameRole:
        return device.visibleLightUsername;
    case VisibleLightPasswordRole:
        return device.visibleLightPassword;
    case InfraredUsernameRole:
        return device.infraredUsername;
    case InfraredPasswordRole:
        return device.infraredPassword;
    case HikvisionUsernameRole:
        return device.hikvisionUsername;
    case HikvisionPasswordRole:
        return device.hikvisionPassword;
    case HikvisionPortRole:
        return device.hikvisionPort;
    case InfraredDownloadChannelRole:
        return device.infraredDownloadChannel;
    case VisibleLightDownloadChannelRole:
        return device.visibleLightDownloadChannel;
    case AlarmConcentrationRole:
        return device.alarmConcentration;
    case AlarmRecordDurationRole:
        return device.alarmRecordDuration;
    case AlarmOutputDurationRole:
        return device.alarmOutputDuration;
    case VisibleLightUrlRole:
        return device.visibleLightUrl;
    case InfraredUrlRole:
        return device.infraredUrl;
    case VisibleLightRecordUrlRole:
        return device.visibleLightRecordUrl;
    case InfraredRecordUrlRole:
        return device.infraredRecordUrl;
    case RecordUrlbaseRole:
        return device.recordUrlbase;
    case GroupNameRole:
        return device.groupName;
    case IsOnlineRole:
        return device.isOnline;
    case IsSelectedRole:
        return device.isSelected;
    case ChannelIndexRole:
        return device.channelIndex;
    case IsInfraredSelectedRole:
        return device.isInfraredSelected;
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> DeviceModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[DeviceIdRole] = "deviceId";
    roles[DeviceNameRole] = "deviceName";
    roles[DeviceTypeRole] = "deviceType";
    roles[VisibleLightIpRole] = "visibleLightIp";
    roles[InfraredIpRole] = "infraredIp";
    roles[HikvisionIpRole] = "hikvisionIp";
    roles[PortRole] = "port";
    roles[VisibleLightUsernameRole] = "visibleLightUsername";
    roles[VisibleLightPasswordRole] = "visibleLightPassword";
    roles[InfraredUsernameRole] = "infraredUsername";
    roles[InfraredPasswordRole] = "infraredPassword";
    roles[HikvisionUsernameRole] = "hikvisionUsername";
    roles[HikvisionPasswordRole] = "hikvisionPassword";
    roles[HikvisionPortRole] = "hikvisionPort";
    roles[InfraredDownloadChannelRole] = "infraredDownloadChannel";
    roles[VisibleLightDownloadChannelRole] = "visibleLightDownloadChannel";
    roles[AlarmConcentrationRole] = "alarmConcentration";
    roles[AlarmRecordDurationRole] = "alarmRecordDuration";
    roles[AlarmOutputDurationRole] = "alarmOutputDuration";
    roles[VisibleLightUrlRole] = "visibleLightUrl";
    roles[InfraredUrlRole] = "infraredUrl";
    roles[VisibleLightRecordUrlRole] = "visibleLightRecordUrl";
    roles[InfraredRecordUrlRole] = "infraredRecordUrl";
    roles[RecordUrlbaseRole] = "recordUrlbase";
    roles[GroupNameRole] = "groupName";
    roles[IsOnlineRole] = "isOnline";
    roles[IsSelectedRole] = "isSelected";
    roles[ChannelIndexRole] = "channelIndex";
    roles[IsInfraredSelectedRole] = "isInfraredSelected";
    return roles;
}

void DeviceModel::addDevice(const DeviceInfo &device, bool saveToFile)
{
    // 如果channelIndex有效，自动分配播放器
    if (device.channelIndex >= 0) {
        PlayerManager* playerManager = PlayerManager::instance();
        if (playerManager) {
            qDebug() << "为设备" << device.deviceId << "分配播放器到通道" << device.channelIndex;
            
            // 分配播放器给channel
            int playerIndex = playerManager->allocatePlayerForChannel(device.channelIndex);
            qDebug() << "分配的播放器索引: " << playerIndex;
            
            // 设置播放器URL（如果有的话）
            if (!device.visibleLightUrl.isEmpty()) {
                playerManager->setPlayerUrl(device.channelIndex, PlayerManager::VisibleLightLive, device.visibleLightUrl);
                qDebug() << "设置可见光URL: " << device.visibleLightUrl;
            }
            if (!device.infraredUrl.isEmpty()) {
                playerManager->setPlayerUrl(device.channelIndex, PlayerManager::InfraredLive, device.infraredUrl);
                qDebug() << "设置红外URL: " << device.infraredUrl;
            }
            if (!device.visibleLightRecordUrl.isEmpty()) {
                playerManager->setPlayerUrl(device.channelIndex, PlayerManager::VisibleLightRecord, device.visibleLightRecordUrl);
                qDebug() << "设置可见光录像URL: " << device.visibleLightRecordUrl;
            }
            if (!device.infraredRecordUrl.isEmpty()) {
                playerManager->setPlayerUrl(device.channelIndex, PlayerManager::InfraredRecord, device.infraredRecordUrl);
                qDebug() << "设置红外录像URL: " << device.infraredRecordUrl;
            }
        } else {
            qWarning() << "PlayerManager实例未找到，无法分配播放器";
        }
    }
    
    beginInsertRows(QModelIndex(), m_devices.size(), m_devices.size());
    m_devices.append(device);
    endInsertRows();
    
    // 同时更新树形模型
    if (m_treeModel) {
        qDebug() << "Adding device to tree model:" << device.deviceName << "in group:" << device.groupName;
        m_treeModel->addDevice(device);
    } else {
        qDebug() << "Tree model is null!";
    }
    
    // 只有在需要保存到文件时才执行保存操作
    if (saveToFile) {
        
        // 保存设备信息到文件
        QString appDir = QCoreApplication::applicationDirPath();
        QString deviceInfoDir = appDir + "/config/deviceinfo";
        QDir dir(deviceInfoDir);
        if (!dir.exists()) {
            dir.mkpath(".");
        }        
        QString deviceFilePath = deviceInfoDir + "/" + device.deviceId + ".json";
        saveDevicesToFile(deviceFilePath, device);

    }
    
    updateDeviceGroups();
    emit deviceAdded(device.deviceId);
    
    // 记录系统日志
    QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    SystemLog::instance()->addLog(
        "admin", // 操作账户
        LOG_TYPE_OPERATION, // 日志类型：操作日志
        ACTION_TYPE_ADD_DEVICE, // 操作类型：添加设备
        currentTime, // 操作时间
        device.visibleLightIp, // 操作IP
        RESULT_SUCCESS, // 操作结果：成功
        QString("添加设备：%1 (IP: %2, 通道: %3, 分组: %4)")
            .arg(device.deviceName)
            .arg(device.visibleLightIp)
            .arg(device.channelIndex)
            .arg(device.groupName) // 操作描述
    );
}

void DeviceModel::addDevice(const QVariantMap &deviceData)
{
    qDebug() << "Adding device:" << deviceData;
    DeviceInfo device;
    
    // 从QVariantMap中提取设备信息
    device.deviceId = deviceData.value("deviceId").toString();
    device.deviceName = deviceData.value("deviceName").toString();
    device.deviceType = deviceData.value("deviceType", "PTZ").toString();
    device.visibleLightIp = deviceData.value("visibleLightIp").toString();
    device.infraredIp = deviceData.value("infraredIp").toString();
    device.tdlasIp = deviceData.value("tdlasIp").toString();
    device.modbusIp = deviceData.value("modbusIp").toString();
    device.tofIp = deviceData.value("tofIp").toString();
    device.hikvisionIp = deviceData.value("hikvisionIp").toString();
    device.port = deviceData.value("port", 80).toInt();
    device.tdlasPort = deviceData.value("tdlasPort", 502).toInt();
    device.modbusPort = deviceData.value("modbusPort", 502).toInt();
    device.tofPort = deviceData.value("tofPort", 80).toInt();
    device.visibleLightUsername = deviceData.value("visibleLightUsername").toString();
    device.visibleLightPassword = deviceData.value("visibleLightPassword").toString();
    device.infraredUsername = deviceData.value("infraredUsername").toString();
    device.infraredPassword = deviceData.value("infraredPassword").toString();
    device.hikvisionUsername = deviceData.value("hikvisionUsername").toString();
    device.hikvisionPassword = deviceData.value("hikvisionPassword").toString();
    device.hikvisionPort = deviceData.value("hikvisionPort", 8000).toInt();
    device.infraredDownloadChannel = deviceData.value("infraredDownloadChannel", 1).toInt();
    device.visibleLightDownloadChannel = deviceData.value("visibleLightDownloadChannel", 1).toInt();
    device.alarmConcentration = deviceData.value("alarmConcentration", 1000).toInt();
    device.alarmRecordDuration = deviceData.value("alarmRecordDuration", 30).toInt();
    device.alarmOutputDuration = deviceData.value("alarmOutputDuration", 10).toInt();
    device.groupName = deviceData.value("groupName").toString();
    device.channelIndex = deviceData.value("channelIndex", -1).toInt();
    device.isOnline = deviceData.value("isOnline", false).toBool();
    device.isSelected = deviceData.value("isSelected", false).toBool();
    device.isInfraredSelected = deviceData.value("isInfraredSelected", false).toBool();
    
    qDebug() << "Adding device: device.tdlasPort" << device.tdlasPort;

    // 如果QVariantMap中没有提供URL，则根据规则生成
    if (deviceData.contains("visibleLightUrl")) {
        device.visibleLightUrl = deviceData["visibleLightUrl"].toString();
    } else {
        device.visibleLightUrl = QString("rtsp://%1:%2@%3/video2")
            .arg(device.visibleLightUsername)
            .arg(device.visibleLightPassword)
            .arg(device.visibleLightIp);
    }
    
    if (deviceData.contains("infraredUrl")) {
        device.infraredUrl = deviceData["infraredUrl"].toString();
    } else {
        device.infraredUrl = QString("rtsp://%1:%2@%3:554/live?channel=0&subtype=1")
            .arg(device.infraredUsername)
            .arg(device.infraredPassword)
            .arg(device.infraredIp);
    }
    
    if (deviceData.contains("recordUrlbase")) {
        device.recordUrlbase = deviceData["recordUrlbase"].toString();
    } else {
        device.recordUrlbase = QString("rtsp://%1:%2@%3:554/Streaming/tracks")
            .arg(device.hikvisionUsername)
            .arg(device.hikvisionPassword)
            .arg(device.hikvisionIp);
    }
    
    // 调用原始的addDevice方法
    addDevice(device, true);
}

void DeviceModel::removeDevice(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    qDebug() << "removeDevice: deviceId =" << deviceId << "index =" << index;
    
    // 获取设备信息用于日志记录
    DeviceInfo deviceToRemove;
    if (index >= 0) {
        deviceToRemove = m_devices[index];
    }
    
    if (index >= 0) {
        // 在移除设备前，先清理相关的播放器和FrameProvider连接
        PlayerManager* playerManager = PlayerManager::instance();
        if (playerManager) {
            playerManager->cleanupDeviceChannels(deviceId);
        }
        
        // 删除设备配置文件
        QString configPath = QCoreApplication::applicationDirPath() + "/config/deviceinfo/" + deviceId + ".json";
        qDebug() << "removeDevice: 删除设备配置文件:" << configPath;
        QFile configFile(configPath);
        if (configFile.exists()) {
            if (configFile.remove()) {
                qDebug() << "设备配置文件已删除:" << configPath;
            } else {
                qWarning() << "删除设备配置文件失败:" << configPath;
            }
        }
        
        beginRemoveRows(QModelIndex(), index, index);
        m_devices.removeAt(index);
        endRemoveRows();
        
        // 同时从树形模型中移除
        if (m_treeModel) {
            m_treeModel->removeDevice(deviceId);
        }
        
        updateDeviceGroups();
        emit deviceRemoved(deviceId);
        
        // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        SystemLog::instance()->addLog(
            "admin", // 操作账户
            LOG_TYPE_OPERATION, // 日志类型：操作日志
            ACTION_TYPE_DELETE_DEVICE, // 操作类型：删除设备
            currentTime, // 操作时间
            deviceToRemove.visibleLightIp, // 操作IP
            RESULT_SUCCESS, // 操作结果：成功
            QString("删除设备：%1 (IP: %2, 通道: %3, 分组: %4)")
                .arg(deviceToRemove.deviceName)
                .arg(deviceToRemove.visibleLightIp)
                .arg(deviceToRemove.channelIndex)
                .arg(deviceToRemove.groupName) // 操作描述
        );
    }
    qDebug() << "removeDevice: returning" << m_devices.size() << "devices";
}

void DeviceModel::modifyDevice(const QString &deviceId, const QVariantMap &deviceData)
{
    qDebug() << "modifyDevice: deviceId =" << deviceId;
    
    // 获取修改前的设备信息用于日志记录
    DeviceInfo oldDevice;
    int oldIndex = findDeviceIndex(deviceId);
    if (oldIndex >= 0) {
        oldDevice = m_devices[oldIndex];
    }
    
    // 先删除原设备配置文件
    QString configPath = QCoreApplication::applicationDirPath() + "/config/deviceinfo/" + deviceId + ".json";
    QFile configFile(configPath);
    if (configFile.exists()) {
        if (configFile.remove()) {
            qDebug() << "原设备配置文件已删除:" << configPath;
        } else {
            qWarning() << "删除原设备配置文件失败:" << configPath;
        }
    }
    
    // 如果设备ID发生变化，需要先从内存中移除旧设备
    QString newDeviceId = deviceData["deviceId"].toString();
    if (newDeviceId != deviceId) {
        int index = findDeviceIndex(deviceId);
        if (index >= 0) {
            beginRemoveRows(QModelIndex(), index, index);
            m_devices.removeAt(index);
            endRemoveRows();
            
            // 同时从树形模型中移除
            if (m_treeModel) {
                m_treeModel->removeDevice(deviceId);
            }
        }
    }
    
    // 调用addDevice方法添加修改后的设备，并保存到文件
    addDevice(deviceData);
    
    // 记录系统日志
    QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    QString logDescription;
    
    if (newDeviceId != deviceId) {
        logDescription = QString("修改设备：%1 -> %2 (IP: %3, 通道: %4, 分组: %5)")
            .arg(oldDevice.deviceName)
            .arg(deviceData["deviceName"].toString())
            .arg(deviceData["visibleLightIp"].toString())
            .arg(deviceData["channelIndex"].toInt())
            .arg(deviceData["groupName"].toString());
    } else {
        logDescription = QString("修改设备：%1 (IP: %2, 通道: %3, 分组: %4)")
            .arg(deviceData["deviceName"].toString())
            .arg(deviceData["visibleLightIp"].toString())
            .arg(deviceData["channelIndex"].toInt())
            .arg(deviceData["groupName"].toString());
    }
    
    SystemLog::instance()->addLog(
        "admin", // 操作账户
        LOG_TYPE_OPERATION, // 日志类型：操作日志
        ACTION_TYPE_MODIFY_DEVICE, // 操作类型：修改设备
        currentTime, // 操作时间
        deviceData["visibleLightIp"].toString(), // 操作IP
        RESULT_SUCCESS, // 操作结果：成功
        logDescription // 操作描述
    );
    
    qDebug() << "modifyDevice: 设备修改完成";
}

void DeviceModel::updateDevice(const DeviceInfo &device)
{
    int index = findDeviceIndex(device.deviceId);
    if (index >= 0) {
        m_devices[index] = device;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        
        // 同时更新树形模型
        if (m_treeModel) {
            m_treeModel->updateDevice(device);
        }
        
        updateDeviceGroups();
        emit deviceUpdated(device.deviceId);
    }
}

DeviceInfo DeviceModel::getDevice(const QString &deviceId)
{
    //qDebug() << "getDevice: deviceId =" << deviceId;
    int index = findDeviceIndex(deviceId);
    //qDebug() << "getDevice: found index =" << index;
    if (index >= 0) {
        //qDebug() << "getDevice: returning device with infraredDownloadChannel =" << m_devices[index].infraredDownloadChannel;
        //qDebug() << "getDevice: returning device with visibleLightDownloadChannel =" << m_devices[index].visibleLightDownloadChannel;
        return m_devices[index];
    }
    //qDebug() << "getDevice: device not found, returning empty DeviceInfo";
    return DeviceInfo{};
}

QVariantMap DeviceModel::getDeviceAsVariant(const QString &deviceId) const
{
    QVariantMap deviceMap;
    int index = findDeviceIndex(deviceId);
    
    if (index >= 0) {
        const DeviceInfo &device = m_devices[index];
        deviceMap["deviceId"] = device.deviceId;
        deviceMap["deviceName"] = device.deviceName;
        deviceMap["deviceType"] = device.deviceType;
        deviceMap["visibleLightIp"] = device.visibleLightIp;
        deviceMap["infraredIp"] = device.infraredIp;
        deviceMap["tdlasIp"] = device.tdlasIp;
        deviceMap["modbusIp"] = device.modbusIp;
        deviceMap["tofIp"] = device.tofIp;
        deviceMap["hikvisionIp"] = device.hikvisionIp;
        deviceMap["port"] = device.port;
        deviceMap["tdlasPort"] = device.tdlasPort;
        deviceMap["modbusPort"] = device.modbusPort;
        deviceMap["tofPort"] = device.tofPort;
        deviceMap["visibleLightUsername"] = device.visibleLightUsername;
        deviceMap["visibleLightPassword"] = device.visibleLightPassword;
        deviceMap["infraredUsername"] = device.infraredUsername;
        deviceMap["infraredPassword"] = device.infraredPassword;
        deviceMap["hikvisionUsername"] = device.hikvisionUsername;
        deviceMap["hikvisionPassword"] = device.hikvisionPassword;
        deviceMap["hikvisionPort"] = device.hikvisionPort;
        deviceMap["infraredDownloadChannel"] = device.infraredDownloadChannel;
        deviceMap["visibleLightDownloadChannel"] = device.visibleLightDownloadChannel;
        deviceMap["alarmConcentration"] = device.alarmConcentration;
        deviceMap["alarmRecordDuration"] = device.alarmRecordDuration;
        deviceMap["alarmOutputDuration"] = device.alarmOutputDuration;
        deviceMap["visibleLightUrl"] = device.visibleLightUrl;
        deviceMap["infraredUrl"] = device.infraredUrl;
        deviceMap["visibleLightRecordUrl"] = device.visibleLightRecordUrl;
        deviceMap["infraredRecordUrl"] = device.infraredRecordUrl;
        deviceMap["recordUrlbase"] = device.recordUrlbase;
        deviceMap["groupName"] = device.groupName;
        deviceMap["isOnline"] = device.isOnline;
        deviceMap["isSelected"] = device.isSelected;
        deviceMap["channelIndex"] = device.channelIndex;
        deviceMap["isInfraredSelected"] = device.isInfraredSelected;
    }
    
    return deviceMap;
}

DeviceInfo DeviceModel::getDeviceByIndex(int index)
{
    if (index >= 0 && index < m_devices.size()) {
        return m_devices[index];
    }
    return DeviceInfo{};
}

QList<DeviceInfo> DeviceModel::getAllDevices() const
{
    qDebug() << "getAllDevices: returning" << m_devices.size() << "devices";
    return m_devices;
}

void DeviceModel::selectDevice(const QString &deviceId)
{
    // 清除之前的选择
    for (int i = 0; i < m_devices.size(); ++i) {
        if (m_devices[i].isSelected) {
            m_devices[i].isSelected = false;
            QModelIndex index = this->index(i);
            emit dataChanged(index, index);
        }
    }
    
    // 设置新的选择
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        m_devices[index].isSelected = true;
        m_selectedDeviceId = deviceId;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        emit deviceSelected(deviceId);
    }
}

void DeviceModel::selectDeviceByIndex(int index)
{
    if (index >= 0 && index < m_devices.size()) {
        selectDevice(m_devices[index].deviceId);
    }
}

void DeviceModel::setDeviceOnlineStatus(const QString &deviceId, bool isOnline)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].isOnline != isOnline) {
        m_devices[index].isOnline = isOnline;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        emit deviceStatusChanged(deviceId, isOnline);
    }
}

void DeviceModel::setDeviceChannelIndex(const QString &deviceId, int channelIndex)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].channelIndex != channelIndex) {
        m_devices[index].channelIndex = channelIndex;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
    }
}

int DeviceModel::getDeviceChannelIndex(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].channelIndex;
    }
    return -1; // 未找到设备
}

QList<DeviceGroup> DeviceModel::getDeviceGroups() const
{
    qDebug() << "getDeviceGroups: returning" << m_deviceGroups.size() << "device groups";
    return m_deviceGroups;
}

// QML友好的方法实现
QStringList DeviceModel::getDeviceGroupNames() const
{
    QStringList groupNames;
    for (const auto &group : m_deviceGroups) {
        groupNames.append(group.groupName);
    }
    qDebug() << "getDeviceGroupNames: returning" << groupNames.size() << "group names";
    return groupNames;
}

QVariantList DeviceModel::getAllDevicesAsVariant() const
{
    QVariantList deviceList;
    qDebug() << "getAllDevicesAsVariant: returning" << m_devices.size() << "devices";
    for (const auto &device : m_devices) {
        QVariantMap deviceMap;
        deviceMap["deviceId"] = device.deviceId;
        deviceMap["deviceName"] = device.deviceName;
        deviceMap["deviceType"] = device.deviceType;
        deviceMap["visibleLightIp"] = device.visibleLightIp;
        deviceMap["infraredIp"] = device.infraredIp;
        deviceMap["tdlasIp"] = device.tdlasIp;
        deviceMap["modbusIp"] = device.modbusIp;
        deviceMap["tofIp"] = device.tofIp;
        deviceMap["hikvisionIp"] = device.hikvisionIp;
        deviceMap["port"] = device.port;
        deviceMap["tdlasPort"] = device.tdlasPort;
        deviceMap["modbusPort"] = device.modbusPort;
        deviceMap["tofPort"] = device.tofPort;
        deviceMap["visibleLightUsername"] = device.visibleLightUsername;
        deviceMap["visibleLightPassword"] = device.visibleLightPassword;
        deviceMap["infraredUsername"] = device.infraredUsername;
        deviceMap["infraredPassword"] = device.infraredPassword;
        deviceMap["hikvisionUsername"] = device.hikvisionUsername;
        deviceMap["hikvisionPassword"] = device.hikvisionPassword;
        deviceMap["hikvisionPort"] = device.hikvisionPort;
        deviceMap["infraredDownloadChannel"] = device.infraredDownloadChannel;
        deviceMap["visibleLightDownloadChannel"] = device.visibleLightDownloadChannel;
        deviceMap["alarmConcentration"] = device.alarmConcentration;
        deviceMap["alarmRecordDuration"] = device.alarmRecordDuration;
        deviceMap["alarmOutputDuration"] = device.alarmOutputDuration;
        deviceMap["visibleLightUrl"] = device.visibleLightUrl;
        deviceMap["infraredUrl"] = device.infraredUrl;
        deviceMap["visibleLightRecordUrl"] = device.visibleLightRecordUrl;
        deviceMap["infraredRecordUrl"] = device.infraredRecordUrl;
        deviceMap["recordUrlbase"] = device.recordUrlbase;
        deviceMap["groupName"] = device.groupName;
        deviceMap["isOnline"] = device.isOnline;
        deviceMap["isSelected"] = device.isSelected;
        deviceMap["channelIndex"] = device.channelIndex;
        deviceMap["isInfraredSelected"] = device.isInfraredSelected;
        deviceList.append(deviceMap);
    }
    qDebug() << "getAllDevicesAsVariant: returning" << deviceList.size() << "devices";
    return deviceList;
}

void DeviceModel::addDeviceGroup(const QString &groupName)
{
    // 检查分组是否已存在
    for (const auto &group : m_deviceGroups) {
        if (group.groupName == groupName) {
            return;
        }
    }
    
    DeviceGroup newGroup;
    newGroup.groupName = groupName;
    newGroup.isExpanded = true;
    m_deviceGroups.append(newGroup);
}

void DeviceModel::removeDeviceGroup(const QString &groupName)
{
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == groupName) {
            // 删除该分组下的所有设备
            QStringList deviceIdsToRemove;
            for (int j = 0; j < m_devices.size(); ++j) {
                if (m_devices[j].groupName == groupName) {
                    deviceIdsToRemove.append(m_devices[j].deviceId);
                }
            }
            
            // 移除设备
            for (const QString &deviceId : deviceIdsToRemove) {
                removeDevice(deviceId);
            }
            
            m_deviceGroups.removeAt(i);
            break;
        }
    }
}

void DeviceModel::modifyDeviceGroupName(const QString &oldName, const QString &newName)
{
    // 检查新分组名是否已存在
    for (const auto &group : m_deviceGroups) {
        if (group.groupName == newName) {
            qDebug() << "分组名已存在:" << newName;
            return;
        }
    }
    
    // 更新分组列表中的分组名
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == oldName) {
            m_deviceGroups[i].groupName = newName;
            break;
        }
    }
    
    // 更新所有属于该分组的设备的分组名
    for (int i = 0; i < m_devices.size(); ++i) {
        if (m_devices[i].groupName == oldName) {
            m_devices[i].groupName = newName;
            QModelIndex index = this->index(i);
            emit dataChanged(index, index);
            
            // 保存更新后的设备信息到文件
            QString appDir = QCoreApplication::applicationDirPath();
            QString deviceInfoDir = appDir + "/config/deviceinfo";
            QString deviceFilePath = deviceInfoDir + "/" + m_devices[i].deviceId + ".json";
            saveDevicesToFile(deviceFilePath, m_devices[i]);
        }
    }
    
    // 同时更新树形模型
    if (m_treeModel) {
        qDebug() << "DeviceModel::modifyDeviceGroupName - updating tree model";
        m_treeModel->modifyGroupName(oldName, newName);
    } else {
        qDebug() << "DeviceModel::modifyDeviceGroupName - no tree model found";
    }
    
    // 更新分组信息
    updateDeviceGroups();
}

void DeviceModel::expandDeviceGroup(const QString &groupName, bool expanded)
{
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == groupName) {
            m_deviceGroups[i].isExpanded = expanded;
            break;
        }
    }
}

QString DeviceModel::getVisibleLightUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightUrl;
}

QString DeviceModel::getInfraredUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredUrl;
}



QString DeviceModel::getSelectedDeviceVisibleLightUrl()
{
    return getVisibleLightUrl(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredUrl()
{
    return getInfraredUrl(m_selectedDeviceId);
}



QString DeviceModel::getVisibleLightRecordUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightRecordUrl;
}

QString DeviceModel::getInfraredRecordUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredRecordUrl;
}

QString DeviceModel::getSelectedDeviceVisibleLightRecordUrl()
{
    return getVisibleLightRecordUrl(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredRecordUrl()
{
    return getInfraredRecordUrl(m_selectedDeviceId);
}

// IP地址管理方法
QString DeviceModel::getVisibleLightIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightIp;
}

QString DeviceModel::getInfraredIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredIp;
}

QString DeviceModel::getTdlasIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.tdlasIp;
}

QString DeviceModel::getSelectedDeviceVisibleLightIp()
{
    return getVisibleLightIp(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredIp()
{
    return getInfraredIp(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceTdlasIp()
{
    return getTdlasIp(m_selectedDeviceId);
}

// 用户名和密码管理方法
QString DeviceModel::getVisibleLightUsername(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightUsername;
}

QString DeviceModel::getVisibleLightPassword(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightPassword;
}

QString DeviceModel::getInfraredUsername(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredUsername;
}

QString DeviceModel::getInfraredPassword(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredPassword;
}



QString DeviceModel::getSelectedDeviceVisibleLightUsername()
{
    return getVisibleLightUsername(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceVisibleLightPassword()
{
    return getVisibleLightPassword(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredUsername()
{
    return getInfraredUsername(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredPassword()
{
    return getInfraredPassword(m_selectedDeviceId);
}



QString DeviceModel::getDeviceUrlByChannelIndex(int channelIndex, bool isVisibleLight)
{
    for (const auto &device : m_devices) {
        if (device.channelIndex == channelIndex) {
            return isVisibleLight ? device.visibleLightUrl : device.infraredUrl;
        }
    }
    return QString();
}

QString DeviceModel::getDeviceRecordUrlByChannelIndex(int channelIndex, bool isVisibleLight)
{
    for (const auto &device : m_devices) {
        if (device.channelIndex == channelIndex) {
            return isVisibleLight ? device.visibleLightRecordUrl : device.infraredRecordUrl;
        }
    }
    return QString();
}

QString DeviceModel::getDeviceIdByChannelIndex(int channelIndex)
{
    for (const auto &device : m_devices) {
        if (device.channelIndex == channelIndex) {
            return device.deviceId;
        }
    }
    return QString();
}

int DeviceModel::getChannelCount()
{
    return 9;
}

void DeviceModel::clearAllDevices()
{
    beginResetModel();
    m_devices.clear();
    m_deviceGroups.clear();
    endResetModel();
}

QList<int> DeviceModel::getAllDeviceChannelIndexes() const
{
    QList<int> channelIndexes;
    for (const auto &device : m_devices) {
        channelIndexes.append(device.channelIndex);
    }
    return channelIndexes;
}

void DeviceModel::saveDevicesToFile(const QString &filename, const DeviceInfo &device)
{
    QJsonObject deviceObj;
    deviceObj["deviceId"] = device.deviceId;
    deviceObj["deviceName"] = device.deviceName;
    deviceObj["deviceType"] = device.deviceType;
    deviceObj["visibleLightIp"] = device.visibleLightIp;
    deviceObj["infraredIp"] = device.infraredIp;
    deviceObj["tdlasIp"] = device.tdlasIp;
    deviceObj["modbusIp"] = device.modbusIp;
    deviceObj["tofIp"] = device.tofIp;
    deviceObj["hikvisionIp"] = device.hikvisionIp;
    deviceObj["port"] = device.port;
    deviceObj["tdlasPort"] = device.tdlasPort;
    deviceObj["modbusPort"] = device.modbusPort;
    deviceObj["tofPort"] = device.tofPort;
    deviceObj["visibleLightUsername"] = device.visibleLightUsername;
    deviceObj["visibleLightPassword"] = device.visibleLightPassword;
    deviceObj["infraredUsername"] = device.infraredUsername;
    deviceObj["infraredPassword"] = device.infraredPassword;

    deviceObj["hikvisionUsername"] = device.hikvisionUsername;
    deviceObj["hikvisionPassword"] = device.hikvisionPassword;
    deviceObj["hikvisionPort"] = device.hikvisionPort;
    deviceObj["infraredDownloadChannel"] = device.infraredDownloadChannel;
    deviceObj["visibleLightDownloadChannel"] = device.visibleLightDownloadChannel;
    deviceObj["visibleLightUrl"] = device.visibleLightUrl;
    deviceObj["infraredUrl"] = device.infraredUrl;

    deviceObj["visibleLightRecordUrl"] = device.visibleLightRecordUrl;
    deviceObj["infraredRecordUrl"] = device.infraredRecordUrl;
    deviceObj["recordUrlbase"] = device.recordUrlbase;
    deviceObj["groupName"] = device.groupName;
    deviceObj["isOnline"] = device.isOnline;
    deviceObj["isSelected"] = device.isSelected;
    deviceObj["channelIndex"] = device.channelIndex;
    deviceObj["isInfraredSelected"] = device.isInfraredSelected;
    deviceObj["alarmConcentration"] = device.alarmConcentration;
    deviceObj["alarmRecordDuration"] = device.alarmRecordDuration;
    deviceObj["alarmOutputDuration"] = device.alarmOutputDuration;
    
    QJsonObject rootObj;
    rootObj["devices"] = QJsonArray({deviceObj});
    
    QJsonDocument doc(rootObj);
    QFile file(filename);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        qDebug() << "设备配置已保存到:" << filename;
    }
}

void DeviceModel::loadDevicesFromFile(const QString &filename)
{
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "无法打开设备配置文件:" << filename;
        return;
    }
    
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    QJsonObject rootObj = doc.object();
    QJsonArray devicesArray = rootObj["devices"].toArray();
    
    // beginResetModel();
    // m_devices.clear();
    
    for (const auto &deviceValue : devicesArray) {
        QJsonObject deviceObj = deviceValue.toObject();
        DeviceInfo device;
        device.deviceId = deviceObj["deviceId"].toString();
        device.deviceName = deviceObj["deviceName"].toString();
        device.deviceType = deviceObj["deviceType"].toString();
        device.visibleLightIp = deviceObj["visibleLightIp"].toString();
        device.infraredIp = deviceObj["infraredIp"].toString();
        device.tdlasIp = deviceObj["tdlasIp"].toString();
        device.modbusIp = deviceObj["modbusIp"].toString();
        device.tofIp = deviceObj["tofIp"].toString();
        device.hikvisionIp = deviceObj["hikvisionIp"].toString();
        device.port = deviceObj["port"].toInt();
        device.tdlasPort = deviceObj["tdlasPort"].toInt();
        device.modbusPort = deviceObj["modbusPort"].toInt();
        device.tofPort = deviceObj["tofPort"].toInt();
        device.visibleLightUsername = deviceObj["visibleLightUsername"].toString();
        device.visibleLightPassword = deviceObj["visibleLightPassword"].toString();
        device.infraredUsername = deviceObj["infraredUsername"].toString();
        device.infraredPassword = deviceObj["infraredPassword"].toString();

        device.hikvisionUsername = deviceObj["hikvisionUsername"].toString();
        device.hikvisionPassword = deviceObj["hikvisionPassword"].toString();
        device.hikvisionPort = deviceObj["hikvisionPort"].toInt();
        device.infraredDownloadChannel = deviceObj["infraredDownloadChannel"].toInt();
        device.visibleLightDownloadChannel = deviceObj["visibleLightDownloadChannel"].toInt();
        device.visibleLightUrl = deviceObj["visibleLightUrl"].toString();
        device.infraredUrl = deviceObj["infraredUrl"].toString();

        device.visibleLightRecordUrl = deviceObj["visibleLightRecordUrl"].toString();
        device.infraredRecordUrl = deviceObj["infraredRecordUrl"].toString();
        device.recordUrlbase = deviceObj["recordUrlbase"].toString();
        device.groupName = deviceObj["groupName"].toString();
        device.isOnline = deviceObj["isOnline"].toBool();
        device.isSelected = deviceObj["isSelected"].toBool();
        device.channelIndex = deviceObj["channelIndex"].toInt();
        device.isInfraredSelected = deviceObj["isInfraredSelected"].toBool();
        device.alarmConcentration = deviceObj["alarmConcentration"].toInt();
        device.alarmRecordDuration = deviceObj["alarmRecordDuration"].toInt();
        device.alarmOutputDuration = deviceObj["alarmOutputDuration"].toInt();
        //m_devices.append(device);
        addDevice(device, false);//从文件读取就不再存文件，避免循环
    }
    
    // endResetModel();
    // updateDeviceGroups();
    qDebug() << "设备配置已从文件加载:" << filename;
}

void DeviceModel::loadDefaultDevices()
{
    // 清空现有设备
    clearAllDevices();
    
    // 首先尝试从配置文件加载设备
    QString appDir = QCoreApplication::applicationDirPath();
    QString deviceInfoDir = appDir + "/config/deviceinfo";
    QDir dir(deviceInfoDir);
    
    if (dir.exists()) {
        QStringList deviceFiles = dir.entryList(QStringList() << "*.json", QDir::Files);
        if (!deviceFiles.isEmpty()) {
            qDebug() << "Loading devices from config files:" << deviceFiles.size() << "files";
            
            for (const QString &fileName : deviceFiles) {
                QString filePath = deviceInfoDir + "/" + fileName;
                //QFile deviceFile(filePath);
                loadDevicesFromFile(filePath);
            }
            
            qDebug() << "Loaded" << m_devices.size() << "devices from config files";
            return; // 成功加载配置文件后返回
        }
    }
    
    // 如果没有配置文件，使用默认设备
    qDebug() << "No config files found, loading default devices";
    
    // DeviceInfo device1;
    // device1.deviceId = "device_001";
    // device1.deviceName = "监控点1";
    // device1.deviceType = "PTZ";
    // device1.visibleLightIp = "192.168.1.105";  // 可见光设备IP
    // device1.infraredIp = "192.168.1.123";      // 红外设备IP
    // device1.tdlasIp = "192.168.1.204";         // TDLAS设备IP
    // device1.modbusIp = "192.168.1.205";        // Modbus设备IP
    // device1.tofIp = "192.168.1.205";           // TOF设备IP (修改为不同的IP)
    // device1.hikvisionIp = "192.168.1.168";    // 海康设备IP
    // device1.port = 554;
    // device1.tdlasPort = 2000;                  // TDLAS设备端口
    // device1.modbusPort = 2000;                  
    // device1.tofPort = 2000;                    
    // device1.visibleLightUsername = "admin";
    // device1.visibleLightPassword = "123456";
    // device1.infraredUsername = "admin";
    // device1.infraredPassword = "system123";
    // device1.hikvisionUsername = "admin";
    // device1.hikvisionPassword = "hwzg2025";
    // device1.hikvisionPort = 8000;
    // device1.infraredDownloadChannel = 33;  // 红外下载通道
    // device1.visibleLightDownloadChannel = 34; // 可见光下载通道
    // device1.visibleLightUrl = QString("rtsp://%1:%2@%3/video2")
    //    .arg(device1.visibleLightUsername)
    //    .arg(device1.visibleLightPassword)
    //    .arg(device1.visibleLightIp);
    // device1.infraredUrl = QString("rtsp://%1:%2@%3:554/live?channel=0&subtype=1")
    //    .arg(device1.infraredUsername)
    //    .arg(device1.infraredPassword)
    //    .arg(device1.infraredIp);
    // device1.recordUrlbase = QString("rtsp://%1:%2@%3:554/Streaming/tracks")
    //    .arg(device1.hikvisionUsername)
    //    .arg(device1.hikvisionPassword)
    //    .arg(device1.hikvisionIp);
    // // 使用动态方法生成录像URL
    // device1.visibleLightRecordUrl = generateRecordUrl(device1.recordUrlbase, device1.hikvisionIp, 
    //                                                 device1.hikvisionPort, device1.hikvisionUsername, 
    //                                                 device1.hikvisionPassword, device1.visibleLightIp);
    // device1.infraredRecordUrl = generateRecordUrl(device1.recordUrlbase, device1.hikvisionIp, 
    //                                             device1.hikvisionPort, device1.hikvisionUsername, 
    //                                             device1.hikvisionPassword, device1.infraredIp);
    // device1.groupName = "第一园区";
    // device1.isOnline = true;
    // device1.isSelected = false;
    // device1.channelIndex = 0;
    // device1.isInfraredSelected = false;  // 默认可见光被选中
    // device1.alarmConcentration = 300;  // 默认报警浓度值300ppm
    // device1.alarmRecordDuration = 30;  // 默认报警录制时长30秒
    // device1.alarmOutputDuration = 10;  // 默认报警输出时长10秒
    // addDevice(device1,true);
    
    //  DeviceInfo device1;
    //  device1.deviceId = "device_001";
    //  device1.deviceName = "监控点1";
    //  device1.deviceType = "PTZ";
    //  device1.visibleLightIp = "192.168.1.105";  // 可见光设备IP
    //  device1.infraredIp = "192.168.1.123";      // 红外设备IP
    //  device1.tdlasIp = "192.168.1.204";         // TDLAS设备IP
    //  device1.modbusIp = "192.168.1.205";        // Modbus设备IP
    //  device1.tofIp = "192.168.1.205";           // TOF设备IP (修改为不同的IP)
    //  device1.hikvisionIp = "192.168.1.102";    // 海康设备IP
    //  device1.port = 554;
    //  device1.tdlasPort = 2000;                  // TDLAS设备端口
    //  device1.modbusPort = 2000;                  
    //  device1.tofPort = 2000;                    
    //  device1.visibleLightUsername = "admin";
    //  device1.visibleLightPassword = "123456";
    //  device1.infraredUsername = "admin";
    //  device1.infraredPassword = "system123";
    //  device1.hikvisionUsername = "admin";
    //  device1.hikvisionPassword = "WANG234WH";
    //  device1.hikvisionPort = 8000;
    //  device1.infraredDownloadChannel = 33;  // 红外下载通道
    //  device1.visibleLightDownloadChannel = 34; // 可见光下载通道
    // device1.visibleLightUrl = QString("rtsp://%1:%2@%3/video2")
    //     .arg(device1.visibleLightUsername)
    //     .arg(device1.visibleLightPassword)
    //     .arg(device1.visibleLightIp);
    // device1.infraredUrl = QString("rtsp://%1:%2@%3:554/live?channel=0&subtype=1")
    //     .arg(device1.infraredUsername)
    //     .arg(device1.infraredPassword)
    //     .arg(device1.infraredIp);
    // device1.recordUrlbase = QString("rtsp://%1:%2@%3:554/Streaming/tracks")
    //     .arg(device1.hikvisionUsername)
    //     .arg(device1.hikvisionPassword)
    //     .arg(device1.hikvisionIp);
    //  // 使用动态方法生成录像URL
    //  device1.visibleLightRecordUrl = generateRecordUrl(device1.recordUrlbase, device1.hikvisionIp, 
    //                                                  device1.hikvisionPort, device1.hikvisionUsername, 
    //                                                  device1.hikvisionPassword, device1.visibleLightIp);
    //  device1.infraredRecordUrl = generateRecordUrl(device1.recordUrlbase, device1.hikvisionIp, 
    //                                              device1.hikvisionPort, device1.hikvisionUsername, 
    //                                              device1.hikvisionPassword, device1.infraredIp);
    //  device1.groupName = "第一园区";
    //  device1.isOnline = true;
    //  device1.isSelected = false;
    //  device1.channelIndex = 0;
    //  device1.isInfraredSelected = false;  // 默认可见光被选中
    //  device1.alarmConcentration = 300;  // 默认报警浓度值300ppm
    //  device1.alarmRecordDuration = 30;  // 默认报警录制时长30秒
    //  device1.alarmOutputDuration = 10;  // 默认报警输出时长10秒
    //  addDevice(device1,true);

    DeviceInfo device2;
    device2.deviceId = "device_002";
    device2.deviceName = "监控点2";
    device2.deviceType = "PTZ";
    device2.visibleLightIp = "192.168.1.100";  // 可见光设备IP
    device2.infraredIp = "192.168.1.125";      // 红外设备IP
    device2.tdlasIp = "192.168.1.202";         // TDLAS设备IP
    device2.modbusIp = "192.168.1.203";        // Modbus设备IP
    device2.tofIp = "192.168.1.203";           // TOF设备IP (修改为不同的IP)
    device2.hikvisionIp = "192.168.1.102";    // 海康设备IP
    device2.port = 554;
    device2.tdlasPort = 2000;                  // TDLAS设备端口
    device2.modbusPort = 2000;                  
    device2.tofPort = 2000;                    
    device2.visibleLightUsername = "admin";
    device2.visibleLightPassword = "123456";
    device2.infraredUsername = "admin";
    device2.infraredPassword = "system123";
    device2.hikvisionUsername = "admin";
    device2.hikvisionPassword = "WANG234WH";
    device2.hikvisionPort = 8000;
    device2.infraredDownloadChannel = 35;  // 红外下载通道
    device2.visibleLightDownloadChannel = 36; // 可见光下载通道
    // 根据规则生成URL
    device2.visibleLightUrl = QString("rtsp://%1:%2@%3/video2")
        .arg(device2.visibleLightUsername)
        .arg(device2.visibleLightPassword)
        .arg(device2.visibleLightIp);
    device2.infraredUrl = QString("rtsp://%1:%2@%3:554/live?channel=0&subtype=1")
        .arg(device2.infraredUsername)
        .arg(device2.infraredPassword)
        .arg(device2.infraredIp);
    device2.recordUrlbase = QString("rtsp://%1:%2@%3:554/Streaming/tracks")
        .arg(device2.hikvisionUsername)
        .arg(device2.hikvisionPassword)
        .arg(device2.hikvisionIp);
    // 使用动态方法生成录像URL
    device2.visibleLightRecordUrl = generateRecordUrl(device2.recordUrlbase, device2.hikvisionIp, 
                                                     device2.hikvisionPort, device2.hikvisionUsername, 
                                                     device2.hikvisionPassword, device2.visibleLightIp);
    device2.infraredRecordUrl = generateRecordUrl(device2.recordUrlbase, device2.hikvisionIp, 
                                                 device2.hikvisionPort, device2.hikvisionUsername, 
                                                 device2.hikvisionPassword, device2.infraredIp);
    device2.groupName = "第一园区";
    device2.isOnline = true;
    device2.isSelected = false;
    device2.channelIndex = 1;
    device2.isInfraredSelected = false;  // 默认可见光被选中
    device2.alarmConcentration = 300;  // 默认报警浓度值300ppm
    device2.alarmRecordDuration = 30;  // 默认报警录制时长30秒
    device2.alarmOutputDuration = 10;  // 默认报警输出时长10秒
    addDevice(device2, true); // 加载默认设备时保存到文件
    
    qDebug() << "默认设备配置加载完成";

}

void DeviceModel::checkDeviceStatus()
{
    // 这里可以实现设备在线状态检查逻辑
    // 可以通过ping IP地址或尝试连接RTSP流来检查
    qDebug() << "检查设备在线状态...";
    
    // 示例：模拟状态检查
    for (int i = 0; i < m_devices.size(); ++i) {
        // 这里应该实现真正的设备状态检查
        // 暂时保持原有状态
        bool wasOnline = m_devices[i].isOnline;
        // m_devices[i].isOnline = checkDeviceConnectivity(m_devices[i].ipAddress);
        
        if (wasOnline != m_devices[i].isOnline) {
            QModelIndex index = this->index(i);
            emit dataChanged(index, index);
            emit deviceStatusChanged(m_devices[i].deviceId, m_devices[i].isOnline);
        }
    }
}

void DeviceModel::updateDeviceGroups()
{
    // 清空分组中的设备列表
    for (auto &group : m_deviceGroups) {
        group.devices.clear();
    }
    
    // 重新分配设备到分组
    for (const auto &device : m_devices) {
        int groupIndex = findGroupIndex(device.groupName);
        if (groupIndex >= 0) {
            m_deviceGroups[groupIndex].devices.append(device);
        } else {
            // 如果分组不存在，创建新分组
            addDeviceGroup(device.groupName);
            groupIndex = findGroupIndex(device.groupName);
            if (groupIndex >= 0) {
                m_deviceGroups[groupIndex].devices.append(device);
            }
        }
    }
}

int DeviceModel::findDeviceIndex(const QString &deviceId) const
{
    for (int i = 0; i < m_devices.size(); ++i) {
        //qDebug() << "Comparing deviceId:" << m_devices[i].deviceId << "with:" << deviceId;
        if (m_devices[i].deviceId == deviceId) {
            return i;
        }
    }
    return -1;
}

int DeviceModel::findGroupIndex(const QString &groupName) const
{
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == groupName) {
            return i;
        }
    }
    return -1;
}

// 报警配置管理方法实现
int DeviceModel::getAlarmConcentration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmConcentration;
}

int DeviceModel::getAlarmRecordDuration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmRecordDuration;
}

int DeviceModel::getAlarmOutputDuration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmOutputDuration;
}

int DeviceModel::getSelectedDeviceAlarmConcentration()
{
    return getAlarmConcentration(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceAlarmRecordDuration()
{
    return getAlarmRecordDuration(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceAlarmOutputDuration()
{
    return getAlarmOutputDuration(m_selectedDeviceId);
}

// Modbus相关方法实现
QString DeviceModel::getModbusIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.modbusIp;
}

QString DeviceModel::getSelectedDeviceModbusIp()
{
    return getModbusIp(m_selectedDeviceId);
}

 

QString DeviceModel::getTofIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.tofIp;
}

QString DeviceModel::getSelectedDeviceTofIp()
{
    return getTofIp(m_selectedDeviceId);
}





// 海康相关方法实现
QString DeviceModel::getHikvisionUsername(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionUsername;
}

QString DeviceModel::getHikvisionPassword(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionPassword;
}

int DeviceModel::getHikvisionPort(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionPort;
}

QString DeviceModel::getSelectedDeviceHikvisionUsername()
{
    return getHikvisionUsername(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceHikvisionPassword()
{
    return getHikvisionPassword(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceHikvisionPort()
{
    return getHikvisionPort(m_selectedDeviceId);
}

int DeviceModel::getInfraredDownloadChannel(const QString &deviceId)
{
    qDebug() << "getInfraredDownloadChannel: deviceId =" << deviceId;
    DeviceInfo device = getDevice(deviceId);
    qDebug() << "getInfraredDownloadChannel: device.infraredDownloadChannel =" << device.infraredDownloadChannel;
    return device.infraredDownloadChannel;
}

int DeviceModel::getVisibleLightDownloadChannel(const QString &deviceId)
{
    qDebug() << "getVisibleLightDownloadChannel: deviceId =" << deviceId;
    DeviceInfo device = getDevice(deviceId);
    qDebug() << "getVisibleLightDownloadChannel: device.visibleLightDownloadChannel =" << device.visibleLightDownloadChannel;
    return device.visibleLightDownloadChannel;
}

int DeviceModel::getSelectedDeviceInfraredDownloadChannel()
{
    qDebug() << "getSelectedDeviceInfraredDownloadChannel: m_selectedDeviceId =" << m_selectedDeviceId;
    int channel = getInfraredDownloadChannel(m_selectedDeviceId);
    qDebug() << "getSelectedDeviceInfraredDownloadChannel: returned channel =" << channel;
    return channel;
}

int DeviceModel::getSelectedDeviceVisibleLightDownloadChannel()
{
    qDebug() << "getSelectedDeviceVisibleLightDownloadChannel: m_selectedDeviceId =" << m_selectedDeviceId;
    int channel = getVisibleLightDownloadChannel(m_selectedDeviceId);
    qDebug() << "getSelectedDeviceVisibleLightDownloadChannel: returned channel =" << channel;
    return channel;
}

int DeviceModel::getSelectedDeviceChannelIndex()
{
    return getDeviceChannelIndex(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceId()
{
    return m_selectedDeviceId;
}

QString DeviceModel::getHikvisionIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionIp;
}

QString DeviceModel::getSelectedDeviceHikvisionIp()
{
    return getHikvisionIp(m_selectedDeviceId);
}

// 树形模型管理方法
DeviceTreeModel* DeviceModel::getTreeModel() const
{
    return m_treeModel;
}

void DeviceModel::setTreeModel(DeviceTreeModel* treeModel)
{
    if (m_treeModel != treeModel) {
        m_treeModel = treeModel;
        
        // 如果设置了新的树形模型，将现有设备添加到树形模型中
        if (m_treeModel) {
            qDebug() << "Setting tree model, adding" << m_devices.size() << "existing devices";
            for (const DeviceInfo& device : m_devices) {
                qDebug() << "Adding existing device:" << device.deviceName << "in group:" << device.groupName;
                m_treeModel->addDevice(device);
            }
        }
    }
}

// 红外选中状态管理方法实现
void DeviceModel::setDeviceInfraredSelected(const QString &deviceId, bool isInfraredSelected)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].isInfraredSelected != isInfraredSelected) {
        m_devices[index].isInfraredSelected = isInfraredSelected;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        qDebug() << "Device" << deviceId << "infrared selected status changed to:" << isInfraredSelected;
    }
}

bool DeviceModel::getDeviceInfraredSelected(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].isInfraredSelected;
    }
    return false; // 默认返回false（可见光）
}

bool DeviceModel::getSelectedDeviceInfraredSelected()
{
    return getDeviceInfraredSelected(m_selectedDeviceId);
}

// recordUrlbase相关方法实现
QString DeviceModel::getRecordUrlbase(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.recordUrlbase;
}

QString DeviceModel::getSelectedDeviceRecordUrlbase()
{
    return getRecordUrlbase(m_selectedDeviceId);
}

// HikvisionCtrl 设置方法实现
void DeviceModel::setHikvisionCtrl(HikvisionCtrl* hikvisionCtrl)
{
    m_hikvisionCtrl = hikvisionCtrl;
    qDebug() << "HikvisionCtrl set for DeviceModel";
    
    // 连接HikvisionCtrl的信号，监听通道查找完成事件
    if (m_hikvisionCtrl) {
        connect(m_hikvisionCtrl, &HikvisionCtrl::channelLookupCompleted,
                this, &DeviceModel::onChannelLookupCompleted);
        connect(m_hikvisionCtrl, &HikvisionCtrl::channelLookupFailed,
                this, &DeviceModel::onChannelLookupFailed);
        connect(m_hikvisionCtrl, &HikvisionCtrl::channelInitializationCompleted,
                this, &DeviceModel::onChannelInitializationCompleted);
    }
}

// 通道信息管理方法实现
void DeviceModel::forceUpdateDeviceChannelInfo(const QString &deviceId)
{
    qDebug() << "强制更新设备通道信息:" << deviceId;
    
    if (!m_hikvisionCtrl) {
        qWarning() << "HikvisionCtrl未设置，无法更新通道信息";
        return;
    }
    
    DeviceInfo device = getDevice(deviceId);
    if (device.deviceId.isEmpty()) {
        qWarning() << "设备不存在:" << deviceId;
        return;
    }
    
    // 强制更新可见光设备通道
    if (!device.visibleLightIp.isEmpty() && !device.hikvisionIp.isEmpty()) {
        qDebug() << "强制更新可见光设备通道:" << device.visibleLightIp;
        m_hikvisionCtrl->forceUpdateChannelInfo(
            device.hikvisionIp, 
            device.hikvisionPort, 
            device.hikvisionUsername, 
            device.hikvisionPassword, 
            device.visibleLightIp
        );
    }
    
    // 强制更新红外设备通道
    if (!device.infraredIp.isEmpty() && !device.hikvisionIp.isEmpty()) {
        qDebug() << "强制更新红外设备通道:" << device.infraredIp;
        m_hikvisionCtrl->forceUpdateChannelInfo(
            device.hikvisionIp, 
            device.hikvisionPort, 
            device.hikvisionUsername, 
            device.hikvisionPassword, 
            device.infraredIp
        );
    }
}

void DeviceModel::initializeAllChannelInfo()
{
    qDebug() << "初始化所有设备的通道信息";
    
    if (!m_hikvisionCtrl) {
        qWarning() << "HikvisionCtrl未设置，无法初始化通道信息";
        return;
    }
    
    // 准备批量初始化数据
    QStringList hikvisionIps;
    QStringList hikvisionUsernames; 
    QStringList hikvisionPasswords;
    QStringList visibleLightIps;
    QStringList infraredIps;
    
    for (const auto& device : m_devices) {
        if (!device.hikvisionIp.isEmpty()) {
            // 收集可见光设备信息
            if (!device.visibleLightIp.isEmpty()) {
                hikvisionIps.append(device.hikvisionIp);
                hikvisionUsernames.append(device.hikvisionUsername);
                hikvisionPasswords.append(device.hikvisionPassword);
                visibleLightIps.append(device.visibleLightIp);
            }
            
            // 收集红外设备信息
            if (!device.infraredIp.isEmpty()) {
                hikvisionIps.append(device.hikvisionIp);
                hikvisionUsernames.append(device.hikvisionUsername);
                hikvisionPasswords.append(device.hikvisionPassword);
                infraredIps.append(device.infraredIp);
            }
        }
    }
    
    // 批量初始化
    if (!hikvisionIps.isEmpty()) {
        if (!visibleLightIps.isEmpty()) {
            qDebug() << "批量初始化可见光设备通道，数量:" << visibleLightIps.size();
            m_hikvisionCtrl->initializeChannelInfo(hikvisionIps, hikvisionUsernames, hikvisionPasswords, visibleLightIps);
        }
        
        if (!infraredIps.isEmpty()) {
            qDebug() << "批量初始化红外设备通道，数量:" << infraredIps.size();
            m_hikvisionCtrl->initializeChannelInfo(hikvisionIps, hikvisionUsernames, hikvisionPasswords, infraredIps);
        }
    }
}

bool DeviceModel::isDeviceChannelCacheValid(const QString &deviceId)
{
    if (!m_hikvisionCtrl) {
        return false;
    }
    
    DeviceInfo device = getDevice(deviceId);
    if (device.deviceId.isEmpty()) {
        return false;
    }
    
    bool visibleLightValid = true;
    bool infraredValid = true;
    
    // 检查可见光设备通道缓存
    if (!device.visibleLightIp.isEmpty() && !device.hikvisionIp.isEmpty()) {
        visibleLightValid = m_hikvisionCtrl->isChannelCacheValid(device.hikvisionIp, device.visibleLightIp);
    }
    
    // 检查红外设备通道缓存
    if (!device.infraredIp.isEmpty() && !device.hikvisionIp.isEmpty()) {
        infraredValid = m_hikvisionCtrl->isChannelCacheValid(device.hikvisionIp, device.infraredIp);
    }
    
    return visibleLightValid && infraredValid;
}

// 新增：通道查找完成的槽函数
void DeviceModel::onChannelLookupCompleted(const QString& nvrIp, const QString& ipcIp, int channelNumber)
{
    qDebug() << "通道查找完成 - NVR:" << nvrIp << "IPC:" << ipcIp << "通道:" << channelNumber;
    // 这里可以进一步处理，比如更新UI或日志
}

void DeviceModel::onChannelLookupFailed(const QString& nvrIp, const QString& ipcIp, const QString& errorMessage)
{
    qWarning() << "通道查找失败 - NVR:" << nvrIp << "IPC:" << ipcIp << "错误:" << errorMessage;
    // 这里可以进一步处理，比如显示错误消息
}

void DeviceModel::onChannelInitializationCompleted()
{
    qDebug() << "所有通道信息初始化完成";
    // 这里可以进一步处理，比如通知UI更新
}

// 生成录像URL的辅助方法
QString DeviceModel::generateRecordUrl(const QString& recordUrlBase, const QString& hikvisionIp, 
                                      int hikvisionPort, const QString& hikvisionUsername, 
                                      const QString& hikvisionPassword, const QString& ipcIp)
{
    QString result = recordUrlBase;
    
    // 获取通道号
    int channelNumber = -1;
    if (m_hikvisionCtrl) {
        qDebug() << "Using HikvisionCtrl to find channel for IPC:" << ipcIp;
        channelNumber = m_hikvisionCtrl->findChannelByIP(hikvisionIp, hikvisionPort, 
                                                        hikvisionUsername, hikvisionPassword, ipcIp);
        
        if (channelNumber > 0) {
            // findChannelByIP返回的值已经加了32，需要减去32得到实际通道号
            channelNumber = channelNumber - 32;
            qDebug() << "Found channel via HikvisionCtrl, adjusted channel number:" << channelNumber;
        } else {
            qWarning() << "Failed to find channel via HikvisionCtrl for IPC:" << ipcIp;
            channelNumber = 1; // 默认通道1
        }
    } else {
        qWarning() << "HikvisionCtrl not available, using default channel 1";
        channelNumber = 1; // 默认通道1
    }
    
    // 构建通道编号（通道号 + 01，表示主码流）
    QString channelCode = QString("%1%2").arg(channelNumber).arg("01");
    
    // 获取当前时间减1小时作为开始时间
    QDateTime currentTime = QDateTime::currentDateTime();
    QDateTime startTime = currentTime.addSecs(-28800); // 减去8小时（28800秒）
    QString formattedStartTime = startTime.toString("yyyyMMddThhmmssZ");
    
    // 构建完整URL
    result += QString("/%1/?starttime=%2").arg(channelCode).arg(formattedStartTime);
    
    qDebug() << "Generated record URL:" << result;
    return result;
}

// 生成带时间参数的录像URL方法
QString DeviceModel::generateTimedRecordUrl(const QString &deviceId, bool isVisibleLight, const QString &timeStr)
{
    DeviceInfo device = getDevice(deviceId);
    if (device.deviceId.isEmpty()) {
        qWarning() << "Device not found:" << deviceId;
        return QString();
    }
    
    if (device.recordUrlbase.isEmpty()) {
        qWarning() << "No record URL base for device:" << deviceId;
        return QString();
    }
    
    // 选择对应的IPC IP地址
    QString ipcIp = isVisibleLight ? device.visibleLightIp : device.infraredIp;
    if (ipcIp.isEmpty()) {
        qWarning() << "No IPC IP for device:" << deviceId << "isVisibleLight:" << isVisibleLight;
        return QString();
    }
    
    QString result = device.recordUrlbase;
    
    // 获取通道号
    int channelNumber = -1;
    if (m_hikvisionCtrl) {
        qDebug() << "Using HikvisionCtrl to find channel for IPC:" << ipcIp;
        channelNumber = m_hikvisionCtrl->findChannelByIP(device.hikvisionIp, device.hikvisionPort, 
                                                        device.hikvisionUsername, device.hikvisionPassword, ipcIp);
        
        if (channelNumber > 0) {
            // findChannelByIP返回的值已经加了32，需要减去32得到实际通道号
            channelNumber = channelNumber - 32;
            qDebug() << "Found channel via HikvisionCtrl, adjusted channel number:" << channelNumber;
        } else {
            qWarning() << "Failed to find channel via HikvisionCtrl for IPC:" << ipcIp;
            channelNumber = 1; // 默认通道1
        }
    } else {
        qWarning() << "HikvisionCtrl not available, using default channel 1";
        channelNumber = 1; // 默认通道1
    }
    
    // 构建通道编号（通道号 + 01，表示主码流）
    QString channelCode = QString("%1%2").arg(channelNumber).arg("01");
    
    // 构建完整URL，使用传入的时间参数
    result += QString("/%1/?starttime=%2").arg(channelCode).arg(timeStr);
    
    qDebug() << "Generated timed record URL:" << result << "for device:" << deviceId << "isVisibleLight:" << isVisibleLight;
    return result;
}

// 便捷方法：获取选中设备的带时间参数的可见光录像URL
QString DeviceModel::getSelectedDeviceTimedVisibleLightRecordUrl(const QString &timeStr)
{
    return generateTimedRecordUrl(m_selectedDeviceId, true, timeStr);
}

// 便捷方法：获取选中设备的带时间参数的红外录像URL
QString DeviceModel::getSelectedDeviceTimedInfraredRecordUrl(const QString &timeStr)
{
    return generateTimedRecordUrl(m_selectedDeviceId, false, timeStr);
}

// 存储设置管理方法实现
void DeviceModel::saveStorageSettings(const QString &settingsJson)
{
    qDebug() << "保存存储设置:" << settingsJson;
    
    // 解析JSON字符串
    QJsonDocument doc = QJsonDocument::fromJson(settingsJson.toUtf8());
    if (!doc.isObject()) {
        qWarning() << "存储设置JSON格式错误";
        return;
    }
    
    QJsonObject settingsObj = doc.object();
    
    // 创建存储设置目录
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configDir = appDir.absoluteFilePath("config/storage");
    if (!appDir.mkpath(configDir)) {
        qWarning() << "无法创建存储设置目录:" << configDir;
        return;
    }
    
    // 保存设置到文件
    QString configFile = configDir + "/settings.json";
    QFile file(configFile);
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "无法打开存储设置文件进行写入:" << configFile;
        return;
    }
    
    QJsonDocument saveDoc(settingsObj);
    file.write(saveDoc.toJson());
    file.close();
    
    qDebug() << "存储设置已保存到:" << configFile;
}

// 录像设置管理方法实现
void DeviceModel::saveVideoSettings(const QString &settingsJson)
{
    qDebug() << "保存录像设置:" << settingsJson;
    
    // 解析JSON字符串
    QJsonDocument doc = QJsonDocument::fromJson(settingsJson.toUtf8());
    if (!doc.isObject()) {
        qWarning() << "录像设置JSON格式错误";
        return;
    }
    
    QJsonObject settingsObj = doc.object();
    
    // 创建存储设置目录
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configDir = appDir.absoluteFilePath("config/storage");
    if (!appDir.mkpath(configDir)) {
        qWarning() << "无法创建存储设置目录:" << configDir;
        return;
    }
    
    // 保存设置到文件
    QString configFile = configDir + "/video_settings.json";
    QFile file(configFile);
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "无法打开录像设置文件进行写入:" << configFile;
        return;
    }
    
    QJsonDocument saveDoc(settingsObj);
    file.write(saveDoc.toJson());
    file.close();
    
    qDebug() << "录像设置已保存到:" << configFile;
}

QString DeviceModel::getVideoSettings(const QString &key)
{
    // 读取录像设置文件
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configFile = appDir.absoluteFilePath("config/storage/video_settings.json");
    
    QFile file(configFile);
    if (!file.exists() || !file.open(QIODevice::ReadOnly)) {
        qDebug() << "录像设置文件不存在或无法打开，返回默认值";
        // 返回默认值
        if (key == "videoFormat") {
            return "MP4";
        } else if (key == "manualVideoPath") {
            return "D:/ZG_Client/Video";
        } else if (key == "alarmVideoPath") {
            return "D:/ZG_Client/Alarm_video";
        }
        return QString();
    }
    
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();
    
    if (!doc.isObject()) {
        qWarning() << "录像设置文件格式错误";
        return QString();
    }
    
    QJsonObject settingsObj = doc.object();
    return settingsObj.value(key).toString();
}

QString DeviceModel::getStorageSettings(const QString &key)
{
    // 读取存储设置文件
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configFile = appDir.absoluteFilePath("config/storage/settings.json");
    
    QFile file(configFile);
    if (!file.exists() || !file.open(QIODevice::ReadOnly)) {
        qDebug() << "存储设置文件不存在或无法打开，返回默认值";
        // 返回默认值
        if (key == "photoPath") {
            return "D:/ZG_Client/Photo";
        } else if (key == "alarmPhotoPath") {
            return "D:/ZG_Client/Alarm_Photo";
        } else if (key == "photoFormat") {
            return "JPEG";
        } else if (key == "photoRatio") {
            return "16:9";
        } else if (key == "photoQuality") {
            return "95";
        } else if (key == "photoResolution") {
            return "16:9";
        } else if (key == "alarmPhotoFormat") {
            return "JPEG";
        } else if (key == "alarmPhotoQuality") {
            return "95";
        } else if (key == "alarmPhotoResolution") {
            return "16:9";
        }
        return QString();
    }
    
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();
    
    if (!doc.isObject()) {
        qWarning() << "存储设置文件格式错误";
        return QString();
    }
    
    QJsonObject settingsObj = doc.object();
    return settingsObj.value(key).toString();
}