#include "devicemodel.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QDebug>
#include <QTimer>
#include <QThread>
#include <QDateTime>
#include <QCoreApplication>
#include <QDir>
#include <QProcess>
#include "hikvision_ctrl.h"
#include "../frame_provider.h"
#include "../ptz_device_manager.h"
#include "../thermal_device_manager.h"
#include "../ptz_device_cgi.h"
#include "../playermanager.h"
#include "../systemlog.h"

class DeviceStatusWorkerThread : public QThread {
public:
    DeviceStatusWorkerThread(DeviceModel* model, const QList<DeviceInfo>& devices)
        : m_model(model), m_devices(devices) {}
protected:
    void run() override {
        for (const auto& device : m_devices) {
            bool visibleLightOnline = true;
            if (!device.visibleLightIp.isEmpty()) {
                visibleLightOnline = m_model->pingDevice(device.visibleLightIp);
            }
            bool infraredOnline = true;
            if (!device.infraredIp.isEmpty()) {
                infraredOnline = m_model->pingDevice(device.infraredIp);
            }
            bool hikvisionOnline = true;
            if (!device.hikvisionIp.isEmpty()) {
                hikvisionOnline = m_model->pingDevice(device.hikvisionIp);
            }

            bool isOnline = false;
            
            bool hasConfig = false;
            bool allConfiguredOnline = true;

            if (!device.visibleLightIp.isEmpty()) {
                hasConfig = true;
                if (!visibleLightOnline) allConfiguredOnline = false;
            }
            if (!device.infraredIp.isEmpty()) {
                hasConfig = true;
                if (!infraredOnline) allConfiguredOnline = false;
            }
            if (!device.hikvisionIp.isEmpty()) {
                hasConfig = true;
                if (!hikvisionOnline) allConfiguredOnline = false;
            }

            if (hasConfig) {
                isOnline = allConfiguredOnline;
            } else {
                isOnline = true;
            }

            QMetaObject::invokeMethod(m_model, "onDeviceStatusComputed", Qt::QueuedConnection,
                                      Q_ARG(QString, device.deviceId),
                                      Q_ARG(bool, isOnline),
                                      Q_ARG(bool, hikvisionOnline));
        }
    }
private:
    DeviceModel* m_model;
    QList<DeviceInfo> m_devices;
};

DeviceModel* DeviceModel::m_instance = nullptr;

DeviceModel::DeviceModel(QObject *parent)
    : QAbstractListModel(parent)
    , m_treeModel(nullptr)
    , m_hikvisionCtrl(nullptr)
{
    // 初始化默认设备分组
    
    // 加载分组信息
    loadGroupsFromFile();
    
    // 启动设备状态检查定时器
    QTimer *statusTimer = new QTimer(this);
    connect(statusTimer, &QTimer::timeout, this, &DeviceModel::checkDeviceStatus);
    statusTimer->start(5000); // 每5秒检查一次设备状态
}

DeviceModel* DeviceModel::instance()
{
    if (!m_instance) {
        m_instance = new DeviceModel();
    }
    return m_instance;
}

int DeviceModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    return m_devices.size();
}

QVariant DeviceModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || index.row() >= m_devices.size())
        return QVariant();

    const DeviceInfo &device = m_devices[index.row()];

    switch (role) {
    case DeviceIdRole:
        return device.deviceId;
    case DeviceNameRole:
        return device.deviceName;
    case DeviceTypeRole:
        return device.deviceType;
    case VisibleLightIpRole:
        return device.visibleLightIp;
    case InfraredIpRole:
        return device.infraredIp;
    case HikvisionIpRole:
        return device.hikvisionIp;
    case PortRole:
        return device.port;
    case VisibleLightUsernameRole:
        return device.visibleLightUsername;
    case VisibleLightPasswordRole:
        return device.visibleLightPassword;
    case InfraredUsernameRole:
        return device.infraredUsername;
    case InfraredPasswordRole:
        return device.infraredPassword;
    case HikvisionUsernameRole:
        return device.hikvisionUsername;
    case HikvisionPasswordRole:
        return device.hikvisionPassword;
    case HikvisionPortRole:
        return device.hikvisionPort;
    case InfraredDownloadChannelRole:
        return device.infraredDownloadChannel;
    case VisibleLightDownloadChannelRole:
        return device.visibleLightDownloadChannel;
    case AlarmConcentrationRole:
        return device.alarmConcentration;
    case AlarmRecordDurationRole:
        return device.alarmRecordDuration;
    case AlarmOutputDurationRole:
        return device.alarmOutputDuration;
    case AlarmDetectionDurationRole:
        return device.alarmDetectionDuration;
    case CruiseIntervalDurationRole:
        return device.cruiseIntervalDuration;
    case VisibleLightUrlRole:
        return device.visibleLightUrl;
    case InfraredUrlRole:
        return device.infraredUrl;
    case VisibleLightRecordUrlRole:
        return device.visibleLightRecordUrl;
    case InfraredRecordUrlRole:
        return device.infraredRecordUrl;
    case RecordUrlbaseRole:
        return device.recordUrlbase;
    case GroupNameRole:
        return device.groupName;
    case IsOnlineRole:
        return device.isOnline;
    case HikvisionOnlineRole:
        return device.hikvisionOnline;
    case IsSelectedRole:
        return device.isSelected;
    case ChannelIndexRole:
        return device.channelIndex;
    case IsInfraredSelectedRole:
        return device.isInfraredSelected;
    case LaserStateRole:
        return device.laserState;
    case WiperStateRole:
        return device.wiperState;
    case FlapStateRole:
        return device.flapState;
    case ScanModeRole:
        return device.scanMode;
    case PanoramaPathRole:
        return device.panoramaPath;
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> DeviceModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[DeviceIdRole] = "deviceId";
    roles[DeviceNameRole] = "deviceName";
    roles[DeviceTypeRole] = "deviceType";
    roles[VisibleLightIpRole] = "visibleLightIp";
    roles[InfraredIpRole] = "infraredIp";
    roles[HikvisionIpRole] = "hikvisionIp";
    roles[PortRole] = "port";
    roles[VisibleLightUsernameRole] = "visibleLightUsername";
    roles[VisibleLightPasswordRole] = "visibleLightPassword";
    roles[InfraredUsernameRole] = "infraredUsername";
    roles[InfraredPasswordRole] = "infraredPassword";
    roles[HikvisionUsernameRole] = "hikvisionUsername";
    roles[HikvisionPasswordRole] = "hikvisionPassword";
    roles[HikvisionPortRole] = "hikvisionPort";
    roles[InfraredDownloadChannelRole] = "infraredDownloadChannel";
    roles[VisibleLightDownloadChannelRole] = "visibleLightDownloadChannel";
    roles[AlarmConcentrationRole] = "alarmConcentration";
    roles[AlarmRecordDurationRole] = "alarmRecordDuration";
    roles[AlarmOutputDurationRole] = "alarmOutputDuration";
    roles[AlarmDetectionDurationRole] = "alarmDetectionDuration";
    roles[CruiseIntervalDurationRole] = "cruiseIntervalDuration";
    roles[VisibleLightUrlRole] = "visibleLightUrl";
    roles[InfraredUrlRole] = "infraredUrl";
    roles[VisibleLightRecordUrlRole] = "visibleLightRecordUrl";
    roles[InfraredRecordUrlRole] = "infraredRecordUrl";
    roles[RecordUrlbaseRole] = "recordUrlbase";
    roles[GroupNameRole] = "groupName";
    roles[IsOnlineRole] = "isOnline";
    roles[HikvisionOnlineRole] = "hikvisionOnline";
    roles[IsSelectedRole] = "isSelected";
    roles[ChannelIndexRole] = "channelIndex";
    roles[IsInfraredSelectedRole] = "isInfraredSelected";
    roles[LaserStateRole] = "laserState";
    roles[WiperStateRole] = "wiperState";
    roles[FlapStateRole] = "flapState";
    roles[ScanModeRole] = "scanMode";
    roles[PanoramaPathRole] = "panoramaPath";
    return roles;
}

void DeviceModel::addDevice(const DeviceInfo &device, bool saveToFile)
{
    // 确保设备所属分组存在
    if (!device.groupName.isEmpty() && findGroupIndex(device.groupName) < 0) {
        addDeviceGroup(device.groupName);
    }
    
    // 如果channelIndex有效，自动分配播放器
    if (device.channelIndex >= 0) {
        PlayerManager* playerManager = PlayerManager::instance();
        if (playerManager) {
            qDebug() << "为设备" << device.deviceId << "分配播放器到通道" << device.channelIndex;
            
            // 分配播放器给channel
            int playerIndex = playerManager->allocatePlayerForChannel(device.channelIndex);
            qDebug() << "分配的播放器索引: " << playerIndex;
            
            // 设置播放器URL（如果有的话）
            if (!device.visibleLightUrl.isEmpty()) {
                playerManager->setPlayerUrl(device.channelIndex, PlayerManager::VisibleLightLive, device.visibleLightUrl);
                qDebug() << "设置可见光URL: " << device.visibleLightUrl;
            }
            if (!device.infraredUrl.isEmpty()) {
                playerManager->setPlayerUrl(device.channelIndex, PlayerManager::InfraredLive, device.infraredUrl);
                qDebug() << "设置红外URL: " << device.infraredUrl;
            }
            if (!device.visibleLightRecordUrl.isEmpty()) {
                playerManager->setPlayerUrl(device.channelIndex, PlayerManager::VisibleLightRecord, device.visibleLightRecordUrl);
                qDebug() << "设置可见光录像URL: " << device.visibleLightRecordUrl;
            }
            if (!device.infraredRecordUrl.isEmpty()) {
                playerManager->setPlayerUrl(device.channelIndex, PlayerManager::InfraredRecord, device.infraredRecordUrl);
                qDebug() << "设置红外录像URL: " << device.infraredRecordUrl;
            }
        } else {
            qWarning() << "PlayerManager实例未找到，无法分配播放器";
        }
    }
    
    beginInsertRows(QModelIndex(), m_devices.size(), m_devices.size());
    m_devices.append(device);
    endInsertRows();
    
    // 同时更新树形模型
    if (m_treeModel) {
        // 确保分组存在于树模型中
        if (!device.groupName.isEmpty()) {
            // 检查分组是否已存在于DeviceModel的分组列表中
            bool groupExists = false;
            for (const auto &group : m_deviceGroups) {
                if (group.groupName == device.groupName) {
                    groupExists = true;
                    break;
                }
            }
            
            // 如果分组不存在，先添加分组
            if (!groupExists) {
                qDebug() << "DeviceModel::addDevice - 分组不存在，先添加分组:" << device.groupName;
                addDeviceGroup(device.groupName);
            } else {
                // 确保分组也存在于树模型中
                qDebug() << "DeviceModel::addDevice - 确保分组存在于树模型中:" << device.groupName;
                m_treeModel->addGroup(device.groupName);
            }
        }
        
        qDebug() << "DeviceModel::addDevice - 添加设备到树模型:" << device.deviceName << "分组:" << device.groupName;
        m_treeModel->addDevice(device);
    } else {
        qDebug() << "DeviceModel::addDevice - 树模型为空!";
    }
    
    // 只有在需要保存到文件时才执行保存操作
    if (saveToFile) {
        
        // 保存设备信息到文件
        QString appDir = QCoreApplication::applicationDirPath();
        QString deviceInfoDir = appDir + "/config/deviceinfo";
        QDir dir(deviceInfoDir);
        if (!dir.exists()) {
            dir.mkpath(".");
        }        
        QString deviceFilePath = deviceInfoDir + "/" + device.deviceId + ".json";
        saveDevicesToFile(deviceFilePath, device);

    }
    
    updateDeviceGroups();
        emit deviceAdded(device.deviceId);
        emit deviceCountsChanged();
        emit treeModelChanged(); // 发出树模型变化信号
    
    // 记录系统日志
    QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    SystemLog::instance()->addLog(
        "admin", // 操作账户
        LOG_TYPE_OPERATION, // 日志类型：操作日志
        ACTION_TYPE_ADD_DEVICE, // 操作类型：添加设备
        currentTime, // 操作时间
        device.visibleLightIp, // 操作IP
        RESULT_SUCCESS, // 操作结果：成功
        QString("添加设备：%1 (IP: %2, 通道: %3, 分组: %4)")
            .arg(device.deviceName)
            .arg(device.visibleLightIp)
            .arg(device.channelIndex)
            .arg(device.groupName) // 操作描述
    );
}

void DeviceModel::addDevice(const QVariantMap &deviceData)
{
    qDebug() << "Adding device:" << deviceData;
    DeviceInfo device;
    
    // 从QVariantMap中提取设备信息
    device.deviceId = deviceData.value("deviceId").toString();
    device.deviceName = deviceData.value("deviceName").toString();
    device.deviceType = deviceData.value("deviceType", "PTZ").toString();
    device.visibleLightIp = deviceData.value("visibleLightIp").toString();
    device.infraredIp = deviceData.value("infraredIp").toString();
    device.tdlasIp = deviceData.value("tdlasIp").toString();
    device.modbusIp = deviceData.value("modbusIp").toString();
    device.tofIp = deviceData.value("tofIp").toString();
    device.hikvisionIp = deviceData.value("hikvisionIp").toString();
    device.port = deviceData.value("port", 80).toInt();
    device.tdlasPort = deviceData.value("tdlasPort", 502).toInt();
    device.modbusPort = deviceData.value("modbusPort", 502).toInt();
    device.tofPort = deviceData.value("tofPort", 80).toInt();
    device.visibleLightUsername = deviceData.value("visibleLightUsername").toString();
    device.visibleLightPassword = deviceData.value("visibleLightPassword").toString();
    device.infraredUsername = deviceData.value("infraredUsername").toString();
    device.infraredPassword = deviceData.value("infraredPassword").toString();
    device.hikvisionUsername = deviceData.value("hikvisionUsername").toString();
    device.hikvisionPassword = deviceData.value("hikvisionPassword").toString();
    device.hikvisionPort = deviceData.value("hikvisionPort", 8000).toInt();
    device.infraredDownloadChannel = deviceData.value("infraredDownloadChannel", 1).toInt();
    device.visibleLightDownloadChannel = deviceData.value("visibleLightDownloadChannel", 1).toInt();
    device.alarmConcentration = deviceData.value("alarmConcentration", 1000).toInt();
    device.alarmRecordDuration = deviceData.value("alarmRecordDuration", 30).toInt();
    device.alarmOutputDuration = deviceData.value("alarmOutputDuration", 10).toInt();
    device.alarmDetectionDuration = deviceData.value("alarmDetectionDuration", 15000).toInt();
    device.cruiseIntervalDuration = deviceData.value("cruiseIntervalDuration", 15000).toInt();
    device.groupName = deviceData.value("groupName").toString();
    device.channelIndex = deviceData.value("channelIndex", -1).toInt();
    device.isOnline = deviceData.value("isOnline", false).toBool();
    device.hikvisionOnline = deviceData.value("hikvisionOnline", true).toBool();
    device.isSelected = deviceData.value("isSelected", false).toBool();
    device.isInfraredSelected = deviceData.value("isInfraredSelected", false).toBool();
    
    // 初始化设备状态字段（默认为false）
    device.laserState = deviceData.value("laserState", false).toBool();
    device.wiperState = deviceData.value("wiperState", false).toBool();
    device.flapState = deviceData.value("flapState", false).toBool();
    device.scanMode = deviceData.value("scanMode", 0).toInt();
    device.panoramaPath = deviceData.value("panoramaPath").toString();
    
    qDebug() << "Adding device: device.tdlasPort" << device.tdlasPort;

    // 可见光IP连通性测试
    if (!device.visibleLightIp.isEmpty() ) {
        if (deviceData.contains("visibleLightUrl")) {
            device.visibleLightUrl = deviceData["visibleLightUrl"].toString();
            qDebug() << "111 Adding device: device.visibleLightUrl" << device.visibleLightUrl;
        } else {
            device.visibleLightUrl = QString("rtsp://%1:%2@%3/video2")
                .arg(device.visibleLightUsername)
                .arg(device.visibleLightPassword)
                .arg(device.visibleLightIp);
                qDebug() << "222 Adding device: device.visibleLightUrl" << device.visibleLightUrl;
        }
    } else {
        device.visibleLightUrl = QString();
        qDebug() << "可见光IP不可用:" << device.visibleLightIp << "，清空流URL";
    }
    
    // 红外IP连通性测试
    if (!device.infraredIp.isEmpty() ) {
        if (deviceData.contains("infraredUrl")) {
            device.infraredUrl = deviceData["infraredUrl"].toString();
        } else {
            device.infraredUrl = QString("rtsp://%1:%2@%3:554/live?channel=0&subtype=1")
                .arg(device.infraredUsername)
                .arg(device.infraredPassword)
                .arg(device.infraredIp);
        }
    } else {
        device.infraredUrl = QString();
        qDebug() << "红外IP不可用:" << device.infraredIp << "，清空流URL";
    }
    
    // NVR IP连通性测试
    device.visibleLightRecordUrl = QString();
    device.infraredRecordUrl = QString();
    
    if (!device.hikvisionIp.isEmpty()) {
        if (deviceData.contains("recordUrlbase")) {
            device.recordUrlbase = deviceData["recordUrlbase"].toString();
        } else {
            device.recordUrlbase = QString("rtsp://%1:%2@%3:554/Streaming/tracks")
                .arg(device.hikvisionUsername)
                .arg(device.hikvisionPassword)
                .arg(device.hikvisionIp);
        }
        
        // device.visibleLightRecordUrl = generateRecordUrl(device.recordUrlbase, device.hikvisionIp, 
        //                                                device.hikvisionPort, device.hikvisionUsername, 
        //                                                device.hikvisionPassword, device.visibleLightIp);
        // device.infraredRecordUrl = generateRecordUrl(device.recordUrlbase, device.hikvisionIp, 
        //                                            device.hikvisionPort, device.hikvisionUsername, 
        //                                            device.hikvisionPassword, device.infraredIp);
    } else {
        device.recordUrlbase = QString();
        qDebug() << "NVR IP不可用:" << device.hikvisionIp << "，清空录像相关URL";
    }
    
    // 调用原始的addDevice方法
    addDevice(device, true);
}

void DeviceModel::removeDevice(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    qDebug() << "removeDevice: deviceId =" << deviceId << "index =" << index;
    
    // 获取设备信息用于日志记录
    DeviceInfo deviceToRemove;
    if (index >= 0) {
        deviceToRemove = m_devices[index];
    }
    
    if (index >= 0) {
        // 在移除设备前，先清理相关的播放器和FrameProvider连接
        PlayerManager* playerManager = PlayerManager::instance();
        if (playerManager) {
            playerManager->cleanupDeviceChannels(deviceId);
        }
        
        // 删除设备配置文件
        QString configPath = QCoreApplication::applicationDirPath() + "/config/deviceinfo/" + deviceId + ".json";
        qDebug() << "removeDevice: 删除设备配置文件:" << configPath;
        QFile configFile(configPath);
        if (configFile.exists()) {
            if (configFile.remove()) {
                qDebug() << "设备配置文件已删除:" << configPath;
            } else {
                qWarning() << "删除设备配置文件失败:" << configPath;
            }
        }
        
        beginRemoveRows(QModelIndex(), index, index);
        m_devices.removeAt(index);
        endRemoveRows();
        
        // 同时从树形模型中移除
        if (m_treeModel) {
            m_treeModel->removeDevice(deviceId);
        }
        
        updateDeviceGroups();
        emit deviceRemoved(deviceId);
        emit deviceCountsChanged();
        emit treeModelChanged(); // 发出树模型变化信号
        
        // 记录系统日志
        QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
        SystemLog::instance()->addLog(
            "admin", // 操作账户
            LOG_TYPE_OPERATION, // 日志类型：操作日志
            ACTION_TYPE_DELETE_DEVICE, // 操作类型：删除设备
            currentTime, // 操作时间
            deviceToRemove.visibleLightIp, // 操作IP
            RESULT_SUCCESS, // 操作结果：成功
            QString("删除设备：%1 (IP: %2, 通道: %3, 分组: %4)")
                .arg(deviceToRemove.deviceName)
                .arg(deviceToRemove.visibleLightIp)
                .arg(deviceToRemove.channelIndex)
                .arg(deviceToRemove.groupName) // 操作描述
        );
    }
    qDebug() << "removeDevice: returning" << m_devices.size() << "devices";
}

void DeviceModel::modifyDevice(const QString &deviceId, const QVariantMap &deviceData)
{
    qDebug() << "modifyDevice: deviceId =" << deviceId;
    
    // 获取修改前的设备信息用于日志记录
    DeviceInfo oldDevice;
    int oldIndex = findDeviceIndex(deviceId);
    if (oldIndex >= 0) {
        oldDevice = m_devices[oldIndex];
    }
    
    // 先删除原设备配置文件
    QString configPath = QCoreApplication::applicationDirPath() + "/config/deviceinfo/" + deviceId + ".json";
    QFile configFile(configPath);
    if (configFile.exists()) {
        if (configFile.remove()) {
            qDebug() << "原设备配置文件已删除:" << configPath;
        } else {
            qWarning() << "删除原设备配置文件失败:" << configPath;
        }
    }
    
    // 如果设备ID发生变化，需要先从内存中移除旧设备
    QString newDeviceId = deviceData["deviceId"].toString();
    if (newDeviceId != deviceId) {
        int index = findDeviceIndex(deviceId);
        if (index >= 0) {
            beginRemoveRows(QModelIndex(), index, index);
            m_devices.removeAt(index);
            endRemoveRows();
            
            // 同时从树形模型中移除
            if (m_treeModel) {
                m_treeModel->removeDevice(deviceId);
            }
        }
    }
    
    // 调用addDevice方法添加修改后的设备，并保存到文件
    addDevice(deviceData);
    
    // 记录系统日志
    QString currentTime = QDateTime::currentDateTime().toString("yyyy-MM-dd HH:mm:ss");
    QString logDescription;
    
    if (newDeviceId != deviceId) {
        logDescription = QString("修改设备：%1 -> %2 (IP: %3, 通道: %4, 分组: %5)")
            .arg(oldDevice.deviceName)
            .arg(deviceData["deviceName"].toString())
            .arg(deviceData["visibleLightIp"].toString())
            .arg(deviceData["channelIndex"].toInt())
            .arg(deviceData["groupName"].toString());
    } else {
        logDescription = QString("修改设备：%1 (IP: %2, 通道: %3, 分组: %4)")
            .arg(deviceData["deviceName"].toString())
            .arg(deviceData["visibleLightIp"].toString())
            .arg(deviceData["channelIndex"].toInt())
            .arg(deviceData["groupName"].toString());
    }
    
    SystemLog::instance()->addLog(
        "admin", // 操作账户
        LOG_TYPE_OPERATION, // 日志类型：操作日志
        ACTION_TYPE_MODIFY_DEVICE, // 操作类型：修改设备
        currentTime, // 操作时间
        deviceData["visibleLightIp"].toString(), // 操作IP
        RESULT_SUCCESS, // 操作结果：成功
        logDescription // 操作描述
    );
    
    qDebug() << "modifyDevice: 设备修改完成";
}

void DeviceModel::updateDevice(const DeviceInfo &device)
{
    int index = findDeviceIndex(device.deviceId);
    if (index >= 0) {
            // 确保设备所属分组存在
            if (!device.groupName.isEmpty() && findGroupIndex(device.groupName) < 0) {
                addDeviceGroup(device.groupName);
            }
        
        m_devices[index] = device;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        
        // 同时更新树形模型
        if (m_treeModel) {
            m_treeModel->updateDevice(device);
        }
        
        // 保存更新后的设备信息到文件
        QString appDir = QCoreApplication::applicationDirPath();
        QString deviceInfoDir = appDir + "/config/deviceinfo";
        QString deviceFilePath = deviceInfoDir + "/" + device.deviceId + ".json";
        saveDevicesToFile(deviceFilePath, device);
        
        updateDeviceGroups();
        emit deviceUpdated(device.deviceId);
    }
}

DeviceInfo DeviceModel::getDevice(const QString &deviceId)
{
    //qDebug() << "getDevice: deviceId =" << deviceId;
    int index = findDeviceIndex(deviceId);
    //qDebug() << "getDevice: found index =" << index;
    if (index >= 0) {
        //qDebug() << "getDevice: returning device with infraredDownloadChannel =" << m_devices[index].infraredDownloadChannel;
        //qDebug() << "getDevice: returning device with visibleLightDownloadChannel =" << m_devices[index].visibleLightDownloadChannel;
        return m_devices[index];
    }
    //qDebug() << "getDevice: device not found, returning empty DeviceInfo";
    return DeviceInfo{};
}

int DeviceModel::getTotalDevices() const
{
    return m_devices.size();
}

int DeviceModel::getOnlineDevices() const
{
    int count = 0;
    for (const auto &device : m_devices) {
        if (device.isOnline) {
            count++;
        }
    }
    return count;
}

int DeviceModel::getOfflineDevices() const
{
    int count = 0;
    for (const auto &device : m_devices) {
        if (!device.isOnline) {
            count++;
        }
    }
    return count;
}

QVariantMap DeviceModel::getDeviceAsVariant(const QString &deviceId) const
{
    QVariantMap deviceMap;
    int index = findDeviceIndex(deviceId);
    
    if (index >= 0) {
        const DeviceInfo &device = m_devices[index];
        deviceMap["deviceId"] = device.deviceId;
        deviceMap["deviceName"] = device.deviceName;
        deviceMap["deviceType"] = device.deviceType;
        deviceMap["visibleLightIp"] = device.visibleLightIp;
        deviceMap["infraredIp"] = device.infraredIp;
        deviceMap["tdlasIp"] = device.tdlasIp;
        deviceMap["modbusIp"] = device.modbusIp;
        deviceMap["tofIp"] = device.tofIp;
        deviceMap["hikvisionIp"] = device.hikvisionIp;
        deviceMap["port"] = device.port;
        deviceMap["tdlasPort"] = device.tdlasPort;
        deviceMap["modbusPort"] = device.modbusPort;
        deviceMap["tofPort"] = device.tofPort;
        deviceMap["visibleLightUsername"] = device.visibleLightUsername;
        deviceMap["visibleLightPassword"] = device.visibleLightPassword;
        deviceMap["infraredUsername"] = device.infraredUsername;
        deviceMap["infraredPassword"] = device.infraredPassword;
        deviceMap["hikvisionUsername"] = device.hikvisionUsername;
        deviceMap["hikvisionPassword"] = device.hikvisionPassword;
        deviceMap["hikvisionPort"] = device.hikvisionPort;
        deviceMap["infraredDownloadChannel"] = device.infraredDownloadChannel;
        deviceMap["visibleLightDownloadChannel"] = device.visibleLightDownloadChannel;
        deviceMap["alarmConcentration"] = device.alarmConcentration;
        deviceMap["alarmRecordDuration"] = device.alarmRecordDuration;
        deviceMap["alarmOutputDuration"] = device.alarmOutputDuration;
        deviceMap["alarmDetectionDuration"] = device.alarmDetectionDuration;
        deviceMap["cruiseIntervalDuration"] = device.cruiseIntervalDuration;
        deviceMap["visibleLightUrl"] = device.visibleLightUrl;
        deviceMap["infraredUrl"] = device.infraredUrl;
        deviceMap["visibleLightRecordUrl"] = device.visibleLightRecordUrl;
        deviceMap["infraredRecordUrl"] = device.infraredRecordUrl;
        deviceMap["recordUrlbase"] = device.recordUrlbase;
        deviceMap["groupName"] = device.groupName;
        deviceMap["isOnline"] = device.isOnline;
        deviceMap["isSelected"] = device.isSelected;
        deviceMap["channelIndex"] = device.channelIndex;
        deviceMap["isInfraredSelected"] = device.isInfraredSelected;
    }
    
    return deviceMap;
}

DeviceInfo DeviceModel::getDeviceByIndex(int index)
{
    if (index >= 0 && index < m_devices.size()) {
        return m_devices[index];
    }
    return DeviceInfo{};
}

QList<DeviceInfo> DeviceModel::getAllDevices() const
{
    qDebug() << "getAllDevices: returning" << m_devices.size() << "devices";
    return m_devices;
}

void DeviceModel::selectDevice(const QString &deviceId)
{
    // 清除之前的选择
    for (int i = 0; i < m_devices.size(); ++i) {
        if (m_devices[i].isSelected) {
            m_devices[i].isSelected = false;
            QModelIndex index = this->index(i);
            emit dataChanged(index, index);
        }
    }
    
    // 设置新的选择
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        // 懒加载初始化设备
        // 只有当FrameProvider已注册时才尝试初始化（避免启动时selectDevice导致过早初始化，此时FrameProvider尚未创建）
        if (m_channelFrameProvidersVL.contains(m_devices[index].channelIndex)) {
            initializeChannelDevice(m_devices[index].channelIndex);
        }

        m_devices[index].isSelected = true;
        m_selectedDeviceId = deviceId;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        emit deviceSelected(deviceId);
    }
}

void DeviceModel::selectDeviceByIndex(int index)
{
    if (index >= 0 && index < m_devices.size()) {
        selectDevice(m_devices[index].deviceId);
    }
}

void DeviceModel::setDeviceOnlineStatus(const QString &deviceId, bool isOnline)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].isOnline != isOnline) {
        m_devices[index].isOnline = isOnline;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        emit deviceStatusChanged(deviceId, isOnline);
        emit deviceCountsChanged();
    }
}

void DeviceModel::setDeviceChannelIndex(const QString &deviceId, int channelIndex)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].channelIndex != channelIndex) {
        m_devices[index].channelIndex = channelIndex;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
    }
}

int DeviceModel::getDeviceChannelIndex(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].channelIndex;
    }
    return -1; // 未找到设备
}

QList<DeviceGroup> DeviceModel::getDeviceGroups() const
{
    qDebug() << "getDeviceGroups: returning" << m_deviceGroups.size() << "device groups";
    return m_deviceGroups;
}

// QML友好的方法实现
QStringList DeviceModel::getDeviceGroupNames() const
{
    QStringList groupNames;
    for (const auto &group : m_deviceGroups) {
        groupNames.append(group.groupName);
    }
    qDebug() << "getDeviceGroupNames: returning" << groupNames.size() << "group names";
    return groupNames;
}

QVariantList DeviceModel::getAllDevicesAsVariant() const
{
    QVariantList deviceList;
    qDebug() << "getAllDevicesAsVariant: returning" << m_devices.size() << "devices";
    for (const auto &device : m_devices) {
        QVariantMap deviceMap;
        deviceMap["deviceId"] = device.deviceId;
        deviceMap["deviceName"] = device.deviceName;
        deviceMap["deviceType"] = device.deviceType;
        deviceMap["visibleLightIp"] = device.visibleLightIp;
        deviceMap["infraredIp"] = device.infraredIp;
        deviceMap["tdlasIp"] = device.tdlasIp;
        deviceMap["modbusIp"] = device.modbusIp;
        deviceMap["tofIp"] = device.tofIp;
        deviceMap["hikvisionIp"] = device.hikvisionIp;
        deviceMap["port"] = device.port;
        deviceMap["tdlasPort"] = device.tdlasPort;
        deviceMap["modbusPort"] = device.modbusPort;
        deviceMap["tofPort"] = device.tofPort;
        deviceMap["visibleLightUsername"] = device.visibleLightUsername;
        deviceMap["visibleLightPassword"] = device.visibleLightPassword;
        deviceMap["infraredUsername"] = device.infraredUsername;
        deviceMap["infraredPassword"] = device.infraredPassword;
        deviceMap["hikvisionUsername"] = device.hikvisionUsername;
        deviceMap["hikvisionPassword"] = device.hikvisionPassword;
        deviceMap["hikvisionPort"] = device.hikvisionPort;
        deviceMap["infraredDownloadChannel"] = device.infraredDownloadChannel;
        deviceMap["visibleLightDownloadChannel"] = device.visibleLightDownloadChannel;
        deviceMap["alarmConcentration"] = device.alarmConcentration;
        deviceMap["alarmRecordDuration"] = device.alarmRecordDuration;
        deviceMap["alarmOutputDuration"] = device.alarmOutputDuration;
        deviceMap["visibleLightUrl"] = device.visibleLightUrl;
        deviceMap["infraredUrl"] = device.infraredUrl;
        deviceMap["visibleLightRecordUrl"] = device.visibleLightRecordUrl;
        deviceMap["infraredRecordUrl"] = device.infraredRecordUrl;
        deviceMap["recordUrlbase"] = device.recordUrlbase;
        deviceMap["groupName"] = device.groupName;
        deviceMap["isOnline"] = device.isOnline;
        deviceMap["isSelected"] = device.isSelected;
        deviceMap["channelIndex"] = device.channelIndex;
        deviceMap["isInfraredSelected"] = device.isInfraredSelected;
        deviceList.append(deviceMap);
    }
    qDebug() << "getAllDevicesAsVariant: returning" << deviceList.size() << "devices";
    return deviceList;
}

void DeviceModel::addDeviceGroup(const QString &groupName)
{
    // 检查分组是否已存在
    for (const auto &group : m_deviceGroups) {
        if (group.groupName == groupName) {
            return;
        }
    }
    
    DeviceGroup newGroup;
    newGroup.groupName = groupName;
    newGroup.isExpanded = true;
    m_deviceGroups.append(newGroup);
    
    // 保存分组信息到文件
    saveGroupsToFile();
    
    // 同时更新树形模型
    if (m_treeModel) {
        qDebug() << "DeviceModel::addDeviceGroup - adding group to tree model:" << groupName;
        m_treeModel->addGroup(groupName);
    }
    
    // 发出树模型变化信号
    emit treeModelChanged();
}

void DeviceModel::removeDeviceGroup(const QString &groupName)
{
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == groupName) {
            // 删除该分组下的所有设备
            QStringList deviceIdsToRemove;
            for (int j = 0; j < m_devices.size(); ++j) {
                if (m_devices[j].groupName == groupName) {
                    deviceIdsToRemove.append(m_devices[j].deviceId);
                }
            }
            
            // 移除设备
            for (const QString &deviceId : deviceIdsToRemove) {
                removeDevice(deviceId);
            }
            
            m_deviceGroups.removeAt(i);
            
            // 保存分组信息到文件
            saveGroupsToFile();
            
            // 同时更新树形模型
            if (m_treeModel) {
                qDebug() << "DeviceModel::removeDeviceGroup - removing group from tree model:" << groupName;
                m_treeModel->removeGroup(groupName);
            }
            
            // 发出树模型变化信号
            emit treeModelChanged();
            break;
        }
    }
}

void DeviceModel::modifyDeviceGroupName(const QString &oldName, const QString &newName)
{
    // 检查新分组名是否已存在
    for (const auto &group : m_deviceGroups) {
        if (group.groupName == newName) {
            qDebug() << "分组名已存在:" << newName;
            return;
        }
    }
    
    // 更新分组列表中的分组名
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == oldName) {
            m_deviceGroups[i].groupName = newName;
            break;
        }
    }
    
    // 更新所有属于该分组的设备的分组名
    for (int i = 0; i < m_devices.size(); ++i) {
        if (m_devices[i].groupName == oldName) {
            m_devices[i].groupName = newName;
            QModelIndex index = this->index(i);
            emit dataChanged(index, index);
            
            // 保存更新后的设备信息到文件
            QString appDir = QCoreApplication::applicationDirPath();
            QString deviceInfoDir = appDir + "/config/deviceinfo";
            QString deviceFilePath = deviceInfoDir + "/" + m_devices[i].deviceId + ".json";
            saveDevicesToFile(deviceFilePath, m_devices[i]);
        }
    }
    
    // 同时更新树形模型
    if (m_treeModel) {
        qDebug() << "DeviceModel::modifyDeviceGroupName - updating tree model";
        m_treeModel->modifyGroupName(oldName, newName);
    } else {
        qDebug() << "DeviceModel::modifyDeviceGroupName - no tree model found";
    }
    
    // 更新分组信息
    updateDeviceGroups();
    
    // 保存分组信息到文件
    saveGroupsToFile();
    
    // 发出树模型变化信号
    emit treeModelChanged();
}

void DeviceModel::expandDeviceGroup(const QString &groupName, bool expanded)
{
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == groupName) {
            m_deviceGroups[i].isExpanded = expanded;
            
            // 保存分组信息到文件
            saveGroupsToFile();
            break;
        }
    }
}

QString DeviceModel::getVisibleLightUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightUrl;
}

QString DeviceModel::getInfraredUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredUrl;
}



QString DeviceModel::getSelectedDeviceVisibleLightUrl()
{
    return getVisibleLightUrl(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredUrl()
{
    return getInfraredUrl(m_selectedDeviceId);
}



QString DeviceModel::getVisibleLightRecordUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightRecordUrl;
}

QString DeviceModel::getInfraredRecordUrl(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredRecordUrl;
}

QString DeviceModel::getSelectedDeviceVisibleLightRecordUrl()
{
    return getVisibleLightRecordUrl(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredRecordUrl()
{
    return getInfraredRecordUrl(m_selectedDeviceId);
}

// IP地址管理方法
QString DeviceModel::getVisibleLightIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightIp;
}

QString DeviceModel::getInfraredIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredIp;
}

QString DeviceModel::getTdlasIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.tdlasIp;
}

QString DeviceModel::getSelectedDeviceVisibleLightIp()
{
    return getVisibleLightIp(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredIp()
{
    return getInfraredIp(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceTdlasIp()
{
    return getTdlasIp(m_selectedDeviceId);
}

// 用户名和密码管理方法
QString DeviceModel::getVisibleLightUsername(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightUsername;
}

QString DeviceModel::getVisibleLightPassword(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.visibleLightPassword;
}

QString DeviceModel::getInfraredUsername(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredUsername;
}

QString DeviceModel::getInfraredPassword(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.infraredPassword;
}



QString DeviceModel::getSelectedDeviceVisibleLightUsername()
{
    return getVisibleLightUsername(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceVisibleLightPassword()
{
    return getVisibleLightPassword(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredUsername()
{
    return getInfraredUsername(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceInfraredPassword()
{
    return getInfraredPassword(m_selectedDeviceId);
}



QString DeviceModel::getDeviceUrlByChannelIndex(int channelIndex, bool isVisibleLight)
{
    for (const auto &device : m_devices) {
        if (device.channelIndex == channelIndex) {
            return isVisibleLight ? device.visibleLightUrl : device.infraredUrl;
        }
    }
    return QString();
}

QString DeviceModel::getDeviceRecordUrlByChannelIndex(int channelIndex, bool isVisibleLight)
{
    for (const auto &device : m_devices) {
        if (device.channelIndex == channelIndex) {
            return isVisibleLight ? device.visibleLightRecordUrl : device.infraredRecordUrl;
        }
    }
    return QString();
}

QString DeviceModel::getDeviceIdByChannelIndex(int channelIndex)
{
    for (const auto &device : m_devices) {
        if (device.channelIndex == channelIndex) {
            return device.deviceId;
        }
    }
    return QString();
}

int DeviceModel::getChannelCount()
{
    return 9;
}

void DeviceModel::clearAllDevices()
{
    beginResetModel();
    m_devices.clear();
    // 不清空分组信息，因为分组信息需要独立持久化
    // m_deviceGroups.clear();
    endResetModel();
}

QList<int> DeviceModel::getAllDeviceChannelIndexes() const
{
    QList<int> channelIndexes;
    for (const auto &device : m_devices) {
        channelIndexes.append(device.channelIndex);
    }
    return channelIndexes;
}

void DeviceModel::saveDevicesToFile(const QString &filename, const DeviceInfo &device)
{
    QJsonObject deviceObj;
    deviceObj["deviceId"] = device.deviceId;
    deviceObj["deviceName"] = device.deviceName;
    deviceObj["deviceType"] = device.deviceType;
    deviceObj["visibleLightIp"] = device.visibleLightIp;
    deviceObj["infraredIp"] = device.infraredIp;
    deviceObj["tdlasIp"] = device.tdlasIp;
    deviceObj["modbusIp"] = device.modbusIp;
    deviceObj["tofIp"] = device.tofIp;
    deviceObj["hikvisionIp"] = device.hikvisionIp;
    deviceObj["port"] = device.port;
    deviceObj["tdlasPort"] = device.tdlasPort;
    deviceObj["modbusPort"] = device.modbusPort;
    deviceObj["tofPort"] = device.tofPort;
    deviceObj["visibleLightUsername"] = device.visibleLightUsername;
    deviceObj["visibleLightPassword"] = device.visibleLightPassword;
    deviceObj["infraredUsername"] = device.infraredUsername;
    deviceObj["infraredPassword"] = device.infraredPassword;

    deviceObj["hikvisionUsername"] = device.hikvisionUsername;
    deviceObj["hikvisionPassword"] = device.hikvisionPassword;
    deviceObj["hikvisionPort"] = device.hikvisionPort;
    deviceObj["infraredDownloadChannel"] = device.infraredDownloadChannel;
    deviceObj["visibleLightDownloadChannel"] = device.visibleLightDownloadChannel;
    deviceObj["visibleLightUrl"] = device.visibleLightUrl;
    deviceObj["infraredUrl"] = device.infraredUrl;

    deviceObj["visibleLightRecordUrl"] = device.visibleLightRecordUrl;
    deviceObj["infraredRecordUrl"] = device.infraredRecordUrl;
    deviceObj["recordUrlbase"] = device.recordUrlbase;
    deviceObj["groupName"] = device.groupName;
    deviceObj["isOnline"] = device.isOnline;
    deviceObj["hikvisionOnline"] = device.hikvisionOnline;
    deviceObj["isSelected"] = device.isSelected;
    deviceObj["channelIndex"] = device.channelIndex;
    deviceObj["isInfraredSelected"] = device.isInfraredSelected;
    deviceObj["alarmConcentration"] = device.alarmConcentration;
    deviceObj["alarmRecordDuration"] = device.alarmRecordDuration;
    deviceObj["alarmOutputDuration"] = device.alarmOutputDuration;
    deviceObj["alarmDetectionDuration"] = device.alarmDetectionDuration;
    deviceObj["cruiseIntervalDuration"] = device.cruiseIntervalDuration;
    
    // 保存设备状态字段
    deviceObj["laserState"] = device.laserState;
    deviceObj["wiperState"] = device.wiperState;
    deviceObj["flapState"] = device.flapState;
    deviceObj["scanMode"] = device.scanMode;
    deviceObj["panoramaPath"] = device.panoramaPath;
    
    QJsonObject rootObj;
    rootObj["devices"] = QJsonArray({deviceObj});
    
    QJsonDocument doc(rootObj);
    QFile file(filename);
    if (file.open(QIODevice::WriteOnly)) {
        file.write(doc.toJson());
        qDebug() << "设备配置已保存到:" << filename;
    }
}

void DeviceModel::loadDevicesFromFile(const QString &filename)
{
    QFile file(filename);
    if (!file.open(QIODevice::ReadOnly)) {
        qWarning() << "无法打开设备配置文件:" << filename;
        return;
    }
    
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    QJsonObject rootObj = doc.object();
    QJsonArray devicesArray = rootObj["devices"].toArray();
    
    for (const auto &deviceValue : devicesArray) {
        QJsonObject deviceObj = deviceValue.toObject();
        DeviceInfo device;
        device.deviceId = deviceObj["deviceId"].toString();
        device.deviceName = deviceObj["deviceName"].toString();
        device.deviceType = deviceObj["deviceType"].toString();
        device.visibleLightIp = deviceObj["visibleLightIp"].toString();
        device.infraredIp = deviceObj["infraredIp"].toString();
        device.tdlasIp = deviceObj["tdlasIp"].toString();
        device.modbusIp = deviceObj["modbusIp"].toString();
        device.tofIp = deviceObj["tofIp"].toString();
        device.hikvisionIp = deviceObj["hikvisionIp"].toString();
        device.port = deviceObj["port"].toInt();
        device.tdlasPort = deviceObj["tdlasPort"].toInt();
        device.modbusPort = deviceObj["modbusPort"].toInt();
        device.tofPort = deviceObj["tofPort"].toInt();
        device.visibleLightUsername = deviceObj["visibleLightUsername"].toString();
        device.visibleLightPassword = deviceObj["visibleLightPassword"].toString();
        device.infraredUsername = deviceObj["infraredUsername"].toString();
        device.infraredPassword = deviceObj["infraredPassword"].toString();

        device.hikvisionUsername = deviceObj["hikvisionUsername"].toString();
        device.hikvisionPassword = deviceObj["hikvisionPassword"].toString();
        device.hikvisionPort = deviceObj["hikvisionPort"].toInt();
        device.infraredDownloadChannel = deviceObj["infraredDownloadChannel"].toInt();
        device.visibleLightDownloadChannel = deviceObj["visibleLightDownloadChannel"].toInt();
        
        // 可见光IP连通性测试
        if (!device.visibleLightIp.isEmpty()) {
            device.visibleLightUrl = deviceObj["visibleLightUrl"].toString();
        } else {
            device.visibleLightUrl = QString(); // IP不可用，清空URL
            qDebug() << "可见光IP不可用:" << device.visibleLightIp << "，清空流URL";
        }
        
        // 红外IP连通性测试
        if (!device.infraredIp.isEmpty()) {
            device.infraredUrl = deviceObj["infraredUrl"].toString();
        } else {
            device.infraredUrl = QString(); // IP不可用，清空URL
            qDebug() << "红外IP不可用:" << device.infraredIp << "，清空流URL";
        }

        device.visibleLightRecordUrl = QString(); // 初始化为空，后续根据NVR连通性设置
        device.infraredRecordUrl = QString(); // 初始化为空，后续根据NVR连通性设置
        device.recordUrlbase = deviceObj["recordUrlbase"].toString();
        device.groupName = deviceObj["groupName"].toString();
        device.isOnline = true; // 默认设备在线，后续通过checkDeviceStatus检查真实状态
        device.hikvisionOnline = deviceObj["hikvisionOnline"].toBool(true); // 从文件加载海康设备在线状态
        device.isSelected = deviceObj["isSelected"].toBool();
        device.channelIndex = deviceObj["channelIndex"].toInt();
        device.isInfraredSelected = deviceObj["isInfraredSelected"].toBool();
        device.alarmConcentration = deviceObj["alarmConcentration"].toInt();
        device.alarmRecordDuration = deviceObj["alarmRecordDuration"].toInt();
        device.alarmOutputDuration = deviceObj["alarmOutputDuration"].toInt();
        device.alarmDetectionDuration = deviceObj.contains("alarmDetectionDuration") ? deviceObj["alarmDetectionDuration"].toInt() : 15000;
        device.cruiseIntervalDuration = deviceObj.contains("cruiseIntervalDuration") ? deviceObj["cruiseIntervalDuration"].toInt() : 15000;
        
        // 加载设备状态字段（默认为false或0）
        device.laserState = deviceObj["laserState"].toBool(false);
        device.wiperState = deviceObj["wiperState"].toBool(false);
        device.flapState = deviceObj["flapState"].toBool(false);
        device.scanMode = deviceObj["scanMode"].toInt(0); // 默认为0（无扫描）
        device.panoramaPath = deviceObj["panoramaPath"].toString();
        
        if (!device.hikvisionIp.isEmpty() ) {
            // device.visibleLightRecordUrl = generateRecordUrl(device.recordUrlbase, device.hikvisionIp, 
            //                                                 device.hikvisionPort, device.hikvisionUsername, 
            //                                                 device.hikvisionPassword, device.visibleLightIp);
            // device.infraredRecordUrl = generateRecordUrl(device.recordUrlbase, device.hikvisionIp, 
            //                                             device.hikvisionPort, device.hikvisionUsername, 
            //                                             device.hikvisionPassword, device.infraredIp);
        } else {
            qDebug() << "NVR IP不可用:" << device.hikvisionIp << "，清空录像URL";
        }
        
        addDevice(device, false);//从文件读取就不再存文件，避免循环
    }
    
    updateDeviceGroups();
    qDebug() << "设备配置已从文件加载:" << filename;
}

void DeviceModel::loadDefaultDevices()
{
    qDebug() << "DeviceModel::loadDefaultDevices - 开始加载设备配置";
    
    // 首先加载分组信息
    loadGroupsFromFile();
    qDebug() << "DeviceModel::loadDefaultDevices - 已加载分组信息，共" << m_deviceGroups.size() << "个分组";
    
    // 清空现有设备和树模型
    beginResetModel();
    m_devices.clear();
    endResetModel();
    emit deviceCountsChanged();
    
    // 如果有树模型，清空树模型中的所有内容
    if (m_treeModel) {
        qDebug() << "DeviceModel::loadDefaultDevices - 清空树模型";
        m_treeModel->clear();
        
        // 重新添加分组到树模型
        for (const auto &group : m_deviceGroups) {
            qDebug() << "DeviceModel::loadDefaultDevices - 添加分组到树模型:" << group.groupName;
            m_treeModel->addGroup(group.groupName);
        }
    }
    
    // 首先尝试从配置文件加载设备
    QString appDir = QCoreApplication::applicationDirPath();
    QString deviceInfoDir = appDir + "/config/deviceinfo";
    QDir dir(deviceInfoDir);
    
    if (dir.exists()) {
        QStringList deviceFiles = dir.entryList(QStringList() << "*.json", QDir::Files);
        if (!deviceFiles.isEmpty()) {
            qDebug() << "DeviceModel::loadDefaultDevices - 从配置文件加载设备:" << deviceFiles.size() << "个文件";
            
            for (const QString &fileName : deviceFiles) {
                QString filePath = deviceInfoDir + "/" + fileName;
                qDebug() << "DeviceModel::loadDefaultDevices - 加载设备文件:" << filePath;
                loadDevicesFromFile(filePath);
            }
            
            qDebug() << "DeviceModel::loadDefaultDevices - 已从配置文件加载" << m_devices.size() << "个设备";
            
            // 确保设备被正确分配到分组中
            updateDeviceGroups();
            
            // 发出树模型变化信号
            if (m_treeModel) {
                emit treeModelChanged();
            }
            
            return; // 成功加载配置文件后返回
        }
    }
    
    // 如果没有配置文件，使用默认设备
    qDebug() << "DeviceModel::loadDefaultDevices - 未找到配置文件，加载默认设备";
 
}

void DeviceModel::checkDeviceStatus()
{
    QList<DeviceInfo> snapshot = m_devices;
    auto* t = new DeviceStatusWorkerThread(this, snapshot);
    connect(t, &QThread::finished, t, &QObject::deleteLater);
    t->start();
}

void DeviceModel::updateDeviceGroups()
{
    // 清空分组中的设备列表
    for (auto &group : m_deviceGroups) {
        group.devices.clear();
    }
    
    // 重新分配设备到分组
    for (const auto &device : m_devices) {
        int groupIndex = findGroupIndex(device.groupName);
        if (groupIndex >= 0) {
            m_deviceGroups[groupIndex].devices.append(device);
        } else {
            // 如果分组不存在，创建新分组
            addDeviceGroup(device.groupName);
            groupIndex = findGroupIndex(device.groupName);
            if (groupIndex >= 0) {
                m_deviceGroups[groupIndex].devices.append(device);
            }
        }
    }
    
    // 保存分组信息到文件
    saveGroupsToFile();
}

int DeviceModel::findDeviceIndex(const QString &deviceId) const
{
    for (int i = 0; i < m_devices.size(); ++i) {
        if (m_devices[i].deviceId == deviceId) {
            return i;
        }
    }
    return -1;
}

void DeviceModel::onDeviceStatusComputed(const QString &deviceId, bool isOnline, bool hikvisionOnline)
{
    int i = findDeviceIndex(deviceId);
    if (i < 0) return;
    bool wasOnline = m_devices[i].isOnline;
    bool wasHikvisionOnline = m_devices[i].hikvisionOnline;
    
    m_devices[i].isOnline = isOnline;
    m_devices[i].hikvisionOnline = hikvisionOnline;
    
    if (wasOnline != isOnline || wasHikvisionOnline != hikvisionOnline) {
        QModelIndex index = this->index(i);
        emit dataChanged(index, index);
    }
    
    if (wasOnline != isOnline) {
        emit deviceStatusChanged(deviceId, isOnline);
    }
}

bool DeviceModel::getHikvisionOnline(const QString &deviceId)
{
    int i = findDeviceIndex(deviceId);
    if (i >= 0) {
        return m_devices[i].hikvisionOnline;
    }
    return false;
}

bool DeviceModel::getSelectedDeviceHikvisionOnline()
{
    return getHikvisionOnline(m_selectedDeviceId);
}

bool DeviceModel::isDeviceIdExists(const QString &deviceId) const
{
    return findDeviceIndex(deviceId) != -1;
}

bool DeviceModel::isDeviceNameExists(const QString &deviceName) const
{
    for (int i = 0; i < m_devices.size(); ++i) {
        if (m_devices[i].deviceName == deviceName) {
            return true;
        }
    }
    return false;
}

bool DeviceModel::isChannelExists(int channelIndex) const
{
    for (int i = 0; i < m_devices.size(); ++i) {
        if (m_devices[i].channelIndex == channelIndex) {
            return true;
        }
    }
    return false;
}

int DeviceModel::findGroupIndex(const QString &groupName) const
{
    for (int i = 0; i < m_deviceGroups.size(); ++i) {
        if (m_deviceGroups[i].groupName == groupName) {
            return i;
        }
    }
    return -1;
}

// 报警配置管理方法实现
int DeviceModel::getAlarmConcentration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmConcentration;
}

int DeviceModel::getAlarmRecordDuration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmRecordDuration;
}

int DeviceModel::getAlarmOutputDuration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmOutputDuration;
}

int DeviceModel::getAlarmDetectionDuration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.alarmDetectionDuration;
}

void DeviceModel::setAlarmDetectionDuration(const QString &deviceId, int duration)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        m_devices[index].alarmDetectionDuration = duration;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        
        // 保存设备信息到文件
        QString appDir = QCoreApplication::applicationDirPath();
        QString deviceInfoDir = appDir + "/config/deviceinfo";
        QString deviceFilePath = deviceInfoDir + "/" + deviceId + ".json";
        saveDevicesToFile(deviceFilePath, m_devices[index]);
    }
}

int DeviceModel::getSelectedDeviceAlarmConcentration()
{
    return getAlarmConcentration(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceAlarmRecordDuration()
{
    return getAlarmRecordDuration(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceAlarmOutputDuration()
{
    return getAlarmOutputDuration(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceAlarmDetectionDuration()
{
    return getAlarmDetectionDuration(m_selectedDeviceId);
}

void DeviceModel::setSelectedDeviceAlarmDetectionDuration(int duration)
{
    setAlarmDetectionDuration(m_selectedDeviceId, duration);
}

int DeviceModel::getCruiseIntervalDuration(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.cruiseIntervalDuration;
}

void DeviceModel::setCruiseIntervalDuration(const QString &deviceId, int duration)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        m_devices[index].cruiseIntervalDuration = duration;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        
        // 保存设备信息到文件
        QString appDir = QCoreApplication::applicationDirPath();
        QString deviceInfoDir = appDir + "/config/deviceinfo";
        QString deviceFilePath = deviceInfoDir + "/" + deviceId + ".json";
        saveDevicesToFile(deviceFilePath, m_devices[index]);
    }
}

int DeviceModel::getSelectedDeviceCruiseIntervalDuration()
{
    return getCruiseIntervalDuration(m_selectedDeviceId);
}

void DeviceModel::setSelectedDeviceCruiseIntervalDuration(int duration)
{
    setCruiseIntervalDuration(m_selectedDeviceId, duration);
}

// Modbus相关方法实现
QString DeviceModel::getModbusIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.modbusIp;
}

QString DeviceModel::getSelectedDeviceModbusIp()
{
    return getModbusIp(m_selectedDeviceId);
}

 

QString DeviceModel::getTofIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.tofIp;
}

QString DeviceModel::getSelectedDeviceTofIp()
{
    return getTofIp(m_selectedDeviceId);
}





// 海康相关方法实现
QString DeviceModel::getHikvisionUsername(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionUsername;
}

QString DeviceModel::getHikvisionPassword(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionPassword;
}

int DeviceModel::getHikvisionPort(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionPort;
}

QString DeviceModel::getSelectedDeviceHikvisionUsername()
{
    return getHikvisionUsername(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceHikvisionPassword()
{
    return getHikvisionPassword(m_selectedDeviceId);
}

int DeviceModel::getSelectedDeviceHikvisionPort()
{
    return getHikvisionPort(m_selectedDeviceId);
}

int DeviceModel::getInfraredDownloadChannel(const QString &deviceId)
{
    qDebug() << "getInfraredDownloadChannel: deviceId =" << deviceId;
    DeviceInfo device = getDevice(deviceId);
    qDebug() << "getInfraredDownloadChannel: device.infraredDownloadChannel =" << device.infraredDownloadChannel;
    return device.infraredDownloadChannel;
}

int DeviceModel::getVisibleLightDownloadChannel(const QString &deviceId)
{
    qDebug() << "getVisibleLightDownloadChannel: deviceId =" << deviceId;
    DeviceInfo device = getDevice(deviceId);
    qDebug() << "getVisibleLightDownloadChannel: device.visibleLightDownloadChannel =" << device.visibleLightDownloadChannel;
    return device.visibleLightDownloadChannel;
}

int DeviceModel::getSelectedDeviceInfraredDownloadChannel()
{
    qDebug() << "getSelectedDeviceInfraredDownloadChannel: m_selectedDeviceId =" << m_selectedDeviceId;
    int channel = getInfraredDownloadChannel(m_selectedDeviceId);
    qDebug() << "getSelectedDeviceInfraredDownloadChannel: returned channel =" << channel;
    return channel;
}

int DeviceModel::getSelectedDeviceVisibleLightDownloadChannel()
{
    qDebug() << "getSelectedDeviceVisibleLightDownloadChannel: m_selectedDeviceId =" << m_selectedDeviceId;
    int channel = getVisibleLightDownloadChannel(m_selectedDeviceId);
    qDebug() << "getSelectedDeviceVisibleLightDownloadChannel: returned channel =" << channel;
    return channel;
}

int DeviceModel::getSelectedDeviceChannelIndex()
{
    return getDeviceChannelIndex(m_selectedDeviceId);
}

QString DeviceModel::getSelectedDeviceId()
{
    return m_selectedDeviceId;
}

QString DeviceModel::getHikvisionIp(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.hikvisionIp;
}

QString DeviceModel::getSelectedDeviceHikvisionIp()
{
    return getHikvisionIp(m_selectedDeviceId);
}

// 树形模型管理方法
DeviceTreeModel* DeviceModel::getTreeModel() const
{
    return m_treeModel;
}

void DeviceModel::setTreeModel(DeviceTreeModel* treeModel)
{
    if (m_treeModel != treeModel) {
        m_treeModel = treeModel;
        
        // 如果设置了新的树形模型，将现有设备添加到树形模型中
        if (m_treeModel) {
            qDebug() << "Setting tree model, adding" << m_devices.size() << "existing devices";
            for (const DeviceInfo& device : m_devices) {
                qDebug() << "Adding existing device:" << device.deviceName << "in group:" << device.groupName;
                m_treeModel->addDevice(device);
            }
        }
    }
}

// 红外选中状态管理方法实现
void DeviceModel::setDeviceInfraredSelected(const QString &deviceId, bool isInfraredSelected)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].isInfraredSelected != isInfraredSelected) {
        m_devices[index].isInfraredSelected = isInfraredSelected;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        qDebug() << "Device" << deviceId << "infrared selected status changed to:" << isInfraredSelected;
    }
}

bool DeviceModel::getDeviceInfraredSelected(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].isInfraredSelected;
    }
    return false; // 默认返回false（可见光）
}

bool DeviceModel::getSelectedDeviceInfraredSelected()
{
    return getDeviceInfraredSelected(m_selectedDeviceId);
}

// 设备状态管理方法实现
void DeviceModel::setDeviceLaserState(const QString &deviceId, bool laserState)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].laserState != laserState) {
        m_devices[index].laserState = laserState;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        
        // 保存到文件
        QString appDir = QCoreApplication::applicationDirPath();
        QString deviceInfoDir = appDir + "/config/deviceinfo";
        QString deviceFilePath = deviceInfoDir + "/" + deviceId + ".json";
        saveDevicesToFile(deviceFilePath, m_devices[index]);
        
        qDebug() << "Device" << deviceId << "laser state changed to:" << laserState;
    }
}

bool DeviceModel::getDeviceLaserState(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].laserState;
    }
    return false; // 默认返回false
}

void DeviceModel::setDeviceWiperState(const QString &deviceId, bool wiperState)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].wiperState != wiperState) {
        m_devices[index].wiperState = wiperState;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        
        // 保存到文件
        QString appDir = QCoreApplication::applicationDirPath();
        QString deviceInfoDir = appDir + "/config/deviceinfo";
        QString deviceFilePath = deviceInfoDir + "/" + deviceId + ".json";
        saveDevicesToFile(deviceFilePath, m_devices[index]);
        
        qDebug() << "Device" << deviceId << "wiper state changed to:" << wiperState;
    }
}

bool DeviceModel::getDeviceWiperState(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].wiperState;
    }
    return false; // 默认返回false
}

void DeviceModel::setDeviceFlapState(const QString &deviceId, bool flapState)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].flapState != flapState) {
        m_devices[index].flapState = flapState;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        
        // 保存到文件
        QString appDir = QCoreApplication::applicationDirPath();
        QString deviceInfoDir = appDir + "/config/deviceinfo";
        QString deviceFilePath = deviceInfoDir + "/" + deviceId + ".json";
        saveDevicesToFile(deviceFilePath, m_devices[index]);
        
        qDebug() << "Device" << deviceId << "flap state changed to:" << flapState;
    }
}

bool DeviceModel::getDeviceFlapState(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].flapState;
    }
    return false; // 默认返回false
}

void DeviceModel::setDeviceScanMode(const QString &deviceId, int scanMode)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0 && m_devices[index].scanMode != scanMode) {
        m_devices[index].scanMode = scanMode;
        QModelIndex modelIndex = this->index(index);
        emit dataChanged(modelIndex, modelIndex);
        
        // 保存到文件
        QString appDir = QCoreApplication::applicationDirPath();
        QString deviceInfoDir = appDir + "/config/deviceinfo";
        QString deviceFilePath = deviceInfoDir + "/" + deviceId + ".json";
        saveDevicesToFile(deviceFilePath, m_devices[index]);
        
        qDebug() << "Device" << deviceId << "scan mode changed to:" << scanMode;
    }
}

int DeviceModel::getDeviceScanMode(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].scanMode;
    }
    return 0; // 默认返回0（无扫描）
}

int DeviceModel::getSelectedDeviceScanMode()
{
    if (!m_selectedDeviceId.isEmpty()) {
        return getDeviceScanMode(m_selectedDeviceId);
    }
    return 0; // 默认返回0（无扫描）
}

void DeviceModel::updateDevicePanoramaPath(const QString &deviceId, const QString &path)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        if (m_devices[index].panoramaPath != path) {
            m_devices[index].panoramaPath = path;
            QModelIndex modelIndex = this->index(index);
            emit dataChanged(modelIndex, modelIndex, {PanoramaPathRole});
            
            // 保存更新后的设备信息到文件
            QString appDir = QCoreApplication::applicationDirPath();
            QString deviceInfoDir = appDir + "/config/deviceinfo";
            QString deviceFilePath = deviceInfoDir + "/" + deviceId + ".json";
            saveDevicesToFile(deviceFilePath, m_devices[index]);
        }
    }
}

QString DeviceModel::getDevicePanoramaPath(const QString &deviceId)
{
    int index = findDeviceIndex(deviceId);
    if (index >= 0) {
        return m_devices[index].panoramaPath;
    }
    return QString();
}

// recordUrlbase相关方法实现
QString DeviceModel::getRecordUrlbase(const QString &deviceId)
{
    DeviceInfo device = getDevice(deviceId);
    return device.recordUrlbase;
}

QString DeviceModel::getSelectedDeviceRecordUrlbase()
{
    return getRecordUrlbase(m_selectedDeviceId);
}

// HikvisionCtrl 设置方法实现
void DeviceModel::setHikvisionCtrl(HikvisionCtrl* hikvisionCtrl)
{
    m_hikvisionCtrl = hikvisionCtrl;
    qDebug() << "HikvisionCtrl set for DeviceModel";
    
    // 连接HikvisionCtrl的信号，监听通道查找完成事件
    if (m_hikvisionCtrl) {
        connect(m_hikvisionCtrl, &HikvisionCtrl::channelLookupCompleted,
                this, &DeviceModel::onChannelLookupCompleted);
        connect(m_hikvisionCtrl, &HikvisionCtrl::channelLookupFailed,
                this, &DeviceModel::onChannelLookupFailed);

    }
}

// 新增：通道查找完成的槽函数
void DeviceModel::onChannelLookupCompleted(const QString& nvrIp, const QString& ipcIp, int channelNumber)
{
    qDebug() << "通道查找完成 - NVR:" << nvrIp << "IPC:" << ipcIp << "通道:" << channelNumber;
    // 这里可以进一步处理，比如更新UI或日志
}

void DeviceModel::onChannelLookupFailed(const QString& nvrIp, const QString& ipcIp, const QString& errorMessage)
{
    qWarning() << "通道查找失败 - NVR:" << nvrIp << "IPC:" << ipcIp << "错误:" << errorMessage;
}

void DeviceModel::setChannelFrameProviders(int channelIndex, FrameProvider* vl, FrameProvider* ir)
{
    m_channelFrameProvidersVL[channelIndex] = vl;
    m_channelFrameProvidersIR[channelIndex] = ir;
}

void DeviceModel::initializeChannelDevice(int channelIndex)
{
    if (m_initializedChannels.contains(channelIndex)) {
        return;
    }

    qDebug() << "DeviceModel::initializeChannelDevice - 初始化通道:" << channelIndex;

    // 查找对应通道的设备
    DeviceInfo targetDevice;
    bool found = false;
    for (const auto& device : m_devices) {
        if (device.channelIndex == channelIndex) {
            targetDevice = device;
            found = true;
            break;
        }
    }

    if (!found) {
        // 如果没有找到对应通道的设备，也标记为已初始化，避免重复查找
        m_initializedChannels.insert(channelIndex);
        qDebug() << "DeviceModel::initializeChannelDevice - 未找到通道" << channelIndex << "的设备";
        return;
    }

    PtzDeviceManager* ptzDeviceManager = PtzDeviceManager::instance();
    ThermalDeviceManager* thermalDeviceManager = ThermalDeviceManager::instance();

    // 初始化PTZ设备
    if (!targetDevice.visibleLightIp.isEmpty()) {
        qDebug() << "=== 初始化PTZ设备 (通道 " << channelIndex << ") ===";
        qDebug() << "设备ID:" << targetDevice.deviceId;
        qDebug() << "可见光IP:" << targetDevice.visibleLightIp;

        ptzDeviceManager->initializeDevice(
            targetDevice.deviceId,
            targetDevice.visibleLightUsername,
            targetDevice.visibleLightPassword,
            targetDevice.visibleLightIp,
            targetDevice.tdlasIp,
            targetDevice.tdlasPort,
            targetDevice.modbusIp,
            targetDevice.modbusPort,
            targetDevice.tofIp,
            targetDevice.tofPort
        );

        FrameProvider* vlProvider = m_channelFrameProvidersVL.value(channelIndex, nullptr);
        FrameProvider* irProvider = m_channelFrameProvidersIR.value(channelIndex, nullptr);

        if (vlProvider && irProvider) {
            ptzDeviceManager->setDeviceFrameProviders(targetDevice.deviceId, vlProvider, irProvider);
        } else {
             qWarning() << "未找到通道" << channelIndex << "的FrameProvider";
        }
        
        qDebug() << "PTZ设备初始化完成";
    }

    // 初始化热成像设备
    if (!targetDevice.infraredIp.isEmpty()) {
        qDebug() << "=== 初始化热成像设备 (通道 " << channelIndex << ") ===";
        qDebug() << "设备ID:" << targetDevice.deviceId;
        qDebug() << "红外IP:" << targetDevice.infraredIp;

        thermalDeviceManager->initializeDevice(targetDevice.deviceId, targetDevice.infraredUsername, targetDevice.infraredPassword, targetDevice.infraredIp);
        qDebug() << "热成像设备初始化完成";
    }
    
    // 初始化配置信息
    if (!targetDevice.deviceId.isEmpty()) {
        PtzDeviceCgi* ptzDevice = ptzDeviceManager->getDevice(targetDevice.deviceId);
        if (ptzDevice) {
             if (targetDevice.alarmDetectionDuration > 0) {
                 QMetaObject::invokeMethod(ptzDevice, "mvSetAlarmDetectionDuration", Qt::QueuedConnection, 
                                         Q_ARG(int, targetDevice.alarmDetectionDuration));
             }
             if (targetDevice.cruiseIntervalDuration > 0) {
                 QMetaObject::invokeMethod(ptzDevice, "mvSetCruiseIntervalDuration", Qt::QueuedConnection, 
                                         Q_ARG(int, targetDevice.cruiseIntervalDuration));
             }
        }
    }

    m_initializedChannels.insert(channelIndex);
}

// 生成录像URL的辅助方法
QString DeviceModel::generateRecordUrl(const QString& recordUrlBase, const QString& hikvisionIp, 
                                      int hikvisionPort, const QString& hikvisionUsername, 
                                      const QString& hikvisionPassword, const QString& ipcIp)
{
    
    QString result = recordUrlBase;
    
    // 获取通道号
    int channelNumber = -1;
    if (m_hikvisionCtrl) {
        qDebug() << "Using HikvisionCtrl to find channel for IPC:" << ipcIp;
        channelNumber = m_hikvisionCtrl->findChannelByIP(hikvisionIp, hikvisionPort, 
                                                        hikvisionUsername, hikvisionPassword, ipcIp);
        
        if (channelNumber > 0) {
            // findChannelByIP返回的值已经加了32，需要减去32得到实际通道号
            channelNumber = channelNumber - 32;
            qDebug() << "Found channel via HikvisionCtrl, adjusted channel number:" << channelNumber;
        } else {
            qWarning() << "Failed to find channel via HikvisionCtrl for IPC:" << ipcIp;
            channelNumber = 1; // 默认通道1
        }
    } else {
        qWarning() << "HikvisionCtrl not available, using default channel 1";
        channelNumber = 1; // 默认通道1
    }
    
    // 构建通道编号（通道号 + 01，表示主码流）
    QString channelCode = QString("%1%2").arg(channelNumber).arg("01");
    
    // 获取当前时间减1小时作为开始时间
    QDateTime currentTime = QDateTime::currentDateTime();
    QDateTime startTime = currentTime.addSecs(-28800); // 减去8小时（28800秒）
    QString formattedStartTime = startTime.toString("yyyyMMddThhmmssZ");
    
    // 构建完整URL
    result += QString("/%1/?starttime=%2").arg(channelCode).arg(formattedStartTime);
    
    qDebug() << "Generated record URL:" << result;
    return result;
}

// 生成带时间参数的录像URL方法
QString DeviceModel::generateTimedRecordUrl(const QString &deviceId, bool isVisibleLight, const QString &timeStr)
{
    DeviceInfo device = getDevice(deviceId);
    if (device.deviceId.isEmpty()) {
        qWarning() << "Device not found:" << deviceId;
        return QString();
    }
    
    if (device.recordUrlbase.isEmpty()) {
        qWarning() << "No record URL base for device:" << deviceId;
        return QString();
    }
    
    // 选择对应的IPC IP地址
    QString ipcIp = isVisibleLight ? device.visibleLightIp : device.infraredIp;
    if (ipcIp.isEmpty()) {
        qWarning() << "No IPC IP for device:" << deviceId << "isVisibleLight:" << isVisibleLight;
        return QString();
    }
    
    QString result = device.recordUrlbase;
    
    // 获取通道号
    int channelNumber = -1;
    if (m_hikvisionCtrl) {
        qDebug() << "Using HikvisionCtrl to find channel for IPC:" << ipcIp;
        channelNumber = m_hikvisionCtrl->findChannelByIP(device.hikvisionIp, device.hikvisionPort, 
                                                        device.hikvisionUsername, device.hikvisionPassword, ipcIp);
        
        if (channelNumber > 0) {
            // findChannelByIP返回的值已经加了32，需要减去32得到实际通道号
            channelNumber = channelNumber - 32;
            qDebug() << "Found channel via HikvisionCtrl, adjusted channel number:" << channelNumber;
        } else {
            qWarning() << "Failed to find channel via HikvisionCtrl for IPC:" << ipcIp;
            channelNumber = 1; // 默认通道1
        }
    } else {
        qWarning() << "HikvisionCtrl not available, using default channel 1";
        channelNumber = 1; // 默认通道1
    }
    
    // 构建通道编号（通道号 + 01，表示主码流）
    QString channelCode = QString("%1%2").arg(channelNumber).arg("01");
    
    // 构建完整URL，使用传入的时间参数
    result += QString("/%1/?starttime=%2").arg(channelCode).arg(timeStr);
    
    qDebug() << "Generated timed record URL:" << result << "for device:" << deviceId << "isVisibleLight:" << isVisibleLight;
    return result;
}

// 便捷方法：获取选中设备的带时间参数的可见光录像URL
QString DeviceModel::getSelectedDeviceTimedVisibleLightRecordUrl(const QString &timeStr)
{
    return generateTimedRecordUrl(m_selectedDeviceId, true, timeStr);
}

// 便捷方法：获取选中设备的带时间参数的红外录像URL
QString DeviceModel::getSelectedDeviceTimedInfraredRecordUrl(const QString &timeStr)
{
    return generateTimedRecordUrl(m_selectedDeviceId, false, timeStr);
}

// 存储设置管理方法实现
void DeviceModel::saveStorageSettings(const QString &settingsJson)
{
    qDebug() << "保存存储设置:" << settingsJson;
    
    // 解析JSON字符串
    QJsonDocument doc = QJsonDocument::fromJson(settingsJson.toUtf8());
    if (!doc.isObject()) {
        qWarning() << "存储设置JSON格式错误";
        return;
    }
    
    QJsonObject settingsObj = doc.object();
    
    // 创建存储设置目录
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configDir = appDir.absoluteFilePath("config/storage");
    if (!appDir.mkpath(configDir)) {
        qWarning() << "无法创建存储设置目录:" << configDir;
        return;
    }
    
    // 保存设置到文件
    QString configFile = configDir + "/settings.json";
    QFile file(configFile);
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "无法打开存储设置文件进行写入:" << configFile;
        return;
    }
    
    QJsonDocument saveDoc(settingsObj);
    file.write(saveDoc.toJson());
    file.close();
    
    qDebug() << "存储设置已保存到:" << configFile;
}

// 录像设置管理方法实现
void DeviceModel::saveVideoSettings(const QString &settingsJson)
{
    qDebug() << "保存录像设置:" << settingsJson;
    
    // 解析JSON字符串
    QJsonDocument doc = QJsonDocument::fromJson(settingsJson.toUtf8());
    if (!doc.isObject()) {
        qWarning() << "录像设置JSON格式错误";
        return;
    }
    
    QJsonObject settingsObj = doc.object();
    
    // 创建存储设置目录
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configDir = appDir.absoluteFilePath("config/storage");
    if (!appDir.mkpath(configDir)) {
        qWarning() << "无法创建存储设置目录:" << configDir;
        return;
    }
    
    // 保存设置到文件
    QString configFile = configDir + "/video_settings.json";
    QFile file(configFile);
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "无法打开录像设置文件进行写入:" << configFile;
        return;
    }
    
    QJsonDocument saveDoc(settingsObj);
    file.write(saveDoc.toJson());
    file.close();
    
    qDebug() << "录像设置已保存到:" << configFile;
}

QString DeviceModel::getVideoSettings(const QString &key)
{
    // 读取录像设置文件
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configFile = appDir.absoluteFilePath("config/storage/video_settings.json");
    
    QFile file(configFile);
    if (!file.exists() || !file.open(QIODevice::ReadOnly)) {
        qDebug() << "录像设置文件不存在或无法打开，返回默认值";
        // 返回默认值
        if (key == "videoFormat") {
            return "MP4";
        } else if (key == "manualVideoPath") {
            return "D:/ZG_Client/Video";
        } else if (key == "alarmVideoPath") {
            return "D:/ZG_Client/Alarm_video";
        }
        return QString();
    }
    
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();
    
    if (!doc.isObject()) {
        qWarning() << "录像设置文件格式错误";
        return QString();
    }
    
    QJsonObject settingsObj = doc.object();
    return settingsObj.value(key).toString();
}

bool DeviceModel::pingDevice(const QString &ipAddress)
{
    if (ipAddress.isEmpty()) {
        return false;
    }
    
    // 在Windows系统上使用ping命令
    QString command = QString("ping -n 1 -w 1000 %1").arg(ipAddress);
    
    // 执行ping命令
    QProcess process;
    process.start(command);
    process.waitForFinished(2000); // 等待最多2秒
    
    int exitCode = process.exitCode();
    QString output = process.readAllStandardOutput();
    QString error = process.readAllStandardError();
    
    // 检查ping结果
    bool isOnline = (exitCode == 0);
    
    // 进一步检查输出，确保真的ping通了
    if (isOnline) {
        // 在Windows上，成功ping通会包含"TTL="字符串
        isOnline = output.contains("TTL=", Qt::CaseInsensitive);
    }
    
    qDebug() << "Ping" << ipAddress << ":" << (isOnline ? "成功" : "失败") 
             << "ExitCode:" << exitCode << "Output:" << output.left(100);
    
    return isOnline;
}

QString DeviceModel::getStorageSettings(const QString &key)
{
    // 读取存储设置文件
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configFile = appDir.absoluteFilePath("config/storage/settings.json");
    
    QFile file(configFile);
    if (!file.exists() || !file.open(QIODevice::ReadOnly)) {
        qDebug() << "存储设置文件不存在或无法打开，返回默认值";
        // 返回默认值
        if (key == "photoPath") {
            return "D:/ZG_Client/Photo";
        } else if (key == "alarmPhotoPath") {
            return "D:/ZG_Client/Alarm_Photo";
        } else if (key == "photoFormat") {
            return "JPEG";
        } else if (key == "photoRatio") {
            return "16:9";
        } else if (key == "photoQuality") {
            return "95";
        } else if (key == "photoResolution") {
            return "16:9";
        } else if (key == "alarmPhotoFormat") {
            return "JPEG";
        } else if (key == "alarmPhotoQuality") {
            return "95";
        } else if (key == "alarmPhotoResolution") {
            return "16:9";
        }
        return QString();
    }
    
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();
    
    if (!doc.isObject()) {
        qWarning() << "存储设置文件格式错误";
        return QString();
    }
    
    QJsonObject settingsObj = doc.object();
    return settingsObj.value(key).toString();
}

// 分组信息持久化方法实现
void DeviceModel::saveGroupsToFile()
{
    qDebug() << "保存分组信息到文件";
    
    // 创建分组配置目录
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configDir = appDir.absoluteFilePath("config");
    if (!appDir.mkpath(configDir)) {
        qWarning() << "无法创建配置目录:" << configDir;
        return;
    }
    
    // 保存分组信息到文件
    QString configFile = configDir + "/groups.json";
    QFile file(configFile);
    if (!file.open(QIODevice::WriteOnly)) {
        qWarning() << "无法打开分组配置文件进行写入:" << configFile;
        return;
    }
    
    QJsonArray groupsArray;
    for (const auto &group : m_deviceGroups) {
        QJsonObject groupObj;
        groupObj["groupName"] = group.groupName;
        groupObj["isExpanded"] = group.isExpanded;
        groupsArray.append(groupObj);
    }
    
    QJsonDocument saveDoc(groupsArray);
    file.write(saveDoc.toJson());
    file.close();
    
    qDebug() << "分组信息已保存到:" << configFile;
}

void DeviceModel::loadGroupsFromFile()
{
    qDebug() << "从文件加载分组信息";
    
    // 读取分组配置文件
    QDir appDir(QCoreApplication::applicationDirPath());
    QString configFile = appDir.absoluteFilePath("config/groups.json");
    
    QFile file(configFile);
    if (!file.exists() || !file.open(QIODevice::ReadOnly)) {
        qDebug() << "分组配置文件不存在或无法打开";
        return;
    }
    
    QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
    file.close();
    
    if (!doc.isArray()) {
        qWarning() << "分组配置文件格式错误";
        return;
    }
    
    QJsonArray groupsArray = doc.array();
    
    // 清空现有分组
    m_deviceGroups.clear();
    
    // 加载分组信息
    for (const auto &groupValue : groupsArray) {
        if (!groupValue.isObject()) {
            continue;
        }
        
        QJsonObject groupObj = groupValue.toObject();
        DeviceGroup group;
        group.groupName = groupObj["groupName"].toString();
        group.isExpanded = groupObj["isExpanded"].toBool(true);
        
        // 添加到分组列表
        m_deviceGroups.append(group);
    }
    
    // 更新树形模型
    if (m_treeModel) {
        // 清空树形模型的分组
        m_treeModel->clearGroups();
        
        // 添加分组到树形模型
        for (const auto &group : m_deviceGroups) {
            m_treeModel->addGroup(group.groupName);
            // 使用findGroupRow方法获取行号
            int groupRow = m_treeModel->findGroupRow(group.groupName);
            if (groupRow >= 0) {
                m_treeModel->setExpanded(groupRow, group.isExpanded);
            }
        }
        
        // 重新添加所有设备到树形模型
        for (const auto &device : m_devices) {
            m_treeModel->addDevice(device);
        }
    }
    
    qDebug() << "已从文件加载" << m_deviceGroups.size() << "个分组";
}
