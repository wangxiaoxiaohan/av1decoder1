#include "logmodel.h"

// Since most functionality is implemented in the header file,
// this implementation file mainly serves for registering the model
// with the QML engine.

// Register the model with QML
void registerLogModel() {
    // Note: Actual registration should be done in your main.cpp or similar file
    // qmlRegisterSingletonType<LogModel>("App", 1, 0, "LogModel", 
    //     [](QQmlEngine* engine, QJSEngine* scriptEngine) -> QObject* {
    //         Q_UNUSED(engine)
    //         Q_UNUSED(scriptEngine)
    //         return LogModel::instance();
    //     });
} 