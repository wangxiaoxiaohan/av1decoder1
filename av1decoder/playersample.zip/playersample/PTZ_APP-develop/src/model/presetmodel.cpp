#include "presetmodel.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QFile>
#include <QStandardPaths>
#include <QDir>
#include <QDebug>
#include <QCoreApplication>

PresetModel::PresetModel(QObject *parent) 
    : QAbstractListModel(parent)
{
    // 在构造函数中加载所有设备的预置位数据
    loadPresetsFromFile();
}

// 添加预置位
void PresetModel::addPreset(const QString &deviceId, const PresetData &preset)
{
    if (deviceId.isEmpty()) return;
    
    PresetData newPreset = preset;
    newPreset.deviceId = deviceId;
    
    if (!m_devicePresets.contains(deviceId)) {
        m_devicePresets[deviceId] = QList<PresetData>();
    }
    
    // 检查是否已存在相同号码的预置位
    int existingIndex = findPresetIndex(deviceId, preset.number);
    if (existingIndex >= 0) {
        qWarning() << "预置位号码已存在:" << preset.number << "设备:" << deviceId;
        return;
    }
    
    m_devicePresets[deviceId].append(newPreset);
    
    // 如果是当前设备，更新模型显示
    if (deviceId == m_currentDeviceId) {
        updateModel();
    }
    
    // 保存到文件
    savePresetsForDevice(deviceId);
    
    emit presetAdded(deviceId, preset.number);
    qDebug() << "预置位已添加:" << preset.name << "号码:" << preset.number << "设备:" << deviceId;
}

void PresetModel::addPreset(const QString &deviceId, const QVariantMap &map)
{
    PresetData preset;
    preset.number = map["number"].toString();
    preset.name = map["name"].toString();
    preset.status = map["status"].toBool();
    
    addPreset(deviceId, preset);
}

// 删除预置位
void PresetModel::removePreset(const QString &deviceId, int index)
{
    if (!m_devicePresets.contains(deviceId) || 
        index < 0 || index >= m_devicePresets[deviceId].size()) {
        return;
    }
    
    QString presetNumber = m_devicePresets[deviceId][index].number;
    m_devicePresets[deviceId].removeAt(index);
    
    // 如果是当前设备，更新模型显示
    if (deviceId == m_currentDeviceId) {
        updateModel();
    }
    
    // 保存到文件
    savePresetsForDevice(deviceId);
    
    emit presetRemoved(deviceId, presetNumber);
    qDebug() << "预置位已删除:" << presetNumber << "设备:" << deviceId;
}

void PresetModel::removePresetByNumber(const QString &deviceId, const QString &number)
{
    int index = findPresetIndex(deviceId, number);
    if (index >= 0) {
        removePreset(deviceId, index);
    }
}

// 修改预置位
void PresetModel::modifyPreset(const QString &deviceId, int index, const PresetData &preset)
{
    if (!m_devicePresets.contains(deviceId) || 
        index < 0 || index >= m_devicePresets[deviceId].size()) {
        return;
    }
    
    PresetData newPreset = preset;
    newPreset.deviceId = deviceId;
    
    QString oldNumber = m_devicePresets[deviceId][index].number;
    m_devicePresets[deviceId][index] = newPreset;
    
    // 如果是当前设备，更新模型显示
    if (deviceId == m_currentDeviceId) {
        updateModel();
    }
    
    // 保存到文件
    savePresetsForDevice(deviceId);
    
    emit presetModified(deviceId, preset.number);
    qDebug() << "预置位已修改:" << preset.name << "号码:" << preset.number << "设备:" << deviceId;
}

void PresetModel::modifyPreset(const QString &deviceId, int index, const QVariantMap &map)
{
    PresetData preset;
    preset.number = map["number"].toString();
    preset.name = map["name"].toString();
    preset.status = map["status"].toBool();
    
    modifyPreset(deviceId, index, preset);
}

void PresetModel::modifyPresetByNumber(const QString &deviceId, const QString &number, const QVariantMap &map)
{
    int index = findPresetIndex(deviceId, number);
    if (index >= 0) {
        modifyPreset(deviceId, index, map);
    }
}

// 查询预置位
QList<PresetData> PresetModel::getPresetsForDevice(const QString &deviceId)
{
    if (m_devicePresets.contains(deviceId)) {
        return m_devicePresets[deviceId];
    }
    return QList<PresetData>();
}

PresetData PresetModel::getPresetByNumber(const QString &deviceId, const QString &number)
{
    int index = findPresetIndex(deviceId, number);
    if (index >= 0 && m_devicePresets.contains(deviceId)) {
        return m_devicePresets[deviceId][index];
    }
    return PresetData();
}

int PresetModel::getPresetCount(const QString &deviceId)
{
    if (m_devicePresets.contains(deviceId)) {
        return m_devicePresets[deviceId].size();
    }
    return 0;
}

// 设备管理
void PresetModel::clearPresetsForDevice(const QString &deviceId)
{
    if (m_devicePresets.contains(deviceId)) {
        m_devicePresets[deviceId].clear();
        
        // 如果是当前设备，更新模型显示
        if (deviceId == m_currentDeviceId) {
            updateModel();
        }
        
        // 保存到文件
        savePresetsForDevice(deviceId);
        
        qDebug() << "设备预置位已清空:" << deviceId;
    }
}

QStringList PresetModel::getDeviceIds()
{
    return m_devicePresets.keys();
}

// 当前选中设备
void PresetModel::setCurrentDevice(const QString &deviceId)
{
    if (m_currentDeviceId != deviceId) {
        m_currentDeviceId = deviceId;
        updateModel();
        emit currentDeviceChanged(deviceId);
        qDebug() << "当前设备已切换到:" << deviceId;
    }
}

QString PresetModel::getCurrentDevice() const
{
    return m_currentDeviceId;
}

// QAbstractListModel 接口实现
int PresetModel::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent);
    if (m_currentDeviceId.isEmpty() || !m_devicePresets.contains(m_currentDeviceId)) {
        return 0;
    }
    return m_devicePresets[m_currentDeviceId].size();
}

QVariant PresetModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid() || m_currentDeviceId.isEmpty() || 
        !m_devicePresets.contains(m_currentDeviceId) ||
        index.row() >= m_devicePresets[m_currentDeviceId].size()) {
        return QVariant();
    }

    const PresetData &item = m_devicePresets[m_currentDeviceId][index.row()];
    
    switch(role) {
    case DeviceIdRole:
        return item.deviceId;
    case NumberRole:
        return item.number;
    case NameRole:
        return item.name;
    case StatusRole:
        return item.status;
    default:
        return QVariant();
    }
}

// 数据持久化
void PresetModel::savePresetsToFile()
{
    for (const QString &deviceId : m_devicePresets.keys()) {
        savePresetsForDevice(deviceId);
    }
}

void PresetModel::loadPresetsFromFile()
{
    // 加载全局预置位配置文件
    QString globalFilePath = getGlobalPresetFilePath();
    QFile globalFile(globalFilePath);
    
    if (globalFile.exists() && globalFile.open(QIODevice::ReadOnly)) {
        QJsonDocument doc = QJsonDocument::fromJson(globalFile.readAll());
        QJsonObject rootObj = doc.object();
        
        m_devicePresets.clear();
        
        for (auto it = rootObj.begin(); it != rootObj.end(); ++it) {
            QString deviceId = it.key();
            QJsonArray presetsArray = it.value().toArray();
            
            QList<PresetData> presetList;
            for (const auto &presetValue : presetsArray) {
                QJsonObject presetObj = presetValue.toObject();
                PresetData preset;
                preset.deviceId = deviceId;
                preset.number = presetObj["number"].toString();
                preset.name = presetObj["name"].toString();
                preset.status = presetObj["status"].toBool();
                presetList.append(preset);
            }
            
            m_devicePresets[deviceId] = presetList;
        }
        
        updateModel();
        qDebug() << "预置位配置已从全局文件加载:" << globalFilePath;
    } else {
        qDebug() << "全局预置位配置文件不存在，将创建新文件:" << globalFilePath;
    }
}

void PresetModel::savePresetsForDevice(const QString &deviceId)
{
    // 保存单个设备的预置位到设备专用文件
    QString deviceFilePath = getPresetFilePath(deviceId);
    QDir().mkpath(QFileInfo(deviceFilePath).path());
    
    QFile deviceFile(deviceFilePath);
    if (deviceFile.open(QIODevice::WriteOnly)) {
        QJsonArray presetsArray;
        
        if (m_devicePresets.contains(deviceId)) {
            for (const auto &preset : m_devicePresets[deviceId]) {
                QJsonObject presetObj;
                presetObj["number"] = preset.number;
                presetObj["name"] = preset.name;
                presetObj["status"] = preset.status;
                presetsArray.append(presetObj);
            }
        }
        
        QJsonDocument doc(presetsArray);
        deviceFile.write(doc.toJson());
        qDebug() << "设备预置位配置已保存:" << deviceFilePath;
    }
    
    // 同时更新全局配置文件
    QString globalFilePath = getGlobalPresetFilePath();
    QDir().mkpath(QFileInfo(globalFilePath).path());
    
    QJsonObject globalObj;
    for (const QString &devId : m_devicePresets.keys()) {
        QJsonArray presetsArray;
        for (const auto &preset : m_devicePresets[devId]) {
            QJsonObject presetObj;
            presetObj["number"] = preset.number;
            presetObj["name"] = preset.name;
            presetObj["status"] = preset.status;
            presetsArray.append(presetObj);
        }
        globalObj[devId] = presetsArray;
    }
    
    QFile globalFile(globalFilePath);
    if (globalFile.open(QIODevice::WriteOnly)) {
        QJsonDocument doc(globalObj);
        globalFile.write(doc.toJson());
        qDebug() << "全局预置位配置已更新:" << globalFilePath;
    }
}

void PresetModel::loadPresetsForDevice(const QString &deviceId)
{
    QString filePath = getPresetFilePath(deviceId);
    QFile file(filePath);
    
    if (file.exists() && file.open(QIODevice::ReadOnly)) {
        QJsonDocument doc = QJsonDocument::fromJson(file.readAll());
        QJsonArray presetsArray = doc.array();
        
        QList<PresetData> presetList;
        for (const auto &presetValue : presetsArray) {
            QJsonObject presetObj = presetValue.toObject();
            PresetData preset;
            preset.deviceId = deviceId;
            preset.number = presetObj["number"].toString();
            preset.name = presetObj["name"].toString();
            preset.status = presetObj["status"].toBool();
            presetList.append(preset);
        }
        
        m_devicePresets[deviceId] = presetList;
        
        // 如果是当前设备，更新模型显示
        if (deviceId == m_currentDeviceId) {
            updateModel();
        }
        
        qDebug() << "设备预置位配置已加载:" << filePath;
    } else {
        qDebug() << "设备预置位配置文件不存在:" << filePath;
    }
}

// 测试数据
void PresetModel::addSampleData()
{
    // 为默认设备添加示例数据
    QString sampleDeviceId = "device_001";
    
    QVariantMap preset1;
    preset1["number"] = "1";
    preset1["name"] = "预置位1";
    preset1["status"] = true;
    addPreset(sampleDeviceId, preset1);
    
    QVariantMap preset2;
    preset2["number"] = "2";
    preset2["name"] = "预置位2";
    preset2["status"] = false;
    addPreset(sampleDeviceId, preset2);
    
    QVariantMap preset3;
    preset3["number"] = "3";
    preset3["name"] = "预置位3";
    preset3["status"] = true;
    addPreset(sampleDeviceId, preset3);
    
    QVariantMap preset4;
    preset4["number"] = "4";
    preset4["name"] = "预置位4";
    preset4["status"] = false;
    addPreset(sampleDeviceId, preset4);
    
    QVariantMap preset5;
    preset5["number"] = "5";
    preset5["name"] = "预置位5";
    preset5["status"] = true;
    addPreset(sampleDeviceId, preset5);
}

void PresetModel::clearData()
{
    beginResetModel();
    m_devicePresets.clear();
    m_currentDeviceId.clear();
    endResetModel();
    
    // 清空所有配置文件
    QString configDir = getConfigDir();
    QDir dir(configDir);
    QStringList filters;
    filters << "preset_*.json" << "presets_global.json";
    QFileInfoList files = dir.entryInfoList(filters, QDir::Files);
    
    for (const QFileInfo &fileInfo : files) {
        QFile::remove(fileInfo.absoluteFilePath());
        qDebug() << "已删除预置位配置文件:" << fileInfo.absoluteFilePath();
    }
}

// 私有方法
QString PresetModel::getConfigDir() const
{
    QString appDir = QCoreApplication::applicationDirPath();
    QString configDir = QDir(appDir).absoluteFilePath("config/presets");
    return configDir;
}

QString PresetModel::getPresetFilePath(const QString &deviceId) const
{
    QString configDir = getConfigDir();
    return QDir(configDir).absoluteFilePath(QString("preset_%1.json").arg(deviceId));
}

QString PresetModel::getGlobalPresetFilePath() const
{
    QString configDir = getConfigDir();
    return QDir(configDir).absoluteFilePath("presets_global.json");
}

void PresetModel::updateModel()
{
    beginResetModel();
    endResetModel();
}

int PresetModel::findPresetIndex(const QString &deviceId, const QString &number) const
{
    if (!m_devicePresets.contains(deviceId)) {
        return -1;
    }
    
    const QList<PresetData> &presets = m_devicePresets[deviceId];
    for (int i = 0; i < presets.size(); ++i) {
        if (presets[i].number == number) {
            return i;
        }
    }
    return -1;
}

// 注册模型到QML的函数
void registerPresetModel() {
    // 注册已在main.cpp中完成
} 