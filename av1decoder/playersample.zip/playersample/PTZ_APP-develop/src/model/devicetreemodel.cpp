#include "devicetreemodel.h"
#include "devicemodel.h"
#include <QDebug>

DeviceTreeModel::DeviceTreeModel(QObject *parent)
    : QAbstractItemModel(parent)
    , m_rootNode(new TreeNode(TreeNode::GroupNode, "Root", "root"))
{
}

DeviceTreeModel::~DeviceTreeModel()
{
    delete m_rootNode;
}

QModelIndex DeviceTreeModel::index(int row, int column, const QModelIndex &parent) const
{
    if (!hasIndex(row, column, parent))
        return QModelIndex();

    // 在扁平化视图中，所有节点都是根节点的直接子节点
    TreeNode* node = getNodeAtFlatIndex(row);
    if (!node)
        return QModelIndex();

    return createIndex(row, column, node);
}

QModelIndex DeviceTreeModel::parent(const QModelIndex &index) const
{
    if (!index.isValid())
        return QModelIndex();

    // 在扁平化视图中，所有节点都没有父节点（除了根节点）
    return QModelIndex();
}

int DeviceTreeModel::rowCount(const QModelIndex &parent) const
{
    if (parent.column() > 0)
        return 0;

    // 返回扁平化的可见节点数量
    int count = 0;
    for (TreeNode* groupNode : m_rootNode->children) {
        count++; // 分组节点总是可见
        if (groupNode->isExpanded) {
            count += groupNode->children.size(); // 展开时显示子节点
        }
    }
    return count;
}

int DeviceTreeModel::columnCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    return 1;
}

QVariant DeviceTreeModel::data(const QModelIndex &index, int role) const
{
    if (!index.isValid())
        return QVariant();

    // 获取扁平化视图中的节点
    TreeNode* node = getNodeAtFlatIndex(index.row());
    if (!node)
        return QVariant();

    switch (role) {
    case Qt::DisplayRole:
    case NameRole:
        return node->name;
    case IdRole:
        return node->id;
    case TypeRole:
        return node->type;
    case GroupNameRole:
        return node->groupName;
    case DeviceIdRole:
        return node->deviceId;
    case IsExpandedRole:
        return node->isExpanded;
    case HasChildrenRole:
        return !node->children.isEmpty();
    default:
        return QVariant();
    }
}

QHash<int, QByteArray> DeviceTreeModel::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles[NameRole] = "name";
    roles[IdRole] = "id";
    roles[TypeRole] = "type";
    roles[GroupNameRole] = "groupName";
    roles[DeviceIdRole] = "deviceId";
    roles[IsExpandedRole] = "isExpanded";
    roles[HasChildrenRole] = "hasChildren";
    return roles;
}

void DeviceTreeModel::addDevice(const DeviceInfo &device)
{
    // 确保分组存在
    if (!m_groupNodes.contains(device.groupName)) {
        addGroup(device.groupName);
    }

    // 如果设备已存在，先移除
    if (m_deviceNodes.contains(device.deviceId)) {
        removeDevice(device.deviceId);
    }

    // 创建设备节点
    TreeNode* groupNode = m_groupNodes[device.groupName];
    TreeNode* deviceNode = new TreeNode(TreeNode::DeviceNode, device.deviceName, device.deviceId, groupNode);
    deviceNode->groupName = device.groupName;
    deviceNode->deviceId = device.deviceId;

    // 添加到分组
    int row = groupNode->children.size();
    QModelIndex groupIndex = indexForNode(groupNode);
    beginInsertRows(groupIndex, row, row);
    groupNode->children.append(deviceNode);
    m_deviceNodes[device.deviceId] = deviceNode;
    endInsertRows();

    emit deviceAdded(device.deviceId);
    emit treeModelChanged();
}

void DeviceTreeModel::removeDevice(const QString &deviceId)
{
    TreeNode* deviceNode = m_deviceNodes.value(deviceId);
    if (!deviceNode)
        return;

    TreeNode* parentNode = deviceNode->parent;
    if (!parentNode)
        return;

    int row = parentNode->children.indexOf(deviceNode);
    if (row >= 0) {
        QModelIndex parentIndex = indexForNode(parentNode);
        beginRemoveRows(parentIndex, row, row);
        parentNode->children.removeAt(row);
        m_deviceNodes.remove(deviceId);
        delete deviceNode;
        endRemoveRows();

        emit deviceRemoved(deviceId);
        emit treeModelChanged();
    }
}

void DeviceTreeModel::updateDevice(const DeviceInfo &device)
{
    TreeNode* deviceNode = m_deviceNodes.value(device.deviceId);
    if (!deviceNode)
        return;

    // 如果分组发生变化，需要重新添加到新分组
    if (deviceNode->groupName != device.groupName) {
        removeDevice(device.deviceId);
        addDevice(device);
        return;
    }

    // 更新设备信息
    deviceNode->name = device.deviceName;
    
    // 通知视图数据变化
    QModelIndex index = indexForNode(deviceNode);
    emit dataChanged(index, index);

    emit deviceUpdated(device.deviceId);
    emit treeModelChanged();
}

void DeviceTreeModel::addGroup(const QString &groupName)
{
    if (m_groupNodes.contains(groupName))
        return;

    TreeNode* groupNode = new TreeNode(TreeNode::GroupNode, groupName, groupName, m_rootNode);
    int row = m_rootNode->children.size();
    
    qDebug() << "DeviceTreeModel::addGroup - adding group:" << groupName << "at row:" << row;
    
    beginInsertRows(QModelIndex(), row, row);
    m_rootNode->children.append(groupNode);
    m_groupNodes[groupName] = groupNode;
    endInsertRows();

    qDebug() << "DeviceTreeModel::addGroup - root children count after adding:" << m_rootNode->children.size();

    emit groupAdded(groupName);
    emit treeModelChanged();
}

void DeviceTreeModel::removeGroup(const QString &groupName)
{
    TreeNode* groupNode = m_groupNodes.value(groupName);
    if (!groupNode)
        return;

    // 先移除分组下的所有设备
    QList<TreeNode*> devicesToRemove = groupNode->children;
    for (TreeNode* deviceNode : devicesToRemove) {
        m_deviceNodes.remove(deviceNode->deviceId);
    }

    // 移除分组
    int row = m_rootNode->children.indexOf(groupNode);
    if (row >= 0) {
        beginRemoveRows(QModelIndex(), row, row);
        m_rootNode->children.removeAt(row);
        m_groupNodes.remove(groupName);
        delete groupNode;
        endRemoveRows();

        emit groupRemoved(groupName);
        emit treeModelChanged();
    }
}

void DeviceTreeModel::modifyGroupName(const QString &oldName, const QString &newName)
{
    TreeNode* groupNode = m_groupNodes.value(oldName);
    if (!groupNode)
        return;

    // 更新分组节点的名称
    groupNode->name = newName;
    groupNode->id = newName;
    
    // 更新映射表
    m_groupNodes.remove(oldName);
    m_groupNodes[newName] = groupNode;
    
    // 更新分组下所有设备节点的groupName字段
    for (TreeNode* deviceNode : groupNode->children) {
        deviceNode->groupName = newName;
    }
    
    // 通知视图数据变化
    QModelIndex index = indexForNode(groupNode);
    emit dataChanged(index, index);
    
    // 由于是根节点的直接子节点，我们需要重置整个模型来正确更新
    beginResetModel();
    endResetModel();
    
    emit treeModelChanged();
    
    qDebug() << "DeviceTreeModel: 分组名已从" << oldName << "修改为" << newName;
}

void DeviceTreeModel::clearGroups()
{
    beginResetModel();
    
    // 清理所有分组节点，但保留设备节点
    qDeleteAll(m_rootNode->children);
    m_rootNode->children.clear();
    m_groupNodes.clear();
    // 不清空m_deviceNodes，因为设备信息需要保留
    
    endResetModel();
}

int DeviceTreeModel::findGroupRow(const QString &groupName)
{
    TreeNode* groupNode = m_groupNodes.value(groupName);
    if (!groupNode)
        return -1;
    
    // 在扁平化视图中找到分组节点的行号
    int currentIndex = 0;
    for (TreeNode* node : m_rootNode->children) {
        if (node == groupNode) {
            return currentIndex;
        }
        currentIndex++;
    }
    
    return -1;
}

void DeviceTreeModel::clear()
{
    beginResetModel();
    
    // 清理所有节点
    qDeleteAll(m_rootNode->children);
    m_rootNode->children.clear();
    m_groupNodes.clear();
    m_deviceNodes.clear();
    
    endResetModel();
}

void DeviceTreeModel::setExpanded(int row, bool expanded)
{
    TreeNode* node = getNodeAtFlatIndex(row);
    if (!node)
        return;

    node->isExpanded = expanded;
    
    // 触发整个模型更新，因为展开/折叠会影响行数
    beginResetModel();
    endResetModel();
}

bool DeviceTreeModel::isExpanded(const QModelIndex &index) const
{
    if (!index.isValid())
        return false;

    TreeNode* node = static_cast<TreeNode*>(index.internalPointer());
    return node ? node->isExpanded : false;
}

QVariantList DeviceTreeModel::getTreeData() const
{
    QVariantList result;
    
    for (TreeNode* groupNode : m_rootNode->children) {
        QVariantMap groupData;
        groupData["name"] = groupNode->name;
        
        QVariantList children;
        for (TreeNode* deviceNode : groupNode->children) {
            QVariantMap deviceData;
            deviceData["name"] = deviceNode->name;
            deviceData["sn"] = deviceNode->deviceId; // 使用deviceId作为sn
            children.append(deviceData);
        }
        
        groupData["children"] = children;
        result.append(groupData);
    }
    
    return result;
}

TreeNode* DeviceTreeModel::findGroupNode(const QString &groupName) const
{
    return m_groupNodes.value(groupName);
}

TreeNode* DeviceTreeModel::findDeviceNode(const QString &deviceId) const
{
    return m_deviceNodes.value(deviceId);
}

void DeviceTreeModel::rebuildTree()
{
    beginResetModel();
    endResetModel();
}

QModelIndex DeviceTreeModel::indexForNode(TreeNode* node) const
{
    if (!node || node == m_rootNode)
        return QModelIndex();

    TreeNode* parent = node->parent;
    if (!parent)
        return QModelIndex();

    int row = parent->children.indexOf(node);
    if (row < 0)
        return QModelIndex();

    return createIndex(row, 0, node);
}

TreeNode* DeviceTreeModel::nodeForIndex(const QModelIndex &index) const
{
    if (!index.isValid())
        return m_rootNode;

    return static_cast<TreeNode*>(index.internalPointer());
}

TreeNode* DeviceTreeModel::getNodeAtFlatIndex(int flatIndex) const
{
    int currentIndex = 0;
    for (TreeNode* groupNode : m_rootNode->children) {
        if (currentIndex == flatIndex) {
            return groupNode;
        }
        currentIndex++;
        
        if (groupNode->isExpanded) {
            for (TreeNode* deviceNode : groupNode->children) {
                if (currentIndex == flatIndex) {
                    return deviceNode;
                }
                currentIndex++;
            }
        }
    }
    return nullptr;
}

int DeviceTreeModel::rowForNode(TreeNode* node) const
{
    if (!node || !node->parent)
        return -1;

    return node->parent->children.indexOf(node);
}

 