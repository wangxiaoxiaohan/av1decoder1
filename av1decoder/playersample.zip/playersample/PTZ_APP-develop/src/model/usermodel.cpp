#include "usermodel.h"

// Since most functionality is implemented in the header file,
// this implementation file mainly serves for registering the model
// with the QML engine and providing sample data for testing.

// Register the model with QML
void registerUserModel() {
    // Note: Actual registration should be done in your main.cpp or similar file
    // qmlRegisterSingletonType<UserModel>("App", 1, 0, "UserModel", 
    //     [](QQmlEngine* engine, QJSEngine* scriptEngine) -> QObject* {
    //         Q_UNUSED(engine)
    //         Q_UNUSED(scriptEngine)
    //         return UserModel::instance();
    //     });
} 