#pragma once

#ifdef _WIN32
#define VIS_HEATMAP_API __declspec(dllexport)
#else
#define VIS_HEATMAP_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

// 初始化，传入模型路径和json路径，返回0成功
VIS_HEATMAP_API int vis_heatmap_init(const char* model_path, const char* calibration_json_path);

// 处理，输入可见光YUV、红外YUV，输出融合YUV和maskYUV
// 所有YUV均为NV12格式，visible/ir参数为输入数据，fusion_yuv/mask_yuv为输出buffer
// visible_yuv_size = visible_width * visible_height * 3 / 2
// ir_yuv_size = ir_width * ir_height * 3 / 2
VIS_HEATMAP_API int vis_heatmap_process(
    const unsigned char* visible_yuv, int visible_width, int visible_height,
    const unsigned char* ir_yuv, int ir_width, int ir_height,
    int depth, float tdlas,
    unsigned char *ir_heatmap_yuv, int ir_heatmap_yuv_size,
    unsigned char* fusion_yuv, int fusion_yuv_size,
    unsigned char* mask_yuv, int mask_yuv_size
);

// 释放资源
VIS_HEATMAP_API void vis_heatmap_release();

#ifdef __cplusplus
}
#endif 