#ifndef TDLAS_DATA_MANAGER_H
#define TDLAS_DATA_MANAGER_H

#include <QObject>
#include <QString>
#include <QDateTime>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonDocument>
#include <QFile>
#include <QDir>
#include <QDebug>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QThread>
#include <QMutex>

// TDLAS浓度数据结构
struct TdlasConcentrationData {
    int id = -1;                // 数据库ID
    QString timestamp;          // 时间戳 (yyyy-MM-dd HH:mm:ss)
    double concentration;       // 浓度值
    double horizontalAngle;     // 水平角度
    double verticalAngle;       // 垂直角度
    double distance;            // 距离信息
    QString deviceId;           // 设备ID
    
    QJsonObject toJson() const;
    static TdlasConcentrationData fromJson(const QJsonObject& json);
};

// 时间段浓度数据汇总
struct TdlasTimeRangeData {
    QString startTime;          // 开始时间
    QString endTime;            // 结束时间
    double avgConcentration;    // 平均浓度
    double maxConcentration;    // 最大浓度
    double minConcentration;    // 最小浓度
    int dataCount;             // 数据点数量
    
    QJsonObject toJson() const;
    static TdlasTimeRangeData fromJson(const QJsonObject& json);
};

class TdlasDataManager : public QObject
{
    Q_OBJECT

public:
    static TdlasDataManager* instance();
    
    // 数据存储接口
    Q_INVOKABLE bool saveConcentrationData(double concentration, const QString& deviceId = "");
    Q_INVOKABLE bool saveConcentrationData(double concentration, double horizontalAngle, double verticalAngle, double distance, const QString& deviceId = "");

    // 批量保存数据
    Q_INVOKABLE bool saveBatchData(const QVariantList& dataList, const QString& deviceId = "");

    // 查询接口
    Q_INVOKABLE QVariantList queryConcentrationData(const QString& startTime = "",
                                                   const QString& endTime = "",
                                                   const QString& deviceId = "");

    // 查询接口（分页）
    Q_INVOKABLE QVariantList queryConcentrationDataPaginated(const QString& startTime = "",
                                                            const QString& endTime = "",
                                                            int limit = 1000,
                                                            int offset = 0,
                                                            const QString& deviceId = "");

    // 智能采样查询接口
    Q_INVOKABLE QVariantList queryConcentrationDataWithSampling(const QString& startTime = "",
                                                               const QString& endTime = "",
                                                               int maxSamples = 1000,
                                                               const QString& deviceId = "");

    // 查询浓度数据（带阈值筛选的智能采样版本）
    Q_INVOKABLE QVariantList queryConcentrationDataWithThreshold(const QString& startTime = "",
                                                                const QString& endTime = "",
                                                                double thresholdValue = 0.0,
                                                                int maxSamples = 120,
                                                                const QString& deviceId = "");

    // 查询时间段汇总数据
    Q_INVOKABLE QVariantList queryTimeRangeData(const QString& startTime = "",
                                               const QString& endTime = "",
                                               const QString& deviceId = "");

    // 导出数据
    Q_INVOKABLE bool exportToCsv(const QString& outputPath,
                                 const QString& startTime = "",
                                 const QString& endTime = "",
                                 const QString& deviceId = "");

    Q_INVOKABLE bool exportToJson(const QString& startTime = "",
                                 const QString& endTime = "",
                                 const QString& outputPath = "",
                                 const QString& deviceId = "");

    // 数据清理
    Q_INVOKABLE bool deleteData(const QString& startTime = "",
                               const QString& endTime = "",
                               const QString& deviceId = "");

    Q_INVOKABLE bool deleteAllData();

    // 获取统计信息
    Q_INVOKABLE QVariantMap getStatistics(const QString& startTime = "",
                                         const QString& endTime = "",
                                         const QString& deviceId = "");
    
    // 获取报警时间前后的数据
    Q_INVOKABLE QVariantList getDataAroundAlarmTime(const QString& alarmTime,
                                                    int beforeSeconds = 5,
                                                    int afterSeconds = 10,
                                                    const QString& deviceId = "");

private:
    TdlasDataManager(QObject *parent = nullptr);
    ~TdlasDataManager();
    
    static TdlasDataManager* m_instance;
    
    QSqlDatabase m_db;
    QMutex m_dbMutex;  // 添加互斥锁确保线程安全
    
    void initDatabase();
    QString getCurrentDate();
    QDateTime parseDateTime(const QString& dateTimeStr);
    TdlasConcentrationData fromQuery(const QSqlQuery& query);
};

#endif // TDLAS_DATA_MANAGER_H