#include "hikvision_ctrl.h"
#include <QUuid>
#include <QUrl>
#include <QDebug>
#include <QJsonDocument>
#include <QCryptographicHash>
#include <QDateTime>
#include <QXmlStreamReader>
#include <QXmlStreamWriter>
#include <QString>
#include <QTimer>
#include <QThread>
#include <cstring>
#include <curl/curl.h>
#include "model/devicemodel.h"

// CURL 写回调函数
static size_t HikvisionWriteCallback(void* contents, size_t size, size_t nmemb, void* userp)
{
    const size_t totalSize = size * nmemb;
    QByteArray* buffer = static_cast<QByteArray*>(userp);
    buffer->append(static_cast<char*>(contents), static_cast<int>(totalSize));
    return totalSize;
}

// 新增：响应头回调函数，用于提取Cookie
static size_t HikvisionHeaderCallback(char* buffer, size_t size, size_t nitems, void* userdata)
{
    size_t totalSize = size * nitems;
    QString header = QString::fromUtf8(buffer, totalSize).trimmed();
    
    // 查找Set-Cookie头
    if (header.startsWith("Set-Cookie:", Qt::CaseInsensitive)) {
        QString* cookiePtr = static_cast<QString*>(userdata);
        QString cookieValue = header.mid(11).trimmed(); // 跳过"Set-Cookie:"
        
        // 提取Cookie值（到分号为止）
        int semicolonPos = cookieValue.indexOf(';');
        if (semicolonPos > 0) {
            cookieValue = cookieValue.left(semicolonPos);
        }
        
        *cookiePtr = cookieValue;
        qDebug() << "获取到Cookie:" << cookieValue;
    }
    
    return totalSize;
}

HikvisionCtrl::HikvisionCtrl(QObject* parent)
    : QObject(parent)
    , m_curl(nullptr)
    , m_headers(nullptr)
    , m_networkManager(nullptr)
    , m_workerThread(nullptr)
    , m_worker(nullptr)
{
    // 初始化 CURL
    curl_global_init(CURL_GLOBAL_DEFAULT);
    m_curl = curl_easy_init();
    
    // 初始化网络管理器
    m_networkManager = new QNetworkAccessManager(this);
    
    // 硬编码认证信息和服务器IP
    m_serverIp = "192.168.1.102";  // 可以根据需要修改
    m_username = "admin";
    m_password = "WANG234WH1";
    
    // 初始化工作线程
    m_workerThread = new QThread(this);
    m_worker = new HikvisionWorker(nullptr); // 父对象设为nullptr，因为将移动到线程
    m_worker->moveToThread(m_workerThread);
    
    // 设置工作线程的认证信息
    m_worker->setServerIp(m_serverIp);
    m_worker->setUsername(m_username);
    m_worker->setPassword(m_password);
    
    // 连接信号和槽
    connect(m_workerThread, &QThread::started, m_worker, &HikvisionWorker::process);
    connect(m_worker, &HikvisionWorker::finished, m_workerThread, &QThread::quit);
    connect(m_worker, &HikvisionWorker::finished, m_worker, &QObject::deleteLater);
    connect(m_workerThread, &QThread::finished, m_workerThread, &QObject::deleteLater);
    
    // 连接工作线程的信号到主类
    connect(m_worker, &HikvisionWorker::recordingSearchCompleted,
            this, &HikvisionCtrl::recordingSearchCompleted, Qt::QueuedConnection);
    
    // 连接工作线程的通道查找完成信号
    connect(m_worker, &HikvisionWorker::channelLookupCompleted,
            this, &HikvisionCtrl::channelLookupCompleted, Qt::QueuedConnection);
    
    // 连接工作线程的系统能力和通道事件能力信号
    connect(m_worker, &HikvisionWorker::systemCapabilitiesReceived,
            this, &HikvisionCtrl::systemCapabilitiesReceived, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::channelEventCapabilitiesReceived,
            this, &HikvisionCtrl::channelEventCapabilitiesReceived, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::motionDetectionCapabilitiesReceived,
            this, &HikvisionCtrl::motionDetectionCapabilitiesReceived, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::motionDetectionLayoutCapabilitiesReceived,
            this, &HikvisionCtrl::motionDetectionLayoutCapabilitiesReceived, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::motionDetectionConfigReceived,
            this, &HikvisionCtrl::motionDetectionConfigReceived, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::motionDetectionConfigSet,
            this, &HikvisionCtrl::motionDetectionConfigSet, Qt::QueuedConnection);
    
    // 移动侦测相关信号 - 只连接HikvisionWorker中实际存在的信号
    connect(m_worker, &HikvisionWorker::motionDetectionLayoutReceived,
            this, &HikvisionCtrl::motionDetectionLayoutReceived, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::motionDetectionLayoutSet,
            this, &HikvisionCtrl::motionDetectionLayoutSet, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::motionDetectionError,
            this, &HikvisionCtrl::motionDetectionError, Qt::QueuedConnection);
    
    // 移动侦测触发器相关信号 - 从HikvisionWorker转发到HikvisionCtrl
    connect(m_worker, &HikvisionWorker::motionDetectionTriggerReceived,
            this, &HikvisionCtrl::motionDetectionTriggerReceived, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::motionDetectionTriggerSet,
            this, &HikvisionCtrl::motionDetectionTriggerSet, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::motionDetectionTriggerDeleted,
            this, &HikvisionCtrl::motionDetectionTriggerDeleted, Qt::QueuedConnection);
    
    // 移动侦测布防时间相关信号 - 从HikvisionWorker转发到HikvisionCtrl
    connect(m_worker, &HikvisionWorker::motionDetectionScheduleReceived,
            this, &HikvisionCtrl::motionDetectionScheduleReceived, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::motionDetectionScheduleSet,
            this, &HikvisionCtrl::motionDetectionScheduleSet, Qt::QueuedConnection);
    
    // 录像计划相关信号 - 从HikvisionWorker转发到HikvisionCtrl
    connect(m_worker, &HikvisionWorker::recordingScheduleReceived,
            this, &HikvisionCtrl::recordingScheduleReceived, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::recordingScheduleSet,
            this, &HikvisionCtrl::recordingScheduleSet, Qt::QueuedConnection);
    connect(m_worker, &HikvisionWorker::recordingScheduleError,
            this, &HikvisionCtrl::recordingScheduleError, Qt::QueuedConnection);
    
    // 启动工作线程
    m_workerThread->start();
    

}

HikvisionCtrl::~HikvisionCtrl()
{
    // 停止工作线程
    if (m_worker) {
        m_worker->disconnect();
        m_worker->stop();
    }
    
    if (m_workerThread) {
        if (m_workerThread->isRunning()) {
            m_workerThread->quit();
            if (!m_workerThread->wait(5000)) {
                qWarning() << "Hikvision worker thread failed to quit gracefully, terminating...";
                m_workerThread->terminate();
                m_workerThread->wait(1000);
            }
        }
        m_workerThread = nullptr;
    }
    m_worker = nullptr;
    
    if (m_headers) {
        curl_slist_free_all(m_headers);
    }
    if (m_curl) {
        curl_easy_cleanup(m_curl);
    }
    curl_global_cleanup();
    
    // m_networkManager会被Qt的父子关系自动清理
}

void HikvisionCtrl::searchRecording(const QString& searchId, int trackId, 
                                   const QString& startTime, const QString& endTime, 
                                   int maxResults, int searchResultPosition)
{
    // 直接调用工作线程方法 - 移除信号中转机制
    if (m_worker) {
        qDebug() << "调用工作线程中的doSearchRecording方法";
        // 使用QMetaObject::invokeMethod调用工作线程中的方法
        QMetaObject::invokeMethod(m_worker, "doSearchRecording",
                                 Qt::QueuedConnection,
                                 Q_ARG(QString, searchId),
                                 Q_ARG(int, trackId),
                                 Q_ARG(QString, startTime),
                                 Q_ARG(QString, endTime),
                                 Q_ARG(int, maxResults),
                                 Q_ARG(int, searchResultPosition));
    } else {
        qCritical() << "HikvisionWorker未初始化";
        emit recordingSearchCompleted(QJsonObject());
    }
}

void HikvisionWorker::getMotionDetectionTrigger(int channelId)
{
    qDebug() << "Worker: Getting motion detection trigger for channel:" << channelId;
    
    QString url = QString("http://%1/ISAPI/Event/triggers/VMD-%2").arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject trigger = parseMotionDetectionXml(response.toUtf8());
        emit motionDetectionTriggerReceived(channelId, trigger);
    } else {
        emit motionDetectionError("getMotionDetectionTrigger", "Failed to get motion detection trigger");
    }
}

void HikvisionWorker::setMotionDetectionTrigger(int channelId, const QJsonObject& trigger)
{
    qDebug() << "Worker: Setting motion detection trigger for channel:" << channelId;
    
    QString url = QString("http://%1/ISAPI/Event/triggers/VMD-%2").arg(m_serverIp).arg(channelId);
    
    // 将JSON配置转换为XML
    QByteArray xmlData = convertJsonToXml(trigger, "EventTrigger");
    
    QString response;
    if (sendHttpRequest(url, "PUT", QString::fromUtf8(xmlData), &response)) {
        emit motionDetectionTriggerSet(channelId, true, "Motion detection trigger set successfully");
    } else {
        emit motionDetectionTriggerSet(channelId, false, "Failed to set motion detection trigger");
    }
}

void HikvisionWorker::deleteMotionDetectionTrigger(int channelId)
{
    qDebug() << "Worker: Deleting motion detection trigger for channel:" << channelId;
    
    QString url = QString("http://%1/ISAPI/Event/triggers/VMD-%2").arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "DELETE", QString(), &response)) {
        emit motionDetectionTriggerDeleted(channelId, true, "Motion detection trigger deleted successfully");
    } else {
        emit motionDetectionTriggerDeleted(channelId, false, "Failed to delete motion detection trigger");
    }
}


// 修改后的同步接口，优先检查缓存
int HikvisionCtrl::findChannelByIP(const QString& deviceIp, int port,
                                  const QString& username, const QString& password,
                                  const QString& ipcIp)
{
    qDebug() << "Finding channel for IPC IP:" << ipcIp << "on NVR:" << deviceIp;
    
    // 检查设备是否在线
    DeviceModel* deviceModel = DeviceModel::instance();
    if (deviceModel) {
        QList<DeviceInfo> devices = deviceModel->getAllDevices();
        for (const DeviceInfo& device : devices) {
            if (device.visibleLightIp == ipcIp || device.infraredIp == ipcIp) {
                if (!device.hikvisionOnline) {
                    qDebug() << "Hikvision device" << ipcIp << "is offline, skipping findChannelByIP";
                    return -1;
                }else {
                    qDebug() << "Hikvision device" << ipcIp << "is online, proceeding with findChannelByIP";
                }
                break;
            }
        }
    }

    // 将请求转发到工作线程
    if (m_worker) {
        qDebug() << "调用工作线程中的findChannelByIP方法";
        // 使用QMetaObject::invokeMethod调用工作线程中的方法
        int result = -1;
        QMetaObject::invokeMethod(m_worker, "findChannelByIP",
                                 Qt::BlockingQueuedConnection,
                                 Q_RETURN_ARG(int, result),
                                 Q_ARG(QString, deviceIp),
                                 Q_ARG(int, port),
                                 Q_ARG(QString, username),
                                 Q_ARG(QString, password),
                                 Q_ARG(QString, ipcIp));
        return result;
    } else {
        qCritical() << "HikvisionWorker未初始化";
        return -1;
    }
}

// 设置当前设备的认证信息
void HikvisionCtrl::setCurrentDeviceCredentials(const QString& serverIp, const QString& username, const QString& password)
{
    qDebug() << "Setting current device credentials for:" << serverIp << "username:" << username;
    m_serverIp = serverIp;
    m_username = username;
    m_password = password;
    
    // 同时更新工作线程中的认证信息
    QMetaObject::invokeMethod(m_worker, "setCurrentDeviceCredentials", Qt::QueuedConnection,
                              Q_ARG(QString, serverIp),
                              Q_ARG(QString, username),
                              Q_ARG(QString, password));
}

// ========== 移动侦测相关接口实现 ==========

// 1. 获取系统能力（检查是否支持移动侦测）
void HikvisionCtrl::getSystemCapabilities()
{
    // 设置worker的认证信息并调用getSystemCapabilities方法
    m_worker->setCurrentDeviceCredentials(m_serverIp, m_username, m_password);
    QMetaObject::invokeMethod(m_worker, "getSystemCapabilities", Qt::QueuedConnection);
}

// 2. 获取通道事件能力（检查通道是否支持VMD）
void HikvisionCtrl::getChannelEventCapabilities(int channelId)
{
    // 设置worker的认证信息并调用getChannelEventCapabilities方法
    m_worker->setCurrentDeviceCredentials(m_serverIp, m_username, m_password);
    QMetaObject::invokeMethod(m_worker, "getChannelEventCapabilities", Qt::QueuedConnection,
                            Q_ARG(int, channelId));
}

// 3. 获取指定通道移动侦测能力
void HikvisionCtrl::getMotionDetectionCapabilities(int channelId)
{
    // 设置worker的认证信息
    m_worker->setCurrentDeviceCredentials(m_serverIp, m_username, m_password);
    
    // 调用worker线程的方法
    QMetaObject::invokeMethod(m_worker, "getMotionDetectionCapabilities", 
                             Qt::QueuedConnection, 
                             Q_ARG(int, channelId));
}

// 4. 获取移动侦测区域配置能力
void HikvisionCtrl::getMotionDetectionLayoutCapabilities(int channelId)
{
    // 设置worker的认证信息
    m_worker->setCurrentDeviceCredentials(m_serverIp, m_username, m_password);
    
    // 调用worker线程的方法
    QMetaObject::invokeMethod(m_worker, "getMotionDetectionLayoutCapabilities", 
                             Qt::QueuedConnection, 
                             Q_ARG(int, channelId));
}

// 5. 获取移动侦测配置
void HikvisionCtrl::getMotionDetectionConfig(int channelId)
{
    QMetaObject::invokeMethod(m_worker, "getMotionDetectionConfig", Qt::QueuedConnection, Q_ARG(int, channelId));
}

// 6. 设置移动侦测配置
void HikvisionCtrl::setMotionDetectionConfig(int channelId, const QJsonObject& config)
{
    QMetaObject::invokeMethod(m_worker, "setMotionDetectionConfig", Qt::QueuedConnection, Q_ARG(int, channelId), Q_ARG(QJsonObject, config));
}

// 7. 获取移动侦测区域配置
void HikvisionCtrl::getMotionDetectionLayout(int channelId, const QString& regionType)
{
    // 设置worker的认证信息
    m_worker->setCurrentDeviceCredentials(m_serverIp, m_username, m_password);
    
    // 调用worker线程的方法
    QMetaObject::invokeMethod(m_worker, "getMotionDetectionLayout", 
                             Qt::QueuedConnection, 
                             Q_ARG(int, channelId),
                             Q_ARG(QString, regionType));
}

// 8. 设置移动侦测区域配置
void HikvisionCtrl::setMotionDetectionLayout(int channelId, const QJsonObject& layout, const QString& regionType)
{
    // 设置worker的认证信息
    m_worker->setCurrentDeviceCredentials(m_serverIp, m_username, m_password);
    
    // 调用worker线程的方法
    QMetaObject::invokeMethod(m_worker, "setMotionDetectionLayout", 
                             Qt::QueuedConnection, 
                             Q_ARG(int, channelId),
                             Q_ARG(QJsonObject, layout),
                             Q_ARG(QString, regionType));
}

// 9. 获取移动侦测联动规则
void HikvisionCtrl::getMotionDetectionTrigger(int channelId)
{
    qDebug() << "HikvisionCtrl: Forwarding getMotionDetectionTrigger to worker for channel:" << channelId;
    
    // 设置worker的认证信息并调用getMotionDetectionTrigger方法
    m_worker->setCurrentDeviceCredentials(m_serverIp, m_username, m_password);
    QMetaObject::invokeMethod(m_worker, "getMotionDetectionTrigger", Qt::QueuedConnection, Q_ARG(int, channelId));
}

// 10. 设置移动侦测联动规则
void HikvisionCtrl::setMotionDetectionTrigger(int channelId, const QJsonObject& trigger)
{
    qDebug() << "HikvisionCtrl: Forwarding setMotionDetectionTrigger to worker for channel:" << channelId;
    
    // 设置worker的认证信息并调用setMotionDetectionTrigger方法
    m_worker->setCurrentDeviceCredentials(m_serverIp, m_username, m_password);
    QMetaObject::invokeMethod(m_worker, "setMotionDetectionTrigger", Qt::QueuedConnection, 
                             Q_ARG(int, channelId), Q_ARG(QJsonObject, trigger));
}

// 11. 删除移动侦测联动规则
void HikvisionCtrl::deleteMotionDetectionTrigger(int channelId)
{
    qDebug() << "HikvisionCtrl: Forwarding deleteMotionDetectionTrigger to worker for channel:" << channelId;
    
    // 设置worker的认证信息并调用deleteMotionDetectionTrigger方法
    m_worker->setCurrentDeviceCredentials(m_serverIp, m_username, m_password);
    QMetaObject::invokeMethod(m_worker, "deleteMotionDetectionTrigger", Qt::QueuedConnection, Q_ARG(int, channelId));
}

// 12. 获取移动侦测布防时间
void HikvisionCtrl::getMotionDetectionSchedule(int channelId)
{
    qDebug() << "Getting motion detection schedule for channel:" << channelId;
    
    // 使用QMetaObject::invokeMethod调用worker线程中的方法
    QMetaObject::invokeMethod(m_worker, "getMotionDetectionSchedule", Qt::QueuedConnection,
                             Q_ARG(int, channelId));
}

// 13. 设置移动侦测布防时间
void HikvisionCtrl::setMotionDetectionSchedule(int channelId, const QJsonObject& schedule)
{
    qDebug() << "Setting motion detection schedule for channel:" << channelId;
    
    // 使用QMetaObject::invokeMethod调用worker线程中的方法
    QMetaObject::invokeMethod(m_worker, "setMotionDetectionSchedule", Qt::QueuedConnection,
                             Q_ARG(int, channelId),
                             Q_ARG(QJsonObject, schedule));
}

// ========== XML解析和生成辅助函数 ==========

// 将JSON对象转换为XML格式
QByteArray HikvisionCtrl::convertJsonToXml(const QJsonObject& jsonObj, const QString& rootElement)
{
    QDomDocument doc;
    QDomElement root = doc.createElement(rootElement);
    doc.appendChild(root);
    
    // 递归转换JSON对象到XML
    convertJsonObjectToXmlElement(jsonObj, root, doc);
    
    return doc.toByteArray();
}

// 递归将JSON对象转换为XML元素
void HikvisionCtrl::convertJsonObjectToXmlElement(const QJsonObject& jsonObj, QDomElement& xmlElement, QDomDocument& doc)
{
    for (auto it = jsonObj.begin(); it != jsonObj.end(); ++it) {
        const QString& key = it.key();
        const QJsonValue& value = it.value();
        
        QDomElement element = doc.createElement(key);
        
        if (value.isObject()) {
            convertJsonObjectToXmlElement(value.toObject(), element, doc);
        } else if (value.isArray()) {
            const QJsonArray array = value.toArray();
            for (const QJsonValue& arrayValue : array) {
                QDomElement arrayElement = doc.createElement("item");
                if (arrayValue.isObject()) {
                    convertJsonObjectToXmlElement(arrayValue.toObject(), arrayElement, doc);
                } else {
                    arrayElement.appendChild(doc.createTextNode(arrayValue.toVariant().toString()));
                }
                element.appendChild(arrayElement);
            }
        } else {
            element.appendChild(doc.createTextNode(value.toVariant().toString()));
        }
        
        xmlElement.appendChild(element);
    }
}

// 增强的XML到JSON转换函数（专门用于移动侦测）
QJsonObject HikvisionCtrl::parseMotionDetectionXml(const QByteArray& xmlData)
{
    QDomDocument doc;
    if (!doc.setContent(xmlData)) {
        qWarning() << "Failed to parse motion detection XML";
        return QJsonObject();
    }
    
    QDomElement root = doc.documentElement();
    return convertXmlElementToJsonObject(root);
}

// 专门用于解析移动侦测布局XML的函数
QJsonObject HikvisionCtrl::parseMotionDetectionLayoutXml(const QByteArray& xmlData)
{
    QDomDocument doc;
    if (!doc.setContent(xmlData)) {
        qWarning() << "Failed to parse motion detection layout XML";
        return QJsonObject();
    }
    
    QDomElement root = doc.documentElement();
    QJsonObject result;
    
    // 解析sensitivityLevel
    QDomElement sensitivityElement = root.firstChildElement("sensitivityLevel");
    if (!sensitivityElement.isNull()) {
        result["sensitivityLevel"] = sensitivityElement.text().toInt();
    }
    
    // 解析layout
    QDomElement layoutElement = root.firstChildElement("layout");
    if (!layoutElement.isNull()) {
        QJsonObject layoutObj;
        
        // 解析gridMap
        QDomElement gridMapElement = layoutElement.firstChildElement("gridMap");
        if (!gridMapElement.isNull()) {
            layoutObj["gridMap"] = gridMapElement.text();
        }
        
        // 解析roiMap
        QDomElement roiMapElement = layoutElement.firstChildElement("roiMap");
        if (!roiMapElement.isNull()) {
            layoutObj["roiMap"] = roiMapElement.text();
        }
        
        // 解析RegionList
        QDomElement regionListElement = layoutElement.firstChildElement("RegionList");
        if (!regionListElement.isNull()) {
            QJsonArray regionArray;
            QDomNodeList regionNodes = regionListElement.elementsByTagName("Region");
            
            for (int i = 0; i < regionNodes.count(); ++i) {
                QDomElement regionElement = regionNodes.at(i).toElement();
                QJsonObject regionObj;
                
                // 解析id
                QDomElement idElement = regionElement.firstChildElement("id");
                if (!idElement.isNull()) {
                    regionObj["id"] = idElement.text();
                }
                
                // 解析RegionCoordinatesList
                QDomElement coordListElement = regionElement.firstChildElement("RegionCoordinatesList");
                if (!coordListElement.isNull()) {
                    QJsonArray coordArray;
                    QDomNodeList coordNodes = coordListElement.elementsByTagName("RegionCoordinates");
                    
                    for (int j = 0; j < coordNodes.count(); ++j) {
                        QDomElement coordElement = coordNodes.at(j).toElement();
                        QJsonObject coordObj;
                        
                        QDomElement posXElement = coordElement.firstChildElement("positionX");
                        if (!posXElement.isNull()) {
                            coordObj["positionX"] = posXElement.text().toInt();
                        }
                        
                        QDomElement posYElement = coordElement.firstChildElement("positionY");
                        if (!posYElement.isNull()) {
                            coordObj["positionY"] = posYElement.text().toInt();
                        }
                        
                        coordArray.append(coordObj);
                    }
                    
                    regionObj["RegionCoordinatesList"] = coordArray;
                }
                
                regionArray.append(regionObj);
            }
            
            layoutObj["RegionList"] = regionArray;
        }
        
        result["layout"] = layoutObj;
    }
    
    // 解析targetType
    QDomElement targetTypeElement = root.firstChildElement("targetType");
    if (!targetTypeElement.isNull()) {
        result["targetType"] = targetTypeElement.text();
    }
    
    return result;
}





// 将JSON对象转换为移动侦测布局XML格式
QByteArray HikvisionCtrl::convertJsonToMotionDetectionLayoutXml(const QJsonObject& jsonObj)
{
    QDomDocument doc;
    QDomElement root = doc.createElement("MotionDetectionLayout");
    root.setAttribute("xmlns", "http://www.isapi.org/ver20/XMLSchema");
    root.setAttribute("version", "2.0");
    doc.appendChild(root);
    
    // 添加sensitivityLevel
    if (jsonObj.contains("sensitivityLevel")) {
        QDomElement sensitivityElement = doc.createElement("sensitivityLevel");
        sensitivityElement.appendChild(doc.createTextNode(QString::number(jsonObj["sensitivityLevel"].toInt())));
        root.appendChild(sensitivityElement);
    }
    
    // 添加layout
    if (jsonObj.contains("layout")) {
        QJsonObject layoutObj = jsonObj["layout"].toObject();
        QDomElement layoutElement = doc.createElement("layout");
        
        // 添加gridMap
        if (layoutObj.contains("gridMap")) {
            QDomElement gridMapElement = doc.createElement("gridMap");
            gridMapElement.appendChild(doc.createTextNode(layoutObj["gridMap"].toString()));
            layoutElement.appendChild(gridMapElement);
        }
        
        // 添加roiMap
        if (layoutObj.contains("roiMap")) {
            QDomElement roiMapElement = doc.createElement("roiMap");
            roiMapElement.appendChild(doc.createTextNode(layoutObj["roiMap"].toString()));
            layoutElement.appendChild(roiMapElement);
        }
        
        // 添加RegionList
        if (layoutObj.contains("RegionList")) {
            QDomElement regionListElement = doc.createElement("RegionList");
            QJsonArray regionArray = layoutObj["RegionList"].toArray();
            
            for (const QJsonValue& regionValue : regionArray) {
                QJsonObject regionObj = regionValue.toObject();
                QDomElement regionElement = doc.createElement("Region");
                
                // 添加id
                if (regionObj.contains("id")) {
                    QDomElement idElement = doc.createElement("id");
                    idElement.appendChild(doc.createTextNode(regionObj["id"].toString()));
                    regionElement.appendChild(idElement);
                }
                
                // 添加RegionCoordinatesList
                if (regionObj.contains("RegionCoordinatesList")) {
                    QDomElement coordListElement = doc.createElement("RegionCoordinatesList");
                    QJsonArray coordArray = regionObj["RegionCoordinatesList"].toArray();
                    
                    for (const QJsonValue& coordValue : coordArray) {
                        QJsonObject coordObj = coordValue.toObject();
                        QDomElement coordElement = doc.createElement("RegionCoordinates");
                        
                        if (coordObj.contains("positionX")) {
                            QDomElement posXElement = doc.createElement("positionX");
                            posXElement.appendChild(doc.createTextNode(QString::number(coordObj["positionX"].toInt())));
                            coordElement.appendChild(posXElement);
                        }
                        
                        if (coordObj.contains("positionY")) {
                            QDomElement posYElement = doc.createElement("positionY");
                            posYElement.appendChild(doc.createTextNode(QString::number(coordObj["positionY"].toInt())));
                            coordElement.appendChild(posYElement);
                        }
                        
                        coordListElement.appendChild(coordElement);
                    }
                    
                    regionElement.appendChild(coordListElement);
                }
                
                regionListElement.appendChild(regionElement);
            }
            
            layoutElement.appendChild(regionListElement);
        }
        
        root.appendChild(layoutElement);
    }
    
    // 添加targetType
    if (jsonObj.contains("targetType")) {
        QDomElement targetTypeElement = doc.createElement("targetType");
        targetTypeElement.appendChild(doc.createTextNode(jsonObj["targetType"].toString()));
        root.appendChild(targetTypeElement);
    }
    
    return doc.toByteArray();
}

// 14. 诊断移动侦测支持能力（尝试所有可能的端点）
void HikvisionCtrl::diagnoseMotionDetectionSupport(int channelId)
{
    qDebug() << "Starting motion detection support diagnosis for channel:" << channelId;
    
    QJsonObject supportInfo;
    supportInfo["channelId"] = channelId;
    supportInfo["testedEndpoints"] = QJsonArray();
    
    // 定义所有可能的端点
    QStringList testEndpoints = {
        QString("http://%1/ISAPI/System/capabilities").arg(m_serverIp),
        QString("http://%1/ISAPI/Event/channels/capabilities").arg(m_serverIp),
        QString("http://%1/ISAPI/Event/channels/%2/capabilities").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/capabilities").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout/capabilities").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/Event/triggers/VMD-%2").arg(m_serverIp).arg(channelId)
    };
    
    // 如果通道号大于32，也测试原始通道号
    if (channelId > 32) {
        int originalChannel = channelId - 32;
        supportInfo["originalChannelId"] = originalChannel;
        testEndpoints.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection").arg(m_serverIp).arg(originalChannel));
        testEndpoints.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout").arg(m_serverIp).arg(originalChannel));
        testEndpoints.append(QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout").arg(m_serverIp).arg(originalChannel));
    }
    
    QJsonArray endpointResults;
    
    // 测试每个端点
    for (const QString& url : testEndpoints) {
        QJsonObject endpointResult;
        endpointResult["url"] = url;
        
        qDebug() << "Testing endpoint:" << url;
        
        QString response;
        bool success = sendHttpRequest(url, "GET", QString(), &response);
        
        endpointResult["success"] = success;
        endpointResult["httpSuccess"] = success;
        
        if (success) {
            bool hasError = response.contains("Invalid Operation") || response.contains("notSupport");
            endpointResult["hasError"] = hasError;
            endpointResult["supported"] = !hasError;
            
            if (hasError) {
                endpointResult["errorType"] = "API_NOT_SUPPORTED";
                if (response.contains("Invalid Operation")) {
                    endpointResult["errorDetail"] = "Invalid Operation";
                }
                if (response.contains("notSupport")) {
                    endpointResult["errorDetail"] = "Not Supported";
                }
            } else {
                endpointResult["responseSize"] = response.length();
                // 尝试解析响应中的关键信息
                if (response.contains("<enabled>")) {
                    endpointResult["hasEnabledField"] = true;
                }
                if (response.contains("VMD") || response.contains("motionDetection")) {
                    endpointResult["hasMotionDetectionContent"] = true;
                }
            }
        } else {
            endpointResult["errorType"] = "HTTP_ERROR";
            endpointResult["supported"] = false;
        }
        
        endpointResults.append(endpointResult);
    }
    
    supportInfo["testedEndpoints"] = endpointResults;
    
    // 分析支持情况
    QJsonArray supportedEndpoints;
    QJsonArray unsupportedEndpoints;
    
    for (const QJsonValue& result : endpointResults) {
        QJsonObject endpoint = result.toObject();
        if (endpoint["supported"].toBool()) {
            supportedEndpoints.append(endpoint["url"]);
        } else {
            unsupportedEndpoints.append(endpoint["url"]);
        }
    }
    
    supportInfo["supportedEndpoints"] = supportedEndpoints;
    supportInfo["unsupportedEndpoints"] = unsupportedEndpoints;
    supportInfo["totalTested"] = testEndpoints.size();
    supportInfo["supportedCount"] = supportedEndpoints.size();
    
    qDebug() << "Motion detection diagnosis completed for channel" << channelId;
    qDebug() << "Supported endpoints:" << supportedEndpoints.size() << "out of" << testEndpoints.size();
    
    emit motionDetectionDiagnosisCompleted(channelId, supportInfo);
}

// ========== 录像计划相关接口实现 ==========
void HikvisionCtrl::getRecordingSchedule(int channelId, int trackId)
{
    qDebug() << "Getting recording schedule for channel:" << channelId << "trackId:" << trackId;
    
    if (m_worker) {
        QMetaObject::invokeMethod(m_worker, "getRecordingSchedule",
                                 Qt::QueuedConnection,
                                 Q_ARG(int, channelId),
                                 Q_ARG(int, trackId));
    } else {
        qCritical() << "HikvisionWorker未初始化";
        emit recordingScheduleError("getRecordingSchedule", "Worker not initialized");
    }
}

void HikvisionCtrl::setRecordingSchedule(int channelId, const QJsonObject& scheduleConfig, int trackId)
{
    qDebug() << "Setting recording schedule for channel:" << channelId << "trackId:" << trackId;
    
    if (m_worker) {
        QMetaObject::invokeMethod(m_worker, "setRecordingSchedule",
                                 Qt::QueuedConnection,
                                 Q_ARG(int, channelId),
                                 Q_ARG(QJsonObject, scheduleConfig),
                                 Q_ARG(int, trackId));
    } else {
        qCritical() << "HikvisionWorker未初始化";
        emit recordingScheduleError("setRecordingSchedule", "Worker not initialized");
    }
}

// 递归将XML元素转换为JSON对象
QJsonObject HikvisionCtrl::convertXmlElementToJsonObject(const QDomElement& xmlElement)
{
    QJsonObject jsonObj;
    
    QDomNodeList children = xmlElement.childNodes();
    for (int i = 0; i < children.count(); ++i) {
        QDomNode child = children.at(i);
        
        if (child.isElement()) {
            QDomElement childElement = child.toElement();
            QString tagName = childElement.tagName();
            
            if (childElement.hasChildNodes() && childElement.firstChild().isElement()) {
                // 如果子元素还有子元素，递归处理
                jsonObj[tagName] = convertXmlElementToJsonObject(childElement);
            } else {
                // 如果是文本节点，直接获取文本内容
                QString textContent = childElement.text().trimmed();
                
                // 尝试转换为数字或布尔值
                bool ok;
                int intValue = textContent.toInt(&ok);
                if (ok) {
                    jsonObj[tagName] = intValue;
                } else {
                    double doubleValue = textContent.toDouble(&ok);
                    if (ok) {
                        jsonObj[tagName] = doubleValue;
                    } else if (textContent.toLower() == "true" || textContent.toLower() == "false") {
                        jsonObj[tagName] = (textContent.toLower() == "true");
                    } else {
                        jsonObj[tagName] = textContent;
                    }
                }
            }
        }
    }
    
    return jsonObj;
}

// ========== 录像计划XML解析和生成 ==========
QJsonObject HikvisionWorker::parseRecordingScheduleXml(const QByteArray& xmlData)
{
    QJsonObject schedule;
    QXmlStreamReader reader(xmlData);
    
    while (!reader.atEnd()) {
        if (reader.readNext() == QXmlStreamReader::StartElement) {
            QString elementName = reader.name().toString();
            
            if (elementName == "TrackList") {
                QJsonArray tracks;
                while (reader.readNextStartElement()) {
                    if (reader.name() == "Track") {
                        QJsonObject track = parseTrackElement(reader);
                        tracks.append(track);
                    } else {
                        reader.skipCurrentElement();
                    }
                }
                schedule["tracks"] = tracks;
            } else if (elementName == "Track") {
                QJsonObject track = parseTrackElement(reader);
                schedule["track"] = track;
            } else if (elementName == "ResponseStatus") {
                QJsonObject status;
                while (reader.readNextStartElement()) {
                    QString name = reader.name().toString();
                    if (name == "statusCode" || name == "statusString" || name == "subStatusCode") {
                        status[name] = reader.readElementText();
                    } else {
                        reader.skipCurrentElement();
                    }
                }
                schedule["responseStatus"] = status;
            }
        }
    }
    
    if (reader.hasError()) {
        qWarning() << "Error parsing recording schedule XML:" << reader.errorString();
    }
    
    return schedule;
}

QJsonObject HikvisionWorker::parseTrackElement(QXmlStreamReader& reader)
{
    QJsonObject track;
    
    // 读取Track属性
    QXmlStreamAttributes attributes = reader.attributes();
    if (attributes.hasAttribute("version")) {
        track["version"] = attributes.value("version").toString();
    }
    if (attributes.hasAttribute("xmlns")) {
        track["xmlns"] = attributes.value("xmlns").toString();
    }
    
    // 读取Track子元素
    while (reader.readNextStartElement()) {
        QString elementName = reader.name().toString();
        
        if (elementName == "id") {
            track["id"] = reader.readElementText().toInt();
        } else if (elementName == "Channel") {
            track["channel"] = reader.readElementText().toInt();
        } else if (elementName == "Enable") {
            track["enable"] = (reader.readElementText() == "true");
        } else if (elementName == "Description") {
            track["description"] = reader.readElementText();
        } else if (elementName == "TrackGUID") {
            track["trackGUID"] = reader.readElementText();
        } else if (elementName == "Size") {
            track["size"] = reader.readElementText().toLongLong();
        } else if (elementName == "Duration") {
            track["duration"] = reader.readElementText().toLongLong();
        } else if (elementName == "DefaultRecordingMode") {
            track["defaultRecordingMode"] = reader.readElementText();
        } else if (elementName == "LoopEnable") {
            track["loopEnable"] = (reader.readElementText() == "true");
        } else if (elementName == "SrcDescriptor") {
            track["srcDescriptor"] = reader.readElementText();
        } else if (elementName == "TrackSchedule") {
            QJsonObject schedule = parseTrackScheduleElement(reader);
            track["trackSchedule"] = schedule;
        } else if (elementName == "CustomExtensionList") {
            QJsonObject extensions = parseCustomExtensionListElement(reader);
            track["customExtensionList"] = extensions;
        } else if (elementName == "IntelligentRecord") {
            track["intelligentRecord"] = (reader.readElementText() == "true");
        } else if (elementName == "delayTime" || elementName == "DelayTime") {
            track["delayTime"] = reader.readElementText().toInt();
        } else if (elementName == "durationEnabled" || elementName == "DurationEnabled") {
            track["durationEnabled"] = (reader.readElementText() == "true");
        } else if (elementName == "redundancyRec" || elementName == "RedundancyRec") {
            track["redundancyRec"] = (reader.readElementText() == "true");
        } else if (elementName == "passbackRecord" || elementName == "PassbackRecord") {
            track["passbackRecord"] = (reader.readElementText() == "true");
        } else if (elementName == "lockDuration" || elementName == "LockDuration") {
            track["lockDuration"] = reader.readElementText().toInt();
        } else if (elementName == "recordBackup" || elementName == "RecordBackup") {
            track["recordBackup"] = (reader.readElementText() == "true");
        } else if (elementName == "SVCLevel" || elementName == "SVCLevel") {
            track["SVCLevel"] = reader.readElementText().toInt();
        } else if (elementName == "recordManage" || elementName == "RecordManage") {
            track["recordManage"] = (reader.readElementText() == "true");
        } else if (elementName == "extraSaveAudio" || elementName == "ExtraSaveAudio") {
            track["extraSaveAudio"] = (reader.readElementText() == "true");
        } else if (elementName == "associatedResourceID" || elementName == "AssociatedResourceID") {
            track["associatedResourceID"] = reader.readElementText();
        } else if (elementName == "copyChannelList" || elementName == "CopyChannelList") {
            QJsonArray channels;
            while (reader.readNextStartElement()) {
                if (reader.name() == "channelID" || reader.name() == "ChannelID") {
                    channels.append(reader.readElementText().toInt());
                } else {
                    reader.skipCurrentElement();
                }
            }
            track["copyChannelList"] = channels;
        } else {
            reader.skipCurrentElement();
        }
    }
    
    return track;
}

QJsonObject HikvisionWorker::parseTrackScheduleElement(QXmlStreamReader& reader)
{
    QJsonObject schedule;
    
    while (reader.readNextStartElement()) {
        QString elementName = reader.name().toString();
        
        if (elementName == "ScheduleBlockList") {
            QJsonArray blocks;
            while (reader.readNextStartElement()) {
                if (reader.name() == "ScheduleBlock") {
                    QJsonObject block = parseScheduleBlockElement(reader);
                    blocks.append(block);
                } else {
                    reader.skipCurrentElement();
                }
            }
            schedule["scheduleBlockList"] = blocks;
        } else {
            reader.skipCurrentElement();
        }
    }
    
    return schedule;
}

QJsonObject HikvisionWorker::parseScheduleBlockElement(QXmlStreamReader& reader)
{
    QJsonObject block;
    
    while (reader.readNextStartElement()) {
        QString elementName = reader.name().toString();
        
        if (elementName == "ScheduleBlockGUID") {
            block["scheduleBlockGUID"] = reader.readElementText();
        } else if (elementName == "Name") {
            block["name"] = reader.readElementText();
        } else if (elementName == "StartTime") {
            block["startTime"] = reader.readElementText();
        } else if (elementName == "EndTime") {
            block["endTime"] = reader.readElementText();
        } else if (elementName == "DayOfWeek") {
            block["dayOfWeek"] = reader.readElementText();
        } else if (elementName == "TimeOfDay") {
            block["timeOfDay"] = reader.readElementText();
        } else if (elementName == "ScheduleDSTEnable") {
            block["scheduleDSTEnable"] = (reader.readElementText() == "true");
        } else if (elementName == "Description") {
            block["description"] = reader.readElementText();
        } else if (elementName == "Actions") {
            QJsonArray actions;
            while (reader.readNextStartElement()) {
                if (reader.name() == "ScheduleAction") {
                    QJsonObject action = parseScheduleActionElement(reader);
                    actions.append(action);
                } else {
                    reader.skipCurrentElement();
                }
            }
            block["actions"] = actions;
        } else {
            reader.skipCurrentElement();
        }
    }
    
    return block;
}

QJsonObject HikvisionWorker::parseScheduleActionElement(QXmlStreamReader& reader)
{
    QJsonObject action;
    
    while (reader.readNextStartElement()) {
        QString elementName = reader.name().toString();
        
        if (elementName == "id") {
            action["id"] = reader.readElementText().toInt();
        } else if (elementName == "Record") {
            action["record"] = (reader.readElementText() == "true");
        } else if (elementName == "Log") {
            action["log"] = (reader.readElementText() == "true");
        } else if (elementName == "SaveImg") {
            action["saveImg"] = (reader.readElementText() == "true");
        } else if (elementName == "ActionRecordingMode") {
            action["actionRecordingMode"] = reader.readElementText();
        } else if (elementName == "PreRecordTimeSeconds") {
            action["preRecordTimeSeconds"] = reader.readElementText().toInt();
        } else if (elementName == "PostRecordTimeSeconds") {
            action["postRecordTimeSeconds"] = reader.readElementText().toInt();
        } else {
            reader.skipCurrentElement();
        }
    }
    
    return action;
}

QJsonObject HikvisionWorker::parseCustomExtensionListElement(QXmlStreamReader& reader)
{
    QJsonObject extensions;
    
    while (reader.readNextStartElement()) {
        QString elementName = reader.name().toString();
        
        if (elementName == "CustomExtension") {
            QJsonObject extension;
            while (reader.readNextStartElement()) {
                QString extName = reader.name().toString();
                extension[extName] = reader.readElementText();
            }
            extensions[QString("extension%1").arg(extensions.size() + 1)] = extension;
        } else {
            reader.skipCurrentElement();
        }
    }
    
    return extensions;
}

QByteArray HikvisionWorker::convertJsonToRecordingScheduleXml(const QJsonObject& jsonObj)
{
    QByteArray xml;
    QXmlStreamWriter writer(&xml);
    writer.setAutoFormatting(true);
    
    writer.writeStartDocument();
    
    // 检查是单个Track还是TrackList
    if (jsonObj.contains("track")) {
        // 单个Track
        QJsonObject track = jsonObj["track"].toObject();
        writeTrackElement(writer, track);
    } else if (jsonObj.contains("tracks")) {
        // TrackList
        writer.writeStartElement("TrackList");
        writer.writeAttribute("version", "2.0");
        writer.writeAttribute("xmlns", "http://www.isapi.org/ver20/XMLSchema");
        
        QJsonArray tracks = jsonObj["tracks"].toArray();
        for (const QJsonValue& trackValue : tracks) {
            QJsonObject track = trackValue.toObject();
            writeTrackElement(writer, track);
        }
        
        writer.writeEndElement(); // TrackList
    } else {
        // 直接作为Track对象
        writeTrackElement(writer, jsonObj);
    }
    
    writer.writeEndDocument();
    return xml;
}

void HikvisionWorker::writeTrackElement(QXmlStreamWriter& writer, const QJsonObject& track)
{
    writer.writeStartElement("Track");
    writer.writeAttribute("version", "2.0");
    writer.writeAttribute("xmlns", "http://www.isapi.org/ver20/XMLSchema");
    
    // 写入基本属性
    if (track.contains("id")) {
        writer.writeTextElement("id", QString::number(track["id"].toInt()));
    }
    if (track.contains("channel")) {
        writer.writeTextElement("Channel", QString::number(track["channel"].toInt()));
    }
    if (track.contains("enable")) {
        writer.writeTextElement("Enable", track["enable"].toBool() ? "true" : "false");
    }
    if (track.contains("description")) {
        writer.writeTextElement("Description", track["description"].toString());
    }
    if (track.contains("trackGUID")) {
        writer.writeTextElement("TrackGUID", track["trackGUID"].toString());
    }
    if (track.contains("size")) {
        writer.writeTextElement("Size", QString::number(track["size"].toVariant().toLongLong()));
    }
    if (track.contains("duration")) {
        writer.writeTextElement("Duration", QString::number(track["duration"].toVariant().toLongLong()));
    }
    if (track.contains("defaultRecordingMode")) {
        writer.writeTextElement("DefaultRecordingMode", track["defaultRecordingMode"].toString());
    }
    if (track.contains("loopEnable")) {
        writer.writeTextElement("LoopEnable", track["loopEnable"].toBool() ? "true" : "false");
    }
    if (track.contains("srcDescriptor")) {
        writer.writeTextElement("SrcDescriptor", track["srcDescriptor"].toString());
    }
    
    // 写入录像计划
    if (track.contains("trackSchedule")) {
        writeTrackScheduleElement(writer, track["trackSchedule"].toObject());
    }
    
    // 写入自定义扩展
    if (track.contains("customExtensionList")) {
        writeCustomExtensionListElement(writer, track["customExtensionList"].toObject());
    }
    
    // 写入其他属性
    if (track.contains("intelligentRecord")) {
        writer.writeTextElement("IntelligentRecord", track["intelligentRecord"].toBool() ? "true" : "false");
    }
    if (track.contains("delayTime")) {
        writer.writeTextElement("delayTime", QString::number(track["delayTime"].toInt()));
    }
    if (track.contains("durationEnabled")) {
        writer.writeTextElement("durationEnabled", track["durationEnabled"].toBool() ? "true" : "false");
    }
    if (track.contains("redundancyRec")) {
        writer.writeTextElement("redundancyRec", track["redundancyRec"].toBool() ? "true" : "false");
    }
    if (track.contains("passbackRecord")) {
        writer.writeTextElement("passbackRecord", track["passbackRecord"].toBool() ? "true" : "false");
    }
    if (track.contains("lockDuration")) {
        writer.writeTextElement("lockDuration", QString::number(track["lockDuration"].toInt()));
    }
    if (track.contains("recordBackup")) {
        writer.writeTextElement("recordBackup", track["recordBackup"].toBool() ? "true" : "false");
    }
    if (track.contains("SVCLevel")) {
        writer.writeTextElement("SVCLevel", QString::number(track["SVCLevel"].toInt()));
    }
    if (track.contains("recordManage")) {
        writer.writeTextElement("recordManage", track["recordManage"].toBool() ? "true" : "false");
    }
    if (track.contains("extraSaveAudio")) {
        writer.writeTextElement("extraSaveAudio", track["extraSaveAudio"].toBool() ? "true" : "false");
    }
    if (track.contains("associatedResourceID")) {
        writer.writeTextElement("AssociatedResourceID", track["associatedResourceID"].toString());
    }
    if (track.contains("copyChannelList")) {
        QJsonArray channels = track["copyChannelList"].toArray();
        writer.writeStartElement("CopyChannelList");
        for (const QJsonValue& channelValue : channels) {
            writer.writeTextElement("ChannelID", QString::number(channelValue.toInt()));
        }
        writer.writeEndElement(); // CopyChannelList
    }
    
    writer.writeEndElement(); // Track
}

void HikvisionWorker::writeTrackScheduleElement(QXmlStreamWriter& writer, const QJsonObject& schedule)
{
    writer.writeStartElement("TrackSchedule");
    
    if (schedule.contains("scheduleBlockList")) {
        QJsonArray blocks = schedule["scheduleBlockList"].toArray();
        for (const QJsonValue& blockValue : blocks) {
            QJsonObject block = blockValue.toObject();
            writeScheduleBlockElement(writer, block);
        }
    }
    
    writer.writeEndElement(); // TrackSchedule
}

void HikvisionWorker::writeScheduleBlockElement(QXmlStreamWriter& writer, const QJsonObject& block)
{
    writer.writeStartElement("ScheduleBlock");
    
    if (block.contains("scheduleBlockGUID")) {
        writer.writeTextElement("ScheduleBlockGUID", block["scheduleBlockGUID"].toString());
    }
    if (block.contains("name")) {
        writer.writeTextElement("Name", block["name"].toString());
    }
    if (block.contains("startTime")) {
        writer.writeTextElement("StartTime", block["startTime"].toString());
    }
    if (block.contains("endTime")) {
        writer.writeTextElement("EndTime", block["endTime"].toString());
    }
    if (block.contains("dayOfWeek")) {
        writer.writeTextElement("DayOfWeek", block["dayOfWeek"].toString());
    }
    if (block.contains("timeOfDay")) {
        writer.writeTextElement("TimeOfDay", block["timeOfDay"].toString());
    }
    if (block.contains("scheduleDSTEnable")) {
        writer.writeTextElement("ScheduleDSTEnable", block["scheduleDSTEnable"].toBool() ? "true" : "false");
    }
    if (block.contains("description")) {
        writer.writeTextElement("Description", block["description"].toString());
    }
    if (block.contains("actions")) {
        QJsonArray actions = block["actions"].toArray();
        if (!actions.isEmpty()) {
            writer.writeStartElement("Actions");
            for (const QJsonValue& actionValue : actions) {
                QJsonObject action = actionValue.toObject();
                writeScheduleActionElement(writer, action);
            }
            writer.writeEndElement(); // Actions
        }
    }
    
    writer.writeEndElement(); // ScheduleBlock
}

void HikvisionWorker::writeScheduleActionElement(QXmlStreamWriter& writer, const QJsonObject& action)
{
    writer.writeStartElement("ScheduleAction");
    
    if (action.contains("id")) {
        writer.writeTextElement("id", QString::number(action["id"].toInt()));
    }
    if (action.contains("record")) {
        writer.writeTextElement("Record", action["record"].toBool() ? "true" : "false");
    }
    if (action.contains("log")) {
        writer.writeTextElement("Log", action["log"].toBool() ? "true" : "false");
    }
    if (action.contains("saveImg")) {
        writer.writeTextElement("SaveImg", action["saveImg"].toBool() ? "true" : "false");
    }
    if (action.contains("actionRecordingMode")) {
        writer.writeTextElement("ActionRecordingMode", action["actionRecordingMode"].toString());
    }
    if (action.contains("preRecordTimeSeconds")) {
        writer.writeTextElement("PreRecordTimeSeconds", QString::number(action["preRecordTimeSeconds"].toInt()));
    }
    if (action.contains("postRecordTimeSeconds")) {
        writer.writeTextElement("PostRecordTimeSeconds", QString::number(action["postRecordTimeSeconds"].toInt()));
    }
    
    writer.writeEndElement(); // ScheduleAction
}

void HikvisionWorker::writeCustomExtensionListElement(QXmlStreamWriter& writer, const QJsonObject& extensions)
{
    writer.writeStartElement("CustomExtensionList");
    
    // 遍历所有扩展
    for (auto it = extensions.begin(); it != extensions.end(); ++it) {
        QJsonObject extension = it.value().toObject();
        writer.writeStartElement("CustomExtension");
        
        // 写入扩展的所有属性
        for (auto extIt = extension.begin(); extIt != extension.end(); ++extIt) {
            writer.writeTextElement(extIt.key(), extIt.value().toString());
        }
        
        writer.writeEndElement(); // CustomExtension
    }
    
    writer.writeEndElement(); // CustomExtensionList
}

// ========== 录像计划相关Worker方法 ==========
void HikvisionWorker::getRecordingSchedule(int channelId, int trackId)
{
    qDebug() << "Worker: Getting recording schedule for channel:" << channelId << "trackId:" << trackId;
    
    // 构建请求URL
    QString url;
    if (trackId > 0) {
        // 如果指定了trackId，获取特定轨道的录像计划
        url = QString("http://%1/ISAPI/ContentMgmt/record/tracks/%2").arg(m_serverIp).arg(trackId);
    } else {
        // 否则获取所有轨道的录像计划
        url = QString("http://%1/ISAPI/ContentMgmt/record/tracks").arg(m_serverIp);
    }
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject schedule = parseRecordingScheduleXml(response.toUtf8());
        emit recordingScheduleReceived(channelId, trackId, schedule);
    } else {
        emit recordingScheduleError("getRecordingSchedule", "Failed to get recording schedule");
    }
}

void HikvisionWorker::setRecordingSchedule(int channelId, const QJsonObject& scheduleConfig, int trackId)
{
    qDebug() << "Worker: Setting recording schedule for channel:" << channelId << "trackId:" << trackId;
    
    // 构建请求URL
    QString url;
    if (trackId > 0) {
        // 如果指定了trackId，设置特定轨道的录像计划
        url = QString("http://%1/ISAPI/ContentMgmt/record/tracks/%2").arg(m_serverIp).arg(trackId);
    } else {
        // 否则设置所有轨道的录像计划
        url = QString("http://%1/ISAPI/ContentMgmt/record/tracks").arg(m_serverIp);
    }
    
    // 将JSON配置转换为录像计划XML格式
    QByteArray xmlData = convertJsonToRecordingScheduleXml(scheduleConfig);
    
    QString response;
    if (sendHttpRequest(url, "PUT", QString::fromUtf8(xmlData), &response)) {
        emit recordingScheduleSet(channelId, trackId, true, "Recording schedule set successfully");
    } else {
        emit recordingScheduleSet(channelId, trackId, false, "Failed to set recording schedule");
    }
}

// 将JSON对象转换为移动侦测布局XML格式
QByteArray HikvisionWorker::convertJsonToMotionDetectionLayoutXml(const QJsonObject& jsonObj)
{
    QDomDocument doc;
    QDomElement root = doc.createElement("MotionDetectionLayout");
    root.setAttribute("xmlns", "http://www.isapi.org/ver20/XMLSchema");
    root.setAttribute("version", "2.0");
    doc.appendChild(root);
    
    // 添加sensitivityLevel
    if (jsonObj.contains("sensitivityLevel")) {
        QDomElement sensitivityElement = doc.createElement("sensitivityLevel");
        sensitivityElement.appendChild(doc.createTextNode(QString::number(jsonObj["sensitivityLevel"].toInt())));
        root.appendChild(sensitivityElement);
    }
    
    // 添加layout
    if (jsonObj.contains("layout")) {
        QJsonObject layoutObj = jsonObj["layout"].toObject();
        QDomElement layoutElement = doc.createElement("layout");
        
        // 添加gridMap
        if (layoutObj.contains("gridMap")) {
            QDomElement gridMapElement = doc.createElement("gridMap");
            gridMapElement.appendChild(doc.createTextNode(layoutObj["gridMap"].toString()));
            layoutElement.appendChild(gridMapElement);
        }
        
        // 添加roiMap
        if (layoutObj.contains("roiMap")) {
            QDomElement roiMapElement = doc.createElement("roiMap");
            roiMapElement.appendChild(doc.createTextNode(layoutObj["roiMap"].toString()));
            layoutElement.appendChild(roiMapElement);
        }
        
        // 添加RegionList
        if (layoutObj.contains("RegionList")) {
            QDomElement regionListElement = doc.createElement("RegionList");
            QJsonArray regionArray = layoutObj["RegionList"].toArray();
            
            for (const QJsonValue& regionValue : regionArray) {
                QJsonObject regionObj = regionValue.toObject();
                QDomElement regionElement = doc.createElement("Region");
                
                // 添加id
                if (regionObj.contains("id")) {
                    QDomElement idElement = doc.createElement("id");
                    idElement.appendChild(doc.createTextNode(regionObj["id"].toString()));
                    regionElement.appendChild(idElement);
                }
                
                // 添加RegionCoordinatesList
                if (regionObj.contains("RegionCoordinatesList")) {
                    QDomElement coordListElement = doc.createElement("RegionCoordinatesList");
                    QJsonArray coordArray = regionObj["RegionCoordinatesList"].toArray();
                    
                    for (const QJsonValue& coordValue : coordArray) {
                        QJsonObject coordObj = coordValue.toObject();
                        QDomElement coordElement = doc.createElement("RegionCoordinates");
                        
                        if (coordObj.contains("positionX")) {
                            QDomElement posXElement = doc.createElement("positionX");
                            posXElement.appendChild(doc.createTextNode(QString::number(coordObj["positionX"].toInt())));
                            coordElement.appendChild(posXElement);
                        }
                        
                        if (coordObj.contains("positionY")) {
                            QDomElement posYElement = doc.createElement("positionY");
                            posYElement.appendChild(doc.createTextNode(QString::number(coordObj["positionY"].toInt())));
                            coordElement.appendChild(posYElement);
                        }
                        
                        coordListElement.appendChild(coordElement);
                    }
                    
                    regionElement.appendChild(coordListElement);
                }
                
                regionListElement.appendChild(regionElement);
            }
            
            layoutElement.appendChild(regionListElement);
        }
        
        root.appendChild(layoutElement);
    }
    
    // 添加targetType
    if (jsonObj.contains("targetType")) {
        QDomElement targetTypeElement = doc.createElement("targetType");
        targetTypeElement.appendChild(doc.createTextNode(jsonObj["targetType"].toString()));
        root.appendChild(targetTypeElement);
    }
    
    return doc.toByteArray();
}

void HikvisionWorker::getMotionDetectionLayout(int channelId, const QString& regionType)
{
    qDebug() << "Worker: Getting motion detection layout for channel:" << channelId;
    
    // 尝试多个可能的ISAPI端点
    QStringList possibleUrls = {
        QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout")
            .arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout")
            .arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
            .arg(m_serverIp).arg(channelId)
    };
    
    // 如果通道号大于32，也尝试原始通道号
    if (channelId > 32) {
        int originalChannel = channelId - 32;
        possibleUrls.append(QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout")
            .arg(m_serverIp).arg(originalChannel));
        possibleUrls.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout")
            .arg(m_serverIp).arg(originalChannel));
        possibleUrls.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
            .arg(m_serverIp).arg(originalChannel));
    }
    
    // 添加regionType参数
    if (!regionType.isEmpty()) {
        for (int i = 0; i < possibleUrls.size(); ++i) {
            if (possibleUrls[i].contains("/layout")) {
                possibleUrls[i] += QString("?regionType=%1").arg(regionType);
            }
        }
    }
    
    QString response;
    bool success = false;
    QString successUrl;
    QString lastError;
    
    // 尝试每个可能的URL
    for (const QString& url : possibleUrls) {
        qDebug() << "Trying motion detection layout GET URL:" << url;
        
        if (sendHttpRequest(url, "GET", QString(), &response)) {
            // 检查响应是否包含错误信息
            if (!response.contains("Invalid Operation") && !response.contains("notSupport")) {
                success = true;
                successUrl = url;
                qDebug() << "Successfully got motion detection layout via:" << url;
                break;
            } else {
                lastError = QString("URL not supported: %1, Response: %2").arg(url).arg(response);
                qDebug() << lastError;
            }
        } else {
            lastError = QString("Failed to connect to: %1").arg(url);
            qDebug() << lastError;
        }
    }
    
    if (success) {
        QJsonObject layout = parseMotionDetectionLayoutXml(response.toUtf8());
        emit motionDetectionLayoutReceived(channelId, layout);
    } else {
        qCritical() << "All motion detection layout GET endpoints failed for channel:" << channelId;
        qCritical() << "Last error:" << lastError;
        emit motionDetectionError("getMotionDetectionLayout", QString("Failed to get motion detection layout - %1").arg(lastError));
    }
}

void HikvisionWorker::setMotionDetectionLayout(int channelId, const QJsonObject& layout, const QString& regionType)
{
    qDebug() << "Worker: Setting motion detection layout for channel:" << channelId;
    
    // 尝试多个可能的ISAPI端点
    QStringList possibleUrls = {
        QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout")
            .arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout")
            .arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
            .arg(m_serverIp).arg(channelId)
    };
    
    // 如果通道号大于32，也尝试原始通道号
    if (channelId > 32) {
        int originalChannel = channelId - 32;
        possibleUrls.append(QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout")
            .arg(m_serverIp).arg(originalChannel));
        possibleUrls.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout")
            .arg(m_serverIp).arg(originalChannel));
        possibleUrls.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
            .arg(m_serverIp).arg(originalChannel));
    }
    
    // 添加regionType参数
    if (!regionType.isEmpty()) {
        for (int i = 0; i < possibleUrls.size(); ++i) {
            if (possibleUrls[i].contains("/layout")) {
                possibleUrls[i] += QString("?regionType=%1").arg(regionType);
            }
        }
    }
    
    // 将JSON配置转换为移动侦测布局XML
    QByteArray xmlData = convertJsonToMotionDetectionLayoutXml(layout);
    qDebug() << "Motion detection XML data:" << QString::fromUtf8(xmlData);
    
    QString response;
    bool success = false;
    QString successUrl;
    QString lastError;
    
    // 尝试每个可能的URL
    for (const QString& url : possibleUrls) {
        qDebug() << "Trying motion detection layout URL:" << url;
        
        if (sendHttpRequest(url, "PUT", QString::fromUtf8(xmlData), &response)) {
            // 检查响应是否包含错误信息
            if (!response.contains("Invalid Operation") && !response.contains("notSupport")) {
                success = true;
                successUrl = url;
                qDebug() << "Successfully set motion detection layout via:" << url;
                break;
            } else {
                lastError = QString("URL not supported: %1, Response: %2").arg(url).arg(response);
                qDebug() << lastError;
            }
        } else {
            lastError = QString("Failed to connect to: %1").arg(url);
            qDebug() << lastError;
        }
    }
    
    if (success) {
        emit motionDetectionLayoutSet(channelId, true, QString("Motion detection layout set successfully via %1").arg(successUrl));
    } else {
        qCritical() << "All motion detection layout endpoints failed for channel:" << channelId;
        qCritical() << "Last error:" << lastError;
        emit motionDetectionLayoutSet(channelId, false, QString("Failed to set motion detection layout - %1").arg(lastError));
    }
}

// 新增：生成缓存键
QString HikvisionCtrl::generateCacheKey(const QString& nvrIp, const QString& ipcIp)
{
    return QString("%1|%2").arg(nvrIp).arg(ipcIp);
}

// 新增：更新通道缓存
void HikvisionCtrl::updateChannelCache(const QString& nvrIp, const QString& ipcIp, int channelNumber)
{
    QString cacheKey = generateCacheKey(nvrIp, ipcIp);
    ChannelInfo info(channelNumber, nvrIp, ipcIp);
    m_channelCache[cacheKey] = info;
    qDebug() << "更新通道缓存，键:" << cacheKey << "通道:" << channelNumber;
}

// 新增：从缓存获取通道信息
ChannelInfo HikvisionCtrl::getChannelFromCache(const QString& nvrIp, const QString& ipcIp)
{
    QString cacheKey = generateCacheKey(nvrIp, ipcIp);
    if (m_channelCache.contains(cacheKey)) {
        ChannelInfo info = m_channelCache[cacheKey];
        
        // 检查缓存是否过期（例如，1小时后过期）
        QDateTime now = QDateTime::currentDateTime();
        if (info.lastUpdated.secsTo(now) < 3600) {  // 1小时 = 3600秒
            return info;
        } else {
            qDebug() << "缓存过期，移除过期条目:" << cacheKey;
            m_channelCache.remove(cacheKey);
        }
    }
    
    return ChannelInfo();  // 返回无效的缓存信息
}

int HikvisionCtrl::parseChannelInfoForIP(const QString& xmlResponse, const QString& ipcIp)
{
    qDebug() << "Parsing channel info for IP:" << ipcIp;
    
    QXmlStreamReader reader(xmlResponse);
    int channelId = -1;
    bool inChannel = false;
    QString currentChannelId;
    QString currentChannelIp;
    
    // 支持多种通道类型的XML节点名称
    QStringList channelNodeNames = {
        "VideoInputChannel", 
        "InputProxyChannel", 
        "StreamingChannel", 
        "Channel"
    };
    
    // 支持多种IP地址字段的XML节点名称
    QStringList ipFieldNames = {
        "ipAddress",
        "IPAddress", 
        "ip",
        "address",
        "deviceAddress"
    };
    
    QString currentChannelType;
    
    while (!reader.atEnd()) {
        reader.readNext();
        
        if (reader.isStartElement()) {
            // 检查是否是任何类型的通道节点
            QString elementName = reader.name().toString();
            if (channelNodeNames.contains(elementName)) {
                inChannel = true;
                currentChannelType = elementName;
                currentChannelId.clear();
                currentChannelIp.clear();
                qDebug() << "Found channel node:" << elementName;
            } else if (inChannel && reader.name() == "id") {
                currentChannelId = reader.readElementText();
                qDebug() << "Channel ID:" << currentChannelId;
            } else if (inChannel && ipFieldNames.contains(elementName)) {
                // 直接读取IP地址
                currentChannelIp = reader.readElementText();
                qDebug() << "Found IP address:" << currentChannelIp << "in field:" << elementName;
            } else if (inChannel && (reader.name() == "sourceInputPortDescriptor" || 
                                   reader.name() == "inputPort" || 
                                   reader.name() == "deviceInfo" ||
                                   reader.name() == "networkInfo")) {
                // 在这些容器节点中查找IP地址信息
                QString containerName = reader.name().toString();
                while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == containerName)) {
                    reader.readNext();
                    if (reader.isStartElement()) {
                        QString subElementName = reader.name().toString();
                        if (ipFieldNames.contains(subElementName)) {
                            currentChannelIp = reader.readElementText();
                            qDebug() << "Found IP address:" << currentChannelIp << "in container:" << containerName;
                            break;
                        }
                    }
                }
            }
        } else if (reader.isEndElement()) {
            QString elementName = reader.name().toString();
            if (channelNodeNames.contains(elementName) && elementName == currentChannelType) {
                // 检查当前通道是否匹配目标IP
                qDebug() << "End of channel node. Channel ID:" << currentChannelId << "IP:" << currentChannelIp;
                if (!currentChannelIp.isEmpty() && currentChannelIp == ipcIp) {
                    bool ok;
                    int id = currentChannelId.toInt(&ok);
                    if (ok) {
                        channelId = id;
                        qDebug() << "Found matching channel:" << channelId << "for IP:" << ipcIp;
                        break;
                    } else {
                        qDebug() << "Channel ID is not a valid integer:" << currentChannelId;
                    }
                }
                inChannel = false;
                currentChannelType.clear();
            }
        }
    }
    
    if (reader.hasError()) {
        qCritical() << "XML parsing error:" << reader.errorString();
        return -1;
    }
    
    if (channelId == -1) {
        qWarning() << "No channel found for IP:" << ipcIp;
        qDebug() << "Complete XML response:" << xmlResponse;
        
        // 尝试输出所有找到的通道信息用于调试
        QXmlStreamReader debugReader(xmlResponse);
        qDebug() << "=== Debug: All channels found in response ===";
        while (!debugReader.atEnd()) {
            debugReader.readNext();
            if (debugReader.isStartElement() && channelNodeNames.contains(debugReader.name().toString())) {
                QString debugChannelId, debugChannelIp;
                QString channelType = debugReader.name().toString();
                
                while (!debugReader.atEnd() && !(debugReader.isEndElement() && debugReader.name() == channelType)) {
                    debugReader.readNext();
                    if (debugReader.isStartElement()) {
                        if (debugReader.name() == "id") {
                            debugChannelId = debugReader.readElementText();
                        } else if (ipFieldNames.contains(debugReader.name().toString())) {
                            debugChannelIp = debugReader.readElementText();
                        }
                    }
                }
                qDebug() << "Channel found - Type:" << channelType << "ID:" << debugChannelId << "IP:" << debugChannelIp;
            }
        }
        qDebug() << "=== End debug info ===";
    }
    
    return channelId;
}

// 录像搜索处理逻辑已合并到searchRecording方法中

QString HikvisionCtrl::createSearchXml(const QString& searchId, int trackId, 
                                      const QString& startTime, const QString& endTime, 
                                      int maxResults, int searchResultPosition)
{
    QString xml;
    QXmlStreamWriter writer(&xml);
    
    // 设置格式化输出
    writer.setAutoFormatting(true);
    writer.setAutoFormattingIndent(0); // 不使用缩进，保持原格式
    
    // 手动构建XML以确保格式完全匹配官方示例
    xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    xml += "<CMSearchDescription>\n";
    xml += "<searchID>" + searchId + "</searchID>\n";
    xml += "<trackList>\n";
    xml += "<trackID>" + QString::number(trackId) + "</trackID>\n";
    xml += "</trackList>\n";
    xml += "<timeSpanList>\n";
    xml += "<timeSpan>\n";
    xml += "<startTime>" + startTime + "</startTime>\n";
    xml += "<endTime>" + endTime + "</endTime>\n";
    xml += "</timeSpan>\n";
    xml += "</timeSpanList>\n";
    xml += "<maxResults>" + QString::number(maxResults) + "</maxResults>\n";
    xml += "<searchResultPosition>" + QString::number(searchResultPosition) + "</searchResultPosition>\n";
    xml += "<metadataList>\n";
    xml += "<metadataDescriptor>//recordType.meta.std-cgi.com</metadataDescriptor>\n";
    xml += "</metadataList>\n";
    xml += "</CMSearchDescription>";
    
    return xml;
}

QJsonObject HikvisionCtrl::parseSearchResult(const QString& xmlResponse)
{
    QJsonObject result;
    QXmlStreamReader reader(xmlResponse);
    
    while (!reader.atEnd()) {
        reader.readNext();
        
        if (reader.isStartElement()) {
            if (reader.name() == "searchID") {
                result["searchID"] = reader.readElementText();
            } else if (reader.name() == "responseStatus") {
                result["responseStatus"] = reader.readElementText();
            } else if (reader.name() == "responseStatusStrg") {
                result["responseStatusStrg"] = reader.readElementText();
            } else if (reader.name() == "numOfMatches") {
                result["numOfMatches"] = reader.readElementText().toInt();
            } else if (reader.name() == "matchList") {
                QJsonArray matchArray;
                
                while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "matchList")) {
                    reader.readNext();
                    
                    if (reader.isStartElement() && reader.name() == "searchMatchItem") {
                        QJsonObject matchItem;
                        
                        while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "searchMatchItem")) {
                            reader.readNext();
                            
                            if (reader.isStartElement()) {
                                if (reader.name() == "sourceID") {
                                    matchItem["sourceID"] = reader.readElementText();
                                } else if (reader.name() == "trackID") {
                                    matchItem["trackID"] = reader.readElementText();
                                } else if (reader.name() == "timeSpan") {
                                    QJsonObject timeSpan;
                                    
                                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "timeSpan")) {
                                        reader.readNext();
                                        
                                        if (reader.isStartElement()) {
                                            if (reader.name() == "startTime") {
                                                timeSpan["startTime"] = reader.readElementText();
                                            } else if (reader.name() == "endTime") {
                                                timeSpan["endTime"] = reader.readElementText();
                                            }
                                        }
                                    }
                                    matchItem["timeSpan"] = timeSpan;
                                } else if (reader.name() == "mediaSegmentDescriptor") {
                                    QJsonObject mediaSegment;
                                    
                                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "mediaSegmentDescriptor")) {
                                        reader.readNext();
                                        
                                        if (reader.isStartElement()) {
                                            if (reader.name() == "contentType") {
                                                mediaSegment["contentType"] = reader.readElementText();
                                            } else if (reader.name() == "codecType") {
                                                mediaSegment["codecType"] = reader.readElementText();
                                            } else if (reader.name() == "playbackURI") {
                                                mediaSegment["playbackURI"] = reader.readElementText();
                                            } else if (reader.name() == "lockStatus") {
                                                mediaSegment["lockStatus"] = reader.readElementText();
                                            } else if (reader.name() == "name") {
                                                mediaSegment["name"] = reader.readElementText();
                                            }
                                        }
                                    }
                                    matchItem["mediaSegmentDescriptor"] = mediaSegment;
                                }
                            }
                        }
                        
                        matchArray.append(matchItem);
                    }
                }
                
                result["matchList"] = matchArray;
            }
        }
    }
    
    if (reader.hasError()) {
        qCritical() << "XML parsing error:" << reader.errorString();
    }
    
    return result;
}

bool HikvisionCtrl::sendHttpRequest(const QString& url, const QString& method, 
                                   const QString& data, QString* response)
{
    if (!m_curl) {
        qCritical() << "CURL not initialized";
        return false;
    }
    
    QByteArray responseData;
    QString receivedCookie;
    
    // 重置 CURL 选项
    curl_easy_reset(m_curl);
    
    // 设置基本选项
    curl_easy_setopt(m_curl, CURLOPT_URL, url.toUtf8().constData());
    curl_easy_setopt(m_curl, CURLOPT_WRITEFUNCTION, HikvisionWriteCallback);
    curl_easy_setopt(m_curl, CURLOPT_WRITEDATA, &responseData);
    
    // 设置响应头回调以提取Cookie
    curl_easy_setopt(m_curl, CURLOPT_HEADERFUNCTION, HikvisionHeaderCallback);
    curl_easy_setopt(m_curl, CURLOPT_HEADERDATA, &receivedCookie);
    
    // 设置超时 - 减少超时时间防止UI卡顿
    curl_easy_setopt(m_curl, CURLOPT_TIMEOUT, 5L);        // 总超时5秒
    curl_easy_setopt(m_curl, CURLOPT_CONNECTTIMEOUT, 2L);  // 连接超时2秒
    curl_easy_setopt(m_curl, CURLOPT_NOSIGNAL, 1L);       // 防止DNS超时信号中断
    
    // 设置 Digest Auth - 使用硬编码的认证信息
    curl_easy_setopt(m_curl, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
    qDebug() << "username:" << m_username << "password:" << m_password;
    curl_easy_setopt(m_curl, CURLOPT_USERPWD, QString("%1:%2").arg(m_username).arg(m_password).toUtf8().constData());
    
    // 设置请求头
    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded; charset=UTF-8");
    headers = curl_slist_append(headers, "Accept: application/xml");
    headers = curl_slist_append(headers, "User-Agent: ISAPI-Client/1.0");
    
    // 如果有Cookie，添加到请求头
    if (!m_cookie.isEmpty()) {
        QString cookieHeader = QString("Cookie: %1").arg(m_cookie);
        headers = curl_slist_append(headers, cookieHeader.toUtf8().constData());
    }
    
    curl_easy_setopt(m_curl, CURLOPT_HTTPHEADER, headers);
    
    // 设置请求方法和数据
    if (method == "POST") {
        curl_easy_setopt(m_curl, CURLOPT_POST, 1L);
        if (!data.isEmpty()) {
            QByteArray postData = data.toUtf8();
            qDebug() << "POST data size:" << postData.size() << "bytes";
            qDebug() << "POST data preview:" << postData.left(200);
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDS, postData.constData());
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDSIZE, postData.size());
        }
    } else if (method == "GET") {
        curl_easy_setopt(m_curl, CURLOPT_HTTPGET, 1L);
    } else if (method == "PUT") {
        curl_easy_setopt(m_curl, CURLOPT_CUSTOMREQUEST, "PUT");
        if (!data.isEmpty()) {
            QByteArray putData = data.toUtf8();
            qDebug() << "PUT data size:" << putData.size() << "bytes";
            qDebug() << "PUT data preview:" << putData.left(200);
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDS, putData.constData());
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDSIZE, putData.size());
        }
    }
    
    // 执行请求
    CURLcode res = curl_easy_perform(m_curl);
    
    // 清理头部
    curl_slist_free_all(headers);
    
    if (res != CURLE_OK) {
        qCritical() << "CURL request failed:" << curl_easy_strerror(res);
        return false;
    }
    
    // 如果收到了新的Cookie，保存它
    if (!receivedCookie.isEmpty()) {
        m_cookie = receivedCookie;
    }
    
    // 检查HTTP状态码
    long httpCode = 0;
    curl_easy_getinfo(m_curl, CURLINFO_RESPONSE_CODE, &httpCode);
    
    qDebug() << "HTTP Response Code:" << httpCode;
    qDebug() << "HTTP Response Body:" << QString::fromUtf8(responseData);
    
    if (httpCode != 200) {
        qCritical() << "HTTP request failed with code:" << httpCode;
        qCritical() << "URL:" << url;
        qCritical() << "Method:" << method;
        qCritical() << "Request Data:" << data;
        qCritical() << "Response:" << QString::fromUtf8(responseData);
        
        // 对于403错误，可能是权限问题或者XML格式问题
        if (httpCode == 403) {
            qCritical() << "403 Forbidden - This could be due to:";
            qCritical() << "1. Insufficient user permissions";
            qCritical() << "2. Invalid XML format or structure";
            qCritical() << "3. Device does not support this specific ISAPI endpoint";
        }
        
        return false;
    }
    
    if (response) {
        *response = QString::fromUtf8(responseData);
    }
    
    qDebug() << "HTTP request successful:" << url;
    return true;
}




bool HikvisionCtrl::authenticateAndGetCookie()
{
    // 如果已有Cookie，先尝试验证是否有效
    if (!m_cookie.isEmpty()) {
        return true;
    }
    
    QString url = QString("http://%1/ISAPI/Security/userCheck").arg(m_serverIp);
    QString response;
    
    // 发送认证请求
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        // 从响应头中提取Cookie
        // 注意：实际实现中需要从CURL获取响应头
        qDebug() << "获取Cookie成功";
        return true;
    }
    
    return false;
}

QString HikvisionCtrl::buildAuthenticatedRtspUrl(const QString& originalUrl)
{
    qDebug() << "=== 开始构建认证RTSP URL ===";
    qDebug() << "原始URL:" << originalUrl;
    
    // 首先解码HTML实体（如 &amp; -> &）
    QString decodedUrl = originalUrl;
    decodedUrl.replace("&amp;", "&");
    qDebug() << "解码HTML实体后:" << decodedUrl;
    
    // 从原始URL中提取参数
    QUrl url(decodedUrl);
    
    // 检查URL是否有效
    if (!url.isValid()) {
        qCritical() << "无效的RTSP URL:" << decodedUrl;
        return QString();
    }
    
    // 获取主机和端口
    QString host = url.host();
    int port = url.port(554); // RTSP默认端口是554
    
    // 构建带用户名密码的RTSP URL
    // 格式: rtsp://username:password@host:port/path?params
    QString authenticatedUrl = QString("rtsp://%1:%2@%3:%4")
        .arg(m_username)
        .arg(m_password)  
        .arg(host)
        .arg(port);
    
    // 添加路径
    authenticatedUrl += url.path();
    
    // 过滤查询参数，只保留时间相关的参数
    if (url.hasQuery()) {
        QString queryString = url.query();
        qDebug() << "原始查询字符串:" << queryString;
        
        // 使用字符串处理方式，更可靠
        QStringList params = queryString.split('&');
        QStringList filteredParams;
        
        qDebug() << "开始过滤参数，总共" << params.size() << "个参数";
        
        for (const QString& param : params) {
            if (param.contains('=')) {
                QString paramName = param.split('=').first().toLower();
                if (paramName == "starttime" ) {
                    filteredParams.append(param);
                    qDebug() << "✓ 保留参数:" << param;
                } else {
                    qDebug() << "✗ 过滤掉参数:" << param;
                }
            }
        }
        
        qDebug() << "过滤后剩余参数:" << filteredParams.size() << "个";
        
        // 如果有过滤后的参数，添加到URL中
        if (!filteredParams.isEmpty()) {
            QString filteredQuery = filteredParams.join('&');
            authenticatedUrl += "?" + filteredQuery;
            qDebug() << "过滤后查询字符串:" << filteredQuery;
        }
    }
    
    qDebug() << "构建的认证RTSP URL:" << authenticatedUrl;
    qDebug() << "=== 认证RTSP URL构建完成 ===";
    return authenticatedUrl;
}

QString HikvisionCtrl::getRtspUrlFromSegment(const QJsonObject& segment)
{
    if (segment.contains("mediaSegmentDescriptor")) {
        QJsonObject mediaDesc = segment["mediaSegmentDescriptor"].toObject();
        if (mediaDesc.contains("playbackURI")) {
            return mediaDesc["playbackURI"].toString();
        }
    }
    return QString();
}

// ==================== HikvisionWorker 实现 ====================

HikvisionWorker::HikvisionWorker(QObject* parent)
    : QObject(parent)
    , m_curl(nullptr)
    , m_stopped(false)
{
    // 初始化CURL
    curl_global_init(CURL_GLOBAL_DEFAULT);
    m_curl = curl_easy_init();
    
    if (!m_curl) {
        qCritical() << "Failed to initialize CURL in worker thread";
    }
}

HikvisionWorker::~HikvisionWorker()
{
    // 清理CURL资源
    if (m_curl) {
        curl_easy_cleanup(m_curl);
        m_curl = nullptr;
    }
    curl_global_cleanup();
}

void HikvisionWorker::process()
{
    qDebug() << "HikvisionWorker线程开始运行";
    // 不需要循环，直接启动线程的事件循环
    // 线程会自动处理信号槽调用
    qDebug() << "HikvisionWorker线程事件循环已启动";
}

void HikvisionWorker::stop()
{
    qDebug() << "停止HikvisionWorker线程";
    m_stopped.store(true);
    // 手动发出finished信号，因为没有循环了
    emit finished();
}

void HikvisionWorker::doSearchRecording(const QString& searchId, int trackId, 
                                       const QString& startTime, const QString& endTime, 
                                       int maxResults, int searchResultPosition)
{
    qDebug() << "工作线程中处理录像查询请求";
    
    // 构建请求URL
    QString url = QString("http://%1/ISAPI/ContentMgmt/search").arg(m_serverIp);
    
    // 创建XML请求体
    QString xmlData = createSearchXml(searchId, trackId, startTime, endTime, maxResults, searchResultPosition);
    
    qDebug() << "发送海康录像查询请求到:" << url;
    qDebug() << "用户名:" << m_username << " 密码:" << m_password;

    qDebug() << "请求体:" << xmlData;
    
    // 重试机制配置
    const int maxRetries = 10;           // 最大重试次数
    const int retryDelayMs = 100;      // 重试间隔时间（毫秒）
    QString response;
    bool success = false;
    int attemptCount = 0;
    
    // 尝试发送请求，直到成功或达到最大重试次数
    while (attemptCount < maxRetries && !success) {
        attemptCount++;
        
        if (attemptCount > 1) {
            qDebug() << "第" << attemptCount << "次尝试录像查询...";
            // 重试前等待一段时间
            QThread::msleep(retryDelayMs);
        }
        
        // 发送POST请求
        if (sendHttpRequest(url, "POST", xmlData, &response)) {
            qDebug() << "海康录像查询响应:" << response;
            
            // 解析XML响应
            QJsonObject result = parseSearchResult(response);
            
            // 检查是否有有用的录像段信息
            bool hasValidResults = false;
            if (result.contains("matchList")) {
                QJsonArray matchList = result["matchList"].toArray();
                if (!matchList.isEmpty()) {
                    // 检查是否有有效的mediaSegmentDescriptor
                    for (const QJsonValue& matchValue : matchList) {
                        QJsonObject matchItem = matchValue.toObject();
                        if (matchItem.contains("mediaSegmentDescriptor")) {
                            QJsonObject mediaDesc = matchItem["mediaSegmentDescriptor"].toObject();
                            if (mediaDesc.contains("playbackURI") && !mediaDesc["playbackURI"].toString().isEmpty()) {
                                hasValidResults = true;
                                break;
                            }
                        }
                    }
                }
            }
            
            if (hasValidResults) {
                qDebug() << "找到有效的录像段信息，查询成功";
                emit recordingSearchCompleted(result);
                
                // 如果有录像结果，自动准备第一个录像的RTSP流
                QJsonArray matchList = result["matchList"].toArray();
                if (!matchList.isEmpty()) {
                    QJsonObject firstMatch = matchList.first().toObject();
                    if (firstMatch.contains("mediaSegmentDescriptor")) {
                        QJsonObject mediaDesc = firstMatch["mediaSegmentDescriptor"].toObject();
                        if (mediaDesc.contains("playbackURI")) {
                            QString playbackUri = mediaDesc["playbackURI"].toString();
                            qDebug() << "找到录像播放URI:" << playbackUri;
                        }
                    }
                }
                
                success = true;
            } else {
                qWarning() << "第" << attemptCount << "次尝试：响应中没有有效的录像段信息";
                
                // 检查响应状态
                if (result.contains("responseStatus")) {
                    QString status = result["responseStatus"].toString();
                    QString statusStr = result["responseStatusStrg"].toString();
                    qWarning() << "响应状态:" << status << "(" << statusStr << ")";
                }
                
                if (attemptCount >= maxRetries) {
                    qCritical() << "达到最大重试次数，录像查询失败";
                    emit recordingSearchCompleted(QJsonObject());
                }
            }
        } else {
            qWarning() << "第" << attemptCount << "次尝试：HTTP请求失败";
            
            if (attemptCount >= maxRetries) {
                qCritical() << "达到最大重试次数，海康录像查询失败";
                emit recordingSearchCompleted(QJsonObject());
            }
        }
    }
}

QString HikvisionWorker::createSearchXml(const QString& searchId, int trackId, 
                                       const QString& startTime, const QString& endTime, 
                                       int maxResults, int searchResultPosition)
{
    QString xml;
    xml += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    xml += "<CMSearchDescription>\n";
    xml += "<searchID>" + searchId + "</searchID>\n";
    xml += "<trackList>\n";
    xml += "<trackID>" + QString::number(trackId) + "</trackID>\n";
    xml += "</trackList>\n";
    xml += "<timeSpanList>\n";
    xml += "<timeSpan>\n";
    xml += "<startTime>" + startTime + "</startTime>\n";
    xml += "<endTime>" + endTime + "</endTime>\n";
    xml += "</timeSpan>\n";
    xml += "</timeSpanList>\n";
    xml += "<maxResults>" + QString::number(maxResults) + "</maxResults>\n";
    xml += "<searchResultPostion>" + QString::number(searchResultPosition) + "</searchResultPostion>\n";
    xml += "<metadataList>\n";
    xml += "<metadataDescriptor>//recordType.meta.std-cgi.com</metadataDescriptor>\n";
    xml += "</metadataList>\n";
    xml += "</CMSearchDescription>";
    
    return xml;
}

QJsonObject HikvisionWorker::parseSearchResult(const QString& xmlResponse)
{
    QJsonObject result;
    QXmlStreamReader reader(xmlResponse);
    
    while (!reader.atEnd()) {
        reader.readNext();
        
        if (reader.isStartElement()) {
            if (reader.name() == "searchID") {
                result["searchID"] = reader.readElementText();
            } else if (reader.name() == "responseStatus") {
                result["responseStatus"] = reader.readElementText();
            } else if (reader.name() == "responseStatusStrg") {
                result["responseStatusStrg"] = reader.readElementText();
            } else if (reader.name() == "numOfMatches") {
                result["numOfMatches"] = reader.readElementText().toInt();
            } else if (reader.name() == "matchList") {
                QJsonArray matchArray;
                
                while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "matchList")) {
                    reader.readNext();
                    
                    if (reader.isStartElement() && reader.name() == "searchMatchItem") {
                        QJsonObject matchItem;
                        
                        while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "searchMatchItem")) {
                            reader.readNext();
                            
                            if (reader.isStartElement()) {
                                if (reader.name() == "sourceID") {
                                    matchItem["sourceID"] = reader.readElementText();
                                } else if (reader.name() == "trackID") {
                                    matchItem["trackID"] = reader.readElementText();
                                } else if (reader.name() == "timeSpan") {
                                    QJsonObject timeSpan;
                                    
                                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "timeSpan")) {
                                        reader.readNext();
                                        
                                        if (reader.isStartElement()) {
                                            if (reader.name() == "startTime") {
                                                timeSpan["startTime"] = reader.readElementText();
                                            } else if (reader.name() == "endTime") {
                                                timeSpan["endTime"] = reader.readElementText();
                                            }
                                        }
                                    }
                                    matchItem["timeSpan"] = timeSpan;
                                } else if (reader.name() == "mediaSegmentDescriptor") {
                                    QJsonObject mediaSegment;
                                    
                                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "mediaSegmentDescriptor")) {
                                        reader.readNext();
                                        
                                        if (reader.isStartElement()) {
                                            if (reader.name() == "contentType") {
                                                mediaSegment["contentType"] = reader.readElementText();
                                            } else if (reader.name() == "codecType") {
                                                mediaSegment["codecType"] = reader.readElementText();
                                            } else if (reader.name() == "playbackURI") {
                                                mediaSegment["playbackURI"] = reader.readElementText();
                                            } else if (reader.name() == "lockStatus") {
                                                mediaSegment["lockStatus"] = reader.readElementText();
                                            } else if (reader.name() == "name") {
                                                mediaSegment["name"] = reader.readElementText();
                                            }
                                        }
                                    }
                                    matchItem["mediaSegmentDescriptor"] = mediaSegment;
                                }
                            }
                        }
                        
                        matchArray.append(matchItem);
                    }
                }
                
                result["matchList"] = matchArray;
            }
        }
    }
    
    if (reader.hasError()) {
        qCritical() << "XML parsing error:" << reader.errorString();
    }
    
    return result;
}

bool HikvisionWorker::sendHttpRequest(const QString& url, const QString& method, 
                                     const QString& data, QString* response)
{
    if (!m_curl) {
        qCritical() << "CURL not initialized in worker thread";
        return false;
    }
    
    QByteArray responseData;
    QString receivedCookie;
    
    // 重置 CURL 选项
    curl_easy_reset(m_curl);
    
    // 设置基本选项
    curl_easy_setopt(m_curl, CURLOPT_URL, url.toUtf8().constData());
    curl_easy_setopt(m_curl, CURLOPT_WRITEFUNCTION, HikvisionWriteCallback);
    curl_easy_setopt(m_curl, CURLOPT_WRITEDATA, &responseData);
    
    // 设置响应头回调以提取Cookie
    curl_easy_setopt(m_curl, CURLOPT_HEADERFUNCTION, HikvisionHeaderCallback);
    curl_easy_setopt(m_curl, CURLOPT_HEADERDATA, &receivedCookie);
    
    // 设置超时 - 减少超时时间防止UI卡顿
    curl_easy_setopt(m_curl, CURLOPT_TIMEOUT, 5L);        // 总超时5秒
    curl_easy_setopt(m_curl, CURLOPT_CONNECTTIMEOUT, 2L);  // 连接超时2秒
    curl_easy_setopt(m_curl, CURLOPT_NOSIGNAL, 1L);       // 防止DNS超时信号中断
    
    // 设置 Digest Auth
    curl_easy_setopt(m_curl, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
    curl_easy_setopt(m_curl, CURLOPT_USERPWD, QString("%1:%2").arg(m_username).arg(m_password).toUtf8().constData());
    
    // 设置请求头
    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/xml; charset=UTF-8");
    headers = curl_slist_append(headers, "Accept: application/xml");
    headers = curl_slist_append(headers, "User-Agent: ISAPI-Client/1.0");
    
    // 如果有Cookie，添加到请求头
    if (!m_cookie.isEmpty()) {
        QString cookieHeader = QString("Cookie: %1").arg(m_cookie);
        headers = curl_slist_append(headers, cookieHeader.toUtf8().constData());
    }
    
    curl_easy_setopt(m_curl, CURLOPT_HTTPHEADER, headers);
    
    // 设置请求方法和数据
    if (method == "POST") {
        curl_easy_setopt(m_curl, CURLOPT_POST, 1L);
        if (!data.isEmpty()) {
            QByteArray postData = data.toUtf8();
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDS, postData.constData());
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDSIZE, postData.size());
        }
    } else if (method == "GET") {
        curl_easy_setopt(m_curl, CURLOPT_HTTPGET, 1L);
    } else if (method == "PUT") {
        curl_easy_setopt(m_curl, CURLOPT_CUSTOMREQUEST, "PUT");
        if (!data.isEmpty()) {
            QByteArray putData = data.toUtf8();
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDS, putData.constData());
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDSIZE, putData.size());
        }
    }
    
    // 执行请求
    CURLcode res = curl_easy_perform(m_curl);
    
    // 清理头部
    curl_slist_free_all(headers);
    
    if (res != CURLE_OK) {
        qCritical() << "CURL request failed in worker thread:" << curl_easy_strerror(res);
        return false;
    }
    
    // 如果收到了新的Cookie，保存它
    if (!receivedCookie.isEmpty()) {
        m_cookie = receivedCookie;
    }
    
    // 检查HTTP状态码
    long httpCode = 0;
    curl_easy_getinfo(m_curl, CURLINFO_RESPONSE_CODE, &httpCode);
    
    qDebug() << "HTTP Response Code:" << httpCode;
    
    if (httpCode != 200) {
        qCritical() << "HTTP request failed with code:" << httpCode;
        qCritical() << "URL:" << url;
        qCritical() << "Method:" << method;
        qCritical() << "Request Data:" << data;
        qCritical() << "Response:" << QString::fromUtf8(responseData);
        return false;
    }
    
    if (response) {
        *response = QString::fromUtf8(responseData);
    }
    
    qDebug() << "HTTP request successful in worker thread:" << url;
    return true;
}

int HikvisionWorker::findChannelByIP(const QString& deviceIp, int port,
                                    const QString& username, const QString& password,
                                    const QString& ipcIp)
{
    qDebug() << "Worker: Finding channel for IPC IP:" << ipcIp << "on NVR:" << deviceIp;
    
    qDebug() << "Worker: Using ISAPI interface with credentials:" << username << "password:" << password;

    // 尝试多个不同的ISAPI路径来获取通道信息
    QStringList possibleUrls = {
        QString("http://%1/ISAPI/System/Video/inputs").arg(deviceIp),
        QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels").arg(deviceIp),
        QString("http://%1/ISAPI/Streaming/channels").arg(deviceIp),
        QString("http://%1/ISAPI/System/channels").arg(deviceIp)
    };
    
    // 临时保存当前认证信息
    QString originalServerIp = m_serverIp;
    QString originalUsername = m_username;
    QString originalPassword = m_password;
    
    // 设置临时认证信息
    m_serverIp = deviceIp;
    m_username = username;
    m_password = password;
    
    QString response;
    bool success = false;
    QString successUrl;
    
    // 尝试每个可能的URL，直到找到一个有效的
    for (const QString& url : possibleUrls) {
        qDebug() << "Worker: Trying ISAPI URL:" << url;
        
        if (sendHttpRequest(url, "GET", QString(), &response)) {
            // 检查响应是否包含错误信息
            if (!response.contains("Invalid Operation") && !response.contains("notSupport")) {
                success = true;
                successUrl = url;
                qDebug() << "Worker: Successfully got response from:" << url;
                break;
            } else {
                qDebug() << "Worker: URL not supported:" << url;
            }
        } else {
            qDebug() << "Worker: Failed to connect to:" << url;
        }
    }
    
    // 恢复原始认证信息
    m_serverIp = originalServerIp;
    m_username = originalUsername;
    m_password = originalPassword;
    
    if (!success) {
        qCritical() << "Worker: Failed to get channel info via any ISAPI endpoint";
        qCritical() << "Worker: Last response:" << response;
        return -1;
    }
    
    qDebug() << "Worker: Channel info response:" << response;
    
    // 解析XML响应，查找匹配的IP通道
    int channel = this->parseChannelInfoForIP(response, ipcIp);
    
    if (channel > 0) {
        qDebug() << "Worker: Found IPC" << ipcIp << "on channel" << channel;
    } else {
        qWarning() << "Worker: IPC" << ipcIp << "not found on NVR" << deviceIp;
    }

    return channel < 32 ? channel + 32 : channel;
}

void HikvisionWorker::setCurrentDeviceCredentials(const QString& serverIp, const QString& username, const QString& password)
{
    qDebug() << "Worker: Setting current device credentials for:" << serverIp << "username:" << username;
    m_serverIp = serverIp;
    m_username = username;
    m_password = password;
}

void HikvisionWorker::getSystemCapabilities()
{
    qDebug() << "Worker: Getting system capabilities from:" << m_serverIp;
    
    QString url = QString("http://%1/ISAPI/System/capabilities").arg(m_serverIp);
    QString response;
    
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject capabilities;
        
        // 解析XML响应
        QXmlStreamReader reader(response);
        while (!reader.atEnd()) {
            reader.readNext();
            
            if (reader.isStartElement()) {
                QString elementName = reader.name().toString();
                
                if (elementName == "DeviceCap" || elementName == "SystemCap") {
                    // 解析设备能力信息
                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == elementName)) {
                        reader.readNext();
                        
                        if (reader.isStartElement()) {
                            QString capName = reader.name().toString();
                            QString capValue = reader.readElementText();
                            
                            if (!capValue.isEmpty()) {
                                capabilities[capName] = capValue;
                            }
                        }
                    }
                }
            }
        }
        
        if (reader.hasError()) {
            qCritical() << "Worker: XML parsing error in system capabilities:" << reader.errorString();
            emit systemCapabilitiesReceived(QJsonObject());
        } else {
            qDebug() << "Worker: System capabilities received successfully";
            emit systemCapabilitiesReceived(capabilities);
        }
    } else {
        qCritical() << "Worker: Failed to get system capabilities";
        emit systemCapabilitiesReceived(QJsonObject());
    }
}

void HikvisionWorker::getChannelEventCapabilities(int channelId)
{
    qDebug() << "Worker: Getting channel event capabilities for channel:" << channelId << "from:" << m_serverIp;
    
    QString url = QString("http://%1/ISAPI/Event/channels/%2/capabilities").arg(m_serverIp).arg(channelId);
    QString response;
    
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject capabilities;
        
        // 解析XML响应
        QXmlStreamReader reader(response);
        while (!reader.atEnd()) {
            reader.readNext();
            
            if (reader.isStartElement()) {
                QString elementName = reader.name().toString();
                
                if (elementName == "EventCap") {
                    // 解析事件能力信息
                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "EventCap")) {
                        reader.readNext();
                        
                        if (reader.isStartElement()) {
                            QString capName = reader.name().toString();
                            QString capValue = reader.readElementText();
                            
                            if (!capValue.isEmpty()) {
                                capabilities[capName] = capValue;
                            }
                        }
                    }
                }
            }
        }
        
        if (reader.hasError()) {
            qCritical() << "Worker: XML parsing error in channel event capabilities:" << reader.errorString();
            emit channelEventCapabilitiesReceived(channelId, QJsonObject());
        } else {
            qDebug() << "Worker: Channel event capabilities received successfully for channel:" << channelId;
            emit channelEventCapabilitiesReceived(channelId, capabilities);
        }
    } else {
        qCritical() << "Worker: Failed to get channel event capabilities for channel:" << channelId;
        emit channelEventCapabilitiesReceived(channelId, QJsonObject());
    }
}

void HikvisionWorker::getMotionDetectionCapabilities(int channelId)
{
    qDebug() << "Worker: Getting motion detection capabilities for channel:" << channelId << "from:" << m_serverIp;
    
    QString url = QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/capabilities")
                      .arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject capabilities;
        
        // 解析XML响应
        QXmlStreamReader reader(response);
        while (!reader.atEnd()) {
            reader.readNext();
            
            if (reader.isStartElement()) {
                QString elementName = reader.name().toString();
                
                if (elementName == "MotionDetectionCap") {
                    // 解析移动侦测能力信息
                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "MotionDetectionCap")) {
                        reader.readNext();
                        
                        if (reader.isStartElement()) {
                            QString capName = reader.name().toString();
                            QString capValue = reader.readElementText();
                            
                            if (!capValue.isEmpty()) {
                                capabilities[capName] = capValue;
                            }
                        }
                    }
                }
            }
        }
        
        if (reader.hasError()) {
            qCritical() << "Worker: XML parsing error in motion detection capabilities:" << reader.errorString();
            emit motionDetectionCapabilitiesReceived(channelId, QJsonObject());
        } else {
            qDebug() << "Worker: Motion detection capabilities received successfully for channel:" << channelId;
            emit motionDetectionCapabilitiesReceived(channelId, capabilities);
        }
    } else {
        qCritical() << "Worker: Failed to get motion detection capabilities for channel:" << channelId;
        emit motionDetectionCapabilitiesReceived(channelId, QJsonObject());
    }
}

void HikvisionWorker::getMotionDetectionLayoutCapabilities(int channelId)
{
    qDebug() << "Worker: Getting motion detection layout capabilities for channel:" << channelId << "from:" << m_serverIp;
    
    QString url = QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout/capabilities")
                      .arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject capabilities = parseMotionDetectionLayoutXml(response.toUtf8());
        emit motionDetectionLayoutCapabilitiesReceived(channelId, capabilities);
    } else {
        qCritical() << "Worker: Failed to get motion detection layout capabilities for channel:" << channelId;
        emit motionDetectionLayoutCapabilitiesReceived(channelId, QJsonObject());
    }
}

int HikvisionWorker::parseChannelInfoForIP(const QString& xmlResponse, const QString& ipcIp)
{
    qDebug() << "Worker: Parsing channel info for IP:" << ipcIp;
    
    QXmlStreamReader reader(xmlResponse);
    int channelId = -1;
    bool inChannel = false;
    QString currentChannelId;
    QString currentChannelIp;
    
    // 支持多种通道类型的XML节点名称
    QStringList channelNodeNames = {
        "VideoInputChannel", 
        "InputProxyChannel", 
        "StreamingChannel", 
        "Channel"
    };
    
    // 支持多种IP地址字段的XML节点名称
    QStringList ipFieldNames = {
        "ipAddress",
        "IPAddress", 
        "ip",
        "address",
        "deviceAddress"
    };
    
    QString currentChannelType;
    
    while (!reader.atEnd()) {
        reader.readNext();
        
        if (reader.isStartElement()) {
            // 检查是否是任何类型的通道节点
            QString elementName = reader.name().toString();
            if (channelNodeNames.contains(elementName)) {
                inChannel = true;
                currentChannelType = elementName;
                currentChannelId.clear();
                currentChannelIp.clear();
                qDebug() << "Worker: Found channel node:" << elementName;
            } else if (inChannel && reader.name() == "id") {
                currentChannelId = reader.readElementText();
                qDebug() << "Worker: Channel ID:" << currentChannelId;
            } else if (inChannel && ipFieldNames.contains(elementName)) {
                // 直接读取IP地址
                currentChannelIp = reader.readElementText();
                qDebug() << "Worker: Found IP address:" << currentChannelIp << "in field:" << elementName;
            } else if (inChannel && (reader.name() == "sourceInputPortDescriptor" || 
                                   reader.name() == "inputPort" || 
                                   reader.name() == "deviceInfo" ||
                                   reader.name() == "networkInfo")) {
                // 在这些容器节点中查找IP地址信息
                QString containerName = reader.name().toString();
                while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == containerName)) {
                    reader.readNext();
                    if (reader.isStartElement()) {
                        QString subElementName = reader.name().toString();
                        if (ipFieldNames.contains(subElementName)) {
                            currentChannelIp = reader.readElementText();
                            qDebug() << "Worker: Found IP address:" << currentChannelIp << "in container:" << containerName;
                            break;
                        }
                    }
                }
            }
        } else if (reader.isEndElement()) {
            QString elementName = reader.name().toString();
            if (channelNodeNames.contains(elementName) && elementName == currentChannelType) {
                // 检查当前通道是否匹配目标IP
                qDebug() << "Worker: End of channel node. Channel ID:" << currentChannelId << "IP:" << currentChannelIp;
                if (!currentChannelIp.isEmpty() && currentChannelIp == ipcIp) {
                    bool ok;
                    int id = currentChannelId.toInt(&ok);
                    if (ok) {
                        channelId = id;
                        qDebug() << "Worker: Found matching channel:" << channelId << "for IP:" << ipcIp;
                        break;
                    } else {
                        qDebug() << "Worker: Channel ID is not a valid integer:" << currentChannelId;
                    }
                }
                inChannel = false;
                currentChannelType.clear();
            }
        }
    }
    
    if (reader.hasError()) {
        qCritical() << "Worker: XML parsing error:" << reader.errorString();
        return -1;
    }
    
    if (channelId == -1) {
        qWarning() << "Worker: No channel found for IP:" << ipcIp;
        qDebug() << "Worker: Complete XML response:" << xmlResponse;
        
        // 尝试输出所有找到的通道信息用于调试
        QXmlStreamReader debugReader(xmlResponse);
        qDebug() << "Worker: === Debug: All channels found in response ===";
        while (!debugReader.atEnd()) {
            debugReader.readNext();
            if (debugReader.isStartElement() && channelNodeNames.contains(debugReader.name().toString())) {
                QString debugChannelId, debugChannelIp;
                QString channelType = debugReader.name().toString();
                
                while (!debugReader.atEnd() && !(debugReader.isEndElement() && debugReader.name() == channelType)) {
                    debugReader.readNext();
                    if (debugReader.isStartElement()) {
                        if (debugReader.name() == "id") {
                            debugChannelId = debugReader.readElementText();
                        } else if (ipFieldNames.contains(debugReader.name().toString())) {
                            debugChannelIp = debugReader.readElementText();
                        }
                    }
                }
                qDebug() << "Worker: Channel found - Type:" << channelType << "ID:" << debugChannelId << "IP:" << debugChannelIp;
            }
        }
        qDebug() << "Worker: === End debug info ===";
    }
    
    return channelId;
}

QJsonObject HikvisionWorker::parseMotionDetectionLayoutXml(const QByteArray& xmlData)
{
    QDomDocument doc;
    if (!doc.setContent(xmlData)) {
        qWarning() << "Worker: Failed to parse motion detection layout XML";
        return QJsonObject();
    }
    
    QDomElement root = doc.documentElement();
    QJsonObject result;
    
    // 解析sensitivityLevel
    QDomElement sensitivityElement = root.firstChildElement("sensitivityLevel");
    if (!sensitivityElement.isNull()) {
        result["sensitivityLevel"] = sensitivityElement.text().toInt();
    }
    
    // 解析layout
    QDomElement layoutElement = root.firstChildElement("layout");
    if (!layoutElement.isNull()) {
        QJsonObject layoutObj;
        
        // 解析gridMap
        QDomElement gridMapElement = layoutElement.firstChildElement("gridMap");
        if (!gridMapElement.isNull()) {
            layoutObj["gridMap"] = gridMapElement.text();
        }
        
        // 解析roiMap
        QDomElement roiMapElement = layoutElement.firstChildElement("roiMap");
        if (!roiMapElement.isNull()) {
            layoutObj["roiMap"] = roiMapElement.text();
        }
        
        // 解析RegionList
        QDomElement regionListElement = layoutElement.firstChildElement("RegionList");
        if (!regionListElement.isNull()) {
            QJsonArray regionArray;
            QDomNodeList regionNodes = regionListElement.elementsByTagName("Region");
            
            for (int i = 0; i < regionNodes.count(); ++i) {
                QDomElement regionElement = regionNodes.at(i).toElement();
                QJsonObject regionObj;
                
                // 解析id
                QDomElement idElement = regionElement.firstChildElement("id");
                if (!idElement.isNull()) {
                    regionObj["id"] = idElement.text();
                }
                
                // 解析RegionCoordinatesList
                QDomElement coordListElement = regionElement.firstChildElement("RegionCoordinatesList");
                if (!coordListElement.isNull()) {
                    QJsonArray coordArray;
                    QDomNodeList coordNodes = coordListElement.elementsByTagName("RegionCoordinates");
                    
                    for (int j = 0; j < coordNodes.count(); ++j) {
                        QDomElement coordElement = coordNodes.at(j).toElement();
                        QJsonObject coordObj;
                        
                        QDomElement posXElement = coordElement.firstChildElement("positionX");
                        if (!posXElement.isNull()) {
                            coordObj["positionX"] = posXElement.text().toInt();
                        }
                        
                        QDomElement posYElement = coordElement.firstChildElement("positionY");
                        if (!posYElement.isNull()) {
                            coordObj["positionY"] = posYElement.text().toInt();
                        }
                        
                        coordArray.append(coordObj);
                    }
                    
                    regionObj["RegionCoordinatesList"] = coordArray;
                }
                
                regionArray.append(regionObj);
            }
            
            layoutObj["RegionList"] = regionArray;
        }
        
        result["layout"] = layoutObj;
    }
    
    // 解析targetType
    QDomElement targetTypeElement = root.firstChildElement("targetType");
    if (!targetTypeElement.isNull()) {
        result["targetType"] = targetTypeElement.text();
    }
    
    return result;
}

QJsonObject HikvisionWorker::parseMotionDetectionScheduleXml(const QByteArray& xmlData)
{
    QJsonObject result;
    QDomDocument doc;
    QString errorMsg;
    int errorLine, errorColumn;
    
    if (!doc.setContent(xmlData, &errorMsg, &errorLine, &errorColumn)) {
        qDebug() << "Failed to parse motion detection schedule XML:" << errorMsg << "at line" << errorLine << "column" << errorColumn;
        return result;
    }
    
    QDomElement root = doc.documentElement();
    if (root.tagName() != "Schedule") {
        qDebug() << "Invalid motion detection schedule XML root element:" << root.tagName();
        return result;
    }
    
    // 解析基本信息
    QDomElement idElement = root.firstChildElement("id");
    if (!idElement.isNull()) {
        result["id"] = idElement.text();
    }
    
    QDomElement eventTypeElement = root.firstChildElement("eventType");
    if (!eventTypeElement.isNull()) {
        result["eventType"] = eventTypeElement.text();
    }
    
    QDomElement videoInputChannelIDElement = root.firstChildElement("videoInputChannelID");
    if (!videoInputChannelIDElement.isNull()) {
        result["videoInputChannelID"] = videoInputChannelIDElement.text();
    }
    
    // 解析TimeBlockList
    QDomElement timeBlockListElement = root.firstChildElement("TimeBlockList");
    if (!timeBlockListElement.isNull()) {
        QJsonArray timeBlockArray;
        QDomNodeList timeBlocks = timeBlockListElement.elementsByTagName("TimeBlock");
        
        for (int i = 0; i < timeBlocks.count(); ++i) {
            QDomElement timeBlock = timeBlocks.at(i).toElement();
            QJsonObject timeBlockObj;
            
            QDomElement dayOfWeekElement = timeBlock.firstChildElement("dayOfWeek");
            if (!dayOfWeekElement.isNull()) {
                timeBlockObj["dayOfWeek"] = dayOfWeekElement.text().toInt();
            }
            
            QDomElement timeRangeElement = timeBlock.firstChildElement("TimeRange");
            if (!timeRangeElement.isNull()) {
                QJsonObject timeRangeObj;
                
                QDomElement beginTimeElement = timeRangeElement.firstChildElement("beginTime");
                if (!beginTimeElement.isNull()) {
                    timeRangeObj["beginTime"] = beginTimeElement.text();
                }
                
                QDomElement endTimeElement = timeRangeElement.firstChildElement("endTime");
                if (!endTimeElement.isNull()) {
                    timeRangeObj["endTime"] = endTimeElement.text();
                }
                
                timeBlockObj["TimeRange"] = timeRangeObj;
            }
            
            timeBlockArray.append(timeBlockObj);
        }
        
        result["TimeBlockList"] = timeBlockArray;
    }
    
    // 解析HolidayBlockList
    QDomElement holidayBlockListElement = root.firstChildElement("HolidayBlockList");
    if (!holidayBlockListElement.isNull()) {
        QJsonArray holidayBlockArray;
        QDomNodeList holidayBlocks = holidayBlockListElement.elementsByTagName("TimeBlock");
        
        for (int i = 0; i < holidayBlocks.count(); ++i) {
            QDomElement timeBlock = holidayBlocks.at(i).toElement();
            QJsonObject timeBlockObj;
            
            QDomElement timeRangeElement = timeBlock.firstChildElement("TimeRange");
            if (!timeRangeElement.isNull()) {
                QJsonObject timeRangeObj;
                
                QDomElement beginTimeElement = timeRangeElement.firstChildElement("beginTime");
                if (!beginTimeElement.isNull()) {
                    timeRangeObj["beginTime"] = beginTimeElement.text();
                }
                
                QDomElement endTimeElement = timeRangeElement.firstChildElement("endTime");
                if (!endTimeElement.isNull()) {
                    timeRangeObj["endTime"] = endTimeElement.text();
                }
                
                timeBlockObj["TimeRange"] = timeRangeObj;
            }
            
            holidayBlockArray.append(timeBlockObj);
        }
        
        result["HolidayBlockList"] = holidayBlockArray;
    }
    
    return result;
}

QByteArray HikvisionWorker::convertJsonToMotionDetectionScheduleXml(const QJsonObject& jsonObj)
{
    qDebug() << "Converting JSON to Motion Detection Schedule XML:" << QJsonDocument(jsonObj).toJson();
    
    // 使用QString构建XML，然后转换为UTF-8字节数组
    QString xmlString;
    
    // 手动构建XML以确保格式正确
    xmlString += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    xmlString += "<Schedule xmlns=\"http://www.isapi.org/ver20/XMLSchema\" version=\"2.0\">\n";
    
    // 添加基本信息
    if (jsonObj.contains("id")) {
        xmlString += QString("  <id>%1</id>\n").arg(jsonObj["id"].toString());
    }
    
    if (jsonObj.contains("eventType")) {
        xmlString += QString("  <eventType>%1</eventType>\n").arg(jsonObj["eventType"].toString());
    }
    
    if (jsonObj.contains("videoInputChannelID")) {
        xmlString += QString("  <videoInputChannelID>%1</videoInputChannelID>\n").arg(jsonObj["videoInputChannelID"].toString());
    }
    
    // 处理TimeBlockList - 支持两种数据格式：timeBlockList和TimeBlockList
    QJsonArray timeBlockArray;
    if (jsonObj.contains("timeBlockList")) {
        timeBlockArray = jsonObj["timeBlockList"].toArray();
    } else if (jsonObj.contains("TimeBlockList")) {
        timeBlockArray = jsonObj["TimeBlockList"].toArray();
    }
    
    if (!timeBlockArray.isEmpty()) {
        xmlString += QString("  <TimeBlockList size=\"%1\">\n").arg(timeBlockArray.size());
        
        for (const QJsonValue& value : timeBlockArray) {
            QJsonObject timeBlockObj = value.toObject();
            xmlString += "    <TimeBlock>\n";
            
            if (timeBlockObj.contains("dayOfWeek")) {
                xmlString += QString("      <dayOfWeek>%1</dayOfWeek>\n").arg(timeBlockObj["dayOfWeek"].toInt());
            }
            
            // 处理时间范围 - 支持两种格式：timeBlock和TimeRange
            QJsonObject timeRangeObj;
            if (timeBlockObj.contains("timeBlock")) {
                timeRangeObj = timeBlockObj["timeBlock"].toObject();
            } else if (timeBlockObj.contains("TimeRange")) {
                timeRangeObj = timeBlockObj["TimeRange"].toObject();
            }
            
            if (!timeRangeObj.isEmpty()) {
                xmlString += "      <TimeRange>\n";
                
                if (timeRangeObj.contains("beginTime")) {
                    xmlString += QString("        <beginTime>%1</beginTime>\n").arg(timeRangeObj["beginTime"].toString());
                }
                
                if (timeRangeObj.contains("endTime")) {
                    xmlString += QString("        <endTime>%1</endTime>\n").arg(timeRangeObj["endTime"].toString());
                }
                
                xmlString += "      </TimeRange>\n";
            }
            
            xmlString += "    </TimeBlock>\n";
        }
        
        xmlString += "  </TimeBlockList>\n";
    }
    
    xmlString += "</Schedule>";
    
    // 转换为UTF-8字节数组，不包含BOM
    QByteArray xmlData = xmlString.toUtf8();
    
    qDebug() << "Generated Motion Detection Schedule XML:" << xmlString;
    qDebug() << "XML byte array size:" << xmlData.size();
    qDebug() << "XML starts with:" << xmlData.left(50);
    
    return xmlData;
}

void HikvisionWorker::getMotionDetectionConfig(int channelId)
{
    qDebug() << "Worker: Getting motion detection config for channel:" << channelId;
    
    QString url = QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
                      .arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject config = parseMotionDetectionXml(response.toUtf8());
        emit motionDetectionConfigReceived(channelId, config);
    } else {
        emit motionDetectionConfigReceived(channelId, QJsonObject());
    }
}

void HikvisionWorker::getMotionDetectionSchedule(int channelId)
{
    qDebug() << "Worker: Getting motion detection schedule for channel:" << channelId;
    
    // 尝试多个可能的ISAPI端点
    QStringList possibleUrls;
    
    // 根据通道号类型选择合适的端点格式
    if (channelId > 32) {
        // IP通道 (数字通道)
        int ipChannel = channelId - 32;
        possibleUrls << QString("http://%1/ISAPI/Event/schedules/motionDetections/VMD_video%2")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/Event/schedules/VMD_video%2")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/schedule")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/schedule")
                         .arg(m_serverIp).arg(ipChannel);
    } else {
        // 模拟通道
        possibleUrls << QString("http://%1/ISAPI/Event/schedules/motionDetections/VMD_video%2")
                         .arg(m_serverIp).arg(channelId)
                     << QString("http://%1/ISAPI/Event/schedules/VMD_video%2")
                         .arg(m_serverIp).arg(channelId)
                     << QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/schedule")
                         .arg(m_serverIp).arg(channelId);
    }
    
    QString response;
    bool success = false;
    QString successUrl;
    QString lastError;
    
    // 尝试每个可能的URL
    for (const QString& url : possibleUrls) {
        qDebug() << "Worker: Trying motion detection schedule URL:" << url;
        
        if (sendHttpRequest(url, "GET", QString(), &response)) {
            // 检查响应是否包含错误信息
            if (!response.contains("Invalid Operation") && !response.contains("notSupport") && 
                !response.contains("invalid") && !response.isEmpty()) {
                success = true;
                successUrl = url;
                qDebug() << "Worker: Successfully got motion detection schedule via:" << url;
                break;
            } else {
                lastError = QString("URL not supported: %1, Response: %2").arg(url).arg(response);
                qDebug() << "Worker:" << lastError;
            }
        } else {
            lastError = QString("Failed to connect to: %1").arg(url);
            qDebug() << "Worker:" << lastError;
        }
    }
    
    if (success) {
        QJsonObject schedule = parseMotionDetectionScheduleXml(response.toUtf8());
        emit motionDetectionScheduleReceived(channelId, schedule);
    } else {
        qCritical() << "Worker: All motion detection schedule endpoints failed for channel:" << channelId;
        qCritical() << "Worker: Last error:" << lastError;
        emit motionDetectionError("getMotionDetectionSchedule", QString("Failed to get motion detection schedule - %1").arg(lastError));
    }
}

void HikvisionWorker::setMotionDetectionConfig(int channelId, const QJsonObject& config)
{
    qDebug() << "Worker: Setting motion detection config for channel:" << channelId;
    
    QString url = QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
                      .arg(m_serverIp).arg(channelId);
    
    // 将JSON配置转换为XML
    QByteArray xmlData = convertJsonToXml(config, "MotionDetection");
    
    QString response;
    if (sendHttpRequest(url, "PUT", QString::fromUtf8(xmlData), &response)) {
        emit motionDetectionConfigSet(channelId, true, "Motion detection config set successfully");
    } else {
        emit motionDetectionConfigSet(channelId, false, "Failed to set motion detection config");
    }
}

void HikvisionWorker::setMotionDetectionSchedule(int channelId, const QJsonObject& schedule)
{
    qDebug() << "Worker: Setting motion detection schedule for channel:" << channelId;
    
    // 尝试多个可能的ISAPI端点
    QStringList possibleUrls;
    
    // 根据通道号类型选择合适的端点格式
    if (channelId > 32) {
        // IP通道 (数字通道)
        int ipChannel = channelId - 32;
        possibleUrls << QString("http://%1/ISAPI/Event/schedules/motionDetections/VMD_video%2")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/Event/schedules/VMD_video%2")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/schedule")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/schedule")
                         .arg(m_serverIp).arg(ipChannel);
    } else {
        // 模拟通道
        possibleUrls << QString("http://%1/ISAPI/Event/schedules/motionDetections/VMD_video%2")
                         .arg(m_serverIp).arg(channelId)
                     << QString("http://%1/ISAPI/Event/schedules/VMD_video%2")
                         .arg(m_serverIp).arg(channelId)
                     << QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/schedule")
                         .arg(m_serverIp).arg(channelId);
    }
    
    // 创建包含channelId信息的schedule对象
    QJsonObject scheduleWithId = schedule;
    scheduleWithId["id"] = QString("VMD_video%1").arg(channelId);
    scheduleWithId["eventType"] = "VMD";
    scheduleWithId["videoInputChannelID"] = QString::number(channelId);
    
    // 将JSON配置转换为布防时间XML
    QByteArray xmlData = convertJsonToMotionDetectionScheduleXml(scheduleWithId);
    
    QString response;
    bool success = false;
    QString successUrl;
    QString lastError;
    
    // 尝试每个可能的URL，同时尝试PUT和POST方法
    QStringList methods = {"PUT", "POST"};
    
    for (const QString& url : possibleUrls) {
        for (const QString& method : methods) {
            qDebug() << "Worker: Trying motion detection schedule URL:" << url << "with method:" << method;
            
            if (sendHttpRequest(url, method, QString::fromUtf8(xmlData), &response)) {
                // 检查响应是否包含错误信息
                if (!response.contains("Invalid Operation") && !response.contains("notSupport") && 
                    !response.contains("two root tags") && !response.contains("invalid")) {
                    success = true;
                    successUrl = url;
                    qDebug() << "Worker: Successfully set motion detection schedule via:" << url << "method:" << method;
                    break;
                } else {
                    lastError = QString("URL/Method not supported: %1 %2, Response: %3").arg(method).arg(url).arg(response);
                    qDebug() << "Worker:" << lastError;
                }
            } else {
                lastError = QString("Failed to connect to: %1 with method: %2").arg(url).arg(method);
                qDebug() << "Worker:" << lastError;
            }
        }
        
        if (success) break;
    }
    
    if (success) {
        emit motionDetectionScheduleSet(channelId, true, QString("Motion detection schedule set successfully via %1").arg(successUrl));
    } else {
        qCritical() << "Worker: All motion detection schedule endpoints failed for channel:" << channelId;
        qCritical() << "Worker: Last error:" << lastError;
        emit motionDetectionScheduleSet(channelId, false, QString("Failed to set motion detection schedule - %1").arg(lastError));
    }
}

// 将JSON对象转换为XML格式
QByteArray HikvisionWorker::convertJsonToXml(const QJsonObject& jsonObj, const QString& rootElement)
{
    QDomDocument doc;
    QDomElement root = doc.createElement(rootElement);
    doc.appendChild(root);
    
    // 递归转换JSON对象到XML
    convertJsonObjectToXmlElement(jsonObj, root, doc);
    
    return doc.toByteArray();
}

// 递归将JSON对象转换为XML元素
void HikvisionWorker::convertJsonObjectToXmlElement(const QJsonObject& jsonObj, QDomElement& xmlElement, QDomDocument& doc)
{
    for (auto it = jsonObj.begin(); it != jsonObj.end(); ++it) {
        const QString& key = it.key();
        const QJsonValue& value = it.value();
        
        QDomElement element = doc.createElement(key);
        
        if (value.isObject()) {
            convertJsonObjectToXmlElement(value.toObject(), element, doc);
        } else if (value.isArray()) {
            const QJsonArray array = value.toArray();
            for (const QJsonValue& arrayValue : array) {
                QDomElement arrayElement = doc.createElement("item");
                if (arrayValue.isObject()) {
                    convertJsonObjectToXmlElement(arrayValue.toObject(), arrayElement, doc);
                } else {
                    arrayElement.appendChild(doc.createTextNode(arrayValue.toVariant().toString()));
                }
                element.appendChild(arrayElement);
            }
        } else {
            element.appendChild(doc.createTextNode(value.toVariant().toString()));
        }
        
        xmlElement.appendChild(element);
    }
}

// 增强的XML到JSON转换函数（专门用于移动侦测）
QJsonObject HikvisionWorker::parseMotionDetectionXml(const QByteArray& xmlData)
{
    QDomDocument doc;
    if (!doc.setContent(xmlData)) {
        qWarning() << "Failed to parse motion detection XML";
        return QJsonObject();
    }
    
    QDomElement root = doc.documentElement();
    return convertXmlElementToJsonObject(root);
}

// 递归将XML元素转换为JSON对象
QJsonObject HikvisionWorker::convertXmlElementToJsonObject(const QDomElement& xmlElement)
{
    QJsonObject jsonObj;
    
    QDomNodeList children = xmlElement.childNodes();
    for (int i = 0; i < children.count(); ++i) {
        QDomNode child = children.at(i);
        
        if (child.isElement()) {
            QDomElement childElement = child.toElement();
            QString tagName = childElement.tagName();
            
            if (childElement.hasChildNodes() && childElement.firstChild().isElement()) {
                // 如果子元素还有子元素，递归处理
                jsonObj[tagName] = convertXmlElementToJsonObject(childElement);
            } else {
                // 如果是文本节点，直接获取文本内容
                QString textContent = childElement.text().trimmed();
                
                // 尝试转换为数字或布尔值
                bool ok;
                int intValue = textContent.toInt(&ok);
                if (ok) {
                    jsonObj[tagName] = intValue;
                } else {
                    double doubleValue = textContent.toDouble(&ok);
                    if (ok) {
                        jsonObj[tagName] = doubleValue;
                    } else if (textContent.toLower() == "true" || textContent.toLower() == "false") {
                        jsonObj[tagName] = (textContent.toLower() == "true");
                    } else {
                        jsonObj[tagName] = textContent;
                    }
                }
            }
        }
    }
    
    return jsonObj;
}