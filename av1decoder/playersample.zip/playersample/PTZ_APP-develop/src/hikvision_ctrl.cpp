#include "hikvision_ctrl.h"
#include <QUuid>
#include <QUrl>
#include <QDebug>
#include <QJsonDocument>
#include <QCryptographicHash>
#include <QDateTime>
#include <QXmlStreamReader>
#include <QXmlStreamWriter>
#include <QString>
#include <QTimer>
#include <cstring>
#include <curl/curl.h>

// CURL 写回调函数
static size_t HikvisionWriteCallback(void* contents, size_t size, size_t nmemb, void* userp)
{
    const size_t totalSize = size * nmemb;
    QByteArray* buffer = static_cast<QByteArray*>(userp);
    buffer->append(static_cast<char*>(contents), static_cast<int>(totalSize));
    return totalSize;
}

// 新增：响应头回调函数，用于提取Cookie
static size_t HikvisionHeaderCallback(char* buffer, size_t size, size_t nitems, void* userdata)
{
    size_t totalSize = size * nitems;
    QString header = QString::fromUtf8(buffer, totalSize).trimmed();
    
    // 查找Set-Cookie头
    if (header.startsWith("Set-Cookie:", Qt::CaseInsensitive)) {
        QString* cookiePtr = static_cast<QString*>(userdata);
        QString cookieValue = header.mid(11).trimmed(); // 跳过"Set-Cookie:"
        
        // 提取Cookie值（到分号为止）
        int semicolonPos = cookieValue.indexOf(';');
        if (semicolonPos > 0) {
            cookieValue = cookieValue.left(semicolonPos);
        }
        
        *cookiePtr = cookieValue;
        qDebug() << "获取到Cookie:" << cookieValue;
    }
    
    return totalSize;
}

HikvisionCtrl::HikvisionCtrl(QObject* parent)
    : QObject(parent)
    , m_curl(nullptr)
    , m_headers(nullptr)
    , m_networkManager(nullptr)
{
    // 初始化 CURL
    curl_global_init(CURL_GLOBAL_DEFAULT);
    m_curl = curl_easy_init();
    
    // 初始化网络管理器
    m_networkManager = new QNetworkAccessManager(this);
    
    // 硬编码认证信息和服务器IP
    m_serverIp = "192.168.1.102";  // 可以根据需要修改
    m_username = "admin";
    m_password = "WANG234WH1";
    
    // 连接信号和槽，确保异步执行
    connect(this, &HikvisionCtrl::searchRecordingRequested,
            this, &HikvisionCtrl::doSearchRecording,
            Qt::QueuedConnection);
    
    // 新增：连接通道查找的信号和槽
    connect(this, &HikvisionCtrl::channelLookupRequested,
            this, &HikvisionCtrl::doChannelLookup,
            Qt::QueuedConnection);
}

HikvisionCtrl::~HikvisionCtrl()
{
    if (m_headers) {
        curl_slist_free_all(m_headers);
    }
    if (m_curl) {
        curl_easy_cleanup(m_curl);
    }
    curl_global_cleanup();
    
    // m_networkManager会被Qt的父子关系自动清理
}

void HikvisionCtrl::searchRecording(const QString& searchId, int trackId, 
                                   const QString& startTime, const QString& endTime, 
                                   int maxResults, int searchResultPosition)
{
    // 只发信号，不做耗时工作
    emit searchRecordingRequested(searchId, trackId, startTime, endTime, maxResults, searchResultPosition);
}

// 新增：异步通道查找接口
void HikvisionCtrl::findChannelByIPAsync(const QString& deviceIp, int port,
                                        const QString& username, const QString& password,
                                        const QString& ipcIp)
{
    qDebug() << "异步查找通道，NVR IP:" << deviceIp << "IPC IP:" << ipcIp;
    emit channelLookupRequested(deviceIp, port, username, password, ipcIp, false);
}

// 修改后的同步接口，优先检查缓存
int HikvisionCtrl::findChannelByIP(const QString& deviceIp, int port,
                                  const QString& username, const QString& password,
                                  const QString& ipcIp)
{
    qDebug() << "Finding channel for IPC IP:" << ipcIp << "on NVR:" << deviceIp;
    
    // // 首先检查缓存
    // ChannelInfo cachedInfo = getChannelFromCache(deviceIp, ipcIp);
    // if (cachedInfo.isValid) {
    //     qDebug() << "从缓存中找到通道信息，通道号:" << cachedInfo.channelNumber;
    //     return cachedInfo.channelNumber;
    // }
    
    qDebug() << "缓存中没有找到通道信息，进行实时查询";
    qDebug() << "Using ISAPI interface with credentials:" << username << "password:" << password;

    // 尝试多个不同的ISAPI路径来获取通道信息
    QStringList possibleUrls = {
        QString("http://%1/ISAPI/System/Video/inputs").arg(deviceIp),
        QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels").arg(deviceIp),
        QString("http://%1/ISAPI/Streaming/channels").arg(deviceIp),
        QString("http://%1/ISAPI/System/channels").arg(deviceIp)
    };
    
    // 临时保存当前认证信息
    QString originalServerIp = m_serverIp;
    QString originalUsername = m_username;
    QString originalPassword = m_password;
    
    // 设置临时认证信息
    m_serverIp = deviceIp;
    m_username = username;
    m_password = password;
    
    QString response;
    bool success = false;
    QString successUrl;
    
    // 尝试每个可能的URL，直到找到一个有效的
    for (const QString& url : possibleUrls) {
        qDebug() << "Trying ISAPI URL:" << url;
        
        if (sendHttpRequest(url, "GET", QString(), &response)) {
            // 检查响应是否包含错误信息
            if (!response.contains("Invalid Operation") && !response.contains("notSupport")) {
                success = true;
                successUrl = url;
                qDebug() << "Successfully got response from:" << url;
                break;
            } else {
                qDebug() << "URL not supported:" << url;
            }
        } else {
            qDebug() << "Failed to connect to:" << url;
        }
    }
    
    // 恢复原始认证信息
    m_serverIp = originalServerIp;
    m_username = originalUsername;
    m_password = originalPassword;
    
    if (!success) {
        qCritical() << "Failed to get channel info via any ISAPI endpoint";
        qCritical() << "Last response:" << response;
        return -1;
    }
    
    qDebug() << "Channel info response:" << response;
    
    // 解析XML响应，查找匹配的IP通道
    int channel = parseChannelInfoForIP(response, ipcIp);
    
    if (channel > 0) {
        qDebug() << "Found IPC" << ipcIp << "on channel" << channel;
        // 更新缓存
        updateChannelCache(deviceIp, ipcIp, channel < 32 ? channel + 32 : channel);
    } else {
        qWarning() << "IPC" << ipcIp << "not found on NVR" << deviceIp;
    }

    return channel < 32 ? channel + 32 : channel;
}

// 新增：强制更新通道信息
void HikvisionCtrl::forceUpdateChannelInfo(const QString& deviceIp, int port,
                                          const QString& username, const QString& password,
                                          const QString& ipcIp)
{
    qDebug() << "强制更新通道信息，NVR IP:" << deviceIp << "IPC IP:" << ipcIp;
    
    // 清除缓存中的对应条目
    QString cacheKey = generateCacheKey(deviceIp, ipcIp);
    m_channelCache.remove(cacheKey);
    
    // 发起异步查询请求
    emit channelLookupRequested(deviceIp, port, username, password, ipcIp, true);
}

// 新增：批量初始化通道信息
void HikvisionCtrl::initializeChannelInfo(const QStringList& deviceIps, 
                                         const QStringList& usernames,
                                         const QStringList& passwords,
                                         const QStringList& ipcIps,
                                         int port)
{
    qDebug() << "开始批量初始化通道信息，设备数量:" << deviceIps.size();
    
    if (deviceIps.size() != usernames.size() || deviceIps.size() != passwords.size() || deviceIps.size() != ipcIps.size()) {
        qWarning() << "批量初始化参数数量不匹配";
        emit channelInitializationCompleted();
        return;
    }
    
    // 为每个设备发起异步查询
    for (int i = 0; i < deviceIps.size(); ++i) {
        findChannelByIPAsync(deviceIps[i], port, usernames[i], passwords[i], ipcIps[i]);
    }
    
    // 注意：这里简化处理，实际应该等待所有查询完成后再发信号
    // 可以通过计数器来跟踪完成状态
    QTimer::singleShot(5000, this, &HikvisionCtrl::channelInitializationCompleted);
}

// 新增：获取缓存的通道信息
int HikvisionCtrl::getCachedChannelNumber(const QString& nvrIp, const QString& ipcIp)
{
    ChannelInfo info = getChannelFromCache(nvrIp, ipcIp);
    return info.isValid ? info.channelNumber : -1;
}

// 新增：检查缓存是否有效
bool HikvisionCtrl::isChannelCacheValid(const QString& nvrIp, const QString& ipcIp)
{
    ChannelInfo info = getChannelFromCache(nvrIp, ipcIp);
    return info.isValid;
}

// 新增：清除所有缓存
void HikvisionCtrl::clearChannelCache()
{
    qDebug() << "清除所有通道缓存，当前缓存数量:" << m_channelCache.size();
    m_channelCache.clear();
}

// 设置当前设备的认证信息
void HikvisionCtrl::setCurrentDeviceCredentials(const QString& serverIp, const QString& username, const QString& password)
{
    qDebug() << "Setting current device credentials for:" << serverIp << "username:" << username;
    m_serverIp = serverIp;
    m_username = username;
    m_password = password;
}

// ========== 移动侦测相关接口实现 ==========

// 1. 获取系统能力（检查是否支持移动侦测）
void HikvisionCtrl::getSystemCapabilities()
{
    QString url = QString("http://%1/ISAPI/System/capabilities").arg(m_serverIp);
    QString response;
    
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject capabilities = parseMotionDetectionXml(response.toUtf8());
        emit systemCapabilitiesReceived(capabilities);
    } else {
        emit motionDetectionError("getSystemCapabilities", "Failed to get system capabilities");
    }
}

// 2. 获取通道事件能力（检查通道是否支持VMD）
void HikvisionCtrl::getChannelEventCapabilities(int channelId)
{
    QString url;
    if (channelId == -1) {
        // 获取全部通道事件能力
        url = QString("http://%1/ISAPI/Event/channels/capabilities").arg(m_serverIp);
    } else {
        // 获取指定通道事件能力
        url = QString("http://%1/ISAPI/Event/channels/%2/capabilities").arg(m_serverIp).arg(channelId);
    }
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject capabilities = parseMotionDetectionXml(response.toUtf8());
        emit channelEventCapabilitiesReceived(channelId, capabilities);
    } else {
        emit motionDetectionError("getChannelEventCapabilities", "Failed to get channel event capabilities");
    }
}

// 3. 获取指定通道移动侦测能力
void HikvisionCtrl::getMotionDetectionCapabilities(int channelId)
{
    QString url = QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/capabilities")
                      .arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject capabilities = parseMotionDetectionXml(response.toUtf8());
        emit motionDetectionCapabilitiesReceived(channelId, capabilities);
    } else {
        emit motionDetectionError("getMotionDetectionCapabilities", "Failed to get motion detection capabilities");
    }
}

// 4. 获取移动侦测区域配置能力
void HikvisionCtrl::getMotionDetectionLayoutCapabilities(int channelId)
{
    QString url = QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout/capabilities")
                      .arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject capabilities = parseMotionDetectionXml(response.toUtf8());
        emit motionDetectionLayoutCapabilitiesReceived(channelId, capabilities);
    } else {
        emit motionDetectionError("getMotionDetectionLayoutCapabilities", "Failed to get motion detection layout capabilities");
    }
}

// 5. 获取移动侦测配置
void HikvisionCtrl::getMotionDetectionConfig(int channelId)
{
    QString url = QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
                      .arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject config = parseMotionDetectionXml(response.toUtf8());
        emit motionDetectionConfigReceived(channelId, config);
    } else {
        emit motionDetectionError("getMotionDetectionConfig", "Failed to get motion detection config");
    }
}

// 6. 设置移动侦测配置
void HikvisionCtrl::setMotionDetectionConfig(int channelId, const QJsonObject& config)
{
    QString url = QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
                      .arg(m_serverIp).arg(channelId);
    
    // 将JSON配置转换为XML
    QByteArray xmlData = convertJsonToXml(config, "MotionDetection");
    
    QString response;
    if (sendHttpRequest(url, "PUT", QString::fromUtf8(xmlData), &response)) {
        emit motionDetectionConfigSet(channelId, true, "Motion detection config set successfully");
    } else {
        emit motionDetectionConfigSet(channelId, false, "Failed to set motion detection config");
    }
}

// 7. 获取移动侦测区域配置
void HikvisionCtrl::getMotionDetectionLayout(int channelId, const QString& regionType)
{
    qDebug() << "Getting motion detection layout for channel:" << channelId;
    
    // 尝试多个可能的ISAPI端点
    QStringList possibleUrls = {
        QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout")
            .arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout")
            .arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
            .arg(m_serverIp).arg(channelId)
    };
    
    // 如果通道号大于32，也尝试原始通道号
    if (channelId > 32) {
        int originalChannel = channelId - 32;
        possibleUrls.append(QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout")
            .arg(m_serverIp).arg(originalChannel));
        possibleUrls.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout")
            .arg(m_serverIp).arg(originalChannel));
        possibleUrls.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
            .arg(m_serverIp).arg(originalChannel));
    }
    
    // 添加regionType参数
    if (!regionType.isEmpty()) {
        for (int i = 0; i < possibleUrls.size(); ++i) {
            if (possibleUrls[i].contains("/layout")) {
                possibleUrls[i] += QString("?regionType=%1").arg(regionType);
            }
        }
    }
    
    QString response;
    bool success = false;
    QString successUrl;
    QString lastError;
    
    // 尝试每个可能的URL
    for (const QString& url : possibleUrls) {
        qDebug() << "Trying motion detection layout GET URL:" << url;
        
        if (sendHttpRequest(url, "GET", QString(), &response)) {
            // 检查响应是否包含错误信息
            if (!response.contains("Invalid Operation") && !response.contains("notSupport")) {
                success = true;
                successUrl = url;
                qDebug() << "Successfully got motion detection layout via:" << url;
                break;
            } else {
                lastError = QString("URL not supported: %1, Response: %2").arg(url).arg(response);
                qDebug() << lastError;
            }
        } else {
            lastError = QString("Failed to connect to: %1").arg(url);
            qDebug() << lastError;
        }
    }
    
    if (success) {
        QJsonObject layout = parseMotionDetectionLayoutXml(response.toUtf8());
        emit motionDetectionLayoutReceived(channelId, layout);
    } else {
        qCritical() << "All motion detection layout GET endpoints failed for channel:" << channelId;
        qCritical() << "Last error:" << lastError;
        emit motionDetectionError("getMotionDetectionLayout", QString("Failed to get motion detection layout - %1").arg(lastError));
    }
}

// 8. 设置移动侦测区域配置
void HikvisionCtrl::setMotionDetectionLayout(int channelId, const QJsonObject& layout, const QString& regionType)
{
    qDebug() << "Setting motion detection layout for channel:" << channelId;
    
    // 尝试多个可能的ISAPI端点
    QStringList possibleUrls = {
        QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout")
            .arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout")
            .arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
            .arg(m_serverIp).arg(channelId)
    };
    
    // 如果通道号大于32，也尝试原始通道号
    if (channelId > 32) {
        int originalChannel = channelId - 32;
        possibleUrls.append(QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout")
            .arg(m_serverIp).arg(originalChannel));
        possibleUrls.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout")
            .arg(m_serverIp).arg(originalChannel));
        possibleUrls.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection")
            .arg(m_serverIp).arg(originalChannel));
    }
    
    // 添加regionType参数
    if (!regionType.isEmpty()) {
        for (int i = 0; i < possibleUrls.size(); ++i) {
            if (possibleUrls[i].contains("/layout")) {
                possibleUrls[i] += QString("?regionType=%1").arg(regionType);
            }
        }
    }
    
    // 将JSON配置转换为移动侦测布局XML
    QByteArray xmlData = convertJsonToMotionDetectionLayoutXml(layout);
    qDebug() << "Motion detection XML data:" << QString::fromUtf8(xmlData);
    
    QString response;
    bool success = false;
    QString successUrl;
    QString lastError;
    
    // 尝试每个可能的URL
    for (const QString& url : possibleUrls) {
        qDebug() << "Trying motion detection layout URL:" << url;
        
        if (sendHttpRequest(url, "PUT", QString::fromUtf8(xmlData), &response)) {
            // 检查响应是否包含错误信息
            if (!response.contains("Invalid Operation") && !response.contains("notSupport")) {
                success = true;
                successUrl = url;
                qDebug() << "Successfully set motion detection layout via:" << url;
                break;
            } else {
                lastError = QString("URL not supported: %1, Response: %2").arg(url).arg(response);
                qDebug() << lastError;
            }
        } else {
            lastError = QString("Failed to connect to: %1").arg(url);
            qDebug() << lastError;
        }
    }
    
    if (success) {
        emit motionDetectionLayoutSet(channelId, true, QString("Motion detection layout set successfully via %1").arg(successUrl));
    } else {
        qCritical() << "All motion detection layout endpoints failed for channel:" << channelId;
        qCritical() << "Last error:" << lastError;
        emit motionDetectionLayoutSet(channelId, false, QString("Failed to set motion detection layout - %1").arg(lastError));
    }
}

// 9. 获取移动侦测联动规则
void HikvisionCtrl::getMotionDetectionTrigger(int channelId)
{
    QString url = QString("http://%1/ISAPI/Event/triggers/VMD-%2").arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        QJsonObject trigger = parseMotionDetectionXml(response.toUtf8());
        emit motionDetectionTriggerReceived(channelId, trigger);
    } else {
        emit motionDetectionError("getMotionDetectionTrigger", "Failed to get motion detection trigger");
    }
}

// 10. 设置移动侦测联动规则
void HikvisionCtrl::setMotionDetectionTrigger(int channelId, const QJsonObject& trigger)
{
    QString url = QString("http://%1/ISAPI/Event/triggers/VMD-%2").arg(m_serverIp).arg(channelId);
    
    // 将JSON配置转换为XML
    QByteArray xmlData = convertJsonToXml(trigger, "EventTrigger");
    
    QString response;
    if (sendHttpRequest(url, "PUT", QString::fromUtf8(xmlData), &response)) {
        emit motionDetectionTriggerSet(channelId, true, "Motion detection trigger set successfully");
    } else {
        emit motionDetectionTriggerSet(channelId, false, "Failed to set motion detection trigger");
    }
}

// 11. 删除移动侦测联动规则
void HikvisionCtrl::deleteMotionDetectionTrigger(int channelId)
{
    QString url = QString("http://%1/ISAPI/Event/triggers/VMD-%2").arg(m_serverIp).arg(channelId);
    
    QString response;
    if (sendHttpRequest(url, "DELETE", QString(), &response)) {
        emit motionDetectionTriggerDeleted(channelId, true, "Motion detection trigger deleted successfully");
    } else {
        emit motionDetectionTriggerDeleted(channelId, false, "Failed to delete motion detection trigger");
    }
}

// 12. 获取移动侦测布防时间
void HikvisionCtrl::getMotionDetectionSchedule(int channelId)
{
    qDebug() << "Getting motion detection schedule for channel:" << channelId;
    
    // 尝试多个可能的ISAPI端点
    QStringList possibleUrls;
    
    // 根据通道号类型选择合适的端点格式
    if (channelId > 32) {
        // IP通道 (数字通道)
        int ipChannel = channelId - 32;
        possibleUrls << QString("http://%1/ISAPI/Event/schedules/motionDetections/VMD_video%2")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/Event/schedules/VMD_video%2")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/schedule")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/schedule")
                         .arg(m_serverIp).arg(ipChannel);
    } else {
        // 模拟通道
        possibleUrls << QString("http://%1/ISAPI/Event/schedules/motionDetections/VMD_video%2")
                         .arg(m_serverIp).arg(channelId)
                     << QString("http://%1/ISAPI/Event/schedules/VMD_video%2")
                         .arg(m_serverIp).arg(channelId)
                     << QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/schedule")
                         .arg(m_serverIp).arg(channelId);
    }
    
    QString response;
    bool success = false;
    QString successUrl;
    QString lastError;
    
    // 尝试每个可能的URL
    for (const QString& url : possibleUrls) {
        qDebug() << "Trying motion detection schedule URL:" << url;
        
        if (sendHttpRequest(url, "GET", QString(), &response)) {
            // 检查响应是否包含错误信息
            if (!response.contains("Invalid Operation") && !response.contains("notSupport") && 
                !response.contains("invalid") && !response.isEmpty()) {
                success = true;
                successUrl = url;
                qDebug() << "Successfully got motion detection schedule via:" << url;
                break;
            } else {
                lastError = QString("URL not supported: %1, Response: %2").arg(url).arg(response);
                qDebug() << lastError;
            }
        } else {
            lastError = QString("Failed to connect to: %1").arg(url);
            qDebug() << lastError;
        }
    }
    
    if (success) {
        QJsonObject schedule = parseMotionDetectionScheduleXml(response.toUtf8());
        emit motionDetectionScheduleReceived(channelId, schedule);
    } else {
        qCritical() << "All motion detection schedule endpoints failed for channel:" << channelId;
        qCritical() << "Last error:" << lastError;
        emit motionDetectionError("getMotionDetectionSchedule", QString("Failed to get motion detection schedule - %1").arg(lastError));
    }
}

// 13. 设置移动侦测布防时间
void HikvisionCtrl::setMotionDetectionSchedule(int channelId, const QJsonObject& schedule)
{
    qDebug() << "Setting motion detection schedule for channel:" << channelId;
    
    // 尝试多个可能的ISAPI端点
    QStringList possibleUrls;
    
    // 根据通道号类型选择合适的端点格式
    if (channelId > 32) {
        // IP通道 (数字通道)
        int ipChannel = channelId - 32;
        possibleUrls << QString("http://%1/ISAPI/Event/schedules/motionDetections/VMD_video%2")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/Event/schedules/VMD_video%2")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/schedule")
                         .arg(m_serverIp).arg(ipChannel)
                     << QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/schedule")
                         .arg(m_serverIp).arg(ipChannel);
    } else {
        // 模拟通道
        possibleUrls << QString("http://%1/ISAPI/Event/schedules/motionDetections/VMD_video%2")
                         .arg(m_serverIp).arg(channelId)
                     << QString("http://%1/ISAPI/Event/schedules/VMD_video%2")
                         .arg(m_serverIp).arg(channelId)
                     << QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/schedule")
                         .arg(m_serverIp).arg(channelId);
    }
    
    // 创建包含channelId信息的schedule对象
    QJsonObject scheduleWithId = schedule;
    scheduleWithId["id"] = QString("VMD_video%1").arg(channelId);
    scheduleWithId["eventType"] = "VMD";
    scheduleWithId["videoInputChannelID"] = QString::number(channelId);
    
    // 将JSON配置转换为布防时间XML
    QByteArray xmlData = convertJsonToMotionDetectionScheduleXml(scheduleWithId);
    
    QString response;
    bool success = false;
    QString successUrl;
    QString lastError;
    
    // 尝试每个可能的URL，同时尝试PUT和POST方法
    QStringList methods = {"PUT", "POST"};
    
    for (const QString& url : possibleUrls) {
        for (const QString& method : methods) {
            qDebug() << "Trying motion detection schedule URL:" << url << "with method:" << method;
            
            if (sendHttpRequest(url, method, QString::fromUtf8(xmlData), &response)) {
                // 检查响应是否包含错误信息
                if (!response.contains("Invalid Operation") && !response.contains("notSupport") && 
                    !response.contains("two root tags") && !response.contains("invalid")) {
                    success = true;
                    successUrl = url;
                    qDebug() << "Successfully set motion detection schedule via:" << url << "method:" << method;
                    break;
                } else {
                    lastError = QString("URL/Method not supported: %1 %2, Response: %3").arg(method).arg(url).arg(response);
                    qDebug() << lastError;
                }
            } else {
                lastError = QString("Failed to connect to: %1 with method: %2").arg(url).arg(method);
                qDebug() << lastError;
            }
        }
        
        if (success) break;
    }
    
    if (success) {
        emit motionDetectionScheduleSet(channelId, true, QString("Motion detection schedule set successfully via %1").arg(successUrl));
    } else {
        qCritical() << "All motion detection schedule endpoints failed for channel:" << channelId;
        qCritical() << "Last error:" << lastError;
        emit motionDetectionScheduleSet(channelId, false, QString("Failed to set motion detection schedule - %1").arg(lastError));
    }
}

// ========== XML解析和生成辅助函数 ==========

// 将JSON对象转换为XML格式
QByteArray HikvisionCtrl::convertJsonToXml(const QJsonObject& jsonObj, const QString& rootElement)
{
    QDomDocument doc;
    QDomElement root = doc.createElement(rootElement);
    doc.appendChild(root);
    
    // 递归转换JSON对象到XML
    convertJsonObjectToXmlElement(jsonObj, root, doc);
    
    return doc.toByteArray();
}

// 递归将JSON对象转换为XML元素
void HikvisionCtrl::convertJsonObjectToXmlElement(const QJsonObject& jsonObj, QDomElement& xmlElement, QDomDocument& doc)
{
    for (auto it = jsonObj.begin(); it != jsonObj.end(); ++it) {
        const QString& key = it.key();
        const QJsonValue& value = it.value();
        
        QDomElement element = doc.createElement(key);
        
        if (value.isObject()) {
            convertJsonObjectToXmlElement(value.toObject(), element, doc);
        } else if (value.isArray()) {
            const QJsonArray array = value.toArray();
            for (const QJsonValue& arrayValue : array) {
                QDomElement arrayElement = doc.createElement("item");
                if (arrayValue.isObject()) {
                    convertJsonObjectToXmlElement(arrayValue.toObject(), arrayElement, doc);
                } else {
                    arrayElement.appendChild(doc.createTextNode(arrayValue.toVariant().toString()));
                }
                element.appendChild(arrayElement);
            }
        } else {
            element.appendChild(doc.createTextNode(value.toVariant().toString()));
        }
        
        xmlElement.appendChild(element);
    }
}

// 增强的XML到JSON转换函数（专门用于移动侦测）
QJsonObject HikvisionCtrl::parseMotionDetectionXml(const QByteArray& xmlData)
{
    QDomDocument doc;
    if (!doc.setContent(xmlData)) {
        qWarning() << "Failed to parse motion detection XML";
        return QJsonObject();
    }
    
    QDomElement root = doc.documentElement();
    return convertXmlElementToJsonObject(root);
}

// 专门用于解析移动侦测布局XML的函数
QJsonObject HikvisionCtrl::parseMotionDetectionLayoutXml(const QByteArray& xmlData)
{
    QDomDocument doc;
    if (!doc.setContent(xmlData)) {
        qWarning() << "Failed to parse motion detection layout XML";
        return QJsonObject();
    }
    
    QDomElement root = doc.documentElement();
    QJsonObject result;
    
    // 解析sensitivityLevel
    QDomElement sensitivityElement = root.firstChildElement("sensitivityLevel");
    if (!sensitivityElement.isNull()) {
        result["sensitivityLevel"] = sensitivityElement.text().toInt();
    }
    
    // 解析layout
    QDomElement layoutElement = root.firstChildElement("layout");
    if (!layoutElement.isNull()) {
        QJsonObject layoutObj;
        
        // 解析gridMap
        QDomElement gridMapElement = layoutElement.firstChildElement("gridMap");
        if (!gridMapElement.isNull()) {
            layoutObj["gridMap"] = gridMapElement.text();
        }
        
        // 解析roiMap
        QDomElement roiMapElement = layoutElement.firstChildElement("roiMap");
        if (!roiMapElement.isNull()) {
            layoutObj["roiMap"] = roiMapElement.text();
        }
        
        // 解析RegionList
        QDomElement regionListElement = layoutElement.firstChildElement("RegionList");
        if (!regionListElement.isNull()) {
            QJsonArray regionArray;
            QDomNodeList regionNodes = regionListElement.elementsByTagName("Region");
            
            for (int i = 0; i < regionNodes.count(); ++i) {
                QDomElement regionElement = regionNodes.at(i).toElement();
                QJsonObject regionObj;
                
                // 解析id
                QDomElement idElement = regionElement.firstChildElement("id");
                if (!idElement.isNull()) {
                    regionObj["id"] = idElement.text();
                }
                
                // 解析RegionCoordinatesList
                QDomElement coordListElement = regionElement.firstChildElement("RegionCoordinatesList");
                if (!coordListElement.isNull()) {
                    QJsonArray coordArray;
                    QDomNodeList coordNodes = coordListElement.elementsByTagName("RegionCoordinates");
                    
                    for (int j = 0; j < coordNodes.count(); ++j) {
                        QDomElement coordElement = coordNodes.at(j).toElement();
                        QJsonObject coordObj;
                        
                        QDomElement posXElement = coordElement.firstChildElement("positionX");
                        if (!posXElement.isNull()) {
                            coordObj["positionX"] = posXElement.text().toInt();
                        }
                        
                        QDomElement posYElement = coordElement.firstChildElement("positionY");
                        if (!posYElement.isNull()) {
                            coordObj["positionY"] = posYElement.text().toInt();
                        }
                        
                        coordArray.append(coordObj);
                    }
                    
                    regionObj["RegionCoordinatesList"] = coordArray;
                }
                
                regionArray.append(regionObj);
            }
            
            layoutObj["RegionList"] = regionArray;
        }
        
        result["layout"] = layoutObj;
    }
    
    // 解析targetType
    QDomElement targetTypeElement = root.firstChildElement("targetType");
    if (!targetTypeElement.isNull()) {
        result["targetType"] = targetTypeElement.text();
    }
    
    return result;
}

// 将JSON对象转换为移动侦测布局XML格式
QByteArray HikvisionCtrl::convertJsonToMotionDetectionLayoutXml(const QJsonObject& jsonObj)
{
    QDomDocument doc;
    QDomElement root = doc.createElement("MotionDetectionLayout");
    root.setAttribute("xmlns", "http://www.isapi.org/ver20/XMLSchema");
    root.setAttribute("version", "2.0");
    doc.appendChild(root);
    
    // 添加sensitivityLevel
    if (jsonObj.contains("sensitivityLevel")) {
        QDomElement sensitivityElement = doc.createElement("sensitivityLevel");
        sensitivityElement.appendChild(doc.createTextNode(QString::number(jsonObj["sensitivityLevel"].toInt())));
        root.appendChild(sensitivityElement);
    }
    
    // 添加layout
    if (jsonObj.contains("layout")) {
        QJsonObject layoutObj = jsonObj["layout"].toObject();
        QDomElement layoutElement = doc.createElement("layout");
        
        // 添加gridMap
        if (layoutObj.contains("gridMap")) {
            QDomElement gridMapElement = doc.createElement("gridMap");
            gridMapElement.appendChild(doc.createTextNode(layoutObj["gridMap"].toString()));
            layoutElement.appendChild(gridMapElement);
        }
        
        // 添加roiMap
        if (layoutObj.contains("roiMap")) {
            QDomElement roiMapElement = doc.createElement("roiMap");
            roiMapElement.appendChild(doc.createTextNode(layoutObj["roiMap"].toString()));
            layoutElement.appendChild(roiMapElement);
        }
        
        // 添加RegionList
        if (layoutObj.contains("RegionList")) {
            QDomElement regionListElement = doc.createElement("RegionList");
            QJsonArray regionArray = layoutObj["RegionList"].toArray();
            
            for (const QJsonValue& regionValue : regionArray) {
                QJsonObject regionObj = regionValue.toObject();
                QDomElement regionElement = doc.createElement("Region");
                
                // 添加id
                if (regionObj.contains("id")) {
                    QDomElement idElement = doc.createElement("id");
                    idElement.appendChild(doc.createTextNode(regionObj["id"].toString()));
                    regionElement.appendChild(idElement);
                }
                
                // 添加RegionCoordinatesList
                if (regionObj.contains("RegionCoordinatesList")) {
                    QDomElement coordListElement = doc.createElement("RegionCoordinatesList");
                    QJsonArray coordArray = regionObj["RegionCoordinatesList"].toArray();
                    
                    for (const QJsonValue& coordValue : coordArray) {
                        QJsonObject coordObj = coordValue.toObject();
                        QDomElement coordElement = doc.createElement("RegionCoordinates");
                        
                        if (coordObj.contains("positionX")) {
                            QDomElement posXElement = doc.createElement("positionX");
                            posXElement.appendChild(doc.createTextNode(QString::number(coordObj["positionX"].toInt())));
                            coordElement.appendChild(posXElement);
                        }
                        
                        if (coordObj.contains("positionY")) {
                            QDomElement posYElement = doc.createElement("positionY");
                            posYElement.appendChild(doc.createTextNode(QString::number(coordObj["positionY"].toInt())));
                            coordElement.appendChild(posYElement);
                        }
                        
                        coordListElement.appendChild(coordElement);
                    }
                    
                    regionElement.appendChild(coordListElement);
                }
                
                regionListElement.appendChild(regionElement);
            }
            
            layoutElement.appendChild(regionListElement);
        }
        
        root.appendChild(layoutElement);
    }
    
    // 添加targetType
    if (jsonObj.contains("targetType")) {
        QDomElement targetTypeElement = doc.createElement("targetType");
        targetTypeElement.appendChild(doc.createTextNode(jsonObj["targetType"].toString()));
        root.appendChild(targetTypeElement);
    }
    
    return doc.toByteArray();
}

// 14. 诊断移动侦测支持能力（尝试所有可能的端点）
void HikvisionCtrl::diagnoseMotionDetectionSupport(int channelId)
{
    qDebug() << "Starting motion detection support diagnosis for channel:" << channelId;
    
    QJsonObject supportInfo;
    supportInfo["channelId"] = channelId;
    supportInfo["testedEndpoints"] = QJsonArray();
    
    // 定义所有可能的端点
    QStringList testEndpoints = {
        QString("http://%1/ISAPI/System/capabilities").arg(m_serverIp),
        QString("http://%1/ISAPI/Event/channels/capabilities").arg(m_serverIp),
        QString("http://%1/ISAPI/Event/channels/%2/capabilities").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/capabilities").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout/capabilities").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout").arg(m_serverIp).arg(channelId),
        QString("http://%1/ISAPI/Event/triggers/VMD-%2").arg(m_serverIp).arg(channelId)
    };
    
    // 如果通道号大于32，也测试原始通道号
    if (channelId > 32) {
        int originalChannel = channelId - 32;
        supportInfo["originalChannelId"] = originalChannel;
        testEndpoints.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection").arg(m_serverIp).arg(originalChannel));
        testEndpoints.append(QString("http://%1/ISAPI/System/Video/inputs/channels/%2/motionDetection/layout").arg(m_serverIp).arg(originalChannel));
        testEndpoints.append(QString("http://%1/ISAPI/ContentMgmt/InputProxy/channels/%2/video/motionDetection/layout").arg(m_serverIp).arg(originalChannel));
    }
    
    QJsonArray endpointResults;
    
    // 测试每个端点
    for (const QString& url : testEndpoints) {
        QJsonObject endpointResult;
        endpointResult["url"] = url;
        
        qDebug() << "Testing endpoint:" << url;
        
        QString response;
        bool success = sendHttpRequest(url, "GET", QString(), &response);
        
        endpointResult["success"] = success;
        endpointResult["httpSuccess"] = success;
        
        if (success) {
            bool hasError = response.contains("Invalid Operation") || response.contains("notSupport");
            endpointResult["hasError"] = hasError;
            endpointResult["supported"] = !hasError;
            
            if (hasError) {
                endpointResult["errorType"] = "API_NOT_SUPPORTED";
                if (response.contains("Invalid Operation")) {
                    endpointResult["errorDetail"] = "Invalid Operation";
                }
                if (response.contains("notSupport")) {
                    endpointResult["errorDetail"] = "Not Supported";
                }
            } else {
                endpointResult["responseSize"] = response.length();
                // 尝试解析响应中的关键信息
                if (response.contains("<enabled>")) {
                    endpointResult["hasEnabledField"] = true;
                }
                if (response.contains("VMD") || response.contains("motionDetection")) {
                    endpointResult["hasMotionDetectionContent"] = true;
                }
            }
        } else {
            endpointResult["errorType"] = "HTTP_ERROR";
            endpointResult["supported"] = false;
        }
        
        endpointResults.append(endpointResult);
    }
    
    supportInfo["testedEndpoints"] = endpointResults;
    
    // 分析支持情况
    QJsonArray supportedEndpoints;
    QJsonArray unsupportedEndpoints;
    
    for (const QJsonValue& result : endpointResults) {
        QJsonObject endpoint = result.toObject();
        if (endpoint["supported"].toBool()) {
            supportedEndpoints.append(endpoint["url"]);
        } else {
            unsupportedEndpoints.append(endpoint["url"]);
        }
    }
    
    supportInfo["supportedEndpoints"] = supportedEndpoints;
    supportInfo["unsupportedEndpoints"] = unsupportedEndpoints;
    supportInfo["totalTested"] = testEndpoints.size();
    supportInfo["supportedCount"] = supportedEndpoints.size();
    
    qDebug() << "Motion detection diagnosis completed for channel" << channelId;
    qDebug() << "Supported endpoints:" << supportedEndpoints.size() << "out of" << testEndpoints.size();
    
    emit motionDetectionDiagnosisCompleted(channelId, supportInfo);
}

// 递归将XML元素转换为JSON对象
QJsonObject HikvisionCtrl::convertXmlElementToJsonObject(const QDomElement& xmlElement)
{
    QJsonObject jsonObj;
    
    QDomNodeList children = xmlElement.childNodes();
    for (int i = 0; i < children.count(); ++i) {
        QDomNode child = children.at(i);
        
        if (child.isElement()) {
            QDomElement childElement = child.toElement();
            QString tagName = childElement.tagName();
            
            if (childElement.hasChildNodes() && childElement.firstChild().isElement()) {
                // 如果子元素还有子元素，递归处理
                jsonObj[tagName] = convertXmlElementToJsonObject(childElement);
            } else {
                // 如果是文本节点，直接获取文本内容
                QString textContent = childElement.text().trimmed();
                
                // 尝试转换为数字或布尔值
                bool ok;
                int intValue = textContent.toInt(&ok);
                if (ok) {
                    jsonObj[tagName] = intValue;
                } else {
                    double doubleValue = textContent.toDouble(&ok);
                    if (ok) {
                        jsonObj[tagName] = doubleValue;
                    } else if (textContent.toLower() == "true" || textContent.toLower() == "false") {
                        jsonObj[tagName] = (textContent.toLower() == "true");
                    } else {
                        jsonObj[tagName] = textContent;
                    }
                }
            }
        }
    }
    
    return jsonObj;
}

// 解析移动侦测布防时间XML
QJsonObject HikvisionCtrl::parseMotionDetectionScheduleXml(const QByteArray& xmlData)
{
    QJsonObject result;
    QDomDocument doc;
    QString errorMsg;
    int errorLine, errorColumn;
    
    if (!doc.setContent(xmlData, &errorMsg, &errorLine, &errorColumn)) {
        qDebug() << "Failed to parse motion detection schedule XML:" << errorMsg << "at line" << errorLine << "column" << errorColumn;
        return result;
    }
    
    QDomElement root = doc.documentElement();
    if (root.tagName() != "Schedule") {
        qDebug() << "Invalid motion detection schedule XML root element:" << root.tagName();
        return result;
    }
    
    // 解析基本信息
    QDomElement idElement = root.firstChildElement("id");
    if (!idElement.isNull()) {
        result["id"] = idElement.text();
    }
    
    QDomElement eventTypeElement = root.firstChildElement("eventType");
    if (!eventTypeElement.isNull()) {
        result["eventType"] = eventTypeElement.text();
    }
    
    QDomElement videoInputChannelIDElement = root.firstChildElement("videoInputChannelID");
    if (!videoInputChannelIDElement.isNull()) {
        result["videoInputChannelID"] = videoInputChannelIDElement.text();
    }
    
    // 解析TimeBlockList
    QDomElement timeBlockListElement = root.firstChildElement("TimeBlockList");
    if (!timeBlockListElement.isNull()) {
        QJsonArray timeBlockArray;
        QDomNodeList timeBlocks = timeBlockListElement.elementsByTagName("TimeBlock");
        
        for (int i = 0; i < timeBlocks.count(); ++i) {
            QDomElement timeBlock = timeBlocks.at(i).toElement();
            QJsonObject timeBlockObj;
            
            QDomElement dayOfWeekElement = timeBlock.firstChildElement("dayOfWeek");
            if (!dayOfWeekElement.isNull()) {
                timeBlockObj["dayOfWeek"] = dayOfWeekElement.text().toInt();
            }
            
            QDomElement timeRangeElement = timeBlock.firstChildElement("TimeRange");
            if (!timeRangeElement.isNull()) {
                QJsonObject timeRangeObj;
                
                QDomElement beginTimeElement = timeRangeElement.firstChildElement("beginTime");
                if (!beginTimeElement.isNull()) {
                    timeRangeObj["beginTime"] = beginTimeElement.text();
                }
                
                QDomElement endTimeElement = timeRangeElement.firstChildElement("endTime");
                if (!endTimeElement.isNull()) {
                    timeRangeObj["endTime"] = endTimeElement.text();
                }
                
                timeBlockObj["TimeRange"] = timeRangeObj;
            }
            
            timeBlockArray.append(timeBlockObj);
        }
        
        result["TimeBlockList"] = timeBlockArray;
    }
    
    // 解析HolidayBlockList
    QDomElement holidayBlockListElement = root.firstChildElement("HolidayBlockList");
    if (!holidayBlockListElement.isNull()) {
        QJsonArray holidayBlockArray;
        QDomNodeList holidayBlocks = holidayBlockListElement.elementsByTagName("TimeBlock");
        
        for (int i = 0; i < holidayBlocks.count(); ++i) {
            QDomElement timeBlock = holidayBlocks.at(i).toElement();
            QJsonObject timeBlockObj;
            
            QDomElement timeRangeElement = timeBlock.firstChildElement("TimeRange");
            if (!timeRangeElement.isNull()) {
                QJsonObject timeRangeObj;
                
                QDomElement beginTimeElement = timeRangeElement.firstChildElement("beginTime");
                if (!beginTimeElement.isNull()) {
                    timeRangeObj["beginTime"] = beginTimeElement.text();
                }
                
                QDomElement endTimeElement = timeRangeElement.firstChildElement("endTime");
                if (!endTimeElement.isNull()) {
                    timeRangeObj["endTime"] = endTimeElement.text();
                }
                
                timeBlockObj["TimeRange"] = timeRangeObj;
            }
            
            holidayBlockArray.append(timeBlockObj);
        }
        
        result["HolidayBlockList"] = holidayBlockArray;
    }
    
    return result;
}

// 将JSON对象转换为移动侦测布防时间XML
QByteArray HikvisionCtrl::convertJsonToMotionDetectionScheduleXml(const QJsonObject& jsonObj)
{
    qDebug() << "Converting JSON to Motion Detection Schedule XML:" << QJsonDocument(jsonObj).toJson();
    
    // 使用QString构建XML，然后转换为UTF-8字节数组
    QString xmlString;
    
    // 手动构建XML以确保格式正确
    xmlString += "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
    xmlString += "<Schedule xmlns=\"http://www.isapi.org/ver20/XMLSchema\" version=\"2.0\">\n";
    
    // 添加基本信息
    if (jsonObj.contains("id")) {
        xmlString += QString("  <id>%1</id>\n").arg(jsonObj["id"].toString());
    }
    
    if (jsonObj.contains("eventType")) {
        xmlString += QString("  <eventType>%1</eventType>\n").arg(jsonObj["eventType"].toString());
    }
    
    if (jsonObj.contains("videoInputChannelID")) {
        xmlString += QString("  <videoInputChannelID>%1</videoInputChannelID>\n").arg(jsonObj["videoInputChannelID"].toString());
    }
    
    // 处理TimeBlockList - 支持两种数据格式：timeBlockList和TimeBlockList
    QJsonArray timeBlockArray;
    if (jsonObj.contains("timeBlockList")) {
        timeBlockArray = jsonObj["timeBlockList"].toArray();
    } else if (jsonObj.contains("TimeBlockList")) {
        timeBlockArray = jsonObj["TimeBlockList"].toArray();
    }
    
    if (!timeBlockArray.isEmpty()) {
        xmlString += QString("  <TimeBlockList size=\"%1\">\n").arg(timeBlockArray.size());
        
        for (const QJsonValue& value : timeBlockArray) {
            QJsonObject timeBlockObj = value.toObject();
            xmlString += "    <TimeBlock>\n";
            
            if (timeBlockObj.contains("dayOfWeek")) {
                xmlString += QString("      <dayOfWeek>%1</dayOfWeek>\n").arg(timeBlockObj["dayOfWeek"].toInt());
            }
            
            // 处理时间范围 - 支持两种格式：timeBlock和TimeRange
            QJsonObject timeRangeObj;
            if (timeBlockObj.contains("timeBlock")) {
                timeRangeObj = timeBlockObj["timeBlock"].toObject();
            } else if (timeBlockObj.contains("TimeRange")) {
                timeRangeObj = timeBlockObj["TimeRange"].toObject();
            }
            
            if (!timeRangeObj.isEmpty()) {
                xmlString += "      <TimeRange>\n";
                
                if (timeRangeObj.contains("beginTime")) {
                    xmlString += QString("        <beginTime>%1</beginTime>\n").arg(timeRangeObj["beginTime"].toString());
                }
                
                if (timeRangeObj.contains("endTime")) {
                    xmlString += QString("        <endTime>%1</endTime>\n").arg(timeRangeObj["endTime"].toString());
                }
                
                xmlString += "      </TimeRange>\n";
            }
            
            xmlString += "    </TimeBlock>\n";
        }
        
        xmlString += "  </TimeBlockList>\n";
    }
    
    xmlString += "</Schedule>";
    
    // 转换为UTF-8字节数组，不包含BOM
    QByteArray xmlData = xmlString.toUtf8();
    
    qDebug() << "Generated Motion Detection Schedule XML:" << xmlString;
    qDebug() << "XML byte array size:" << xmlData.size();
    qDebug() << "XML starts with:" << xmlData.left(50);
    
    return xmlData;
}


// 新增：异步通道查找处理函数
void HikvisionCtrl::doChannelLookup(const QString& deviceIp, int port,
                                   const QString& username, const QString& password,
                                   const QString& ipcIp, bool forceUpdate)
{
    qDebug() << "执行异步通道查找，NVR IP:" << deviceIp << "IPC IP:" << ipcIp << "强制更新:" << forceUpdate;
    
    // 如果不是强制更新，先检查缓存
    if (!forceUpdate) {
        ChannelInfo cachedInfo = getChannelFromCache(deviceIp, ipcIp);
        if (cachedInfo.isValid) {
            qDebug() << "从缓存中找到通道信息，直接返回";
            emit channelLookupCompleted(deviceIp, ipcIp, cachedInfo.channelNumber);
            return;
        }
    }
    
    // 执行实际的查找逻辑（复用现有的findChannelByIP逻辑）
    int channel = findChannelByIP(deviceIp, port, username, password, ipcIp);
    
    if (channel > 0) {
        emit channelLookupCompleted(deviceIp, ipcIp, channel);
    } else {
        emit channelLookupFailed(deviceIp, ipcIp, "无法找到对应的通道号");
    }
}

// 新增：生成缓存键
QString HikvisionCtrl::generateCacheKey(const QString& nvrIp, const QString& ipcIp)
{
    return QString("%1|%2").arg(nvrIp).arg(ipcIp);
}

// 新增：更新通道缓存
void HikvisionCtrl::updateChannelCache(const QString& nvrIp, const QString& ipcIp, int channelNumber)
{
    QString cacheKey = generateCacheKey(nvrIp, ipcIp);
    ChannelInfo info(channelNumber, nvrIp, ipcIp);
    m_channelCache[cacheKey] = info;
    qDebug() << "更新通道缓存，键:" << cacheKey << "通道:" << channelNumber;
}

// 新增：从缓存获取通道信息
ChannelInfo HikvisionCtrl::getChannelFromCache(const QString& nvrIp, const QString& ipcIp)
{
    QString cacheKey = generateCacheKey(nvrIp, ipcIp);
    if (m_channelCache.contains(cacheKey)) {
        ChannelInfo info = m_channelCache[cacheKey];
        
        // 检查缓存是否过期（例如，1小时后过期）
        QDateTime now = QDateTime::currentDateTime();
        if (info.lastUpdated.secsTo(now) < 3600) {  // 1小时 = 3600秒
            return info;
        } else {
            qDebug() << "缓存过期，移除过期条目:" << cacheKey;
            m_channelCache.remove(cacheKey);
        }
    }
    
    return ChannelInfo();  // 返回无效的缓存信息
}

int HikvisionCtrl::parseChannelInfoForIP(const QString& xmlResponse, const QString& ipcIp)
{
    qDebug() << "Parsing channel info for IP:" << ipcIp;
    
    QXmlStreamReader reader(xmlResponse);
    int channelId = -1;
    bool inChannel = false;
    QString currentChannelId;
    QString currentChannelIp;
    
    // 支持多种通道类型的XML节点名称
    QStringList channelNodeNames = {
        "VideoInputChannel", 
        "InputProxyChannel", 
        "StreamingChannel", 
        "Channel"
    };
    
    // 支持多种IP地址字段的XML节点名称
    QStringList ipFieldNames = {
        "ipAddress",
        "IPAddress", 
        "ip",
        "address",
        "deviceAddress"
    };
    
    QString currentChannelType;
    
    while (!reader.atEnd()) {
        reader.readNext();
        
        if (reader.isStartElement()) {
            // 检查是否是任何类型的通道节点
            QString elementName = reader.name().toString();
            if (channelNodeNames.contains(elementName)) {
                inChannel = true;
                currentChannelType = elementName;
                currentChannelId.clear();
                currentChannelIp.clear();
                qDebug() << "Found channel node:" << elementName;
            } else if (inChannel && reader.name() == "id") {
                currentChannelId = reader.readElementText();
                qDebug() << "Channel ID:" << currentChannelId;
            } else if (inChannel && ipFieldNames.contains(elementName)) {
                // 直接读取IP地址
                currentChannelIp = reader.readElementText();
                qDebug() << "Found IP address:" << currentChannelIp << "in field:" << elementName;
            } else if (inChannel && (reader.name() == "sourceInputPortDescriptor" || 
                                   reader.name() == "inputPort" || 
                                   reader.name() == "deviceInfo" ||
                                   reader.name() == "networkInfo")) {
                // 在这些容器节点中查找IP地址信息
                QString containerName = reader.name().toString();
                while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == containerName)) {
                    reader.readNext();
                    if (reader.isStartElement()) {
                        QString subElementName = reader.name().toString();
                        if (ipFieldNames.contains(subElementName)) {
                            currentChannelIp = reader.readElementText();
                            qDebug() << "Found IP address:" << currentChannelIp << "in container:" << containerName;
                            break;
                        }
                    }
                }
            }
        } else if (reader.isEndElement()) {
            QString elementName = reader.name().toString();
            if (channelNodeNames.contains(elementName) && elementName == currentChannelType) {
                // 检查当前通道是否匹配目标IP
                qDebug() << "End of channel node. Channel ID:" << currentChannelId << "IP:" << currentChannelIp;
                if (!currentChannelIp.isEmpty() && currentChannelIp == ipcIp) {
                    bool ok;
                    int id = currentChannelId.toInt(&ok);
                    if (ok) {
                        channelId = id;
                        qDebug() << "Found matching channel:" << channelId << "for IP:" << ipcIp;
                        break;
                    } else {
                        qDebug() << "Channel ID is not a valid integer:" << currentChannelId;
                    }
                }
                inChannel = false;
                currentChannelType.clear();
            }
        }
    }
    
    if (reader.hasError()) {
        qCritical() << "XML parsing error:" << reader.errorString();
        return -1;
    }
    
    if (channelId == -1) {
        qWarning() << "No channel found for IP:" << ipcIp;
        qDebug() << "Complete XML response:" << xmlResponse;
        
        // 尝试输出所有找到的通道信息用于调试
        QXmlStreamReader debugReader(xmlResponse);
        qDebug() << "=== Debug: All channels found in response ===";
        while (!debugReader.atEnd()) {
            debugReader.readNext();
            if (debugReader.isStartElement() && channelNodeNames.contains(debugReader.name().toString())) {
                QString debugChannelId, debugChannelIp;
                QString channelType = debugReader.name().toString();
                
                while (!debugReader.atEnd() && !(debugReader.isEndElement() && debugReader.name() == channelType)) {
                    debugReader.readNext();
                    if (debugReader.isStartElement()) {
                        if (debugReader.name() == "id") {
                            debugChannelId = debugReader.readElementText();
                        } else if (ipFieldNames.contains(debugReader.name().toString())) {
                            debugChannelIp = debugReader.readElementText();
                        }
                    }
                }
                qDebug() << "Channel found - Type:" << channelType << "ID:" << debugChannelId << "IP:" << debugChannelIp;
            }
        }
        qDebug() << "=== End debug info ===";
    }
    
    return channelId;
}

void HikvisionCtrl::doSearchRecording(const QString& searchId, int trackId, 
                                     const QString& startTime, const QString& endTime, 
                                     int maxResults, int searchResultPosition)
{
    // 构建请求URL
    QString url = QString("http://%1/ISAPI/ContentMgmt/search").arg(m_serverIp);
    
    // 创建XML请求体
    QString xmlData = createSearchXml(searchId, trackId, startTime, endTime, maxResults, searchResultPosition);
    
    qDebug() << "发送海康录像查询请求到:" << url;
    qDebug() << "请求体:" << xmlData;
    
    // 发送POST请求
    QString response;
    if (sendHttpRequest(url, "POST", xmlData, &response)) {
        qDebug() << "海康录像查询响应:" << response;
        // 解析XML响应
        QJsonObject result = parseSearchResult(response);
        emit recordingSearchCompleted(result);
        
        // 如果有录像结果，自动准备第一个录像的RTSP流
        if (result.contains("matchList")) {
            QJsonArray matchList = result["matchList"].toArray();
            if (!matchList.isEmpty()) {
                QJsonObject firstMatch = matchList.first().toObject();
                if (firstMatch.contains("mediaSegmentDescriptor")) {
                    QJsonObject mediaDesc = firstMatch["mediaSegmentDescriptor"].toObject();
                    if (mediaDesc.contains("playbackURI")) {
                        QString playbackUri = mediaDesc["playbackURI"].toString();
                        qDebug() << "找到录像播放URI:" << playbackUri;
                        
                    }
                }
            }
        }
    } else {
        qCritical() << "海康录像查询失败";
        emit recordingSearchCompleted(QJsonObject());
    }
}

QString HikvisionCtrl::createSearchXml(const QString& searchId, int trackId, 
                                      const QString& startTime, const QString& endTime, 
                                      int maxResults, int searchResultPosition)
{
    QString xml;
    QXmlStreamWriter writer(&xml);
    
    // 设置格式化输出
    writer.setAutoFormatting(true);
    writer.setAutoFormattingIndent(0); // 不使用缩进，保持原格式
    
    // 手动构建XML以确保格式完全匹配官方示例
    xml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>";
    xml += "<CMSearchDescription>\n";
    xml += "<searchID>" + searchId + "</searchID>\n";
    xml += "<trackList>\n";
    xml += "<trackID>" + QString::number(trackId) + "</trackID>\n";
    xml += "</trackList>\n";
    xml += "<timeSpanList>\n";
    xml += "<timeSpan>\n";
    xml += "<startTime>" + startTime + "</startTime>\n";
    xml += "<endTime>" + endTime + "</endTime>\n";
    xml += "</timeSpan>\n";
    xml += "</timeSpanList>\n";
    xml += "<maxResults>" + QString::number(maxResults) + "</maxResults>\n";
    xml += "<searchResultPosition>" + QString::number(searchResultPosition) + "</searchResultPosition>\n";
    xml += "<metadataList>\n";
    xml += "<metadataDescriptor>//recordType.meta.std-cgi.com</metadataDescriptor>\n";
    xml += "</metadataList>\n";
    xml += "</CMSearchDescription>";
    
    return xml;
}

QJsonObject HikvisionCtrl::parseSearchResult(const QString& xmlResponse)
{
    QJsonObject result;
    QXmlStreamReader reader(xmlResponse);
    
    while (!reader.atEnd()) {
        reader.readNext();
        
        if (reader.isStartElement()) {
            if (reader.name() == "searchID") {
                result["searchID"] = reader.readElementText();
            } else if (reader.name() == "responseStatus") {
                result["responseStatus"] = reader.readElementText();
            } else if (reader.name() == "responseStatusStrg") {
                result["responseStatusStrg"] = reader.readElementText();
            } else if (reader.name() == "numOfMatches") {
                result["numOfMatches"] = reader.readElementText().toInt();
            } else if (reader.name() == "matchList") {
                QJsonArray matchArray;
                
                while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "matchList")) {
                    reader.readNext();
                    
                    if (reader.isStartElement() && reader.name() == "searchMatchItem") {
                        QJsonObject matchItem;
                        
                        while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "searchMatchItem")) {
                            reader.readNext();
                            
                            if (reader.isStartElement()) {
                                if (reader.name() == "sourceID") {
                                    matchItem["sourceID"] = reader.readElementText();
                                } else if (reader.name() == "trackID") {
                                    matchItem["trackID"] = reader.readElementText();
                                } else if (reader.name() == "timeSpan") {
                                    QJsonObject timeSpan;
                                    
                                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "timeSpan")) {
                                        reader.readNext();
                                        
                                        if (reader.isStartElement()) {
                                            if (reader.name() == "startTime") {
                                                timeSpan["startTime"] = reader.readElementText();
                                            } else if (reader.name() == "endTime") {
                                                timeSpan["endTime"] = reader.readElementText();
                                            }
                                        }
                                    }
                                    matchItem["timeSpan"] = timeSpan;
                                } else if (reader.name() == "mediaSegmentDescriptor") {
                                    QJsonObject mediaSegment;
                                    
                                    while (!reader.atEnd() && !(reader.isEndElement() && reader.name() == "mediaSegmentDescriptor")) {
                                        reader.readNext();
                                        
                                        if (reader.isStartElement()) {
                                            if (reader.name() == "contentType") {
                                                mediaSegment["contentType"] = reader.readElementText();
                                            } else if (reader.name() == "codecType") {
                                                mediaSegment["codecType"] = reader.readElementText();
                                            } else if (reader.name() == "playbackURI") {
                                                mediaSegment["playbackURI"] = reader.readElementText();
                                            } else if (reader.name() == "lockStatus") {
                                                mediaSegment["lockStatus"] = reader.readElementText();
                                            } else if (reader.name() == "name") {
                                                mediaSegment["name"] = reader.readElementText();
                                            }
                                        }
                                    }
                                    matchItem["mediaSegmentDescriptor"] = mediaSegment;
                                }
                            }
                        }
                        
                        matchArray.append(matchItem);
                    }
                }
                
                result["matchList"] = matchArray;
            }
        }
    }
    
    if (reader.hasError()) {
        qCritical() << "XML parsing error:" << reader.errorString();
    }
    
    return result;
}

bool HikvisionCtrl::sendHttpRequest(const QString& url, const QString& method, 
                                   const QString& data, QString* response)
{
    if (!m_curl) {
        qCritical() << "CURL not initialized";
        return false;
    }
    
    QByteArray responseData;
    QString receivedCookie;
    
    // 重置 CURL 选项
    curl_easy_reset(m_curl);
    
    // 设置基本选项
    curl_easy_setopt(m_curl, CURLOPT_URL, url.toUtf8().constData());
    curl_easy_setopt(m_curl, CURLOPT_WRITEFUNCTION, HikvisionWriteCallback);
    curl_easy_setopt(m_curl, CURLOPT_WRITEDATA, &responseData);
    
    // 设置响应头回调以提取Cookie
    curl_easy_setopt(m_curl, CURLOPT_HEADERFUNCTION, HikvisionHeaderCallback);
    curl_easy_setopt(m_curl, CURLOPT_HEADERDATA, &receivedCookie);
    
    // 设置超时 - 减少超时时间防止UI卡顿
    curl_easy_setopt(m_curl, CURLOPT_TIMEOUT, 5L);        // 总超时5秒
    curl_easy_setopt(m_curl, CURLOPT_CONNECTTIMEOUT, 2L);  // 连接超时2秒
    curl_easy_setopt(m_curl, CURLOPT_NOSIGNAL, 1L);       // 防止DNS超时信号中断
    
    // 设置 Digest Auth - 使用硬编码的认证信息
    curl_easy_setopt(m_curl, CURLOPT_HTTPAUTH, CURLAUTH_DIGEST);
    qDebug() << "username:" << m_username << "password:" << m_password;
    curl_easy_setopt(m_curl, CURLOPT_USERPWD, QString("%1:%2").arg(m_username).arg(m_password).toUtf8().constData());
    
    // 设置请求头
    struct curl_slist* headers = nullptr;
    headers = curl_slist_append(headers, "Content-Type: application/xml; charset=UTF-8");
    headers = curl_slist_append(headers, "Accept: application/xml");
    headers = curl_slist_append(headers, "User-Agent: ISAPI-Client/1.0");
    
    // 如果有Cookie，添加到请求头
    if (!m_cookie.isEmpty()) {
        QString cookieHeader = QString("Cookie: %1").arg(m_cookie);
        headers = curl_slist_append(headers, cookieHeader.toUtf8().constData());
    }
    
    curl_easy_setopt(m_curl, CURLOPT_HTTPHEADER, headers);
    
    // 设置请求方法和数据
    if (method == "POST") {
        curl_easy_setopt(m_curl, CURLOPT_POST, 1L);
        if (!data.isEmpty()) {
            QByteArray postData = data.toUtf8();
            qDebug() << "POST data size:" << postData.size() << "bytes";
            qDebug() << "POST data preview:" << postData.left(200);
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDS, postData.constData());
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDSIZE, postData.size());
        }
    } else if (method == "GET") {
        curl_easy_setopt(m_curl, CURLOPT_HTTPGET, 1L);
    } else if (method == "PUT") {
        curl_easy_setopt(m_curl, CURLOPT_CUSTOMREQUEST, "PUT");
        if (!data.isEmpty()) {
            QByteArray putData = data.toUtf8();
            qDebug() << "PUT data size:" << putData.size() << "bytes";
            qDebug() << "PUT data preview:" << putData.left(200);
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDS, putData.constData());
            curl_easy_setopt(m_curl, CURLOPT_POSTFIELDSIZE, putData.size());
        }
    }
    
    // 执行请求
    CURLcode res = curl_easy_perform(m_curl);
    
    // 清理头部
    curl_slist_free_all(headers);
    
    if (res != CURLE_OK) {
        qCritical() << "CURL request failed:" << curl_easy_strerror(res);
        return false;
    }
    
    // 如果收到了新的Cookie，保存它
    if (!receivedCookie.isEmpty()) {
        m_cookie = receivedCookie;
    }
    
    // 检查HTTP状态码
    long httpCode = 0;
    curl_easy_getinfo(m_curl, CURLINFO_RESPONSE_CODE, &httpCode);
    
    qDebug() << "HTTP Response Code:" << httpCode;
    qDebug() << "HTTP Response Body:" << QString::fromUtf8(responseData);
    
    if (httpCode != 200) {
        qCritical() << "HTTP request failed with code:" << httpCode;
        qCritical() << "URL:" << url;
        qCritical() << "Method:" << method;
        qCritical() << "Request Data:" << data;
        qCritical() << "Response:" << QString::fromUtf8(responseData);
        
        // 对于403错误，可能是权限问题或者XML格式问题
        if (httpCode == 403) {
            qCritical() << "403 Forbidden - This could be due to:";
            qCritical() << "1. Insufficient user permissions";
            qCritical() << "2. Invalid XML format or structure";
            qCritical() << "3. Device does not support this specific ISAPI endpoint";
        }
        
        return false;
    }
    
    if (response) {
        *response = QString::fromUtf8(responseData);
    }
    
    qDebug() << "HTTP request successful:" << url;
    return true;
}




bool HikvisionCtrl::authenticateAndGetCookie()
{
    // 如果已有Cookie，先尝试验证是否有效
    if (!m_cookie.isEmpty()) {
        return true;
    }
    
    QString url = QString("http://%1/ISAPI/Security/userCheck").arg(m_serverIp);
    QString response;
    
    // 发送认证请求
    if (sendHttpRequest(url, "GET", QString(), &response)) {
        // 从响应头中提取Cookie
        // 注意：实际实现中需要从CURL获取响应头
        qDebug() << "获取Cookie成功";
        return true;
    }
    
    return false;
}

QString HikvisionCtrl::buildAuthenticatedRtspUrl(const QString& originalUrl)
{
    qDebug() << "=== 开始构建认证RTSP URL ===";
    qDebug() << "原始URL:" << originalUrl;
    
    // 首先解码HTML实体（如 &amp; -> &）
    QString decodedUrl = originalUrl;
    decodedUrl.replace("&amp;", "&");
    qDebug() << "解码HTML实体后:" << decodedUrl;
    
    // 从原始URL中提取参数
    QUrl url(decodedUrl);
    
    // 检查URL是否有效
    if (!url.isValid()) {
        qCritical() << "无效的RTSP URL:" << decodedUrl;
        return QString();
    }
    
    // 获取主机和端口
    QString host = url.host();
    int port = url.port(554); // RTSP默认端口是554
    
    // 构建带用户名密码的RTSP URL
    // 格式: rtsp://username:password@host:port/path?params
    QString authenticatedUrl = QString("rtsp://%1:%2@%3:%4")
        .arg(m_username)
        .arg(m_password)  
        .arg(host)
        .arg(port);
    
    // 添加路径
    authenticatedUrl += url.path();
    
    // 过滤查询参数，只保留时间相关的参数
    if (url.hasQuery()) {
        QString queryString = url.query();
        qDebug() << "原始查询字符串:" << queryString;
        
        // 使用字符串处理方式，更可靠
        QStringList params = queryString.split('&');
        QStringList filteredParams;
        
        qDebug() << "开始过滤参数，总共" << params.size() << "个参数";
        
        for (const QString& param : params) {
            if (param.contains('=')) {
                QString paramName = param.split('=').first().toLower();
                if (paramName == "starttime" ) {
                    filteredParams.append(param);
                    qDebug() << "✓ 保留参数:" << param;
                } else {
                    qDebug() << "✗ 过滤掉参数:" << param;
                }
            }
        }
        
        qDebug() << "过滤后剩余参数:" << filteredParams.size() << "个";
        
        // 如果有过滤后的参数，添加到URL中
        if (!filteredParams.isEmpty()) {
            QString filteredQuery = filteredParams.join('&');
            authenticatedUrl += "?" + filteredQuery;
            qDebug() << "过滤后查询字符串:" << filteredQuery;
        }
    }
    
    qDebug() << "构建的认证RTSP URL:" << authenticatedUrl;
    qDebug() << "=== 认证RTSP URL构建完成 ===";
    return authenticatedUrl;
}

QString HikvisionCtrl::getRtspUrlFromSegment(const QJsonObject& segment)
{
    if (segment.contains("mediaSegmentDescriptor")) {
        QJsonObject mediaDesc = segment["mediaSegmentDescriptor"].toObject();
        if (mediaDesc.contains("playbackURI")) {
            return mediaDesc["playbackURI"].toString();
        }
    }
    return QString();
}