#include "src/decoder/decode.h"
#include <QDebug>
#include <QCoreApplication>
#include <iostream>
#include <QTime>
#include <QMutex>
#include <QMutexLocker>

worker::worker(packetqueue *pkt_q, AVFramePool *frame_q,AVCodecContext *dec_Ctx){
        p_q = pkt_q;
        f_q = frame_q;
        dec_ctx = dec_Ctx;
        quit_flag = false;
        pause_flag =false;
        std::cout << "decode worker struct" << dec_ctx->codec_type << std::endl  << std::flush;
}
void worker::quit_thread(){
    std::cout << "decode receive quit signal"<< std::endl  << std::flush;
    quit_flag = true;
}
void worker::pause_decode(){

    pause_flag = true;
    std::cout << "pause_decode !!!"<< std::endl  << std::flush;
    //avcodec_flush_buffers(dec_ctx);
    // clear frame queue
    //f_q->clear();
}
void worker::continue_decode(){
    std::cout << "continue decode !!!"<< std::endl  << std::flush;
    pause_flag = false;
}
worker::~worker(){
    std::cout << "decode worker destruct"<< std::endl  << std::flush;
    qDebug() << "WORKER: Destructor called, dec_ctx:" << dec_ctx;
    if(dec_ctx) {
        qDebug() << "WORKER: Destructor - dec_ctx->codec_id:" << dec_ctx->codec_id;
    }
}
void worker::work_thread(){
        int ret;
        AVFrame *frame = av_frame_alloc();
        qDebug() << "in decode work_thread" ;
        long long loop_count = 0;
        while(!quit_flag){

            if(pause_flag){
                std::cout << "wait to continue decode111 !!!"<< std::endl  << std::flush;
                // pause decode
                while(pause_flag){
                    std::cout << "wait to continue decode!!!" << dec_ctx->codec_type<< std::endl  << std::flush;
                   QThread::usleep(5000);
                   //QCoreApplication::processEvents(QEventLoop::AllEvents,100);
                }
                // flush decoder
                //avcodec_send_packet(dec_ctx, NULL);
                avcodec_flush_buffers(dec_ctx); //清理解码器参考帧缓冲区
                // clear frame queue
                f_q->reinitialize();

            }

            // wait packet
            while(p_q->size() == 0){
               QThread::usleep(20000);

            }

           AVPacket pkt;
           p_q->get(&pkt);
           //qDebug() << "get a avcodec_send_packet dec_ctx->codec_type "<< dec_ctx->codec_type << "pts :" << pkt.pts;
           ret = avcodec_send_packet(dec_ctx, &pkt);
           //qDebug() << "avcodec_send_packet ret" << ret;
           if(ret < 0){
                qDebug() << "avcodec_send_packet error ret" << ret;
                av_packet_unref(&pkt);
                continue;
           }
           av_packet_unref(&pkt);
           // must try to avcodec_receive_frame several times
           while(ret >= 0){
                ret = avcodec_receive_frame(dec_ctx, frame);
                if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF)
                    break;
                else if(ret < 0){
                    qDebug() << "receive frame error!" << ret;
                    continue;
                }
                //qDebug()  << "decoding!!!333333 type "<< dec_ctx->codec_type  << "frame pts" << frame->pts ;
                AVFrame *f = f_q->getFreeFrame();
                if (!f) {
                    qWarning() << "Failed to get free frame, skipping";
                    continue;
                }

                av_frame_move_ref(f, frame);
                f_q->commitFrame(f);


           }

        }
        qDebug() <<"decode real quit  threading!!!!!!!! !!! type" << dec_ctx->codec_type ;
        qDebug() << "WORKER: work_thread ending, dec_ctx:" << dec_ctx;
        if(dec_ctx) {
            qDebug() << "WORKER: work_thread ending - dec_ctx->codec_id:" << dec_ctx->codec_id;
        }
        av_frame_free(&frame);
        qDebug() << "WORKER: About to free codec context:" << dec_ctx;
        avcodec_free_context(&dec_ctx);
        qDebug() << "WORKER: Codec context freed, dec_ctx is now:" << dec_ctx;
        // 不主动清理帧队列，让AVFramePool自己处理析构
        f_q->clear();
}
decode::decode()
{

    for(int i = 0 ; i < AVMEDIA_TYPE_NB ; i++){
        stream_index[i] = -1;
    }
    video_frame_q = new AVFramePool(10);
    audio_frame_q = new AVFramePool(10);
    subtitle_frame_q = new AVFramePool();
    
    // 初始化解码器上下文为nullptr
    video_decCtx = nullptr;
    audio_decCtx = nullptr;
    

    
    // 验证帧缓冲池是否成功创建
    if (!video_frame_q->isValid()) {
        qCritical() << "Failed to create video frame pool";
    }
    if (!audio_frame_q->isValid()) {
        qCritical() << "Failed to create audio frame pool";
    }
    if (!subtitle_frame_q->isValid()) {
        qCritical() << "Failed to create subtitle frame pool";
    }

}

decode::~decode()
{

    
    delete video_frame_q;
    delete audio_frame_q;
    delete subtitle_frame_q;
    

}

enum AVPixelFormat decode::getPixfmt(){
    return video_decCtx->pix_fmt;
}
int decode::openCodec(int *stream_idx,
                      AVCodecContext **dec_ctx, AVFormatContext *fmt_ctx, enum AVMediaType type){


    // to do ,use hardware decoder like qsv / nvdec ..etc                    
    int ret, stream_index;
    AVStream *st;
    AVCodec *dec = NULL;
    AVDictionary *opts = NULL;
    ret = av_find_best_stream(fmt_ctx, type, -1, -1, NULL, 0);
    if (ret < 0) {
        qDebug() <<  "Could not find %s stream in input file ";
        return ret;
    } else {
        stream_index = ret;
        st = fmt_ctx->streams[stream_index];

        /* Allocate a codec context for the decoder */
        *dec_ctx = avcodec_alloc_context3(dec);
        if (!*dec_ctx) {
            fprintf(stderr, "Failed to allocate the %s codec context\n",
                    av_get_media_type_string(type));
            return AVERROR(ENOMEM);
        }

        /* Copy codec parameters from input stream to output codec context */
        if ((ret = avcodec_parameters_to_context(*dec_ctx, st->codecpar)) < 0) {
            fprintf(stderr, "Failed to copy %s codec parameters to decoder context\n",
                    av_get_media_type_string(type));
            return ret;
        }

        /* find decoder for the stream */
        dec = avcodec_find_decoder(st->codecpar->codec_id);
        if (!dec) {
            fprintf(stderr, "Failed to find %s codec\n",
                    av_get_media_type_string(type));
            return AVERROR(EINVAL);
        }

        /* Init the decoders, with or without reference counting */
        av_dict_set(&opts, "refcounted_frames","1", 0);
        if ((ret = avcodec_open2(*dec_ctx, dec, &opts)) < 0) {
            fprintf(stderr, "Failed to open %s codec\n",
                    av_get_media_type_string(type));
            return ret;
        }
        *stream_idx = stream_index;

    }
    return ret;
}
int decode::start(AVFormatContext *fmtCtx){

    //video_frame_q->clear();
    //audio_frame_q->clear();

    int ret ;

    int audioStreamIdx = 0;
    int videoStreamIdx = 0;
    ret = openCodec(&videoStreamIdx,&video_decCtx,fmtCtx,AVMEDIA_TYPE_VIDEO);

    if(ret >= 0){

        video_thread = new QThread;
        videoWorker = new worker(video_packq,video_frame_q,video_decCtx);
        videoWorker->moveToThread(video_thread);

        connect(video_thread, SIGNAL(started()), videoWorker, SLOT(work_thread()));
        connect(this, SIGNAL(quitVideoThread()), videoWorker, SLOT(quit_thread()),Qt::DirectConnection);
        connect(video_thread, SIGNAL(finished()), videoWorker, SLOT(deleteLater()));
        connect(video_thread, SIGNAL(finished()), video_thread, SLOT(deleteLater()));
        connect(this, SIGNAL(pauseVideo()), videoWorker, SLOT(pause_decode()),Qt::DirectConnection);
        connect(this, SIGNAL(continueVideo()), videoWorker, SLOT(continue_decode()),Qt::DirectConnection);
        //connect(this, SIGNAL(quitVideoThread()), video_thread, SLOT(quit()));
        video_thread->start();

    }

    ret = openCodec(&audioStreamIdx,&audio_decCtx,fmtCtx,AVMEDIA_TYPE_AUDIO);

    if(ret >= 0){
        audio_thread = new QThread;
        audioWorker = new worker(audio_packq,audio_frame_q,audio_decCtx);
        audioWorker->moveToThread(audio_thread);

        connect(audio_thread, SIGNAL(started()), audioWorker, SLOT(work_thread()));
        connect(this, SIGNAL(quitAudioThread()), audioWorker, SLOT(quit_thread()),Qt::DirectConnection);
        connect(audio_thread, SIGNAL(finished()), audioWorker, SLOT(deleteLater()));
        connect(audio_thread, SIGNAL(finished()), audio_thread, SLOT(deleteLater()));
        connect(this, SIGNAL(pauseAudio()), audioWorker, SLOT(pause_decode()),Qt::DirectConnection);
        connect(this, SIGNAL(continueAudio()), audioWorker, SLOT(continue_decode()),Qt::DirectConnection);
        //connect(this, SIGNAL(quitAudioThread()), audio_thread, SLOT(quit()));
        audio_thread->start();       
    }

    return ret;
}
void decode::stop(){
    emit quitVideoThread();
    emit quitAudioThread();
    
    // 等待视频解码线程结束
    if(video_thread) {
        video_thread->wait(3000);  // 等待最多3秒
        qDebug() << "Video decode thread terminated";
    }
    
    // 等待音频解码线程结束  
    if(audio_thread) {
        audio_thread->wait(3000);  // 等待最多3秒
        qDebug() << "Audio decode thread terminated";
    }
    
    // 清理frame queue
    if(video_frame_q) {
        video_frame_q->clear();
    }
    if(audio_frame_q) {
        audio_frame_q->clear();
    }

}
void decode::pauseDecode(){
    emit pauseAudio();
    emit pauseVideo();
}
void decode::continueDecode(){
    emit continueAudio();
    emit continueVideo();
}

void decode::reinitCodec(enum AVMediaType type, AVFormatContext *fmtCtx){
    static QMutex reinitMutex;
    QMutexLocker locker(&reinitMutex);
    
    qDebug() << "=== DECODE: reinitCodec START for type:" << type << "===";
    
    int streamIdx = av_find_best_stream(fmtCtx, type, -1, -1, NULL, 0);
    if(streamIdx < 0) {
        qWarning() << "DECODE: No stream found for type" << type;
        return;
    }
    qDebug() << "DECODE: Found stream index:" << streamIdx << "for type:" << type;
    
    AVCodecContext **decCtx = nullptr;
    worker *w = nullptr;
    packetqueue *pq = nullptr;
    AVFramePool *fq = nullptr;
    
    if(type == AVMEDIA_TYPE_VIDEO){
        qDebug() << "DECODE: Pausing video decoder...";
        emit pauseVideo();
        decCtx = &video_decCtx;
        w = videoWorker;
        pq = video_packq;
        fq = video_frame_q;
        
        // 验证音频解码器状态
        qDebug() << "DECODE: Before video reinit - audio_decCtx address:" << audio_decCtx;
        if(audio_decCtx) {
            qDebug() << "DECODE: Before video reinit - audio_decCtx->codec_id:" << audio_decCtx->codec_id;
        }
    } else if(type == AVMEDIA_TYPE_AUDIO){
        qDebug() << "DECODE: Pausing audio decoder...";
        emit pauseAudio();
        decCtx = &audio_decCtx;
        w = audioWorker;
        pq = audio_packq;
        fq = audio_frame_q;
        
        // 验证视频解码器状态
        qDebug() << "DECODE: Before audio reinit - video_decCtx address:" << video_decCtx;
        if(video_decCtx) {
            qDebug() << "DECODE: Before audio reinit - video_decCtx->codec_id:" << video_decCtx->codec_id;
        }
    } else {
        qWarning() << "DECODE: Unknown media type:" << type;
        return;
    }
    
    // 等待工作线程暂停
    qDebug() << "DECODE: Waiting for worker to pause...";
    QThread::msleep(50);
    
    qDebug() << "DECODE: Freeing old codec context...";
    if(*decCtx) {
        qDebug() << "DECODE: Old codec ID was:" << (*decCtx)->codec_id;
        qDebug() << "DECODE: Old codec context address:" << *decCtx;
        avcodec_free_context(decCtx);
        qDebug() << "DECODE: Old codec context freed";
        qDebug() << "DECODE: After free - decCtx address:" << *decCtx;
    }
    
    // 验证另一个解码器是否被影响
    if(type == AVMEDIA_TYPE_VIDEO && audio_decCtx) {
        qDebug() << "DECODE: After video free - audio_decCtx address:" << audio_decCtx;
        qDebug() << "DECODE: After video free - audio_decCtx->codec_id:" << audio_decCtx->codec_id;
    } else if(type == AVMEDIA_TYPE_AUDIO && video_decCtx) {
        qDebug() << "DECODE: After audio free - video_decCtx address:" << video_decCtx;
        qDebug() << "DECODE: After audio free - video_decCtx->codec_id:" << video_decCtx->codec_id;
    }
    
    qDebug() << "DECODE: Opening new codec...";
    int ret = openCodec(&streamIdx, decCtx, fmtCtx, type);
    if(ret < 0) {
        qCritical() << "DECODE: Failed to open codec for type:" << type << "ret:" << ret;
        // 尝试恢复解码器状态
        if(type == AVMEDIA_TYPE_VIDEO){
            emit continueVideo();
        } else {
            emit continueAudio();
        }
        return;
    }
    qDebug() << "DECODE: New codec opened successfully, ID:" << (*decCtx)->codec_id;
    qDebug() << "DECODE: New codec context address:" << *decCtx;
    
    stream_index[type] = streamIdx;
    qDebug() << "DECODE: Stream index updated to:" << streamIdx;
    
    if(w && *decCtx) {
        qDebug() << "DECODE: Updating worker codec context...";
        w->dec_ctx = *decCtx;
        qDebug() << "DECODE: Worker codec context updated";
    }
    
    if(pq) {
        qDebug() << "DECODE: Clearing packet queue...";
        pq->clear();
        qDebug() << "DECODE: Packet queue cleared";
    }
    
    if(fq) {
        qDebug() << "DECODE: Reinitializing frame queue...";
        fq->reinitialize();
        qDebug() << "DECODE: Frame queue reinitialized";
    }
    
    // 验证另一个解码器是否被影响
    if(type == AVMEDIA_TYPE_VIDEO && audio_decCtx) {
        qDebug() << "DECODE: After video reinit - audio_decCtx address:" << audio_decCtx;
        qDebug() << "DECODE: After video reinit - audio_decCtx->codec_id:" << audio_decCtx->codec_id;
    } else if(type == AVMEDIA_TYPE_AUDIO && video_decCtx) {
        qDebug() << "DECODE: After audio reinit - video_decCtx address:" << video_decCtx;
        qDebug() << "DECODE: After audio reinit - video_decCtx->codec_id:" << video_decCtx->codec_id;
    }
    
    // 短暂等待确保所有资源都已准备就绪
    QThread::msleep(30);
    
    if(type == AVMEDIA_TYPE_VIDEO){
        qDebug() << "DECODE: Continuing video decoder...";
        emit continueVideo();
    } else {
        qDebug() << "DECODE: Continuing audio decoder...";
        emit continueAudio();
    }
    
    qDebug() << "=== DECODE: reinitCodec COMPLETED for type:" << type << "===";
}

