#ifndef DECODE_H
#define DECODE_H
extern "C"{
#include <libavformat/avformat.h>
#include <libavcodec/avcodec.h>
#include <libavutil/imgutils.h>
}
#include <QThread>
#include <QQueue>
#include <QDebug>
#include "src/base/framequeue.h"
#include "src/base/packetqueue.h"
class worker:public QObject
{
    Q_OBJECT
public:
    worker(packetqueue *pkt_q, AVFramePool *frame_q,AVCodecContext *dec_Ctx, QString url);
    ~worker();
    AVCodecContext *dec_ctx;
private:
    AVFramePool *f_q;
    packetqueue *p_q;
    
    bool  quit_flag;
    bool  pause_flag;
    QString m_url;
public slots:
    void work_thread();
    void quit_thread();
    void pause_decode();
    void continue_decode();
};

class decode:public QObject
{
    Q_OBJECT
public:
    decode();
    ~decode();
    int start(AVFormatContext *fmtCtx);
    void stop();
    void pauseDecode();
    void continueDecode();
    int openCodec(int *stream_idx,
                  AVCodecContext **dec_ctx, AVFormatContext *fmt_ctx, enum AVMediaType type);
    int decodePacket(AVCodecContext *avctx, AVPacket *packet,AVFrame *frame);
    enum AVPixelFormat getPixfmt();
    uchar* imageCopy(AVFrame *pframe);
    void reinitCodec(enum AVMediaType type, AVFormatContext *fmtCtx);
public slots:
 //   int video_thread();
  //  int audio_thread();
  //  int subtitle_thread();
public:
    AVFramePool *video_frame_q;
    AVFramePool *audio_frame_q;
    AVFramePool *subtitle_frame_q;
    AVCodecContext *video_decCtx;
    AVCodecContext *audio_decCtx;
private:

    QThread* video_thread;
    QThread* audio_thread;
    worker *videoWorker;
    worker *audioWorker;
    int stream_index[AVMEDIA_TYPE_NB];
    QString m_url;
public:
    packetqueue *video_packq;
    packetqueue *audio_packq;
    packetqueue *subtitle_packq;
signals:
    void quitAudioThread();
    void quitVideoThread();
    void pauseAudio();
    void pauseVideo();
    void continueAudio();
    void continueVideo();
};

#endif // DECODE_H
