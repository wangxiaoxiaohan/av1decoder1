#ifndef PANORAMA_MANAGER_H
#define PANORAMA_MANAGER_H

#include <QObject>
#include <QStringList>
#include <QThread>
#include <QDir>

class PanoramaWorker : public QObject
{
    Q_OBJECT
public:
    explicit PanoramaWorker(QObject *parent = nullptr);

public slots:
    void processStitching(const QStringList &imagePaths, const QString &outputPath);
    void processImageMatching(const QString &panoramaPath, const QString &targetPath);

signals:
    void stitchingFinished(bool success, const QString &message, const QString &outputPath);
    void imageMatchingFinished(bool success, int x, int y, int w, int h);
};

class PanoramaManager : public QObject
{
    Q_OBJECT
public:
    static PanoramaManager* instance();
    
    Q_INVOKABLE void stitchImages(const QStringList &imagePaths, const QString &outputPath);
    Q_INVOKABLE void requestImageMatching(const QString &panoramaPath, const QString &targetPath);

signals:
    void stitchingStarted();
    void stitchingFinished(bool success, const QString &message, const QString &outputPath);
    void imageMatchingFinished(bool success, int x, int y, int w, int h);

private:
    explicit PanoramaManager(QObject *parent = nullptr);
    ~PanoramaManager();
    
    static PanoramaManager* m_instance;
    QThread* m_workerThread;
    PanoramaWorker* m_worker;
};

#endif // PANORAMA_MANAGER_H
