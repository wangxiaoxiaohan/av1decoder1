#ifndef EVENTSHARE_H
#define EVENTSHARE_H

#include <QObject>
#include <QString>
#include <QList>
#include <QNetworkAccessManager>
#include <QTimer>
#include <QMap>
#include "alarmlog.h"

class EventShare : public QObject {
    Q_OBJECT

public:
    explicit EventShare(QObject *parent = nullptr);
    static EventShare* instance();

    void reportAlarms(const QList<HwAlarmLogEntry> &alarms, const QString &serverIp, int port);
    void uploadImages(const QStringList &filePaths, const QString &serverIp, int port);
    void uploadVideos(const QStringList &filePaths, const QString &serverIp, int port);
    
    // New methods for specific API endpoints
    void reportAlarms(const QList<HwAlarmLogEntry> &alarms, const QString &serverIp, int port, const QString &authToken);
    void uploadImages(const QStringList &filePaths, const QString &serverIp, int port, const QString &authToken);
    void uploadVideos(const QStringList &filePaths, const QString &serverIp, int port, const QString &authToken);

signals:
    void httpResponse(QString result);

private slots:
    void onReplyFinished(QNetworkReply *reply);

private:
    static EventShare* m_instance;
    QNetworkAccessManager *manager;
    void uploadFiles(const QStringList &filePaths, const QString &url, const QString &authToken);
    QString buildUrl(const QString &serverIp, int port, const QString &endpoint) const;

    QMap<QNetworkReply*, QTimer*> timeoutMap;
};


#endif // EVENTSHARE_H