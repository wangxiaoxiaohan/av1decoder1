/**
 * @file concentration_map.h
 * @brief 高斯烟羽可视化模块
 */

#ifndef CONCENTRATION_MAP_H
#define CONCENTRATION_MAP_H

#include "gaussian_plume.h"
#include <string>
#include <utility>
#include <vector>

namespace GaussianPlumeModel
{

    /**
     * @struct ConcentrationMapParams
     * @brief 浓度分布图参数配置结构体
     */
    struct ConcentrationMapParams
    {
        // 空间范围
        std::pair<float, float> x_range = {300.0f, 800.0f};
        std::pair<float, float> y_range = {-150.0f, 150.0f};
        float z = 0.0f;

        // 网格分辨率
        int nx = 200;
        int ny = 150;

        // 大气稳定性
        std::string stability_class = "D";

        // 不规则性参数
        float irregularity_strength = 0.6f;
        int irregularity_scale = 12;

        // 浓度阈值
        float clip_min_ratio = 1e-4f;
        float visible_min_ratio = 0.3f;
        float visible_quantile = 0.98f; // 负值表示不使用

        // 输出尺寸
        int width_px = 0; // 0表示使用原始尺寸
        int height_px = 0;

        // 多方向气团参数
        int num_directions = 6;
        float direction_spread = 0.7f;
        bool random_rotation = false;
        float rotation_min_angle = 30.0f;
        float rotation_max_angle = 60.0f;
    };

    /**
     * @brief 生成不规则烟雾浓度分布图（主要API接口）
     *
     * 这是主要的对外API接口，用于生成带有不规则烟雾效果的浓度分布热力图。
     *
     * @param plume 高斯烟羽模型对象
     * @param params 参数配置结构体
     */
    std::vector<unsigned char> concentrationMapIrregular(
        const GaussianPlume &plume,
        const ConcentrationMapParams &params = ConcentrationMapParams());
}

#endif // CONCENTRATION_MAP_H