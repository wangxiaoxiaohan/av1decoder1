#include "alarmvideoplayer.h"
#include "model/devicemodel.h"
#include "hikvision_ctrl.h"
#include <QDebug>
#include <QDateTime>
#include <QMutexLocker>
#include <QMetaObject>
#include <QThread>
#include <QTimer>

AlarmVideoPlayer* AlarmVideoPlayer::s_instance = nullptr;

AlarmVideoPlayer* AlarmVideoPlayer::instance()
{
    if (!s_instance) {
        s_instance = new AlarmVideoPlayer();
    }
    return s_instance;
}

AlarmVideoPlayer::AlarmVideoPlayer(QObject *parent)
    : QObject(parent)
    , m_player(nullptr)
    , m_playerThread(nullptr)
    , m_frameProvider(nullptr)
    , m_isPlaying(false)
    , m_playerReady(false)
    , m_hikvisionCtrl(nullptr)
{
    qDebug() << "AlarmVideoPlayer created in thread:" << QThread::currentThreadId();
    
    // 创建FrameProvider用于视频显示
    m_frameProvider = new FrameProvider(this);
    qDebug() << "AlarmVideoPlayer: Created FrameProvider:" << m_frameProvider;
}

AlarmVideoPlayer::~AlarmVideoPlayer()
{
    qDebug() << "AlarmVideoPlayer destructor called";
    
    // 确保彻底断开所有连接
    disconnectPlayerConnections();
    
    // 停止播放并清理
    stopAlarmVideo();
    
    // 清理FrameProvider
    if (m_frameProvider) {
        m_frameProvider->disconnectAll();
        m_frameProvider->clearFrameData();
        m_frameProvider->deleteLater();
        m_frameProvider = nullptr;
    }
    
    qDebug() << "AlarmVideoPlayer destructor completed";
}
void AlarmVideoPlayer::setHikvisionCtrl(HikvisionCtrl* hikvisionCtrl)
{
    m_hikvisionCtrl = hikvisionCtrl;
    qDebug() << "HikvisionCtrl set for AlarmVideoPlayer";
}
void AlarmVideoPlayer::playAlarmVideo(const QString& deviceCode, const QString& alarmTime, bool isInfraredVideo)
{
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "AlarmVideoPlayer::playAlarmVideo called with:"
             << "deviceCode:" << deviceCode
             << "alarmTime:" << alarmTime
             << "isInfrared:" << isInfraredVideo;
    
    // 确保FrameProvider存在并清理旧数据
    if (!m_frameProvider) {
        qWarning() << "FrameProvider is null, recreating...";
        m_frameProvider = new FrameProvider(this);
        qDebug() << "AlarmVideoPlayer: Recreated FrameProvider:" << m_frameProvider;
    } else {
        // 清理FrameProvider中的旧帧数据，保留连接
        qDebug() << "Clearing FrameProvider data before new video";
        m_frameProvider->clearFrameData();
    }
    
    // 保存当前播放参数
    m_currentDeviceCode = deviceCode;
    m_currentAlarmTime = alarmTime;
    m_currentIsInfrared = isInfraredVideo;
    
    // 构建视频URL
    QString videoUrl = buildAlarmVideoUrl(deviceCode, alarmTime, isInfraredVideo);
    if (videoUrl.isEmpty()) {
        qWarning() << "Failed to build video URL for alarm video";
        emit playbackError("无法构建视频地址");
        return;
    }
    
    qDebug() << "Built alarm video URL:" << videoUrl;
    
    // 初始化播放器（仅首次创建）
    initializePlayer();
    
    if (!m_player) {
        qWarning() << "Failed to initialize player";
        emit playbackError("播放器初始化失败");
        return;
    }
    
    if (!m_playerReady) {
        // 首次准备
        QMetaObject::invokeMethod(m_player, "prepare", Qt::QueuedConnection, Q_ARG(QString, videoUrl));
        // 延迟启动播放，等待prepare完成
        QTimer::singleShot(300, [this]() {
            if (m_player) {
                QMetaObject::invokeMethod(m_player, "play", Qt::QueuedConnection);
                qDebug() << "AlarmVideoPlayer: Started playback after initial prepare";
            }
        });
        m_playerReady = true;
    } else {
        // 已准备过，快速切换URL
        QMetaObject::invokeMethod(m_player, "fastSwitchUrl", Qt::QueuedConnection, Q_ARG(QString, videoUrl));
        // 恢复播放（如被暂停）
        QTimer::singleShot(100, [this]() {
            if (m_player) {
                QMetaObject::invokeMethod(m_player, "play", Qt::QueuedConnection);
            }
        });
    }
    
    m_isPlaying = true;
    emit playbackStarted();
    
    qDebug() << "Alarm video playback started";
}

void AlarmVideoPlayer::stopAlarmVideo()
{
    QMutexLocker locker(&m_mutex);
    
    qDebug() << "AlarmVideoPlayer::stopAlarmVideo called -> pause";
    
    if (!m_player) {
        m_isPlaying = false;
        emit playbackStopped();
        return;
    }
    
    // 不销毁播放器，仅暂停
    QMetaObject::invokeMethod(m_player, "pause", Qt::QueuedConnection);
    m_isPlaying = false;
    emit playbackStopped();
}

// 新增：暂停
void AlarmVideoPlayer::pauseAlarmVideo()
{
    QMutexLocker locker(&m_mutex);
    if (!m_player) return;
    qDebug() << "AlarmVideoPlayer::pauseAlarmVideo";
    QMetaObject::invokeMethod(m_player, "pause", Qt::QueuedConnection);
    m_isPlaying = false;
}

// 新增：恢复
void AlarmVideoPlayer::resumeAlarmVideo()
{
    QMutexLocker locker(&m_mutex);
    if (!m_player) return;
    qDebug() << "AlarmVideoPlayer::resumeAlarmVideo";
    QMetaObject::invokeMethod(m_player, "play", Qt::QueuedConnection);
    m_isPlaying = true;
}

// 新增：快速切换URL（外部可直接调用）
void AlarmVideoPlayer::fastSwitchAlarmVideo(const QString& deviceCode, const QString& alarmTime, bool isInfraredVideo)
{
    QMutexLocker locker(&m_mutex);
    if (!m_player) {
        playAlarmVideo(deviceCode, alarmTime, isInfraredVideo);
        return;
    }
    
    m_currentDeviceCode = deviceCode;
    m_currentAlarmTime = alarmTime;
    m_currentIsInfrared = isInfraredVideo;
    
    QString videoUrl = buildAlarmVideoUrl(deviceCode, alarmTime, isInfraredVideo);
    if (videoUrl.isEmpty()) {
        qWarning() << "Failed to build video URL for fast switch";
        emit playbackError("无法构建视频地址");
        return;
    }
    qDebug() << "Fast switching to URL:" << videoUrl;
    QMetaObject::invokeMethod(m_player, "fastSwitchUrl", Qt::QueuedConnection, Q_ARG(QString, videoUrl));
    
    // 确保在URL切换完成后启动播放
    QTimer::singleShot(600, [this]() {
        if (m_player) {
            qDebug() << "AlarmVideoPlayer: Ensuring playback after fast switch";
            QMetaObject::invokeMethod(m_player, "play", Qt::QueuedConnection);
        }
    });
    
    // 延迟发出播放开始信号，确保播放器真正开始播放
    QTimer::singleShot(800, [this]() {
        if (m_isPlaying) {
            qDebug() << "AlarmVideoPlayer: Emitting playbackStarted after fast switch";
            emit playbackStarted();
        }
    });
    
    m_isPlaying = true;
}

bool AlarmVideoPlayer::isPlaying() const
{
    QMutexLocker locker(&m_mutex);
    return m_isPlaying;
}

FrameProvider* AlarmVideoPlayer::getFrameProvider() const
{
    qDebug() << "AlarmVideoPlayer::getFrameProvider called, m_frameProvider:" << m_frameProvider;
    return m_frameProvider;
}

void AlarmVideoPlayer::initializePlayer()
{
    qDebug() << "AlarmVideoPlayer::initializePlayer called";
    
    if (m_player && m_playerThread) {
        qDebug() << "Reusing existing player/thread";
        return;
    }
    
    // 创建播放器线程（仅一次）
    m_playerThread = new QThread();
    m_player = new splayer();
    
    // 将播放器移到子线程
    m_player->moveToThread(m_playerThread);
    
    // 设置线程清理
    connect(m_playerThread, &QThread::finished, m_player, &QObject::deleteLater);
    connect(m_playerThread, &QThread::finished, m_playerThread, &QThread::deleteLater);
    
    // 连接播放器信号
    setupPlayerConnections();
    
    // 启动线程
    m_playerThread->start();
    
    qDebug() << "Player thread started with ID:" << m_playerThread;
}

void AlarmVideoPlayer::cleanupPlayer()
{
    qDebug() << "AlarmVideoPlayer::cleanupPlayer called";
    
    if (m_player) {
        // 确保断开所有连接
        disconnectPlayerConnections();
        
        // 停止播放器
        QMetaObject::invokeMethod(m_player, "stop", Qt::QueuedConnection);
        
        // 等待播放器停止，但不要在同一线程中等待
        if (m_playerThread && m_playerThread->isRunning()) {
            QMetaObject::invokeMethod(m_playerThread, "quit", Qt::QueuedConnection);
        }
        
        m_player = nullptr;
        m_playerThread = nullptr;
        m_playerReady = false;
    }
    
    qDebug() << "Player cleanup completed";
}

QString AlarmVideoPlayer::buildAlarmVideoUrl(const QString& deviceCode, const QString& alarmTime, bool isInfraredVideo)
{
    qDebug() << "Building alarm video URL for device:" << deviceCode;
    
    // 通过deviceCode找到设备信息
    DeviceModel* deviceModel = DeviceModel::instance();
    DeviceInfo deviceInfo = deviceModel->getDevice(deviceCode);
    
    if (deviceInfo.deviceId.isEmpty()) {
        qWarning() << "Device not found:" << deviceCode;
        return QString();
    }
    
    // 获取录像URL基础部分
    QString recordUrlBase = deviceInfo.recordUrlbase;
    if (recordUrlBase.isEmpty()) {
        qWarning() << "Record URL base is empty for device:" << deviceCode;
        return QString();
    }
    
    // 使用HikvisionCtrl查找通道号
    int downloadChannel = -1;
    if (m_hikvisionCtrl) {
        QString nvrIp, nvrUsername, nvrPassword, ipcIp;
        int nvrPort = 8000;
        
        nvrIp = deviceInfo.hikvisionIp;
        nvrUsername = deviceInfo.hikvisionUsername;
        nvrPassword = deviceInfo.hikvisionPassword;
        if (isInfraredVideo) {
            ipcIp = deviceInfo.infraredIp; // 如果是直连IPC，使用相同IP
        } else {
            ipcIp = deviceInfo.visibleLightIp; // 如果是直连IPC，使用相同IP
        }
        
        qDebug() << "Finding channel using HikvisionCtrl for NVR:" << nvrIp << "IPC:" << ipcIp;
        
        // 调用HikvisionCtrl查找通道号
        downloadChannel = m_hikvisionCtrl->findChannelByIP(nvrIp, nvrPort, nvrUsername, nvrPassword, ipcIp);
        
        if (downloadChannel <= 0) {
            qWarning() << "Failed to find channel via HikvisionCtrl, falling back to device config";
            // 如果查找失败，回退到设备配置中的通道号
            downloadChannel = isInfraredVideo ? deviceInfo.infraredDownloadChannel : deviceInfo.visibleLightDownloadChannel;
        } else {
            qDebug() << "Found channel via HikvisionCtrl:" << downloadChannel;
        }
    } else {
        qWarning() << "HikvisionCtrl not available, using device config channel";
        // 如果HikvisionCtrl不可用，使用设备配置中的通道号
        downloadChannel = isInfraredVideo ? deviceInfo.infraredDownloadChannel : deviceInfo.visibleLightDownloadChannel;
    }
    
    // 计算通道追踪号 (tracks后面的通道号)
    int trackChannel;
    if (downloadChannel > 32) {
        // 对于IP通道 (通常>32)
        trackChannel = (downloadChannel - 32) * 100 + 1;
    } else {
        // 对于模拟通道 (通常<=32)
        trackChannel = downloadChannel * 100 + 1;
    }
    
    qDebug() << "Download channel:" << downloadChannel << "Track channel:" << trackChannel;
    
    // 解析报警时间
    QDateTime alarmDateTime = QDateTime::fromString(alarmTime, "yyyy-MM-dd hh:mm:ss");
    if (!alarmDateTime.isValid()) {
        qWarning() << "Invalid alarm time format:" << alarmTime;
        return QString();
    }
    
    // 开始时间比报警时间早5秒
    QDateTime startDateTime = alarmDateTime.addSecs(-5);
    QString formattedStartTime = formatAlarmTime(startDateTime.toString("yyyy-MM-dd hh:mm:ss"));
    if (formattedStartTime.isEmpty()) {
        qWarning() << "Failed to format start time";
        return QString();
    }
    
    // 计算结束时间（报警时间 + 10秒，总共15秒的视频片段）
    QDateTime endDateTime = alarmDateTime.addSecs(10);
    QString formattedEndTime = formatAlarmTime(endDateTime.toString("yyyy-MM-dd hh:mm:ss"));
    
    qDebug() << "Alarm time:" << alarmTime;
    qDebug() << "Start time (alarm - 5s):" << startDateTime.toString("yyyy-MM-dd hh:mm:ss");
    qDebug() << "End time (alarm + 10s):" << endDateTime.toString("yyyy-MM-dd hh:mm:ss");
    
    // 构建完整的URL
    // 格式: recordUrlbase/trackChannel/?starttime=...&endtime=...
    QString videoUrl = QString("%1/%2/?starttime=%3&endtime=%4")
                          .arg(recordUrlBase)
                          .arg(trackChannel)
                          .arg(formattedStartTime)
                          .arg(formattedEndTime);
    
    qDebug() << "Built alarm video URL:" << videoUrl;
    return videoUrl;
}

QString AlarmVideoPlayer::formatAlarmTime(const QString& alarmTime)
{
    // 输入格式: "yyyy-MM-dd hh:mm:ss"
    // 输出格式: "yyyyMMddThhmmssZ"
    
    QDateTime dateTime = QDateTime::fromString(alarmTime, "yyyy-MM-dd hh:mm:ss");
    if (!dateTime.isValid()) {
        qWarning() << "Invalid alarm time format:" << alarmTime;
        return QString();
    }
    
    // 保持本地时间，不转换为UTC
    // 海康威视设备通常使用本地时间进行录像检索
    return dateTime.toString("yyyyMMddThhmmssZ");
}

void AlarmVideoPlayer::setupPlayerConnections()
{
    if (!m_player) {
        return;
    }
    
    // 连接新帧信号到FrameProvider
    connect(m_player, &splayer::newFrameAvailable,
            this, &AlarmVideoPlayer::onPlayerNewFrame,
            Qt::QueuedConnection);
    
    qDebug() << "Player connections established";
}

void AlarmVideoPlayer::disconnectPlayerConnections()
{
    if (!m_player) {
        return;
    }
    
    qDebug() << "AlarmVideoPlayer::disconnectPlayerConnections called";
    
    // 断开播放器与当前对象的所有连接
    disconnect(m_player, &splayer::newFrameAvailable,
               this, &AlarmVideoPlayer::onPlayerNewFrame);
    
    // 也可以使用更彻底的方式断开播放器的所有连接
    // disconnect(m_player, nullptr, this, nullptr);
    
    qDebug() << "Player connections disconnected";
}

void AlarmVideoPlayer::onPlayerNewFrame(const QVideoFrame& frame)
{
    static int frameCount = 0;
    frameCount++;
    
    // 每10帧打印一次，避免日志过多
    if (frameCount % 10 == 1) {
        qDebug() << "AlarmVideoPlayer::onPlayerNewFrame #" << frameCount << "frame:" 
                 << "width=" << frame.width() 
                 << "height=" << frame.height() 
                 << "valid=" << frame.isValid()
                 << "pixelFormat=" << frame.pixelFormat();
    }
    
    // 将新帧传递给FrameProvider显示
    if (m_frameProvider) {
        if (frameCount % 10 == 1) {
            qDebug() << "Forwarding frame to FrameProvider:" << m_frameProvider;
        }
        // 直接调用而不使用QMetaObject::invokeMethod
        m_frameProvider->onNewVideoContentReceived(frame);
    } else {
        qWarning() << "FrameProvider is null, cannot display frame";
    }
}

void AlarmVideoPlayer::handlePlayerError()
{
    qWarning() << "Player error occurred";
    
    QMutexLocker locker(&m_mutex);
    if (m_isPlaying) {
        m_isPlaying = false;
        emit playbackError("播放器发生错误");
        
        // 清理播放器
        locker.unlock();
        cleanupPlayer();
    }
} 