#ifndef PALYER_H
#define PALYER_H

#include <QObject>
#include <QAbstractVideoSurface>
#include <QVideoSurfaceFormat>
#include "src/audiooutput.h"
#include "src/demuxer/demux.h"
#include "src/decoder/decode.h"
#include "player_clock.h"

class audioOutput;
class splayer;
class playThread;
double vp_duration(splayer *is, AVFrame *vp, AVFrame *nextvp);
double compute_target_delay(double delay, splayer *is);

class playThread:public QObject
{
    Q_OBJECT
public:
    playThread(splayer *player,AVMediaType type);
    ~playThread(){}
private:
    AVMediaType mMediaType;
    splayer* mPlayer;
signals:
    void signalShowYuv(uchar *ptr_y,uchar *ptr_u,uchar *ptr_v,uint width, uint height);
public slots:
    void play_loop();
};
enum mediaStatus{
    media_idle = 0,
    media_stopped,
    media_playing,
    media_paused,
    media_seeking,
};

enum {
    AV_SYNC_AUDIO_MASTER, /* default choice */
    AV_SYNC_VIDEO_MASTER,
    AV_SYNC_EXTERNAL_CLOCK, /* synchronize to an external clock */
};

class splayer: public QObject{
    Q_OBJECT
public:
    splayer();
    ~splayer();
    Q_INVOKABLE void play();
    Q_INVOKABLE void pause();
    Q_INVOKABLE void stop();
    Q_INVOKABLE void seek(double precent);
    Q_INVOKABLE void setPlayRate(double speed);
    Q_INVOKABLE double playRate();
    Q_INVOKABLE void prepare(QString file);
    Q_INVOKABLE void reset();
    Q_INVOKABLE void switchUrl(QString newUrl);  // 测试方法：停止当前播放并切换到新URL
    Q_INVOKABLE void fastSwitchUrl(QString newUrl);
    Q_INVOKABLE int startRecording(QString filePath, QString format = "ts");
    Q_INVOKABLE int stopRecording();
    Q_INVOKABLE bool isRecording() const;
    void play_loop();
    enum mediaStatus mediaStatus();
    double get_master_clock();

signals:
    void updateProgress(int current,int total);
    void vSync();
    void newFrameAvailable(const QVideoFrame &);
    
    // 异步信号声明
    void playRequested();
    void pauseRequested();
    void stopRequested();
    void seekRequested(double precent);
    void setPlayRateRequested(double speed);
    void prepareRequested(QString file);
    void resetRequested();
    void switchUrlRequested(QString newUrl);
    void fastSwitchUrlRequested(QString newUrl);
    void startRecordingRequested(QString filePath, QString format);
    void stopRecordingRequested();

private slots:
    // 异步槽函数，实际执行耗时操作
    void doPlay();
    void doPause();
    void doStop();
    void doSeek(double precent);
    void doSetPlayRate(double speed);
    void doPrepare(QString file);
    void doReset();
    void doSwitchUrl(QString newUrl);
    void doFastSwitchUrl(QString newUrl);
    void doStartRecording(QString filePath, QString format);
    void doStopRecording();

private:
    void stopDecoderDemuxer();
    void stopState();
    audioOutput* audioOut;
    demux* demuxer;
    decode* decoder;
    AVFormatContext *fmt_ctx;
    
    Clock audclk;
    Clock vidclk;
    Clock extclk;
    int av_sync_type;

    double frame_timer;
    double max_frame_duration;
    bool is_realtime_stream;

    AVRational audio_timebase;
    AVRational video_timebase;
    enum mediaStatus mMediaStatus;
    QWaitCondition condition;
    QMutex mutex;
   // QThread* demuxThread;
    QThread* audio_th;
    QThread* video_th;

    double playSpeed;
    QString mUrl;
friend class playThread;
friend double vp_duration(splayer *is, AVFrame *vp, AVFrame *nextvp);
friend double compute_target_delay(double delay, splayer *is);

};
#endif
