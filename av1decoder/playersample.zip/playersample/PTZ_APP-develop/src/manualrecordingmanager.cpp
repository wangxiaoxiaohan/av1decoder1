#include "manualrecordingmanager.h"
#include <QDateTime>
#include <QCoreApplication>

ManualRecordingManager* ManualRecordingManager::m_instance = nullptr;

ManualRecordingManager* ManualRecordingManager::instance()
{
    if (!m_instance) {
        m_instance = new ManualRecordingManager();
    }
    return m_instance;
}

ManualRecordingManager::ManualRecordingManager(QObject* parent)
    : QObject(parent)
{
    initDatabase();
}

void ManualRecordingManager::initDatabase()
{
    // 创建数据库目录

    //     QString appDir = QCoreApplication::applicationDirPath();
    // QString configDir = QDir(appDir).absoluteFilePath("config/database");

    QString appPath = QCoreApplication::applicationDirPath();
    QString dbDir = QDir(appPath).absoluteFilePath("config/recordvideo");
    QDir dir;
    if (!dir.exists(dbDir)) {
        dir.mkpath(dbDir);
    }

    // 连接数据库
    QString dbPath = dbDir + "/manual_recordings.db";
    m_db = QSqlDatabase::addDatabase("QSQLITE", "manual_recordings");
    m_db.setDatabaseName(dbPath);

    if (!m_db.open()) {
        qWarning() << "Failed to open manual recordings database:" << m_db.lastError().text();
        return;
    }

    // 创建表结构
    QSqlQuery query(m_db);
    QString createTable = R"(
        CREATE TABLE IF NOT EXISTS ManualRecordings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_code TEXT NOT NULL,
            device_name TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT,
            channel_type TEXT NOT NULL,
            duration_seconds INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    )";

    if (!query.exec(createTable)) {
        qWarning() << "Failed to create ManualRecordings table:" << query.lastError().text();
    }

    // 创建索引
    QString createIndex = "CREATE INDEX IF NOT EXISTS idx_device_code ON ManualRecordings(device_code)";
    query.exec(createIndex);
    createIndex = "CREATE INDEX IF NOT EXISTS idx_start_time ON ManualRecordings(start_time)";
    query.exec(createIndex);
}

QJsonObject ManualRecordingEntry::toJson() const
{
    QJsonObject obj;
    obj["id"] = id;
    obj["device_code"] = device_code;
    obj["device_name"] = device_name;
    obj["start_time"] = start_time;
    obj["end_time"] = end_time;
    obj["channel_type"] = channel_type;
    obj["duration_seconds"] = duration_seconds;
    obj["created_at"] = created_at;
    return obj;
}

ManualRecordingEntry ManualRecordingManager::fromQuery(const QSqlQuery& query)
{
    ManualRecordingEntry entry;
    entry.id = query.value("id").toInt();
    entry.device_code = query.value("device_code").toString();
    entry.device_name = query.value("device_name").toString();
    entry.start_time = query.value("start_time").toString();
    entry.end_time = query.value("end_time").toString();
    entry.channel_type = query.value("channel_type").toString();
    entry.duration_seconds = query.value("duration_seconds").toInt();
    entry.created_at = query.value("created_at").toString();
    return entry;
}

void ManualRecordingManager::startRecording(const QString& deviceCode, const QString& deviceName, const QString& channelType)
{
    // 检查是否已经在录制
    if (isRecording(deviceCode, channelType)) {
        qWarning() << "Recording already started for device:" << deviceCode << "channel:" << channelType;
        return;
    }

    QString startTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    
    QSqlQuery query(m_db);
    query.prepare("INSERT INTO ManualRecordings (device_code, device_name, start_time, channel_type) "
                  "VALUES (:device_code, :device_name, :start_time, :channel_type)");
    query.bindValue(":device_code", deviceCode);
    query.bindValue(":device_name", deviceName);
    query.bindValue(":start_time", startTime);
    query.bindValue(":channel_type", channelType);

    if (query.exec()) {
        qDebug() << "Recording started for device:" << deviceCode << "channel:" << channelType;
        emit recordingStarted(deviceCode, channelType, startTime);
    } else {
        qWarning() << "Failed to start recording:" << query.lastError().text();
    }
}

void ManualRecordingManager::stopRecording(const QString& deviceCode, const QString& channelType)
{
    QString currentStartTime = getCurrentRecordingStartTime(deviceCode, channelType);
    if (currentStartTime.isEmpty()) {
        qWarning() << "No active recording found for device:" << deviceCode << "channel:" << channelType;
        return;
    }

    QString endTime = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    
    // 计算时长（秒）
    QDateTime start = QDateTime::fromString(currentStartTime, "yyyy-MM-dd hh:mm:ss");
    QDateTime end = QDateTime::fromString(endTime, "yyyy-MM-dd hh:mm:ss");
    int duration = start.secsTo(end);

    QSqlQuery query(m_db);
    query.prepare("UPDATE ManualRecordings SET end_time = :end_time, duration_seconds = :duration "
                  "WHERE device_code = :device_code AND channel_type = :channel_type AND end_time IS NULL");
    query.bindValue(":end_time", endTime);
    query.bindValue(":duration", duration);
    query.bindValue(":device_code", deviceCode);
    query.bindValue(":channel_type", channelType);

    if (query.exec() && query.numRowsAffected() > 0) {
        qDebug() << "Recording stopped for device:" << deviceCode << "channel:" << channelType << "duration:" << duration;
        emit recordingStopped(deviceCode, channelType, endTime, duration);
    } else {
        qWarning() << "Failed to stop recording:" << query.lastError().text();
    }
}

bool ManualRecordingManager::isRecording(const QString& deviceCode, const QString& channelType)
{
    return !getCurrentRecordingStartTime(deviceCode, channelType).isEmpty();
}

QString ManualRecordingManager::getCurrentRecordingStartTime(const QString& deviceCode, const QString& channelType)
{
    QSqlQuery query(m_db);
    query.prepare("SELECT start_time FROM ManualRecordings "
                  "WHERE device_code = :device_code AND channel_type = :channel_type AND end_time IS NULL "
                  "ORDER BY start_time DESC LIMIT 1");
    query.bindValue(":device_code", deviceCode);
    query.bindValue(":channel_type", channelType);

    if (query.exec() && query.next()) {
        return query.value("start_time").toString();
    }
    return QString();
}

QVariantMap ManualRecordingManager::getCurrentRecording(const QString& deviceCode, const QString& channelType)
{
    QVariantMap result;
    QString startTime = getCurrentRecordingStartTime(deviceCode, channelType);
    
    if (!startTime.isEmpty()) {
        QSqlQuery query(m_db);
        query.prepare("SELECT * FROM ManualRecordings "
                      "WHERE device_code = :device_code AND channel_type = :channel_type AND start_time = :start_time");
        query.bindValue(":device_code", deviceCode);
        query.bindValue(":channel_type", channelType);
        query.bindValue(":start_time", startTime);

        if (query.exec() && query.next()) {
            ManualRecordingEntry entry = fromQuery(query);
            result = entry.toJson().toVariantMap();
        }
    }
    
    return result;
}

QVariantList ManualRecordingManager::queryRecordings(const QString& deviceCode, const QString& startDate, const QString& endDate)
{
    QVariantList result;
    
    QSqlQuery query(m_db);
    QString sql = "SELECT * FROM ManualRecordings WHERE device_code = :device_code";
    
    if (!startDate.isEmpty()) {
        sql += " AND start_time >= :start_date";
    }
    if (!endDate.isEmpty()) {
        sql += " AND end_time <= :end_date";
    }
    
    sql += " ORDER BY start_time DESC";
    
    query.prepare(sql);
    query.bindValue(":device_code", deviceCode);
    
    if (!startDate.isEmpty()) {
        query.bindValue(":start_date", startDate);
    }
    if (!endDate.isEmpty()) {
        query.bindValue(":end_date", endDate);
    }

    if (query.exec()) {
        while (query.next()) {
            ManualRecordingEntry entry = fromQuery(query);
            result.append(entry.toJson().toVariantMap());
        }
    } else {
        qWarning() << "Failed to query recordings:" << query.lastError().text();
    }
    
    return result;
}

QVariantList ManualRecordingManager::queryRecordingsForDate(const QString& deviceCode, const QDate& date)
{
    QString startDate = date.toString("yyyy-MM-dd");
    QString endDate = date.addDays(1).toString("yyyy-MM-dd");
    
    QVariantList result;
    
    QSqlQuery query(m_db);
    query.prepare("SELECT * FROM ManualRecordings "
                  "WHERE device_code = :device_code "
                  "AND start_time >= :start_date AND start_time < :end_date "
                  "AND end_time IS NOT NULL "
                  "ORDER BY start_time ASC");
    query.bindValue(":device_code", deviceCode);
    query.bindValue(":start_date", startDate);
    query.bindValue(":end_date", endDate);

    if (query.exec()) {
        while (query.next()) {
            ManualRecordingEntry entry = fromQuery(query);
            result.append(entry.toJson().toVariantMap());
        }
    } else {
        qWarning() << "Failed to query recordings for date:" << query.lastError().text();
    }
    
    return result;
}

QVariantMap ManualRecordingManager::getRecordingStats(const QString& deviceCode)
{
    QVariantMap stats;
    
    QSqlQuery query(m_db);
    query.prepare("SELECT COUNT(*) as total_count, "
                  "SUM(CASE WHEN end_time IS NULL THEN 1 ELSE 0 END) as active_count, "
                  "SUM(duration_seconds) as total_duration "
                  "FROM ManualRecordings WHERE device_code = :device_code");
    query.bindValue(":device_code", deviceCode);

    if (query.exec() && query.next()) {
        stats["total_count"] = query.value("total_count").toInt();
        stats["active_count"] = query.value("active_count").toInt();
        stats["total_duration"] = query.value("total_duration").toInt();
    }
    
    return stats;
}

bool ManualRecordingManager::deleteRecording(int id)
{
    QSqlQuery query(m_db);
    query.prepare("DELETE FROM ManualRecordings WHERE id = :id");
    query.bindValue(":id", id);

    if (query.exec() && query.numRowsAffected() > 0) {
        emit recordingDeleted();
        return true;
    }
    return false;
}

bool ManualRecordingManager::deleteAllRecordings(const QString& deviceCode)
{
    QSqlQuery query(m_db);
    QString sql = "DELETE FROM ManualRecordings";
    
    if (!deviceCode.isEmpty()) {
        sql += " WHERE device_code = :device_code";
        query.prepare(sql);
        query.bindValue(":device_code", deviceCode);
    } else {
        query.prepare(sql);
    }

    if (query.exec() && query.numRowsAffected() > 0) {
        emit recordingDeleted();
        return true;
    }
    return false;
}