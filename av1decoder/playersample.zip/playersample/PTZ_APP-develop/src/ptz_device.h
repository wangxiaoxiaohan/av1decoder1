//
// Created by Chian on 10/29/2024.
//

#ifndef PTZ_APP_PTZ_DEVICE_H
#define PTZ_APP_PTZ_DEVICE_H

#include <string>
#include <QDebug>
#include "rtsp_decode.h"
#include "net_work_ctrl.h"
#include "interact_cmd.pb.h"
#include <google/protobuf/util/json_util.h>

using namespace std;

enum LenControlEtype{
    LEN_CONTROL_ZOOM,
    LEN_CONTROL_FOCUS,
    LEN_CONTROL_APERTURE
};

enum AccessoryControlEtype{
    ACCESSORYCONTROL_LIGHT,
    ACCESSORYCONTROL_WIPER,
    ACCESSORYCONTROL_ASSIFOCUS,
    ACCESSORYCONTROL_INF_FLAP
};

class PtzDevice : public QObject{
Q_OBJECT
public:
    explicit PtzDevice(QObject* parent = nullptr);
    ~PtzDevice();

    void mvSetDeviceId(string var){  
        device_id_ = var;
    }

    string msGetDeviceId(){
        return device_id_;
    }

    void mvSetDeviceName(string var){
        deviceName_ = var;
    }
    string msGetDeviceName(){
        return deviceName_;
    }

    void mvSetWhiteVideoUrl(string var){
        white_video_url_ = var;
    }

    void mvSetInfVideoUrl(string var){
        inf_video_url_ = var;
    }

    std::string msGetWhiteVideoUrl(){
        return white_video_url_;
    }

    std::string msGetInfVideoUrl(){
        return inf_video_url_;
    }

    bool mbInitVideo();

    void mvTest(){
        qDebug() << "test";
    }

    void mvSetRotation(int dr, int speed);
    void mvSetZoomIn(int val);
    void mvSetFocus(int val);
    void mvSetAperture(int val);

    void mvSetLight(bool val);
    void mvSetWiper(bool val);
    void mvSetAssiFocus(bool val);
    void mvSetInfFlap(bool val);

    LensControl mobGenLenControl(float val, LenControlEtype type);
    AccessoryControl mobGenAccessoryControl(bool val, AccessoryControlEtype type);
    void mvModifyInfraredImageSettings(int bright, int contrac, int denoise, int intens, bool detail_e, bool edg_e, bool strip_filer);
    void mvModifyImageSettings(int bright, int contrac, int saturation, int sharpness, ImageSettings::CaptureType type, Resolution image_size, ImageSettings::ImageQuality img_quality);
    void mvModifyExposureSettings(ExposureSettings::ExposureMode exp_mode, int exp_time);
    void mvModifyDayNightSwitchSettings(DayNightSwitchSettings::Mode mode, string start, string end);
    void mvModifyWhiteBalanceSettings(WhiteBalanceSettings::WhiteBalanceMode mode, int red_gain, int blue_gain);
    void mvModifyImageEnhancement(bool noise_enable, int noise_level, bool fog_enable, bool stabilization, int gray);
    void mvModifyVideoAdjustment(VideoAdjustment::MirrorSetting mirro, VideoAdjustment::StabilizationSetting stab);
    void mvModifyWhideDynamicRange(WideDynamicRange::WideDynamicMode mode, int lv, bool suppress);

    void mvModifyChnTitle(bool enable, QString chn_name);
    void mvModifyTimeStyle(bool enable, bool week_enable, OSDSettings::TimeFormat time_style, OSDSettings::DateFormat date_style);
    void mvModifyPtzInfo(bool preposition, bool zoom_ratio, bool cruisescan, bool trackingscan, bool linescan);
    void mvModifyOverlapString(bool enable_1, QString str_1, bool enable_2, QString str_2, bool enable_3, QString str_3, bool enable_4, QString str_4);
    void mvModifyFontProperty(OSDSettings::Size font_size, OSDSettings::Color font_color, OSDSettings::Alignment font_alig);

    void mvModifyLocalNetworkProperty(bool static_ip, QString ip4_ip, QString ip4_mask, QString ip4_gateway, QString ip6_ip, QString ip6_prefix, QString ip6_gateway, QString pre_dns, QString dns);

    void mvApplyOsdSettings();
    void mvApplyNetWorkSettings();

    MediaSettings mobGenMediaSettings();
    void mvSendCmd(LensControl lencmd);
    void mvSendCmd(AccessoryControl lencmd);
    void mvSendCmd(MediaSettings media_para);
    void mvSendCmd(InfraredImageSettings inf_para);
private:
    std::string deviceName_;
    std::string device_id_;
    std::string white_video_url_;
    std::string inf_video_url_;
    std::string topic_;
    RrspDecode white_video_decode_;
    RrspDecode inf_video_decode_;
    MediaSettings media_settings_;
    InfraredImageSettings infrared_img_settings_;

    ImageSettings img_adj_;
    ExposureSettings exposure_setting_;
    WideDynamicRange wide_dynamic_range_;
    DayNightSwitchSettings day_night_swhitch_setting_;
    WhiteBalanceSettings white_balance_setting_;
    ImageEnhancement img_enhance_;
    VideoAdjustment video_adj_;
    OSDSettings osd_settings_;
    IPSettings ip_settings_;

    bool light_;         // 补光灯开关
    bool wiper_;         // 雨刷开关
    bool assifocus_;         // 辅助聚焦开关
    bool inf_flap_;         // 红外挡板

    int speed_;         // 红外挡板

    float zoom_level_;   // 变倍级别
    float focus_;        // 焦距
    float aperture_;     // 光圈
};

#endif //PTZ_APP_PTZ_DEVICE_H
